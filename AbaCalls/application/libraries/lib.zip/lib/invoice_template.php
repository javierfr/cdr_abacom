<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Invoice_Template {

    public $i_invoice_template;
    public $i_customer;
    public $name;
    public $description;
    public $template;
    public $template_css;
    public $pdf_preview;
    public $is_system;

    private $_fault;
    private $converter_options;

    function __construct($i_customer, $i_invoice_template = NULL) {
        $this->i_invoice_template = $i_invoice_template;
        $this->i_customer = $i_customer;
        $this->name = NULL;
        $this->description = '';
        $this->template = '';
        $this->template_css = '';
        $this->pdf_preview = '';
        $this->is_system = FALSE;

        $this->_fault = FALSE;
        $this->converter_options = '';

        if ($this->i_invoice_template !== NULL) {
            $this->getEntry($this->i_invoice_template);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_invoice_template) {
        global $db;

        $sql = 'SELECT it.i_invoice_template, it.name, it.description,
                       it.template, it.template_css, it.is_system,
                       it.converter_options
                  FROM invoice_templates it
                 WHERE it.i_invoice_template = ?
                       AND (it.i_customer = ? OR it.is_system)
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($i_invoice_template, $this->i_customer));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_invoice_template = $entry['i_invoice_template'];
        $this->name = $entry['name'];
        $this->description = $entry['description'];
        $this->template = base64_decode($entry['template']);
        $this->template_css = base64_decode($entry['template_css']);
        $this->is_system = Cast::str2bool($entry['is_system']);
        $this->converter_options = $entry['converter_options'];
    }

    public function initFromRequest($par) {
        $this->name = $par['it_name'];
        $this->description = $par['description'];
        $this->template = $par['template'];
        $this->template_css = $par['template_css'];
    }

    public function genID() {
        global $db;

        return $db->nextID('invoice_templates_seq');
    }

    public function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('name') != '') {
            $ret['sql'] .= ' AND it.name ' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('name');
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(it.*)
                   FROM invoice_templates it
                  WHERE it.i_customer = ?
                        {$clause['sql']}";
        $params = array_merge(Array($this->i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT it.i_invoice_template AS i_invoice_template, it.name AS name,
                       it.description AS description, it.is_system AS is_system
                  FROM invoice_templates it
                 WHERE it.i_customer = ?
                       {$clause['sql']}
              ORDER BY it.is_system DESC, it.name
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($this->i_customer), $clause['params']);

        $ret = $db->getAll($sql, $params);

        foreach(array_keys($ret) as $key) {
            $ret[$key]['is_system'] = Cast::str2bool($ret[$key]['is_system']);
        }

        return $ret;
    }

    private function doesNameExist($name, $i_invoice_template = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM invoice_templates it
                 WHERE it.i_customer = ? AND it.name ILIKE ? AND i_invoice_template <> ?';
        $params = Array($this->i_customer, $name, $i_invoice_template);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $form_as_add = FALSE) {
        if ($this->is_system) {
            throw new Exception(_('Cannot update Invoice Template. Cannot update system entry.'));
        }

        if ($form_as_add) {
            if ($this->doesNameExist($par['it_name'])) {
                throw new Exception(_('Cannot add Invoice Template. Another Invoice Template with conflicting "Name" already exists.'));
            }
        } else {
            if ($this->doesNameExist($par['it_name'], $par['i_invoice_template'])) {
                throw new Exception(_('Cannot update Invoice Template. Another Invoice Template with conflicting "Name" already exists.'));
            }
        }

        if ($par['it_name'] == '') {
            throw new Exception(_('"Name" field is mandatory.'));
        }

        $params = Array(new xmlrpcval(Array(
            "i_customer" => new xmlrpcval($this->i_customer, "int"),
            "template" => new xmlrpcval(base64_encode(html_entity_decode($par['template'], ENT_COMPAT, 'UTF-8')), "string"),
            "template_css" => new xmlrpcval(base64_encode($par['template_css']), "string"),
            "converter_options" => new xmlrpcval($this->converter_options, "string"),
        ), 'struct'));

        $msg = new xmlrpcmsg('validateInvoiceTemplate', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            error_log('Unable to generate test invoice: ' . htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            throw new Exception(_('Wrong Invoice Template parameters.'));
        }

    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, TRUE);

        $i_invoice_template = $this->genID();

        $sql = 'INSERT INTO invoice_templates (i_invoice_template, i_customer, name, description,
                                               template, template_css)
                     VALUES (?, ?, ?, ?, ?, ?)';
        $params = Array($i_invoice_template, $this->i_customer, $par['it_name'], $par['description'],
                        base64_encode(html_entity_decode($par['template'], ENT_COMPAT, 'UTF-8')),
                        base64_encode($par['template_css']));

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Invoice Template."));
        }

        Audit_Logger::write('A', sprintf('invoice_templates:i_invoice_template=%d', $i_invoice_template));

        $this->getEntry($i_invoice_template);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $sql = 'UPDATE invoice_templates
                   SET name = ?, description = ?, template = ?, template_css = ?
                 WHERE i_customer = ? AND i_invoice_template = ?';
        $params = Array($par['it_name'], $par['description'],
                        base64_encode(html_entity_decode($par['template'], ENT_COMPAT, 'UTF-8')),
                        base64_encode($par['template_css']),
                        $this->i_customer, $this->i_invoice_template);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Invoice Template."));
        }

        Audit_Logger::write('U', sprintf('invoice_templates:i_invoice_template=%d', $this->i_invoice_template));

        $this->getEntry($par['i_invoice_template']);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        if ($this->is_system) {
            throw new Exception(_("Cannot delete Invoice Template. Cannot delete system entry."));
        }

        $sql = 'DELETE FROM invoice_templates
                 WHERE i_customer = ? AND i_invoice_template = ?';
        $params = Array($this->i_customer, $this->i_invoice_template);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Invoice Template."));
        }

        Audit_Logger::write('D', sprintf('invoice_templates:i_invoice_template=%d', $this->i_invoice_template));
    }

    public function duplicate($par) {
        $this->i_invoice_template = NULL;
        $this->name = $par['it_name'];
        $this->is_system = FALSE;
    }

    public function generate_pdf_preview($par) {
        $params = Array(new xmlrpcval(Array(
            "i_customer" => new xmlrpcval($this->i_customer, "int"),
            "template" => new xmlrpcval(base64_encode(html_entity_decode($par['template'], ENT_COMPAT, 'UTF-8')), "string"),
            "template_css" => new xmlrpcval(base64_encode($par['template_css']), "string"),
            "converter_options" => new xmlrpcval($this->converter_options, "string"),
            "return_pdf" => new xmlrpcval(TRUE, "boolean"),
        ), 'struct'));

        $msg = new xmlrpcmsg('validateInvoiceTemplate', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->pdf_preview = base64_decode($res->val['pdf']);
    }
}

?>
