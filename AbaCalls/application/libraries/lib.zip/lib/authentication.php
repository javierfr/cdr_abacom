<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Authentication {

    public $i_customer;
    public $i_authentication;
    public $i_account;
    public $remote_ip;
    public $incoming_cli;
    public $incoming_cld;
    public $cli_translation_rule;
    public $cld_translation_rule;
    public $i_protocol;
    public $i_tariff;
    public $i_routing_group;

    private $_fault;

    function __construct($i_customer, $i_authentication = NULL) {
        $this->i_customer = $i_customer;
        $this->i_authentication = $i_authentication;
        $this->i_account = NULL;
        $this->remote_ip = '';
        $this->incoming_cli = '';
        $this->incoming_cld = '';
        $this->cli_translation_rule = '';
        $this->cld_translation_rule = '';
        $this->i_protocol = 1;
        $this->i_tariff = NULL;
        $this->i_routing_group = NULL;

        $this->_fault = FALSE;

        if ($this->i_authentication !== NULL) {
            $this->getEntry($this->i_authentication);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_authentication) {
        global $db;

        $sql = "SELECT au.*
                  FROM authentications au
                  JOIN accounts a USING (i_account)
                  JOIN customers c ON (a.i_customer = c.i_customer)
                 WHERE au.i_authentication = ? AND c.i_customer = ?
                 LIMIT 1";
        $params = Array($i_authentication, $this->i_customer);
        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception(_("No such Id."));
        }

        $this->i_authentication = $i_authentication;
        $this->i_account = $entry['i_account'];
        $this->remote_ip = $entry['remote_ip'];
        $this->incoming_cli = $entry['incoming_cli'];
        $this->incoming_cld = $entry['incoming_cld'];
        $this->cli_translation_rule = $entry['cli_translation_rule'];
        $this->cld_translation_rule = $entry['cld_translation_rule'];
        $this->i_protocol = $entry['i_protocol'];
        $this->i_tariff = $entry['i_tariff'];
        $this->i_routing_group = $entry['i_routing_group'];
    }

    public function initFromRequest($par) {
        $this->i_account = $par['i_account'];
        $this->remote_ip = $par['remote_ip'];
        $this->incoming_cli = $par['incoming_cli'];
        $this->incoming_cld = $par['incoming_cld'];
        $this->cli_translation_rule = $par['cli_translation_rule'];
        $this->cld_translation_rule = $par['cld_translation_rule'];
        $this->i_protocol = $par['i_protocol'];
        $this->i_tariff = $par['i_tariff'];
        $this->i_routing_group = $par['i_routing_group'];
    }

    public function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('i_account') != '') {
            $ret['sql'] .= ' AND a.i_account = ?';
            $ret['params'][] = get_par('i_account');
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(au.*)
                  FROM authentications au
                  JOIN accounts a USING (i_account)
                  JOIN customers c ON (a.i_customer = c.i_customer)
                 WHERE c.i_customer = ?
                       {$clause['sql']}";

        $params = Array($this->i_customer);
        $params = array_merge($params, $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT au.*
                  FROM authentications au
                  JOIN accounts a USING (i_account)
                  JOIN customers c ON (a.i_customer = c.i_customer)
                 WHERE c.i_customer = ?
                       {$clause['sql']}
              ORDER BY au.i_authentication
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = Array($this->i_customer);
        $params = array_merge($params, $clause['params']);

        $ret = $db->getAll($sql, $params);

        return $ret;
    }

    public function getExportQuery() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT au.*
                  FROM authentications au
                  JOIN accounts a USING (i_account)
                  JOIN customers c ON (a.i_customer = c.i_customer)
                 WHERE c.i_customer = ?
                       {$clause['sql']}
              ORDER BY au.i_authentication";

        $params = Array($this->i_customer);
        $params = array_merge($params, $clause['params']);

        return Array($sql, $params);
    }

    public function add($par) {
        $this->setFault(TRUE);

        $params = Array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'i_account' => new xmlrpcval($par['i_account'], "int"),
            'remote_ip' => new xmlrpcval($par['remote_ip'], "string"),
            'incoming_cli' => new xmlrpcval($par['incoming_cli'], "string"),
            'incoming_cld' => new xmlrpcval($par['incoming_cld'], "string"),
            'cli_translation_rule' => new xmlrpcval($par['cli_translation_rule'], "string"),
            'cld_translation_rule' => new xmlrpcval($par['cld_translation_rule'], "string"),
            'i_protocol' => new xmlrpcval($par['i_protocol'], "int"),
            'i_tariff' => new xmlrpcval($par['i_tariff'], $par['i_tariff'] > 0 ? 'int' : 'null'),
            'i_routing_group' => new xmlrpcval($par['i_routing_group'], $par['i_routing_group'] > 0 ? 'int' : 'null'),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
        );

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('addAuthRule', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $i_authentication = $res->val['i_authentication'];

        $this->getEntry($i_authentication);

        $this->setFault(FALSE);
    }

    public function update($par) {
        $this->setFault(TRUE);

        $params = array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'i_authentication' => new xmlrpcval($par['i_authentication'], "int"),
            'i_account' => new xmlrpcval($par['i_account'], "int"),
            'remote_ip' => new xmlrpcval($par['remote_ip'], "string"),
            'incoming_cli' => new xmlrpcval($par['incoming_cli'], "string"),
            'incoming_cld' => new xmlrpcval($par['incoming_cld'], "string"),
            'cli_translation_rule' => new xmlrpcval($par['cli_translation_rule'], "string"),
            'cld_translation_rule' => new xmlrpcval($par['cld_translation_rule'], "string"),
            'i_protocol' => new xmlrpcval($par['i_protocol'], "int"),
            'i_tariff' => new xmlrpcval($par['i_tariff'], $par['i_tariff'] > 0 ? 'int' : 'null'),
            'i_routing_group' => new xmlrpcval($par['i_routing_group'], $par['i_routing_group'] > 0 ? 'int' : 'null'),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
        );

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('updateAuthRule', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->getEntry($par['i_authentication']);

        $this->setFault(FALSE);
    }


    public function delete($par) {
        $params = array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'i_authentication' =>  new xmlrpcval($par['i_authentication'], "int"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
        );

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('delAuthRule', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }
    }

}

class Account_Authentication {

    public static function proto2str($rule) {
        switch ($rule) {
            case '1':
                return 'SIP';
                break;

            case '2':
                return 'H.323';
                break;

            case '3':
                return 'IAX';
                break;

            case '4':
                return 'Calling Card PIN';
                break;

            default:
                return 'Unknown';
        }
    }

    public static function rule2str($rule) {
        return self::proto2str($rule['i_protocol'])
                . '/' . $rule['remote_ip']
                . '/' . $rule['incoming_cli']
                . '/' . $rule['incoming_cld'];
    }

    public static function getRulesWithTariff($i_account) {
        global $db;

        $rules = Array();

        /***/
        $sql = "SELECT t.i_tariff
                  FROM tariffs t
                 WHERE t.i_tariff = get_account_i_tariff(?)
                 LIMIT 1";
        $params = Array($i_account);
        $default_tariff = $db->getValue($sql, $params);

        $rules[] = Array('i_authentication' => 0,
                         'i_tariff' => $default_tariff,
                         'name' => 'Default');

        /***/
        $sql = "SELECT au.i_authentication, au.i_protocol, au.remote_ip,
                       au.incoming_cli, au.incoming_cld, au.i_tariff
                  FROM authentications au
                 WHERE au.i_account = ? AND au.i_tariff <> ?
              ORDER BY 2, 3, 4, 5";
        $params = Array($i_account, $default_tariff);
        $ret = $db->getAll($sql, $params);

        foreach ($ret as $row) {
            $rules[] = Array('i_authentication' => $row['i_authentication'],
                             'i_tariff' => $row['i_tariff'],
                             'name' => self::rule2str($row));
        }

        /***/
        return $rules;
    }

}
?>
