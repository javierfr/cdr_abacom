<?php

// Copyright (c) 2003-2005 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

function get_description($prefix) {
    global $prefixes;

    $data = Array('Unknown', '', '');

    for ($i = strlen("$prefix"); $i > 0; $i--) {
        $p = substr("$prefix", 0, $i);
        if ($prefixes["$p"] != '') {
            $data = $prefixes["$p"];
            break;
        }
    }

    return $data;
}

function get_area_name($prefix, $area_name) {
    if ($area_name != '') {
        return $area_name;
    }

    if ($prefix == '') {
        return NULL;
    }

    list(,,$area_name) = get_description($prefix);

    return $area_name == '' ? NULL : $area_name;
}

function load_prefixes() {
    global $db;
    global $prefixes;

    $sql = "SELECT prefix, destinations.description, name, area_name
              FROM destinations, countries
             WHERE countries.iso = destinations.country_iso
          ORDER BY prefix DESC, LENGTH(prefix) DESC";
    $rows = $db->getAll($sql);

    foreach ($rows as $p) {
        $prefixes["${p['prefix']}"] = Array("${p['name']}", "${p['description']}", "${p['area_name']}");
    }
}

function get_balance() {
    global $db, $smarty;
    global $base_c;

    $uid = $_SESSION['uid'];
    $account_type = $_SESSION['account_type'];

    switch ($account_type) {
        case 'customer':
            $sql="SELECT i_balance, base_currency FROM customers WHERE i_customer = ?";
            list($i_balance, $base_c) = $db->getRow($sql, Array($uid));

            /* fetch balance */
            $params = Array("i_customer" => new xmlrpcval(1, "int"),
                            "i_balance" => new xmlrpcval($i_balance, "int"),
                           );
            $bal_clnt = new Balanced_Client('getBalanceInfo', $params);
            $ret = $bal_clnt->get();
            $balance = $ret['balance_info']['balance'];

            $smarty->assign('base_c', $base_c);
            $_SESSION['balance'] = $balance;

            /* * */
            $params = Array("i_customer" => new xmlrpcval($uid, "int"),
                           );
            $bal_clnt = new Balanced_Client('getAccountsBalancesTotal', $params);
            $balance_info = $bal_clnt->get();
            $_SESSION['accounts_balance'] = $balance_info['balances_total'];

            /* * */
            $params = Array("i_wholesaler" => new xmlrpcval($uid, "int"),
                           );
            $bal_clnt = new Balanced_Client('getCustomersBalancesTotal', $params);
            $balance_info = $bal_clnt->get();
            $_SESSION['subcustomers_balance'] = $balance_info['balances_total'];

            break;

        case 'vendor':
            $sql = "SELECT i_balance, base_currency
                      FROM vendors
                     WHERE i_vendor = ?";
            list($i_balance, $base_c) = $db->getRow($sql, Array($uid));

            /* fetch balance */
            $params = Array("i_customer" => new xmlrpcval(1, "int"),
                            "i_balance" => new xmlrpcval($i_balance, "int"),
                           );
            $bal_clnt = new Balanced_Client('getBalanceInfo', $params);
            $ret = $bal_clnt->get();
            $balance = $ret['balance_info']['balance'];

            $smarty->assign('base_c', $base_c);
            $_SESSION['balance'] = $balance;

            break;

        case 'account':
        default:
            $sql = "SELECT i_balance, base_currency
                      FROM accounts
                     WHERE i_account = ?";
            list($i_balance, $base_c) = $db->getRow($sql, Array($uid));

            /* fetch balance */
            $params = Array("i_customer" => new xmlrpcval(1, "int"),
                            "i_balance" => new xmlrpcval($i_balance, "int"),
                           );
            $bal_clnt = new Balanced_Client('getBalanceInfo', $params);
            $ret = $bal_clnt->get();
            $balance = $ret['balance_info']['balance'];

            $smarty->assign('base_c', $base_c);
            $_SESSION['balance'] = $balance;

            break;
    }
}

function set_title_text() {
    global $db;
    $_SESSION['title_text'] = $db->getValue("SELECT title_text FROM system LIMIT 1");
}

function set_is_callshop_available() {
    global $db;

    $res = $db->getValue('SELECT callshop_enabled
                            FROM customers
                           WHERE i_customer = ?',
                         Array($_SESSION['uid']));
    $_SESSION['is_callshop_available'] = Cast::str2bool($res);
}

function set_conferencing_enabled() {
    global $db;
    global $web_session;

    if ($_SESSION['account_type'] == 'account') {
        $_SESSION['conferencing_enabled'] = $_SESSION['conferencing_enabled'] &&
                                            is_module_installed('conferencing') &&
                                            check_account_class_acl('conferencing_enabled', $_SESSION['uid']);
        // check if customer owner has defined conference
        if ($_SESSION['conferencing_enabled']) {
            $sql = 'SELECT COUNT(*)
                      FROM ivr_applications ia
                      JOIN dids USING (i_ivr_application)
                     WHERE ia.i_customer = ? AND ia.type = 5';
            $params = Array($web_session->user_info['i_customer']);
            if ($db->getValue($sql, $params) < 1) {
                $_SESSION['conferencing_enabled'] = FALSE;
            }
        }
    } else {
        $_SESSION['conferencing_enabled'] = $_SESSION['conferencing_enabled'] &&
                                            is_module_installed('conferencing');
    }
}

function set_is_web_phone_available() {

    $_SESSION['is_web_phone_available'] = 0;
    if ($_SESSION['account_type'] == 'account') {
        if (is_module_installed('web_phone') &&  check_account_class_acl('webphone_enabled', $_SESSION['uid'])) {
            $_SESSION['is_web_phone_available'] = 1;
        }    
    } else {
        if (is_module_installed('web_phone')) {
            $_SESSION['is_web_phone_available'] = 1;
        }
    }
}

function set_is_commissions_menu_available() {
    global $db;

    $uid = $_SESSION['uid'];

    $sql = "SELECT (SELECT COUNT(i_commission_agent)
                      FROM customers
                     WHERE i_commission_agent = ?) +
                   (SELECT COUNT(i_commission_agent)
                      FROM accounts
                     WHERE i_commission_agent = ?)";

    $_SESSION['is_commissions_menu_available'] = $db->getValue($sql, Array($uid, $uid));
};

function set_is_vouchers_menu_available() {
    global $db;
    $uid = $_SESSION['uid'];

    $_SESSION['is_vouchers_menu_available'] = 0;
    if ($_SESSION['account_type'] == 'customer') {
        if (!can_add($_SESSION['vouchers_mgmt'])) {
            $c = $db->getValue("SELECT COUNT(*) FROM vouchers WHERE i_customer = ?", Array($uid));
            if ($c > 0) {
                $_SESSION['is_vouchers_menu_available'] = 1;
            }
        } else {
            $_SESSION['is_vouchers_menu_available'] = 1;
        }
    }
};

function set_is_accounts_menu_available() {
    global $db;
    $uid = $_SESSION['uid'];

    $_SESSION['is_accounts_menu_available'] = 0;
    if ($_SESSION['account_type'] == 'customer') {
        if (!can_add($_SESSION['accounts_mgmt'])) {
            $c = $db->getValue("SELECT COUNT(*) FROM accounts WHERE i_customer = ?", Array($uid));
            if ($c > 0) {
                        $_SESSION['is_accounts_menu_available'] = 1;
            }
        } else {
            $_SESSION['is_accounts_menu_available'] = 1;
        }
    }
};

function set_is_tariffs_menu_available() {
    global $db;
    global $web_session;

    $uid = $_SESSION['uid'];

    $_SESSION['is_tariffs_menu_available'] = 0;
    if ($_SESSION['account_type'] == 'customer') {
        try {
            $access_level = new Access_Level($web_session->user_info['i_access_level'], 'TARIFFS');
        } catch (Exception $e) {
            /* ignore errors */
        }

        if (!can_add($_SESSION['tariffs_mgmt']) ||
            (!is_null($access_level) && !$access_level->can_add())
           ) {
            $c = $db->getValue("SELECT COUNT(*) FROM tariffs WHERE i_owner = ?", Array($uid));
            if ($c > 0) {
                $_SESSION['is_tariffs_menu_available'] = 1;
            }
        } else {
            $_SESSION['is_tariffs_menu_available'] = 1;
        }
    }
};

function set_is_customers_menu_available() {
    global $db;
    $uid = $_SESSION['uid'];

    $_SESSION['is_customers_menu_available'] = 0;
    if ($_SESSION['account_type'] == 'customer') {
        $c = $db->getValue("SELECT COUNT(*) FROM customers WHERE i_wholesaler = ? AND i_customer <> i_wholesaler", Array($uid));
        if (!can_add($_SESSION['customers_mgmt'])) {
            if ($c > 0) {
                $_SESSION['is_customers_menu_available'] = 1;
            }
        } else {
            $_SESSION['is_customers_menu_available'] = 1;
        }

        $max_depth = $db->getValue("SELECT max_depth FROM customers WHERE i_customer = ?", Array($uid));

        $_SESSION['is_permissions_menu_available'] = ($c > 0 && $max_depth > 0);

        if ($max_depth == 0) {
            $_SESSION['is_customers_menu_available'] = 0;
        }
    }
};

function set_is_sysinfo_available() {
    $env_info = get_own_env_info();
    $_SESSION['is_sysinfo_available'] = Cast::str2bool($env_info['enable_sysinfo']);
}

function set_is_payment_available() {
    global $db;
    $username = $_SESSION["username"];

    $_SESSION['is_payment_available'] = 0;

    $account_type = $_SESSION['account_type'];

    /* does customer's owner have appropriate payment processor */
    if ($account_type == 'customer') {
        $sql= "SELECT COUNT(*)
                 FROM customers c
                 JOIN payment_processors p ON (c.i_wholesaler = p.i_customer AND c.payment_currency = p.iso_4217)
                 JOIN web_users wu ON (wu.i_customer = c.i_customer AND wu.default_user)
                 JOIN merchant_types m ON (get_pp_i_merchant(p.i_payment_processor) = m.i_merchant
                                           AND substr(m.capabilities, 4, 1) <> 'Y')
                WHERE wu.web_login = ?";
        $_SESSION['is_payment_available'] = $db->getValue($sql, Array($username)) > 0 ? 1 : 0;
    };


    /* does account's owner have appropriate payment processor */
    if ($account_type == 'account') {
        $sql= "SELECT COUNT(*)
                 FROM accounts a
                 JOIN payment_processors pp ON (pp.i_customer = a.i_customer)
                 JOIN merchant_types m ON (m.i_merchant = get_pp_i_merchant(pp.i_payment_processor))
                WHERE a.username = ? AND a.payment_currency = pp.iso_4217
                      AND substr(m.capabilities, 3, 1) = 'Y'";
        $count_by_card = $db->getValue($sql, Array($username));

        $sql= "SELECT COUNT(*)
                 FROM accounts a
                 JOIN payment_processors pp ON (pp.i_customer = a.i_customer)
                 JOIN merchant_types m ON (m.i_merchant = get_pp_i_merchant(pp.i_payment_processor))
                WHERE a.username = ? AND a.payment_currency = pp.iso_4217
                      AND substr(m.capabilities, 4, 1) = 'Y'";
        $count_by_voucher = $db->getValue($sql, Array($username));

        if (($count_by_card > 0 && $_SESSION['debit_credit_cards_enabled']) ||
            ($count_by_voucher > 0 && $_SESSION['is_voucher_payments_available'])) {
            $_SESSION['is_payment_available'] = 1;
        }
    };
    return;
}

function set_warn_ssl_certificate() {
    global $db;
    global $web_session;

    $_SESSION['warn_ssl_certificate'] = FALSE;

    if ($_SESSION['hide_ssl_certificate_warning']) {
        return;
    }

    if (!$_SESSION['is_root_customer'] ||
        $web_session->user_info['i_access_level'] != 'ADMINISTRATOR' ) {
        return;
    }

    $dw = new System_Config_Entry('webui/disable_ssl_warning');
    if (Cast::str2bool($dw->value)) {
        $_SESSION['hide_ssl_certificate_warning'] = true;
        return;
    }

    $_SESSION['warn_ssl_certificate'] = file_exists('/var/env' . get_my_i_env() . '/run/check_ssl_cert.failed');
}

function set_warn_security_vulnerability() {
    global $db;
    global $web_session;

    $alert_types = Array('web' => FALSE,
                         'db'  => FALSE,
                         'ssh' => FALSE,
                         'sip' => FALSE);

    $_SESSION['warn_security_vulnerability'] = FALSE;

    if (!$_SESSION['is_root_customer'] ||
        $web_session->user_info['i_access_level'] != 'ADMINISTRATOR' ) {
        return;
    }

    $need_alert = FALSE;
    foreach ($alert_types as $k => $v) {
        $sc_entry = new System_Config_Entry('system/security/alert/open_' . $k . '_firewall');
        $alert_types[$k] = Cast::str2bool($sc_entry->value);

        $need_alert = $need_alert || $alert_types[$k];
    }

    if (!$need_alert) {
        return;
    }

    $sql = "SELECT COUNT(*) AS cnt, frt.description
              FROM firewall_rules fr
              JOIN firewall_types frt USING (i_firewall_type)
             WHERE frt.system_wide IN (?, ?) AND allow AND ip = ? AND netmask = ?
             GROUP BY frt.description";
    $params = Array(FALSE, is_root_environment(), '0.0.0.0', '0.0.0.0');
    $rows = $db->getAll($sql, $params);

    $types = Array();
    foreach ($rows as $row) {
        if ($alert_types[strtolower($row['description'])] && $row['cnt'] > 0) {
            $_SESSION['warn_security_vulnerability'] = TRUE;
            $types[] = $row['description'];
        }
    }
};

/* check if module is installed */
function is_module_installed($module) {
    global $db;

    $installed_modules = $db->getValue("SELECT installed_modules FROM system LIMIT 1");

    if ($installed_modules != '') {
        $installed_modules = explode(",", $installed_modules);
        foreach ($installed_modules as $m) {
            list($m, $args) = explode(':', $m);
            if ($m == $module) {
                return true;
            }
        }
    }

    return false;
}

/* get module arguments */
function get_module_args($module) {
    global $db;

    $installed_modules = $db->getValue("SELECT installed_modules FROM system LIMIT 1");

    if ($installed_modules != '') {
        $installed_modules = explode(",", $installed_modules);
        foreach ($installed_modules as $m) {
            list($m, $args) = explode(':', $m);
            if ($m == $module) {
                return $args;
            }
        }
    }

    return '';
}

function set_is_my_plan_menu_available() {
    global $db;

    $_SESSION['is_my_plan_menu_available'] = 0; /* not available */
    $i_account = $_SESSION['uid'];

    /* Calling Cards is available only for accounts */
    if ($_SESSION['account_type'] != 'account') {
        return;
    };

    include_once 'billing_plan.php';

    $bp = new Account_Billing_Plan($i_account);

    if (count($bp->scs) + count($bp->sps) > 0) {
        $_SESSION['is_my_plan_menu_available'] = 1;
    }
}

function set_is_calling_cards_menu_available() {
    global $db;

    $_SESSION['is_calling_cards_menu_available'] = 0;   /* not available */
    $username = $_SESSION['username'];

    /* Calling Cards is available only for accounts */
    if ($_SESSION['account_type'] != 'account') {
        return;
    };

    $sql = "SELECT max_sessions FROM accounts WHERE username = ?";
    $max_sessions = $db->getValue($sql, Array($username));

    if ( ((is_module_installed('ani_callback') && ($max_sessions > 1 || $max_sessions == -1)) ||
          (is_module_installed('calling_card') && ($max_sessions > 0 || $max_sessions == -1))) &&
           check_account_class_acl('ivr_enabled', $_SESSION['uid']) ) {
        $_SESSION['is_calling_cards_menu_available'] = 1;
    }
}

function set_is_vm_available() {
    global $db;

    $_SESSION['is_vm_available'] = 0;   /* not available */
    $i_account = $_SESSION['uid'];

    if ($_SESSION['account_type'] != 'account') {
        return;
    };

    $sql = "SELECT vm_enabled FROM accounts WHERE i_account = ?";
    $vm_available = Cast::str2bool($db->getValue($sql, Array($i_account)));
    if ($vm_available && check_account_class_acl('vm_enabled', $i_account)) {
        $_SESSION['is_vm_available'] = 1;
    }
}

function set_is_voucher_payments_available() {
    global $db;

    $_SESSION['is_voucher_payments_available'] = 0;   /* not available */
    $i_account = $_SESSION['uid'];


    if ($_SESSION['account_type'] != 'account') {
        return;
    };

    if (check_account_class_acl('voucher_payments_enabled', $i_account)) {
        $_SESSION['is_voucher_payments_available'] = 1;
    }
}

function set_is_followme_available() {
    global $db;

    $_SESSION['is_followme_available'] = 0;   /* not available */
    $i_account = $_SESSION['uid'];

    if ($_SESSION['account_type'] != 'account') {
        return;
    };

    $sql = "SELECT followme_enabled FROM accounts WHERE i_account = ?";
    $followme_available = Cast::str2bool($db->getValue($sql, Array($i_account)));

    if ($followme_available && check_account_class_acl('followme_enabled', $i_account)) {
        $_SESSION['is_followme_available'] = 1;
    }
}

function check_account_class_acl($acl, $i_account) {
    global $db;

    $sql = "SELECT ac.$acl
              FROM account_classes ac, accounts a
             WHERE a.i_account = ?
               AND a.i_account_class = ac.i_account_class";
    $status = $db->getValue($sql, Array($i_account));
    return Cast::str2bool($status);
}

function set_is_cb_available() {
    global $db;

    $_SESSION['is_cb_available'] = 0;   /* not available */
    $username = $_SESSION['username'];

    /* CallBack is available only for accounts */
    if ($_SESSION['account_type'] != 'account') {
        return;
    };

    if (check_account_class_acl('cb_enabled', $_SESSION['uid'])) {

        /* CallBack is avilable only if accounts.max_sessions > 1 */
        $sql = "SELECT max_sessions > 1 OR max_sessions = -1 FROM accounts WHERE username = ?";
        if ($db->getValue($sql, Array($username)) != 't') {
            return;
        };

        if (is_module_installed('web_callback_ng')) {
            $_SESSION['is_cb_available'] = 2;       /* ivrd-based */
            return;
        }
        
        /* Check if CallBack script is installed */
        if (!is_executable(CB_AGENT) || !is_readable(CB_AGENT)) {
            return;
        };

        /* All seem OK */
        $_SESSION['is_cb_available'] = 1;                   /* script-based */
    }
}

function set_is_vpn_available() {
    $_SESSION['is_vpn_available'] = 0;

    if (is_module_installed('vpn')) {
        $_SESSION['is_vpn_available'] = 1;
    }
}

function set_hosted_max() {
    $_SESSION['hosted_max'] = 1;

    if (is_module_installed('hosted')) {
        $args = get_module_args('hosted');
        if ($args > 1 || empty($args)) {
            $_SESSION['hosted_max'] = $args > 1 ? $args : 0;
        }
    }
}

function get_access_rights() {
    global $db;
    global $web_session;

    $account_type = $_SESSION['account_type'];

    if ($account_type == "customer") {
        $sql = "SELECT accounts_mgmt, customers_mgmt, system_mgmt, api_mgmt,
                       tariffs_mgmt, use_own_tariff, vouchers_mgmt, did_pool_enabled,
                       ivr_apps_enabled, asr_acd_enabled, debit_credit_cards_enabled,
                       conferencing_enabled, dncl_enabled
                  FROM customers
                 WHERE i_customer = ?";
        $row = $db->getAssociatedArray($sql, Array($_SESSION['uid']));

        $_SESSION['accounts_mgmt'] = $row['accounts_mgmt'];
        $_SESSION['customers_mgmt'] = $row['customers_mgmt'];
        $_SESSION['system_mgmt'] = $row['system_mgmt'];
        $_SESSION['api_mgmt'] = $row['api_mgmt'];
        $_SESSION['tariffs_mgmt'] = $row['tariffs_mgmt'];
        $_SESSION['use_own_tariff'] = $row['use_own_tariff'];
        $_SESSION['vouchers_mgmt'] = $row['vouchers_mgmt'];
        $_SESSION['did_pool_enabled'] = Cast::str2bool($row['did_pool_enabled']);
        $_SESSION['ivr_apps_enabled'] = Cast::str2bool($row['ivr_apps_enabled']);
        $_SESSION['asr_acd_enabled'] = Cast::str2bool($row['asr_acd_enabled']);
        $_SESSION['debit_credit_cards_enabled'] = Cast::str2bool($row['debit_credit_cards_enabled']);
        $_SESSION['conferencing_enabled'] = Cast::str2bool($row['conferencing_enabled']);
        $_SESSION['dncl_enabled'] = Cast::str2bool($row['dncl_enabled']);

    } elseif ($account_type == "account") {

        $sql = 'SELECT debit_credit_cards_enabled, conferencing_enabled
                  FROM customers
                 WHERE i_customer = ?
                 LIMIT 1';
        $row = $db->getAssociatedArray($sql, Array($web_session->user_info['i_customer']));
        $debit_credit_cards_enabled = Cast::str2bool($row['debit_credit_cards_enabled']);

        $_SESSION['debit_credit_cards_enabled'] = 0;
        if ($debit_credit_cards_enabled && check_account_class_acl('cc_payments_enabled', $_SESSION['uid'])) {
            $_SESSION['debit_credit_cards_enabled'] = 1;
        }

        $_SESSION['conferencing_enabled'] = Cast::str2bool($row['conferencing_enabled']);
    }
}

function make_timestamp($year="", $month="", $day="") {
    if (empty($year)) {
        $year = strftime("%Y");
    }
    if (empty($month)) {
        $month = strftime("%m");
    }
    if (empty($day)) {
        $day = strftime("%d");
    }

    return mktime(0, 0, 0, $month, $day, $year);
}


function normalize_seconds($sec) {
    $ss = $sec % 60;
    $mm = ($sec - $ss) / 60;
    return sprintf("%02d:%02d", $mm, $ss);
}

function load_timezones() {
    global $db;

    $sql = "SELECT i_time_zone, tz FROM time_zones ORDER BY tz";
    $res = $db->getAll($sql);

    $tzs = array();
    foreach ($res as $zone) {
        $tzs[$zone['i_time_zone']] = $zone['tz'];
    }
    return $tzs;
}

function set_timezone() {
    global $db;

    if ($i_tz = $_SESSION['i_time_zone']) {
        $sql = "SELECT tz, format, format_no_seconds, format_date_only FROM time_zones WHERE i_time_zone = ?";
        list($time_zone, $time_zone_format, $time_zone_format_no_seconds,
             $time_zone_format_date_only) = $db->getRow($sql, Array($i_tz));

        $_SESSION['tz'] = $time_zone;
        $_SESSION['tz_format'] = $time_zone_format;
        $_SESSION['tz_format_no_seconds'] = $time_zone_format_no_seconds;
        $_SESSION['tz_format_date_only'] = $time_zone_format_date_only;

        $sql = "SET TIME ZONE '{$time_zone}'";
        $db->prepNexec($sql);

        if ($time_zone) {
            date_default_timezone_set($time_zone);
            putenv("TZ={$time_zone}");
        }
    }
}

function show_login() {
    session_destroy();
    redirect_to_page('/index.php');
}

function assign_smarty_const() {
    global $smarty;

    $smarty->assign(Array(
        'PP_TX_OK' => PP_TX_OK,
        'PP_TX_FAIL' => PP_TX_FAIL,
        'PP_TX_PENDING' => PP_TX_PENDING,
        'PP_TX_COMPLETED' => PP_TX_COMPLETED,
    ));

    set_is_customers_menu_available();

    $smarty->assign(array(
        "acct_type" => $_SESSION['account_type'],
        "account_subtype" => $_SESSION['account_subtype'],
        "username" => $_SESSION['username'] ,
        "sub_web_login" => $_SESSION['sub_web_login'],
        "first_name" => $_SESSION['first_name'],
        "last_name" => $_SESSION['last_name'],
        "uid" => $_SESSION['uid'],
        "sub_uid" => $_SESSION['sub_uid'],
        "customer_name" => $_SESSION['customer_name'],
        "is_sippy_support_user" => $_SESSION['is_sippy_support_user'],
        "css" => $_SESSION['css'],
        "dns_alias" => $_SESSION['dns_alias'],
        "customer_id" => $_SESSION['customer_id'],
        "balance" => $_SESSION['balance'],
        "accounts_balance" => $_SESSION['accounts_balance'],
        "subcustomers_balance" => $_SESSION['subcustomers_balance'],
        "tz" => $_SESSION['tz'],
        "tz_format" => $_SESSION['tz_format'],
        "tz_format_no_seconds" => $_SESSION['tz_format_no_seconds'],
        "tz_format_date_only" => $_SESSION['tz_format_date_only'],
        "rule_trunc"=>RULE_TRUNC,

        'maintenance_mode' => $_SESSION['maintenance_mode'],
        'warn_ssl_certificate' => $_SESSION['warn_ssl_certificate'],
        'warn_security_vulnerability' => $_SESSION['warn_security_vulnerability'],

        'is_root_environment' => is_root_environment(),

        "accounts_mgmt" => $_SESSION['accounts_mgmt'],
        "customers_mgmt" => $_SESSION['customers_mgmt'],
        "system_mgmt" => $_SESSION['system_mgmt'],
        "api_mgmt" => $_SESSION['api_mgmt'],
        "vouchers_mgmt" => $_SESSION['vouchers_mgmt'],
        "did_pool_enabled" => $_SESSION['did_pool_enabled'],
        "ivr_apps_enabled" => $_SESSION['ivr_apps_enabled'],
        "asr_acd_enabled" => $_SESSION['asr_acd_enabled'],
        "debit_credit_cards_enabled" => $_SESSION['debit_credit_cards_enabled'],
        "conferencing_enabled" => $_SESSION['conferencing_enabled'],
        "dncl_enabled" => $_SESSION['dncl_enabled'],

        "is_accounts_menu_available" => $_SESSION['is_accounts_menu_available'],
        "is_customers_menu_available" => $_SESSION['is_customers_menu_available'],
        "is_commissions_menu_available" => $_SESSION['is_commissions_menu_available'],
        "is_vouchers_menu_available" => $_SESSION['is_vouchers_menu_available'],
        "is_permissions_menu_available" => $_SESSION['is_permissions_menu_available'],
        "is_tariffs_menu_available" => $_SESSION['is_tariffs_menu_available'],
        "use_own_tariff" => $_SESSION['use_own_tariff'],
        "is_calling_cards_menu_available" => $_SESSION['is_calling_cards_menu_available'],
        "is_followme_available" => $_SESSION['is_followme_available'],
        "is_vm_available" => $_SESSION['is_vm_available'],
        "is_voucher_payments_available" => $_SESSION['is_voucher_payments_available'],
        
        "is_web_phone_available" => $_SESSION['is_web_phone_available'],
        "is_my_plan_menu_available" => $_SESSION['is_my_plan_menu_available'],
        "is_callshop_available" => $_SESSION['is_callshop_available'],

        "is_root_customer" => $_SESSION['is_root_customer'],
        "is_payment_available" => $_SESSION['is_payment_available'],
        "is_cb_available" => $_SESSION['is_cb_available'],
        "is_vpn_available" => $_SESSION['is_vpn_available'],
        "is_sysinfo_available" => $_SESSION['is_sysinfo_available'],
        "vm_enabled" => $_SESSION['vm_enabled'],
        "title_text" => $_SESSION['title_text']
    ));

    /* load ExtJS when show warning */
    if ($_SESSION['warn_ssl_certificate'] && !$smarty->getTemplateVars('extjs_enabled')) {
        $smarty->assign('extjs_enabled', TRUE);
    };
}

function check_rules_account($rules, $account) {
    if (!empty($rules)) {
        $rules_array = explode(';', $rules);
        $test = false;
        foreach ($rules_array as $rule) {
            $rule = trim($rule);
            $test = $test || @preg_match('/' . $rule . '/', $account);
        }
        return $test;
    } else {
        return true;
    }
}

function check_account_up($account, $cid) {
    global $db;

    if ($cid == 1) {
        return true;
    }

    $sql = "SELECT accounts_matching_rule FROM customers WHERE i_customer = ?";
    $rules = $db->getValue($sql, Array($cid));

    if (!empty($rules)) {
        $rules_array = explode(';', $rules);
        $test = false;
        $i = 0;
        while (!$test && $i < count($rules_array)) {
            $rule = trim($rules_array[$i]);
            $test = @preg_match('/' . $rule . '/', $account);
            $i++;
        }
    } else {
        $test = true;
    }

    if ($test) {
        $sql = "SELECT i_wholesaler FROM customers WHERE i_customer = ? AND i_customer <> 1";
        $customers = $db->getAll($sql, Array($cid));

        foreach ($customers as $customer) {
            $test = check_account_up($account, $customer['i_wholesaler']);
            if (!$test) {
                return false;
            }
        }
        return true;
    } else {
        return false;
    }
}

function check_rules($rules, $cid) {
    global $db;

    $sql = "SELECT username, i_account FROM accounts WHERE i_customer = ?";
    $accounts = $db->getAll($sql, Array($cid));
    $accounts_list = array();
    foreach ($accounts as $account) {
        $test = check_rules_account($rules, $account['username']);
        if (!$test) {
            $accounts_list[]=$account['i_account'];
        }
    }
    $sql = "SELECT i_customer FROM customers WHERE i_wholesaler = ?";
    $customers = $db->getAll($sql, Array($cid));
    foreach($customers as $customer) {
        $accounts_add = check_rules($rules, $customer['i_customer']);
        $accounts_list += $accounts_add;
    }
    return $accounts_list;
}

function is_vm_password_valid($p_vm_password, $p_add_or_edit) {

    $f_result = str_replace(" ","", trim($p_vm_password));    

    if ($p_add_or_edit == 'add') {
        if ($f_result == '' || preg_match("/^[0-9]+$/", $f_result))
            return true;
    } elseif ($p_add_or_edit == 'edit') {
        if ($f_result == '@@@@@@' || $f_result == '' ||  preg_match("/^[0-9]+$/", $f_result))
            return true;
    }
    
    return false;
}

function can_add($rights) {
    return ($rights & 1);
}

function can_edit($rights) {
    return ($rights & 2);
}

function can_delete($rights) {
    return ($rights & 4);
}

function getNavigationAttributes($totalRecords) {
    global $smarty;

    $lastPage = $totalPages = ((int)$totalRecords>0) ? ceil($totalRecords / ROW_PER_PAGE) - 1 : 0;

    if (isset_par('n') && is_numeric(get_par('n')) && (int)get_par('n') >= 0) {
        if((int)get_par('n') > $lastPage)
            $currentPage = $lastPage;
        else
            $currentPage = (int)get_par('n');
    } else {
        $currentPage=0;
    }
    
    $sqlOffset = $currentPage * ROW_PER_PAGE;
    $prevPages = max($currentPage - 1, 0);
    $nextPage  = min($currentPage + 1, $totalPages);

    $smarty->assign(array(
        'n' => $currentPage,
        'p' => $prevPages,
        'last' => $lastPage,
        'next' => $nextPage,
        'total' => $totalPages,
        'total_rows' => $totalRecords
    ));

    return array(
        "off" => $sqlOffset
    );
}

function tx_log($tx_id, $msg) {
    date_default_timezone_set(ini_get('date.timezone'));
    putenv("TZ");
    $i_env = get_my_i_env();
    $msg = sprintf("%0d:%010s: %s: %s\n", $i_env, $tx_id, strftime("%D %T %Z"), $msg);
    error_log("$msg", 3, PATH_PAYMENTS_TX_LOG);
    date_default_timezone_set($_SESSION['tz']);
    putenv("TZ=" . $_SESSION['tz']);
}

function get_export_types() {
    global $db;

    $sql = "SELECT i_export_type, name FROM export_types ORDER BY name";
    $ret = $db->getAll($sql);

    return $ret ? $ret : array();
}

function get_export_type() {
    global $db;
    global $web_session;

    $acct_type = $web_session->type;
    $acct_subtype = $web_session->subtype;
    $uid = $web_session->user_info['uid'];
    $sub_uid = $web_session->user_info['sub_uid'];

    switch ($acct_type) {
        case Web_Session::TYPE_CUSTOMER:
            if ($acct_subtype == Web_Session::TYPE_WEB_USER) {
                $sql = 'SELECT i_export_type
                          FROM web_users
                         WHERE i_web_user = ?
                         LIMIT 1';
                $params = Array($sub_uid);
            } else {
                $sql = 'SELECT i_export_type
                          FROM web_users
                         WHERE i_customer = ? AND default_user
                         LIMIT 1';
                $params = Array($uid);
            }
            break;

        case Web_Session::TYPE_VENDOR:
            $sql = 'SELECT i_export_type
                      FROM vendors
                     WHERE i_vendor = ?
                     LIMIT 1';
            $params = Array($uid);
            break;

        case Web_Session::TYPE_ACCOUNT:
        default:
            $sql = 'SELECT i_export_type
                      FROM accounts
                     WHERE i_account = ?
                     LIMIT 1';
            $params = Array($uid);
            break;
    }

    return $db->getValue($sql, $params);
}

/* get display precission format */
function get_dpf() {
    global $db;
    static $dpf = '';           /* cache the value */

    if ($dpf == '') {
        $dpf = sprintf("%%.%df", $db->getValue("SELECT display_precision FROM system LIMIT 1"));
    }

    return $dpf;
}

function parse_date($value, $return_timestamp = FALSE) {
    $r = strtotime($value);
    if ($r === FALSE) {
        $r = time();
    }

    if ($return_timestamp) {
        return $r;
    } else {
        return date('Y-m-d H:i:s', $r);
    }
}

function parse_future_date($value) {
    $is_future = TRUE;

    if (strtoupper($value) == 'NEVER') {
        $res = 'NULL';
        $utime = NULL;
    } elseif(strtoupper($value) == 'NOW') {
        $parsed_date = parse_date('');
        $res = "timestamp '$parsed_date'";
        $utime = strtotime($parsed_date);
    } else {
        $parsed_date = parse_date($value);
        $res = "timestamp '$parsed_date'";
        $utime = strtotime($parsed_date);
        $is_future = $utime >= time();
    }

    return Array('is_future' => $is_future,
                 'date' => $res,
                 'utime' => $utime);
}

function prepare_XMLAPI_date($value) {
    $r = strtotime($value);
    if ($r === FALSE) {
        $r = time();
    }
    $timezone = date_default_timezone_get();
    date_default_timezone_set('UTC');
    $date = date('H:i:s.000 \G\M\T D M d Y', $r);
    date_default_timezone_set($timezone);

    return $date;
}

function create_temp_directory($path = '/var/tmp') {
    $path = rtrim($path, '/') . '/';
    for ($s = '', $i = 0, $z = strlen($a = 'abcdefghijklmnopqrstuvwxyz0123456789') - 1;
         $i != 10; $x = rand(0,$z), $s .= $a{$x}, $i++);
    $basedir = $path . "$s";
    mkdir($basedir, 0700);

    return $basedir;
}

function rmdir_recurse($path) {
    $path = rtrim($path, '/') . '/';
    $handle = opendir($path);
    if ($handle !== FALSE) {
        for (;false !== ($file = readdir($handle));) {
            if ($file != "." && $file != ".." ) {
                $fullpath = $path . $file;
                if (is_dir($fullpath)) {
                    rmdir_recurse($fullpath);
                    rmdir($fullpath);
                } else {
                    @unlink($fullpath);
                }
            }
        }
        closedir($handle);
    }
    rmdir($path);
}

function redirect_to_page($url) {
    header("Location: {$url}");
    exit();
}

function get_default_login_page() {
    global $db;

    $default_login_page = $db->getValue("SELECT default_login_page FROM system LIMIT 1");

    switch ($default_login_page) {
        case 2:
            $ret = 'account';
            break;
        case 3:
            $ret = 'customer';
            break;
        case 4:
            $ret = 'vendor';
            break;
        case 1:
        default:
            $ret = 'all';
            break;
    }

    return $ret;
}

function get_default_login_type() {
    global $db;

    $default_login_page = $db->getValue("SELECT default_login_page FROM system LIMIT 1");

    switch ($default_login_page) {
        case 2:
            $ret = 'account';
            break;
        case 3:
            $ret = 'customer';
            break;
        case 4:
            $ret = 'vendor';
            break;
        case 1:
        default:
            $ret = 'customer';
            break;
    }

    return $ret;
}

function get_own_env_info($flush_cashe = FALSE) {
    static $env_info = NULL;           /* cache the value */

    if (!$flush_cashe && $env_info !== NULL) {
        return $env_info;
    }

    $params = array(new xmlrpcval(array(
                    "i_environment" => new xmlrpcval(get_my_i_env(), "int"),
                    ), 'struct'));
    $msg = new xmlrpcmsg('jailGetEnvironmentInfo', $params);
    $cli = new xmlrpc_client('https://xmlrpc-root/xmlapi/xmlapi');
    $cli->request_charset_encoding = 'UTF-8';
    $cli->setSSLVerifyPeer(false);
    $cli->return_type = 'phpvals';
    $cli->addHeader('X-From-I-Environment', get_my_i_env());

    $res = $cli->send($msg);

    if ($res->faultCode()) {
        error_log('get_own_env_info(): ' . htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        return;
    }

    if (!is_array($res->val['environment'])) {
        error_log('get_own_env_info(): unable to get info');
        return;
    }

    $env_info = $res->val['environment'];
    $env_info['gen_cert'] = Cast::str2bool($env_info['https_certificate_type'] == 2);

    return $env_info;
}

function get_master_XMLRPC_server() {
    $own_env = get_own_env_info();
    $ips = explode(',', $own_env['assigned_ips']);

    return $ips[0];
}

/* get default Start Date */
function get_dsd() {
    global $db;

    static $dsd = '';           /* cache the value */

    $start_dates = Array(
        1 => '1 hour ago',      /* default */
        2 => 'today',
        3 => '2 days ago',
        4 => '1 week ago',
        5 => '1 month ago'
    );


    if ($dsd == '') {
        $dsd = $db->getValue("SELECT web_start_date FROM system LIMIT 1");
    }

    return array_key_exists($dsd, $start_dates) ? $start_dates[$dsd] : $start_dates[2];
}

function get_own_mail_address($ws = NULL) {
    global $db;
    global $web_session;

    if ($ws === NULL) {
        $ws = $web_session;
    }

    $acct_type = $ws->type;
    $acct_subtype = $ws->subtype;
    $uid = $ws->user_info['uid'];
    $sub_uid = $ws->user_info['sub_uid'];

    switch ($acct_type) {
        case Web_Session::TYPE_CUSTOMER:
            if ($acct_subtype == Web_Session::TYPE_WEB_USER) {
                $sql = 'SELECT email
                          FROM web_users
                         WHERE i_web_user = ?
                         LIMIT 1';
                $params = Array($sub_uid);
            } else {
                $sql = 'SELECT c.email
                          FROM customers
                          JOIN contacts c USING (i_contact)
                         WHERE i_customer = ?
                         LIMIT 1';
                $params = Array($uid);
            }
            break;

        case Web_Session::TYPE_VENDOR:
            $sql = 'SELECT c.email
                      FROM vendors
                      JOIN contacts c USING (i_contact)
                     WHERE i_vendor = ?
                     LIMIT 1';
            $params = Array($uid);
            break;

        case Web_Session::TYPE_ACCOUNT:
        default:
            $sql = 'SELECT c.email
                      FROM accounts
                      JOIN contacts c USING (i_contact)
                     WHERE i_account = ?
                     LIMIT 1';
            $params = Array($uid);
            break;
    }

    return $db->getValue($sql, $params);
}

function get_own_mail_from($domain, $ws = NULL) {
    global $db;
    global $web_session;

    if ($ws === NULL) {
        $ws = $web_session;
    }

    $acct_type = $ws->type;
    $acct_subtype = $ws->subtype;
    $uid = $ws->user_info['uid'];
    $sub_uid = $ws->user_info['sub_uid'];

    if ($acct_type == Web_Session::TYPE_CUSTOMER && $acct_subtype === NULL) {
        $sql = 'SELECT mail_from FROM customers WHERE i_customer = ? LIMIT 1';
        $params = Array($uid);
        $ret = $db->getValue($sql, $params);
        if ($ret != '') {
            return $ret;
        }
    }

    $ret = get_own_mail_address($ws);
    if ($ret != '') {
        return $ret;
    }

    return 'www@' . $domain;
};

function init_email_delivery($acct_type, $uid) {
    global $db_master;
    global $par;

    switch ($acct_type) {
        case 'customer':        $i_owner = 'i_customer'; break;
        case 'vendor':          $i_owner = 'i_vendor'; break;
        case 'account':
        default:                $i_owner = 'i_account'; break;
    }

    /* acquire a lock */ 
    $db_master->begin();
    if (!$db_master->prepNexec('LOCK web_jobs')) {
        $msg = Array('success' => FALSE,
                     'error_message' => 'Unable to acquire the lock. Please try again later.');
        $msg = json_encode($msg);

        send_responce_to_browser($msg, 'application/json');

        $db_master->rollback();
        exit();
    };

    $sql = "SELECT procid
              FROM web_jobs w
             WHERE i_type = 'SEND_BY_EMAIL' AND w.$i_owner = ?";
    $procid = $db_master->getValue($sql, Array($uid));

    if ($db_master->affected_rows > 0) {
        /* check if process is still alive */
        $ps = shell_exec("/bin/ps $procid");
        $ps = explode("\n", $ps);
        $ps = preg_split("/\s+/", trim($ps[1]));
        if ($ps[4] == '/usr/local/bin/php') {
            $msg = Array('success' => FALSE,
                         'error_message' => 'Another download generation is already in progress. Please try again later.');
            $msg = json_encode($msg);

            send_responce_to_browser($msg, 'application/json');
            $db_master->rollback();
            exit();
        }
    }

    $sql = "DELETE FROM web_jobs WHERE i_type = 'SEND_BY_EMAIL' AND $i_owner = ?";
    $db_master->prepNexec($sql, Array($uid));

    $i_web_job = $db_master->nextID('web_jobs_seq');
    $wrapped_file_name = escapeshellarg(get_par('wrapped_file_name'));

    $command = '/usr/local/bin/php cli_wrapper.php -- ' . getenv('I_ENVIRONMENT') . ' ' . $i_web_job . ' ' . $wrapped_file_name . ' > /dev/null 2>&1 & echo $!';
    //$command = '/usr/local/bin/php cli_wrapper.php -- ' . getenv('I_ENVIRONMENT') . ' ' . $i_web_job . ' ' . $wrapped_file_name . ' > /var/tmp/err.log 2>&1 & echo $!';
    exec($command, $op);

    $procid = (int)$op[0]; 
    $ps = shell_exec("/bin/ps $procid");
    $ps = explode("\n", $ps);
    $ps = preg_split("/\s+/", trim($ps[1]));
    if ($procid == '' || $ps[4] != '/usr/local/bin/php') {
        $msg = Array('success' => FALSE,
                     'error_message' => 'Unable to initiate E-Mail sending. Please try again later.');
        $msg = json_encode($msg);

        send_responce_to_browser($msg, 'application/json');
        $db_master->rollback();
        exit();
    }

    $par['email_domain'] = $_SERVER['SERVER_NAME'];
    $params = serialize($par);
    $session = serialize($_SESSION);

    $sql = "INSERT INTO web_jobs (i_web_job, $i_owner, i_type, procid, params, session) VALUES (?, ?, ?, ?, ?, ?)";
    $db_master->prepNexec($sql, Array($i_web_job, $uid, 'SEND_BY_EMAIL', $procid, $params, $session));

    $db_master->commit();
    $msg = Array('success' => TRUE);
    $msg = json_encode($msg);
    send_responce_to_browser($msg, 'application/json');

    error_log('Launch ' . $wrapped_file_name . ' in CLI mode, i_environment = ' . getenv('I_ENVIRONMENT') . ', i_web_job = ' . $i_web_job);

    exit();
}

function send_responce_to_browser($msg, $ctype = 'text/html') {
    header("Content-type: " . $ctype);
    header("Content-Length: " . strlen($msg));
    print $msg;
}

function send_report_by_email($mail_from, $mail_mailto, $mail_subject, $mail_message,
                              $basedir, $zip_attach, $zip_filename = NULL) {
    global $db_master;

    $db_master->begin();

    $i_mail = $db_master->nextID('mails_seq');

    $mail_subject = '=?UTF-8?B?' . base64_encode(email_apply_macros($mail_subject)) . '?=';

    $sql = 'INSERT INTO mails (i_mail, mail_from, mail_to, subject, message, message_charset, status)
                 VALUES (?, ?, ?, ?, ?, ?, 0)';
    $params = Array($i_mail, $mail_from, $mail_mailto, $mail_subject, $mail_message, 'UTF-8');
    $db_master->prepNexec($sql, $params);

    if ($zip_attach) {
        send_report_by_email_zip_attaches($basedir, $zip_filename);
    }

    send_report_by_email_attach_files($i_mail, $basedir);

    $sql = 'UPDATE mails SET status = 1 WHERE i_mail = ?';
    $db_master->prepNexec($sql, Array($i_mail));

    $db_master->commit();
}

function send_report_by_email_zip_attaches($basedir, $zip_filename = NULL) {
    $basedir = rtrim($basedir, '/') . '/';
    $handle = opendir($basedir);

    $files = Array();
    for (; false !== ($file = readdir($handle)); ) {
        $fullpath = $basedir . $file;
        if ($file != "." && $file != ".." && is_file($fullpath)) {
            $files[] = Array('name' => $file, 'path' => $fullpath);
        }
    }

    closedir($handle);

    if (count($files) == 0) {
        return;
    }

    $arch_name = ($zip_filename === NULL) ? 'Reports.zip' : $zip_filename . '.zip';
    if (count($files) == 1) {
        $a = explode('.', $files[0]['name']);
        $arch_name = $a[0] . '.zip';
    }

    $arch = new ZipArchive();
    $arch->open($basedir . $arch_name, ZipArchive::CREATE | ZipArchive::OVERWRITE);

    foreach ($files as $file) {
        $arch->addFile($file['path'], $file['name']);
    }

    $arch->close();

    foreach ($files as $file) {
        @unlink($file['path']);
    }
}

function send_report_by_email_attach_files($i_mail, $basedir) {
    global $db_master;

    $basedir = rtrim($basedir, '/') . '/';
    $handle = opendir($basedir);
    for (; false !== ($file = readdir($handle)); ) {
        $fullpath = $basedir . $file;
        if ($file != "." && $file != ".." && is_file($fullpath)) {
            $ext = explode('.', $file);
            switch ($ext[1]) {
                case 'xlsx': $content_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'; break;
                case 'csv': $content_type = 'application/vnd.ms-excel'; break;
                case 'zip': $content_type = 'application/zip'; break;
                default: $content_type = 'application/octet-stream';
            }

            $data = file_get_contents($fullpath);
            $data = chunk_split(base64_encode($data));

            $sql = 'INSERT INTO mail_attachments (i_mail, content_name, content_type, data) VALUES (?, ?, ?, ?)';
            $db_master->prepNexec($sql, Array($i_mail, $file, $content_type, $data));
        }
    }
    closedir($handle);
}

function clear_web_jobs() {
    global $db_master;
    global $i_web_job;

    $sql = 'DELETE FROM web_jobs WHERE i_web_job = ?';
    $db_master->prepNexec($sql, Array($i_web_job));
}

function email_apply_macros($message) {
    global $startDate, $endDate;

    $search = Array('${DATE_FROM}', '${DATE_TO}');
    $replace = Array(parse_date($startDate), parse_date($endDate));

    return str_replace($search, $replace, $message);
};

function are_cdrs_blocked() {
    global $web_session;

    return (
             ( !$_SESSION['is_root_customer'] ||
               ($_SESSION['is_root_customer'] && !empty($_SESSION['account_subtype']))
             ) &&
             !$web_session->is_sippy_support_user
           ) &&
           $_SESSION['maintenance_mode'] == 1;
}

function get_langs() {
    global $db;

    $sql = "SELECT i_lang, name FROM languages WHERE web ORDER BY name";
    $ret = $db->getAll($sql);

    return $ret ? $ret : array();
}

function require_account_type($type) {
    if (is_array($type)) {
        if (!in_array($_SESSION['account_type'], $type)) {
            show_login();
        }
    } elseif ($type != $_SESSION['account_type']) {
        show_login();
    }
}

function require_account_subtype($type) {
    if (is_array($type)) {
        if (!in_array($_SESSION['account_subtype'], $type)) {
            show_login();
        }
    } elseif ($type != $_SESSION['account_subtype']) {
        show_login();
    }
}

function get_my_i_env() {
    if (defined('CLI_MODE') && defined('WEB_JOB')) {
        return I_ENVIRONMENT;
    } else {
        return getenv('I_ENVIRONMENT') === '0' ? $_SERVER['HTTP_X_I_ENVIRONMENT'] : getenv('I_ENVIRONMENT');
    }
}

function is_root_environment() {
    return get_my_i_env() == 1;
}

function verify_page_watermark() {
    global $smarty;

    if (array_key_exists('page_watermark', $_SESSION)) {
        $watermark = get_par('page_watermark');
        $_SESSION['page_watermark_verified'] = $watermark >= $_SESSION['page_watermark'];
        $smarty->assign('page_watermark', ++$_SESSION['page_watermark']);
    } else {
        $_SESSION['page_watermark'] = 1;
        $smarty->assign('page_watermark', $_SESSION['page_watermark']);
        $_SESSION['page_watermark_verified'] = TRUE;
    }
}

function get_my_db_name() {
    $i_env = get_my_i_env();
    $cluster_conf = sprintf(PATH_CLUSTER_CONF, $i_env);
    $db_name = NULL;

    if (is_file($cluster_conf) && is_readable($cluster_conf)) {
        $fh = fopen($cluster_conf, 'r');
        if ($fh) {
            while (!feof($fh)) {
                $s = fgets($fh, 256);
                @list($var, $val) = explode('=', trim($s));
                switch ($var) {
                    case 'DB_NAME':
                        $db_name = $val;
                        break;
                    default:
                        break;
                }
            }
            fclose($fh);
        }
    }

    if (empty($db_name)) {
        print "Unable to parse cluster.conf";
        exit();
    }

    return $db_name;
}

function parse_operator_name($name) {
    if ($name == '' || $name == NULL) {
        return _('Not Defined');
    }

    list($type, $id1, $id2, $who) = explode(':', $name);

    switch($type) {
        case 'c':
            return _('Customer') . ' ' . $who;
            break;

        case 'u':
            return _('Web User') . ' ' . $who;
            break;

        case 't':
            return _('Trusted Host') . ' ' . $who;
            break;

        default:
            break;
    };

    return $name;
}

?>
