<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Image {

    public $i_image;
    public $i_customer;
    public $filename;
    public $mime_type;
    public $description;
    public $image;

    private $_fault;

    function __construct($i_customer, $i_image = NULL) {
        $this->i_image = $i_image;
        $this->i_customer = $i_customer;
        $this->filename = '';
        $this->mime_type = '';
        $this->description = '';
        $this->image = NULL;

        $this->_fault = FALSE;

        if ($this->i_image !== NULL) {
            $this->getEntry($this->i_image);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_image) {
        global $db;

        $sql = 'SELECT i.i_image, i.filename, i.mime_type, i.description, i.image
                  FROM images i
                 WHERE i.i_customer = ? AND i.i_image = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($this->i_customer, $i_image));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_image = $entry['i_image'];
        $this->filename = $entry['filename'];
        $this->description = $entry['description'];
        $this->image = base64_decode($entry['image']);
    }

    public function initFromRequest($par) {
        $this->i_image = $par['i_image'];
        $this->filename = $par['filename'];
        $this->description = $par['description'];
    }

    public function genID() {
        global $db;

        return $db->nextID('images_seq');
    }

    public function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('name_pattern') != '') {
            $ret['sql'] .= ' AND i.filename ' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('name_pattern');
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(i.*)
                   FROM images i
                  WHERE i.i_customer = ?
                        {$clause['sql']}";
        $params = array_merge(Array($this->i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function reset_n($id) {
        global $db;

        $clause = $this->buildClause();

        $n = 0;

        $sql = "SELECT i.i_image AS id
                  FROM images i
                 WHERE i.i_customer = ?
                       {$clause['sql']}
              ORDER BY i.filename";
        $params = array_merge(Array($this->i_customer), $clause['params']);

        $rows = $db->getAll($sql, $params);

        $i = 0;
        foreach ($rows as $row) {
            if ($i++ == ROW_PER_PAGE) {
                $n++;
                $i = 0;
            }
            if ($row['id'] == $id) {
                break;
            }
        }

        return $n;
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT i.i_image, i.filename, i.description
                  FROM images i
                 WHERE i.i_customer = ?
                       {$clause['sql']}
              ORDER BY i.filename
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($this->i_customer), $clause['params']);

        return $db->getAll($sql, $params);
    }

    public function getAllList() {
        global $db;

        $sql = "SELECT i.i_image, i.filename, i.description
                  FROM images i
                 WHERE i.i_customer = ?
              ORDER BY i.filename";

        return $db->getAll($sql, Array($this->i_customer));
    }

    private function doesFilenameExist($name, $i_image = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM images i
                 WHERE i.i_customer = ? AND i.filename ILIKE ? AND i.i_image <> ?';

        $params = Array($this->i_customer, $name, $i_image);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $form_as_add = FALSE) {
        if ($form_as_add) {
            if ($_FILES['filename']['error'] != UPLOAD_ERR_OK) {
                error_log('Unable to upload file. Error code: ' . $_FILES['filename']['error']);
                throw new Exception(_('Unable to upload file.'));
            }

            if ($_FILES['filename']['size'] > 520000) {
                throw new Exception(_('The file you are trying to upload is too big.'));
            }

            $supported_types = Array('image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png');
            if (!in_array($_FILES['filename']['type'], $supported_types)) {
                throw new Exception(_('Invalid image format. Only JPG, GIF and PNG formats are supported.'));
            }


            if ($this->doesFilenameExist($_FILES['filename']['name'])) {
                throw new Exception(_('Cannot add Image. Another Image with conflicting "Filename" already exists.'));
            }
        } else {
            if ($this->doesFilenameExist($par['filename'], $par['i_image'])) {
                throw new Exception(_('Cannot update Image. Another Image with conflicting "Filename" already exists.'));
            }
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, TRUE);

        $i_image = $this->genID();
        $filename = $_FILES['filename']['name'];
        $image = file_get_contents($_FILES['filename']['tmp_name']);
        $image = chunk_split(base64_encode($image));

        $sql = 'INSERT INTO images (i_image, i_customer, filename, mime_type, description, image)
                     VALUES (?, ?, ?, ?, ?, ?)';
        $params = Array($i_image, $this->i_customer, $filename, $_FILES['filename']['type'], $par['description'], $image);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Image."));
        }

        $this->getEntry($i_image);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $sql = 'UPDATE images
                   SET filename = ?, description = ?
                 WHERE i_customer = ? AND i_image = ?';
        $params = Array($par['filename'], $par['description'], $this->i_customer, $par['i_image']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Image."));
        }

        $this->getEntry($par['i_image']);

        $this->setFault(FALSE);
    }


    public function delete($par) {
        global $db;

        $sql = 'DELETE FROM images
                 WHERE i_customer = ? AND i_image = ?';
        $params = Array($this->i_customer, $par['i_image']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Image."));
        }
    }

}

?>
