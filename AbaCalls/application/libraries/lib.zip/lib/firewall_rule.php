<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Firewall_Rule {
    public $allow_system_wide;
    public $i_firewall_rule;
    public $system;
    public $i_firewall_type;
    public $ip;
    public $netmask;
    public $allow;
    public $order_num;
    public $description;

    private $_fault;

    function __construct($i_firewall_rule = NULL) {
        $this->allow_system_wide = Cast::str2bool(get_my_i_env() == 1);
        $this->i_firewall_rule = $i_firewall_rule;
        $this->system = FALSE;
        $this->i_firewall_type = NULL;
        $this->ip = NULL;
        $this->netmask = NULL;
        $this->allow = FALSE;
        $this->order_num = 0;
        $this->description = '';

        $this->_fault = FALSE;

        if ($this->i_firewall_rule !== NULL) {
           $this->getEntry($this->i_firewall_rule);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getTypes() {
        global $db;

        $sql = 'SELECT i_firewall_type, description 
                  FROM firewall_types
                 WHERE system_wide IN (?, ?)
              ORDER BY description';
        $params = Array(FALSE, $this->allow_system_wide);

        $ret = $db->getAll($sql, $params);

        return $ret;
    }

    public function getList() {
        global $db;
        
        $sql = 'SELECT fr.i_firewall_rule, fr.system, ft.description AS type,
                       fr.ip, fr.netmask, fr.allow, fr.order_num, fr.description,
                       (SELECT MAX(fr2.order_num) = fr.order_num
                          FROM firewall_rules fr2
                         WHERE fr.i_firewall_type = fr2.i_firewall_type) AS last_rule
                  FROM firewall_rules fr
                  JOIN firewall_types ft ON (fr.i_firewall_type = ft.i_firewall_type) 
                 WHERE system_wide IN (?, ?)
              ORDER BY ft.description, fr.system, fr.order_num';
        $params = Array(FALSE, $this->allow_system_wide);

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$r) {
            $r['system'] = Cast::str2bool($r['system']);
            $r['allow'] = Cast::str2bool($r['allow']);
            $r['last_rule'] = Cast::str2bool($r['last_rule']);
        }

        return $ret;
    }

    public function getEntry($i_firewall_rule) {
        global $db;

        $sql = 'SELECT i_firewall_rule, system, i_firewall_type,
                       ip, netmask, allow, order_num, description
                  FROM firewall_rules 
                 WHERE i_firewall_rule = ?';
        $params = Array($i_firewall_rule);

        $entry = $db->getAssociatedArray($sql, $params);

	    if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
	    }

        $this->i_firewall_rule = $entry['i_firewall_rule'];
        $this->system = Cast::str2bool($entry['system']);
        $this->i_firewall_type = $entry['i_firewall_type'];
        $this->ip = $entry['ip'];
        $this->netmask = $entry['netmask'];
        $this->allow = Cast::str2bool($entry['allow']);
        $this->order_num = $entry['order_num'];
        $this->description = $entry['description'];
    }

    public function initFromRequest($par) {
        $this->i_firewall_type = $par['i_firewall_type'];
        $this->ip = $par['ip'];
        $this->netmask = $par['netmask'];
        $this->allow = Cast::str2bool($par['allow']);
        $this->description = $par['description'];
    }
        

    public function genID() {
        global $db;

        return $db->nextID('firewall_rules_seq');
    }
    
    protected function getMaxOrderNum($i_firewall_type)  {
        global $db;

        $sql = 'SELECT MAX(order_num) 
                  FROM firewall_rules 
                 WHERE i_firewall_type = ?';
        $params = Array($i_firewall_type);

        return $db->getValue($sql, $params);
    } 

    public function validate($par) {
        if (!$this->system) {
            if (!Validator::isIPAddress($par['ip'], TRUE)) {
                throw new Exception(_('"IP Address" field has incorrect format.'));
            }

            if (!Validator::isNetmask($par['netmask'], TRUE)) {
                throw new Exception(_('"Netmask" field has incorrect format.'));
            }
        }
    }

    public function addEntry($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $i_firewall_rule = $this->genID();
        $order_num = $this->getMaxOrderNum($par['i_firewall_type']) + 1;

        $sql = 'INSERT INTO firewall_rules (i_firewall_rule, i_firewall_type, ip,
                                            netmask, allow, order_num, description)
                     VALUES (?, ?, ?, ?, ?, ?, ?)';

        $params = Array($i_firewall_rule,
                        $par['i_firewall_type'],
                        $par['ip'],
                        $par['netmask'],
                        Cast::str2bool($par['allow']),
                        $order_num,
                        $par['description']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_('Cannot add Firewall Entry.'));
        }
        
        Audit_Logger::write('A', sprintf('firewall_rules:i_firewall_rule=%d', $i_firewall_rule));

        $this->getEntry($i_firewall_rule);

        $this->setFault(FALSE);
    }
   
    public function updateEntry($par) {
        global $db;
        
        $this->setFault(TRUE);

        $this->validate($par);

        if ($this->system) {
            $sql = 'UPDATE firewall_rules 
                       SET allow = ?
                     WHERE system AND i_firewall_rule = ?';
            $params = Array(Cast::str2bool($par['allow']),
                            $this->i_firewall_rule);
        } else {
            $sql = 'UPDATE firewall_rules 
                       SET i_firewall_type = ?, ip = ?, netmask = ?, allow = ?, description = ?
                     WHERE NOT system AND i_firewall_rule = ?';
            $params = Array($par['i_firewall_type'], 
                            $par['ip'],
                            $par['netmask'],
                            Cast::str2bool($par['allow']),
                            $par['description'],
                            $this->i_firewall_rule);
        }

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_('Cannot update Firewall Entry.'));
        }

        Audit_Logger::write('U', sprintf('firewall_rules:i_firewall_rule=%d', $this->i_firewall_rule));

        $this->getEntry($this->i_firewall_rule);

        $this->setFault(FALSE);
    }

    public function upEntry() {
        global $db;

        if ($this->system || $this->order_num == 1) {
            return;
        }

        $this->setFault(TRUE);

        $db->begin();

        $sql = 'UPDATE firewall_rules 
                   SET order_num = order_num + 1 
                 WHERE NOT system AND order_num = ? - 1 AND i_firewall_type = ?';
        $params = Array($this->order_num, $this->i_firewall_type);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_('Cannot move up Firewall Entry.'));
        }

        $sql = 'UPDATE firewall_rules 
                   SET order_num = order_num - 1 
                 WHERE NOT system AND i_firewall_rule = ?';
        $params = Array($this->i_firewall_rule);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_('Cannot move up Firewall Entry.'));
        }

        $db->commit();

        Audit_Logger::write('U', sprintf('firewall_rules:i_firewall_rule=%d', $this->i_firewall_rule));

        $this->getEntry($this->i_firewall_rule);

        $this->setFault(FALSE);
    }
    
    public function downEntry() {
        global $db;
        
        if ($this->system ||
            $this->order_num == $this->getMaxOrderNum($this->i_firewall_type)) {
            return;
        }

        $this->setFault(TRUE);

        $db->begin();

        $sql = 'UPDATE firewall_rules 
                   SET order_num = order_num - 1 
                 WHERE NOT system AND order_num = ? + 1 AND i_firewall_type = ?';
        $params = Array($this->order_num, $this->i_firewall_type);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_('Cannot move down Firewall Entry.'));
        }

        $sql = 'UPDATE firewall_rules 
                   SET order_num = order_num + 1 
                 WHERE NOT system AND i_firewall_rule = ?';
        $params = Array($this->i_firewall_rule);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();    
            throw new Exception(_('Cannot move down Firewall Entry.'));
        }
        
        $db->commit();

        Audit_Logger::write('U', sprintf('firewall_rules:i_firewall_rule=%d', $this->i_firewall_rule));

        $this->getEntry($this->i_firewall_rule);

        $this->setFault(FALSE);
    }

    public function deleteEntry() {
        global $db;
            
        $this->setFault(TRUE);

        $sql = 'DELETE FROM firewall_rules 
                 WHERE NOT system AND i_firewall_rule = ?';
        $params = Array($this->i_firewall_rule);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_('Cannot delete Firewall Entry.'));
        }

        $this->squeezeRules($this->order_num);
    
        Audit_Logger::write('D', sprintf('firewall_rules:i_firewall_rule=%d', $this->i_firewall_rule));

        $this->setFault(FALSE);
    }

    public function squeezeRules($order_num) {
        global $db;

        $max_order_num = $this->getMaxOrderNum($this->i_firewall_type);

        if ($max_order_num < $order_num) {
            return;
        }

        $sql = 'UPDATE firewall_rules
                   SET order_num = order_num - 1
                 WHERE NOT system AND i_firewall_type = ? AND order_num = ? + 1';
        $params = Array($this->i_firewall_type, $order_num);

        $db->prepNexec($sql, $params);

        $this->squeezeRules($order_num + 1);
    }
}

?>
