<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class DIDs_Charging_Group {
    const TYPE_SELLING = 1;
    const TYPE_BUYING = 2;

    public $i_customer;
    public $type;
    public $i_dids_charging_group;
    public $name;
    public $description;
    public $connect_fee;
    public $free_seconds;
    public $grace_period;
    public $price_1;
    public $price_n;
    public $interval_1;
    public $interval_n;
    public $iso_4217;
    public $price;
    public $setup_fee;
    public $post_call_surcharge;

    public $linked;

    private $_fault;

    function __construct($i_customer, $i_dids_charging_group = NULL) {
        global $db;

        $this->i_customer = $i_customer;
        $this->i_dids_charging_group = $i_dids_charging_group;
        $this->type = self::TYPE_SELLING;
        $this->name = '';
        $this->description = '';
        $this->connect_fee = 0;
        $this->free_seconds = 0;
        $this->grace_period = 0;
        $this->price_1 = 0;
        $this->price_n = 0;
        $this->interval_1 = 1;
        $this->interval_n = 1;
        $this->price = 0;
        $this->setup_fee = 0;
        $this->post_call_surcharge = 0;

        $this->_fault = FALSE;

        if ($this->i_dids_charging_group !== NULL) {
            $this->getEntry($this->i_dids_charging_group);
        } else {
            $sql = 'SELECT base_currency
                      FROM customers
                     WHERE i_customer = ?
                     LIMIT 1';
            $params = Array($i_customer);
            $this->iso_4217 = $db->getValue($sql, $params);

            $this->linked = FALSE;
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_dids_charging_group) {
        global $db;

        $sql = 'SELECT dcg.*, dcg.post_call_surcharge * 100.0 AS post_call_surcharge,
                       (SELECT COUNT(*) > 0
                          FROM dids
                         WHERE dids.i_dids_charging_group = dcg.i_dids_charging_group) AS linked1,
                       (SELECT COUNT(*) > 0
                          FROM did_authorizations da
                         WHERE da.i_dids_charging_group = dcg.i_dids_charging_group) AS linked2
                  FROM dids_charging_groups dcg
                 WHERE dcg.i_customer = ? AND dcg.i_dids_charging_group = ?
                 LIMIT 1';
        $params = Array($this->i_customer, $i_dids_charging_group);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_dids_charging_group = $i_dids_charging_group;
        $this->type = $entry['type'];
        $this->name = $entry['name'];
        $this->description = $entry['description'];
        $this->connect_fee = $entry['connect_fee'];
        $this->free_seconds = $entry['free_seconds'];
        $this->grace_period = $entry['grace_period'];
        $this->price_1 = $entry['price_1'];
        $this->price_n = $entry['price_n'];
        $this->interval_1 = $entry['interval_1'];
        $this->interval_n = $entry['interval_n'];
        $this->iso_4217= $entry['iso_4217'];
        $this->price = $entry['price'];
        $this->setup_fee = $entry['setup_fee'];
        $this->post_call_surcharge = $entry['post_call_surcharge'];
        $this->linked = Cast::str2bool($entry['linked1']) || Cast::str2bool($entry['linked2']);
    }

    public function initFromRequest($par) {
        $this->i_dids_charging_group = $par['i_dids_charging_group'];
        $this->type = $par['type'];
        $this->name = $par['name'];
        $this->description = $par['description'];
        $this->connect_fee = $par['connect_fee'];
        $this->free_seconds = $par['free_seconds'];
        $this->grace_period = $par['grace_period'];
        $this->price_1 = $par['price_1'];
        $this->price_n = $par['price_n'];
        $this->interval_1 = $par['interval_1'];
        $this->interval_n= $par['interval_n'];
        $this->price = $par['price'];
        $this->setup_fee = $par['setup_fee'];
        if (!$this->linked) {
            $this->iso_4217 = $par['iso_4217'];
        }
    }

    public function genID() {
        global $db;

        return $db->nextID('dids_charging_groups_seq');
    }

    public function buildClause() {
        $fc = (Array) get_par('filter_clause');
        $ret = Array('sql' => '', 'params' => Array());

        if ($fc['name'] != '') {
            $ret['sql'] .= ' AND dcg.name ' . ($fc['name_clause'] ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = $fc['name'];
        }

        if ($fc['type'] != '') {
            $ret['sql'] .= ' AND dcg.type = ?';
            $ret['params'][] = $fc['type'];
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(*)
                  FROM dids_charging_groups dcg
                 WHERE dcg.i_customer = ?
                       {$clause['sql']}";
        $params = Array($this->i_customer);
        $params = array_merge($params, $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT dcg.i_dids_charging_group, dcg.name, dcg.description,
                       dcg.price, dcg.iso_4217, dcg.type,
                       (SELECT COUNT(*) = 0
                          FROM dids
                         WHERE dids.i_dids_charging_group = dcg.i_dids_charging_group) AND
                       (SELECT COUNT(*) = 0
                          FROM did_authorizations da
                         WHERE da.i_dids_charging_group = dcg.i_dids_charging_group) AND
                       (SELECT COUNT(*) = 0
                          FROM did_delegations dd
                         WHERE dd.i_dids_charging_group = dcg.i_dids_charging_group)
                         AS can_delete
                  FROM dids_charging_groups dcg
                 WHERE dcg.i_customer = ?
                       {$clause['sql']}
              ORDER BY dcg.name
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = Array($this->i_customer);
        $params = array_merge($params, $clause['params']);

        $ret = $db->getAll($sql, $params);

        foreach(array_keys($ret) as $key) {
            $ret[$key]['can_delete'] = Cast::str2bool($ret[$key]['can_delete']);
        }

        return $ret;
    }

    private function doesNameExist($name, $i_dids_charging_group = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM dids_charging_groups dcg
                 WHERE dcg.i_customer = ? AND dcg.name = ?
                       AND dcg.i_dids_charging_group <> ?';

        $params = Array($this->i_customer, $name, $i_dids_charging_group);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $i_dids_charging_group = 0) {
        global $db;

        if (!in_array($par['type'], Array(self::TYPE_SELLING, self::TYPE_BUYING))) {
            throw new Exception(_('"Type" field has incorrect value.'));
        }

        if ($par['name'] == '') {
            throw new Exception(_('"Name" field is mandatory.'));
        }

        if ($this->doesNameExist($par['name'], $i_dids_charging_group)) {
            throw new Exception(_('Another Charging Group with conflicting "Name" already exists.'));
        }

        if ($par['type'] == self::TYPE_SELLING) {
            if (!(Validator::isFloat($par['setup_fee'], TRUE) && $par['setup_fee'] >= 0)) {
                throw new Exception(_('"Setup Fee" field has incorrect number format. Non-negative number is expected.'));
            }

            if (!(Validator::isFloat($par['price'], TRUE) && $par['price'] >= 0)) {
                throw new Exception(_('"Monthly Fee" field has incorrect number format. Non-negative number is expected.'));
            }
        }

        if (!$this->linked) {
            $sql = 'SELECT COUNT(x.iso_4217)
                      FROM x_rates x
                      JOIN currencies c USING (iso_4217)
                     WHERE x.iso_4217 = ? AND x.i_customer = ?';
            $params = Array($par['iso_4217'], $this->i_customer);

            $c = $db->getValue($sql, $params);
            if ($c <= 0) {
                throw new Exception(_('"Currency" field has incorrect value.'));
            }
        }

        if (!(Validator::isFloat($par['connect_fee'], TRUE) && $par['connect_fee'] >= 0)) {
            throw new Exception(_('"Connect Fee" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isNumber($par['free_seconds'], TRUE) && $par['free_seconds'] >= 0)) {
            throw new Exception(_('"Free Seconds" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isNumber($par['grace_period'], TRUE) && $par['grace_period'] >= 0)) {
            throw new Exception(_('"Grace Period" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isFloat($par['price_1'], TRUE) && $par['price_1'] >= 0)) {
            throw new Exception(_('"Price 1" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isFloat($par['price_n'], TRUE) && $par['price_n'] >= 0)) {
            throw new Exception(_('"Price N" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isNumber($par['interval_1'], TRUE) && $par['interval_1'] >= 0)) {
            throw new Exception(_('"Interval 1" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isNumber($par['interval_n'], TRUE) && $par['interval_n'] > 0)) {
            throw new Exception(_('"Interval N" field has incorrect number format. Integer number greater than zero is expected.'));
        }

        if (!(Validator::isFloat($par['post_call_surcharge'], TRUE) && $par['post_call_surcharge'] >= 0)) {
            throw new Exception(_('"Post Call Surcharge" field has incorrect number format. Non-negative number is expected.'));
        }

    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $i_dids_charging_group = $this->genID();

        $sql = 'INSERT INTO dids_charging_groups (i_dids_charging_group, i_customer, name, description,
                                          connect_fee, free_seconds, grace_period, price_1,
                                          price_n, interval_1, interval_n, iso_4217,
                                          price, setup_fee, type, post_call_surcharge)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $params = Array($i_dids_charging_group, $this->i_customer, $par['name'],
                        $par['description'], $par['connect_fee'],
                        $par['free_seconds'], $par['grace_period'], $par['price_1'],
                        $par['price_n'], $par['interval_1'], $par['interval_n'],
                        $par['iso_4217'],
                        $par['type'] == self::TYPE_SELLING ? $par['price'] : $this->price,
                        $par['type'] == self::TYPE_SELLING ? $par['setup_fee'] : $this->setup_fee,
                        $par['type'], $par['post_call_surcharge'] / 100.0);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Charging Group."));
        }

        $this->getEntry($i_dids_charging_group);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $this->i_dids_charging_group);

        if (!$this->linked) {
            $add_sql = ', iso_4217 = ?';
            $add_params = Array($par['iso_4217']);
        }

        $sql = "UPDATE dids_charging_groups
                   SET name = ?, description = ?, connect_fee = ?,
                       free_seconds = ?, grace_period = ?, price_1 = ?,
                       price_n = ?, interval_1 = ?, interval_n = ?,
                       price = ?, setup_fee = ?, type = ?,
                       post_call_surcharge = ? $add_sql
                 WHERE i_dids_charging_group = ? AND i_customer = ?";

        $params = Array($par['name'], $par['description'],
                        $par['connect_fee'], $par['free_seconds'],
                        $par['grace_period'], $par['price_1'], $par['price_n'],
                        $par['interval_1'], $par['interval_n'],
                        $par['type'] == self::TYPE_SELLING ? $par['price'] : $this->price,
                        $par['type'] == self::TYPE_SELLING ? $par['setup_fee'] : $this->setup_fee,
                        $par['type'], $par['post_call_surcharge'] / 100.0);

        if (!$this->linked) {
            $params = array_merge($params, (Array)$add_params);
        }

        $params = array_merge($params, Array($this->i_dids_charging_group, $this->i_customer));

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Charging Group."));
        }

        $this->getEntry($this->i_dids_charging_group);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        if ($this->linked) {
            throw new Exception(_("Cannot delete Charging Group."));
        }

        $sql = 'DELETE FROM dids_charging_groups
                 WHERE i_dids_charging_group = ? AND i_customer = ?';
        $params = Array($this->i_dids_charging_group, $this->i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Charging Group."));
        }
    }

}

?>
