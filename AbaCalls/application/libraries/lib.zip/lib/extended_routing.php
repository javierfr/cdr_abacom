<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Extended_Routing {

    public $i_extended_routing;
    public $i_wholesaler;
    public $i_customer;
    public $i_routing_group;
    public $i_tariff;
    public $description;

    private $_fault;

    function __construct($i_wholesaler, $i_customer, $i_extended_routing = NULL) {
        $this->i_extended_routing = $i_extended_routing;
        $this->i_wholesaler = $i_wholesaler;
        $this->i_customer = $i_customer;
        $this->i_routing_group = NULL;
        $this->i_tariff = NULL;
        $this->description = '';

        $this->_fault = FALSE;

        if ($this->i_extended_routing !== NULL) {
            $this->getEntry($this->i_extended_routing);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_extended_routing) {
        global $db;

        $sql = 'SELECT er.i_extended_routing, er.i_wholesaler, er.i_customer, er.i_routing_group,
                       er.i_tariff, er.description
                  FROM extended_routing er
                 WHERE er.i_wholesaler = ? AND er.i_customer = ? AND
                       er.i_extended_routing = ?';
        $params = Array($this->i_wholesaler, $this->i_customer, $i_extended_routing);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_extended_routing = $entry['i_extended_routing'];
        $this->i_wholesaler = $entry['i_wholesaler'];
        $this->i_customer = $entry['i_customer'];
        $this->i_routing_group = $entry['i_routing_group'];
        $this->i_tariff = $entry['i_tariff'];
        $this->description = $entry['description'];
    }

    public function initFromRequest($par) {
        $this->i_extended_routing = $par['i_extended_routing'];
        $this->i_routing_group = $par['i_routing_group'];
        $this->i_tariff = $par['i_tariff'];
        $this->description = $par['description'];
    }

    public function genID() {
        global $db;

        return $db->nextID('extended_routing_seq');
    }

    public function getTotal() {
        global $db;

        $sql = "SELECT COUNT(*)
                  FROM extended_routing er
                 WHERE er.i_wholesaler = ? AND er.i_customer = ?";
        $params = Array($this->i_wholesaler, $this->i_customer);

        return $db->getValue($sql, $params);
    }

    public function reset_n($id) {
        global $db;

        $n = 0;

        $sql = "SELECT er.i_extended_routing AS id
                  FROM extended_routing er
                  JOIN routing_groups rg USING (i_routing_group)
             LEFT JOIN tariffs t USING (i_tariff)
                 WHERE er.i_wholesaler = ? AND er.i_customer = ?
              ORDER BY rg.name, t.name";
        $params = Array($this->i_wholesaler, $this->i_customer);

        $rows = $db->getAll($sql, $params);

        $i = 0;
        foreach ($rows as $row) {
            if ($i++ == ROW_PER_PAGE) {
                $n++;
                $i = 0;
            }
            if ($row['id'] == $id) {
                break;
            }
        }

        return $n;
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $sql = "SELECT er.i_extended_routing, er.i_wholesaler, er.i_customer, er.i_routing_group,
                       er.i_tariff, t.name || ' (' || t.iso_4217 || ')' AS tr_name,
                       rg.name AS rg_name, er.description,
                       (SELECT COUNT(c.*)
                          FROM customers c
                         WHERE c.i_routing_group = er.i_routing_group
                               AND c.i_wholesaler = ?)
                       +
                       (SELECT COUNT(er2.*)
                          FROM extended_routing er2
                         WHERE er2.i_routing_group = er.i_routing_group
                               AND er2.i_wholesaler = ?) = 0 AS can_delete
                  FROM extended_routing er
                  JOIN routing_groups rg USING (i_routing_group)
             LEFT JOIN tariffs t USING (i_tariff)
                 WHERE er.i_wholesaler = ? AND er.i_customer = ?
              ORDER BY rg.name, t.name";
        $params = Array($this->i_customer, $this->i_customer, $this->i_wholesaler, $this->i_customer);

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$r) {
            $r['can_delete'] = Cast::str2bool($r['can_delete']);
        }

        return $ret;
    }

    private function doesExtRtEntryExist($i_routing_group, $i_extended_routing = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM extended_routing er
                 WHERE er.i_wholesaler = ? AND er.i_customer = ? AND
                       er.i_routing_group = ? AND er.i_extended_routing <> ?';

        $params = Array($this->i_wholesaler, $this->i_customer, $i_routing_group, $i_extended_routing);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $i_extended_routing = 0) {
        global $db;


        if ($i_extended_routing === 0 && $par['i_routing_group'] <= 0 ) {
            throw new Exception(_('"Routing Group" field is mandatory.'));
        }

        if (($this->i_wholesaler == 1 && $par['i_tariff'] <= 0) ||
            ($this->i_wholesaler > 1 && $par['i_tariff'] < 0)) {
            throw new Exception(_('"Tariff" field is mandatory.'));
        }

        if ($i_extended_routing === 0) {
            if ($this->doesExtRtEntryExist($par['i_routing_group'], $i_extended_routing)) {
                throw new Exception(_('Conflicting Extended Routing entry already exists.'));
            }

            if ($this->i_wholesaler == 1) {
                $sql = 'SELECT COUNT(*)
                          FROM routing_groups rg
                         WHERE rg.i_routing_group = ?
                               AND rg.i_routing_group NOT IN (
                               SELECT er.i_routing_group
                                 FROM extended_routing er
                                WHERE er.i_customer = ?)
                               AND rg.i_routing_group NOT IN (
                               SELECT c.i_routing_group
                                 FROM customers c
                                WHERE c.i_customer = ?
                               )';
                $params = Array($par['i_routing_group'], $this->i_cusotmer, $this->i_customer);
            } else {
                $sql = 'SELECT COUNT(*)
                          FROM routing_groups rg
                          JOIN extended_routing er USING (i_routing_group)
                         WHERE rg.i_routing_group = ? AND er.i_customer = ? AND
                               rg.i_routing_group NOT IN (
                               SELECT er2.i_routing_group
                                 FROM extended_routing er2
                                WHERE er2.i_customer = ?
                               ) AND rg.i_routing_group NOT IN (
                               SELECT c.i_routing_group
                                 FROM customers c
                                WHERE c.i_customer = ?
                               )';
                $params = Array($par['i_routing_group'], $this->i_wholesaler, $this->i_customer, $this->i_customer);
            }

            $c = $db->getValue($sql, $params);
            if ($c != 1) {
                throw new Exception(_('You cannot use this Routing Group.'));
            }
        }

        if (($this->i_wholesaler == 1) || ($this->i_wholesaler > 1 && $par['i_tariff'] > 0)) {
            $sql = 'SELECT COUNT(*)
                      FROM tariffs t, customers c
                     WHERE t.i_tariff = ? AND t.i_owner = ? AND
                           c.i_customer = ? AND c.base_currency = t.iso_4217';
            $params = Array($par['i_tariff'], $this->i_wholesaler, $this->i_customer);
        } else {        // own tariff
            $sql = 'SELECT COUNT(*)
                      FROM customers c, customers c2
                     WHERE c2.i_customer = c.i_wholesaler AND c.base_currency = c2.base_currency AND
                           c.i_customer = ? AND c.i_wholesaler = ?';
            $params = Array($this->i_customer, $this->i_wholesaler);
        }

        $c = $db->getValue($sql, $params);
        if ($c != 1) {
            throw new Exception(_('You cannot use this Tariff.'));
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $i_extended_routing = $this->genID();

        $sql = 'INSERT INTO extended_routing (i_extended_routing, i_wholesaler, i_customer,
                                              i_routing_group, i_tariff, description)
                     VALUES (?, ?, ?, ?, ?, ?)';
        $params = Array($i_extended_routing, $this->i_wholesaler, $this->i_customer,
                        $par['i_routing_group'],
                        $par['i_tariff'] > 0 ? $par['i_tariff'] : NULL,
                        $par['description']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Extended Routing entry."));
        }

        $this->getEntry($i_extended_routing);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $par['i_extended_routing']);

        $sql = 'UPDATE extended_routing
                   SET i_tariff = ?, description = ?
                 WHERE i_extended_routing = ? AND i_wholesaler = ? AND i_customer = ?';
        $params = Array($par['i_tariff'] > 0 ? $par['i_tariff'] : NULL,
                        $par['description'], $par['i_extended_routing'],
                        $this->i_wholesaler, $this->i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Extended Routing entry."));
        }

        $this->getEntry($par['i_extended_routing']);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        $sql = 'DELETE FROM extended_routing er
                 WHERE er.i_extended_routing = ? AND er.i_wholesaler = ? AND er.i_customer = ? AND
                       (SELECT COUNT(c.*)
                          FROM customers c
                         WHERE c.i_routing_group = er.i_routing_group
                               AND c.i_wholesaler = ?)
                       +
                       (SELECT COUNT(er2.*)
                          FROM extended_routing er2
                         WHERE er2.i_routing_group = er.i_routing_group
                               AND er2.i_wholesaler = ?) = 0';
        $params = Array($par['i_extended_routing'], $this->i_wholesaler, $this->i_customer,
                        $this->i_customer, $this->i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Extended Routing entry."));
        }
    }

}

?>
