<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Deleted_Account {

    public $i_account;
    public $i_customer;

    private $_fault;
    private $_operator;

    function __construct($i_customer, $i_account = NULL) {

        $this->i_customer = $i_customer;
        $this->i_account = $i_account;

        if ($this->i_account !== NULL) {
            $this->getEntry($this->i_account);
        }

        $this->_fault = FALSE;
        $this->_operator = Operator::get();
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_account) {
        global $db;

        $sql = "SELECT a.*, c.*, extract(epoch from (a.deleted_on)) AS deleted_on,
                       extract(epoch from (a.expiration_date)) AS expired_on,
                       (CASE WHEN a.expiration_date IS NULL THEN FALSE
                             ELSE a.expiration_date < now() AND a.first_use IS NOT NULL END) AS is_expired,
                       extract(epoch from a.first_use) AS first_use,
                       extract(epoch from last_login) AS last_login,
                       extract(epoch from last_password_change) AS last_password_change,
                       bp.i_billing_plan AS billing_plan_deleted,
                       tz.tz AS tz, l.name AS language,
                       rg.i_routing_group AS routing_group_deleted,
                       pt.encoding_name AS preferred_codec,
                       mrt.name AS media_relay_type,
                       et.name AS export_type,
                       pp.i_password_policy AS password_policy_deleted,
                       ac.i_account_class AS account_class_deleted,
                       (a.i_commission_agent NOTNULL AND ca.i_customer ISNULL) AS commission_agent_deleted,
                       ct.name AS payment_method, it.name AS invoice_template,
                       a.followme_enabled, a.vm_dialin_access, a.hide_own_cli,
                       a.block_incoming_anonymous, a.i_incoming_anonymous_action,
                       a.dncl_lookup, a.deleted_by, a.generate_ringbacktone,
                       a.allow_free_onnet_calls, a.start_page
                  FROM deleted_accounts a
                  JOIN contacts c USING (i_contact)
             LEFT JOIN billing_plans bp USING (i_billing_plan)
             LEFT JOIN time_zones tz USING (i_time_zone)
             LEFT JOIN languages l USING (i_lang)
             LEFT JOIN routing_groups rg USING (i_routing_group)
             LEFT JOIN payload_types pt ON (pt.i_payload_type = a.preferred_codec)
             LEFT JOIN media_relay_types mrt USING (i_media_relay_type)
             LEFT JOIN export_types et USING (i_export_type)
             LEFT JOIN password_policies pp USING (i_password_policy)
             LEFT JOIN account_classes ac USING (i_account_class)
             LEFT JOIN customers ca ON (a.i_commission_agent = ca.i_customer)
             LEFT JOIN card_types ct ON (a.payment_method = ct.i_card_type)
             LEFT JOIN invoice_templates it ON (a.i_invoice_template = it.i_invoice_template)
                 WHERE a.i_customer = ? AND a.i_account = ?
                 LIMIT 1";
        $entry = $db->getAssociatedArray($sql, Array($this->i_customer, $i_account));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        /* fetch balance */
        $params = Array("i_customer" => new xmlrpcval($this->i_customer, "int"),
                        "i_balance" => new xmlrpcval($entry['i_balance'], "int"),
                       );
        $bal_clnt = new Balanced_Client('getBalanceInfo', $params);
        $ret2 = $bal_clnt->get();
        if (!$ret2) {
            error_log('unable to fetch balance info: i_account = ' . $i_account . ', i_balance = ' . $ret['i_balance']);
            $entry['balance'] = 'NaN';
            $entry['credit_limit'] = 'NaN';
        } else {
            $entry['balance'] = $ret2['balance_info']['balance'];
            $entry['credit_limit'] = $ret2['balance_info']['credit_limit'];
        }

        foreach ($entry as $key => $value) {
            $this->$key = $value;
        }
    
        $this->hide_own_cli = Cast::str2bool($this->hide_own_cli);
        $this->block_incoming_anonymous = Cast::str2bool($this->block_incoming_anonymous);
        $this->is_expired = Cast::str2bool($this->is_expired);
        $this->pass_p_asserted_id = Cast::str2bool($this->pass_p_asserted_id);
        $this->dncl_lookup = Cast::str2bool($this->dncl_lookup);
        $this->deleted_by = parse_operator_name($this->deleted_by);
        $this->generate_ringbacktone = Cast::str2bool($this->generate_ringbacktone);
        $this->allow_free_onnet_calls = Cast::str2bool($this->allow_free_onnet_calls);
    }

    public function initFromRequest($par) {
        $this->i_account = $par['i_account'];
        $this->i_routing_group = $par['i_routing_group'];
        $this->i_billing_plan = $par['i_billing_plan'];
        $this->i_password_policy = $par['i_password_policy'];
        $this->i_account_class = $par['i_account_class'];
        $this->i_commission_agent = $par['i_commission_agent'];
    }

    public static function buildClause() {
        global $acct_clause, $acct_pattern, $bt_clause, $bt_pattern,
               $del_clause, $del_pattern, $start_id, $end_id, $account_class;

        $ret = Array('sql' => '', 'params' => Array());

        if ($acct_pattern != '') {
            $ret['sql'] .= ' AND a.username ' . ($acct_clause ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = $acct_pattern;
        }

        /* Batch Tag */
        if ($bt_pattern != '') {
            $ret['sql'] .= " AND a.batch_tag " . ($bt_clause ? "NOT " : "") . "LIKE ?";
            $ret['params'][] = $bt_pattern;
        }

        /* Deletion date */
        $a = strtoupper(trim($del_pattern));
        $b = $del_clause;
        switch($a) {
            case 'ANY':
                /* do not apply this clause */
                break;
            default:
                /* try to parse user's input */
                $a = preg_replace('/(.*)\s+FROM\s+NOW$/', '${1}', $a);
                if (strtotime($a) == false) {       /* unparsable value */
                    $ret['sql'] .= " AND FALSE";
                    break;
                }
                $d = parse_date($a);
                switch($b) {
                    case 1:         /* Deleted before */
                        $ret['sql'] .= " AND a.deleted_on <= ?";
                        $ret['params'][] = $d;
                        break;
                    case 2:         /* Deleted after */
                        $ret['sql'] .= " AND a.deleted_on > ?";
                        $ret['params'][] = $d;
                        break;
                    case 0:         /* Deleted on */
                    default:
                        $ret['sql'] .= " AND date_trunc('day', a.deleted_on) = date_trunc('day', CAST(? AS timestamp))";
                        $ret['params'][] = $d;
                        break;
                }
                break;
        }

        /* Start ID */
        if ($start_id != 'Any' && $start_id != '') {
            $ret['sql'] .= " AND a.i_account >= ?";
            $ret['params'][] = $start_id;
        }

        /* End ID */
        if ($end_id != 'Any' && $end_id != '') {
            $ret['sql'] .= " AND a.i_account <= ?";
            $ret['params'][] = $end_id;
        }

        /* Class */
        if ($account_class > 0) {
            $ret['sql'] .= " AND a.i_account_class = ?";
            $ret['params'][] = $account_class;
        }

        return $ret;
    }

    public static function getTotal($i_customer) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT COUNT(*)
                  FROM deleted_accounts a
                 WHERE a.i_customer = ?
                       {$clause['sql']}";
        $params = array_merge(Array($i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public static function getList($i_customer, $off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT a.i_account, a.username, a.description, a.i_balance,
                       extract(epoch from (a.deleted_on)) AS deleted_on, a.base_currency
                  FROM deleted_accounts a
                 WHERE a.i_customer = ?
                       {$clause['sql']}
              ORDER BY a.username, a.deleted_on DESC
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($i_customer), $clause['params']);

        $rows = $db->getAll($sql, $params);

        $i_balances = Array();
        $bi_map = Array();

        foreach ($rows as $r) {
            $i_balances[] = new xmlrpcval($r['i_balance'], "int");
        }

        /* fetch balance */
        $params = Array("i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
                        "i_balances" => new xmlrpcval($i_balances, 'array'),
                                       );
        $bal_clnt = new Balanced_Client('getBalances', $params);
        $bal_infos = $bal_clnt->get();

        if (!$bal_infos) {
            error_log('unable to fetch balances');
            $rows2 = Array();
            while ($a = array_shift($rows)) {
                $a['balance'] = 'NaN';
                $a['credit_limit'] = 'NaN';
                $rows2[] = $a;
            }
            $rows = $rows2;
        } else {
            /* map balance infos */
            while ($b = array_pop($bal_infos['balance_infos'])) {
                $bi_map[$b['i_balance']] = Array(
                    'balance' => $b['balance'],
                    'credit_limit' => $b['credit_limit'],
                );
            }
        }

        foreach ($rows as &$r) {
            if (array_key_exists($r['i_balance'], $bi_map)) {
                $r['balance'] = $bi_map[$r['i_balance']]['balance'];
                $r['credit_limit'] = $bi_map[$r['i_balance']]['credit_limit'];
            } else {
                $r['balance'] = 'NaN';
                $r['credit_limit'] = 'NaN';
            }
        }

        return $rows;
    }

    public function restore($par) {
        global $db;

        $this->setFault(TRUE);

        $params['i_customer'] = new xmlrpcval($_SESSION['uid'], "int");
        $params['i_account'] = new xmlrpcval($par['i_account'], "int");
        if (isset_par('i_routing_group')) {
            $params['i_routing_group'] = new xmlrpcval($par['i_routing_group'],
                                                       empty($par['i_routing_group']) ? 'null' : "int");
        }
        if (isset_par('i_billing_plan')) {
            $params['i_billing_plan'] = new xmlrpcval($par['i_billing_plan'], "int");
        }
        if (isset_par('i_password_policy')) {
            $params['i_password_policy'] = new xmlrpcval($par['i_password_policy'], "int");
        }
        if (isset_par('i_account_class')) {
            $params['i_account_class'] = new xmlrpcval($par['i_account_class'], "int");
        }
        if (isset_par('i_commission_agent')) {
            $params['i_commission_agent'] = new xmlrpcval($par['i_commission_agent'],
                                                          empty($par['i_commission_agent']) ? 'null' : "int");
        }

        $params['updated_by'] = new xmlrpcval($this->_operator, "string");
        $params['audit_info'] = new xmlrpcval(Audit_Info::get(), "struct");

        $params = array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('restoreAccount', $params);

        $master_addr = get_master_XMLRPC_server();

        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(_("Unable to restore the account. Please report this issue to the system administrator."));
        }

        $this->i_account = $par['i_account'];

        $this->setFault(FALSE);
    }

}

?>
