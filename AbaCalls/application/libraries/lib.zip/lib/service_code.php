<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id php,v 1.1 2010/01/29 20:10:02 geka Exp $

class Service_Code {
    const CALL_FORWADING_ENABLE            = 1;
    const CALL_FORWADING_DISABLE           = 2;
    const DND_ENABLE                       = 3;
    const DND_DISABLE                      = 4;
    const BLOCK_INCOMING_ANONYMOUS_CALLS   = 5;
    const UNBLOCK_INCOMING_ANONYMOUS_CALLS = 6;
    const CALL_BLOCK_ADD_LAST_CALLERI      = 7;
    const CALL_BLOCK_REMOVE_LAST_CALLER    = 8;
}

class Account_Service_Codes {
    public $i_account_class;
    public $i_customer;
    public $sc_1;
    public $sc_2;
    public $sc_3;
    public $sc_4;
    public $sc_5;
    public $sc_6;
    public $sc_7;
    public $sc_8;

    function __construct($i_customer, $i_account) {
        $this->i_customer = $i_customer;
        $this->i_account = $i_account;
        $this->sc_1 = NULL;
        $this->sc_2 = NULL;
        $this->sc_3 = NULL;
        $this->sc_4 = NULL;
        $this->sc_5 = NULL;
        $this->sc_6 = NULL;
        $this->sc_7 = NULL;
        $this->sc_8 = NULL;

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;

        $sql = 'SELECT a.i_account
                  FROM accounts a
                 WHERE a.i_customer = ? AND a.i_account = ?
                 LIMIT 1';

        $db->prepNexec($sql, Array($this->i_customer, $this->i_account));
        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->sc_1 = new Account_Service_Code(Service_Code::CALL_FORWADING_ENABLE, $this->i_account);
        $this->sc_2 = new Account_Service_Code(Service_Code::CALL_FORWADING_DISABLE, $this->i_account);
        $this->sc_3 = new Account_Service_Code(Service_Code::DND_ENABLE, $this->i_account);
        $this->sc_4 = new Account_Service_Code(Service_Code::DND_DISABLE, $this->i_account);
        $this->sc_5 = new Account_Service_Code(Service_Code::BLOCK_INCOMING_ANONYMOUS_CALLS, $this->i_account);
        $this->sc_6 = new Account_Service_Code(Service_Code::UNBLOCK_INCOMING_ANONYMOUS_CALLS, $this->i_account);
        $this->sc_7 = new Account_Service_Code(Service_Code::CALL_BLOCK_ADD_LAST_CALLERI, $this->i_account);
        $this->sc_8 = new Account_Service_Code(Service_Code::CALL_BLOCK_REMOVE_LAST_CALLER, $this->i_account);
    }

    public function initFromRequest($par) {
        $this->sc_1->initFromRequest($par);
        $this->sc_2->initFromRequest($par);
        $this->sc_3->initFromRequest($par);
        $this->sc_4->initFromRequest($par);
        $this->sc_5->initFromRequest($par);
        $this->sc_6->initFromRequest($par);
        $this->sc_7->initFromRequest($par);
        $this->sc_8->initFromRequest($par);
    }

    public function update($par) {
        Account_Service_Code::delete($this->i_account);

        $this->sc_1->update($par);
        $this->sc_2->update($par);
        $this->sc_3->update($par);
        $this->sc_4->update($par);
        $this->sc_5->update($par);
        $this->sc_6->update($par);
        $this->sc_7->update($par);
        $this->sc_8->update($par);

        $this->getEntry();
    }
}

class Account_Service_Code {
    public $i_service_code;
    public $i_account;
    public $description;
    public $def_code;
    public $code;
    public $js_code;

    function __construct($i_service_code, $i_account) {
        $this->i_service_code = $i_service_code;
        $this->i_account = $i_account;
        $this->description = '';
        $this->def_code = '';
        $this->code = '';
        $this->js_codes = '';

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;

        $sql = 'SELECT sc.i_service_code as i_service_code,
                       sc.description as description,
                       sc.def_code as def_code,
                       acsc.code as code
                  FROM service_codes sc
             LEFT JOIN accounts_service_codes acsc ON (acsc.i_service_code = sc.i_service_code AND acsc.i_account = ?)
                 WHERE sc.i_service_code = ?';
        $params = Array($this->i_account, $this->i_service_code);

        $res = $db->getAll($sql, $params);
        if ($db->affected_rows < 1) {
            throw new Exception("No such Id.");
        }

        $this->description = $res[0]['description'];
        $this->def_code    = $res[0]['def_code'];

        $codes = Array();
        foreach ($res as $entry) {
            $codes[] = $entry['code'];
        }

        $this->code = implode(",", $codes);
        if ($this->code == '') {
            $this->code = 'default';
        }

        $js_codes = Array("[['default'], ['Default']]",
                          "[['disabled'],['Disabled']]");
        if ($this->code == 'default' || $this->code == 'disabled') {
            $js_codes[] = "[['" . Esc::js($this->def_code) . "'],['" . Esc::js($this->def_code) . "']]";
        } else {
            $js_codes[] = "[['" . Esc::js($this->code) ."'],['" . Esc::js($this->code) . "']]";
        }

        $this->js_codes = implode(",", $js_codes);
    }

    public function initFromRequest($par) {
        $code = $par['service_code_' . $this->i_service_code];

        $this->code = $code;
        
        $js_codes = Array("[['default'], ['Default']]",
                          "[['disabled'],['Disabled']]");
        if ($code != '' && $code != 'disabled' && $code != 'default' && $code != $this->def_code) {
            $js_codes[] = "[['" . Esc::js($code)  . "'],['" . Esc::js($code) . "']]";
        } else {
            $js_codes[] = "[['" . Esc::js($this->def_code) ."'],['" . Esc::js($this->def_code) . "']]";
        }
        $this->js_codes = implode(",", $js_codes);
    }

    private function doesCodeExist($code) {
        global $db;
            
        if($code  == 'disabled') return 0;
        $sql = 'SELECT COUNT(*)
                  FROM accounts_service_codes 
                 WHERE i_account = ? AND code = ? AND
                       i_service_code <> ?';

        $params = Array($this->i_account, $code, $this->i_service_code);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par) {
        $code = $par['service_code_' . $this->i_service_code];

        if ($code != 'disabled' && $code != 'default') {
            if (!(Validator::isServiceCodesList($code, TRUE))) {
                throw new Exception(sprintf(_('"%s" has wrong format. *NN list separated by comma is expected.'),
                                            _($this->description)));
            }

            $codes = explode(',', $code);
            foreach ($codes as $c) {
                if ($this->doesCodeExist(trim($c))) {
                    throw new Exception(sprintf(_('"%s" uses conflicting Service Code.'), _($this->description)));
                }
            }
        }
    }

    public function update($par, $i_account = NULL) {
        global $db;

        if ($i_account !== NULL) {
            $this->i_account = $i_account;
        }

        $this->validate($par);

        $codes = explode(',', $par['service_code_' . $this->i_service_code]);
        if ($codes[0] != 'default') {
            foreach ($codes as $code) {
                $sql = 'INSERT INTO accounts_service_codes (i_account, i_service_code, code)
                             VALUES (?, ?, ?)';
                $params = Array($this->i_account, $this->i_service_code, trim($code));

                if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
                    throw new Exception(_("Cannot update Service Code."));
                }
            }
        }

        $this->getEntry();
    }

    public static function delete($i_account) {
        global $db;

        $sql = 'DELETE FROM accounts_service_codes
                 WHERE i_account = ?';
        $params = Array($i_account);
        $db->prepNexec($sql, $params);
    }
}

class Account_Class_Service_Code {
    public $i_service_code;
    public $i_account_class;
    public $description;
    public $def_code;
    public $code;
    public $js_code;

    function __construct($i_service_code, $i_account_class = NULL) {
        $this->i_service_code = $i_service_code;
        $this->i_account_class = $i_account_class;
        $this->description = '';
        $this->def_code = '';
        $this->code = '';
        $this->js_codes = '';

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;

        if ($this->i_account_class !== NULL) {
            $sql = 'SELECT ac.i_account_classes_service_code, ac.code,
                           sc.def_code, sc.description
                      FROM service_codes sc
                 LEFT JOIN account_classes_service_codes ac
                           ON (ac.i_service_code = sc.i_service_code AND ac.i_account_class = ?)
                     WHERE sc.i_service_code = ?';
            $params = Array($this->i_account_class, $this->i_service_code);
        } else {
            $sql = 'SELECT sc.def_code, sc.description
                      FROM service_codes sc
                     WHERE sc.i_service_code = ?';
            $params = Array($this->i_service_code);
        }

        $res = $db->getAll($sql, $params);
        if ($db->affected_rows < 1) {
            throw new Exception("No such Id.");
        }

        $this->description = $res[0]['description'];
        $this->def_code    = $res[0]['def_code'];

        $codes = Array();
        foreach ($res as $entry) {
            $codes[] = $entry['code'];
        }

        $this->code = implode(",", $codes);
        if ($this->code == '') {
            $this->code = 'disabled';
        }

        $js_codes = Array("[['disabled'],['Disabled']]");
        if ($this->code == 'disabled') {
            $js_codes[] = "[['" . Esc::js($this->def_code) ."'],['" . Esc::js($this->def_code) . "']]";
        } else {
            $js_codes[] = "[['" . Esc::js($this->code)  . "'],['" . Esc::js($this->code) . "']]";
        }
        $this->js_codes = implode(",", $js_codes);
    }

    public function initFromRequest($par) {
        $code = $par['service_code_' . $this->i_service_code];

        $this->code = $code;
        
        $js_codes = Array("[['disabled'],['Disabled']]");
        if ($code != '' && $code != 'disabled' && $code != $this->def_code) {
            $js_codes[] = "[['" . Esc::js($code)  . "'],['" . Esc::js($code) . "']]";
        } else {
            $js_codes[] = "[['" . Esc::js($this->def_code) ."'],['" . Esc::js($this->def_code) . "']]";
        }
        $this->js_codes = implode(",", $js_codes);
    }

    private function doesCodeExist($code) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM account_classes_service_codes ac
                 WHERE ac.i_account_class = ? AND ac.code = ? AND
                       ac.i_service_code <> ?';

        $params = Array($this->i_account_class, $code, $this->i_service_code);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par) {
        $code = $par['service_code_' . $this->i_service_code];

        if ($code != 'disabled') {
            if (!(Validator::isServiceCodesList($code, TRUE))) {
                throw new Exception(sprintf(_('"%s" has wrong format. *NN list separated by comma is expected.'),
                                            _($this->description)));
            }

            $codes = explode(',', $code);
            foreach ($codes as $c) {
                if ($this->doesCodeExist(trim($c))) {
                    throw new Exception(sprintf(_('"%s" uses conflicting Service Code.'), _($this->description)));
                }
            }
        }
    }

    public function update($par, $i_account_class = NULL) {
        global $db;

        if ($i_account_class !== NULL) {
            $this->i_account_class = $i_account_class;
        }

        $this->validate($par);

        $codes = explode(',', $par['service_code_' . $this->i_service_code]);
        if ($codes[0] != 'disabled') {
            foreach ($codes as $code) {
                $sql = 'INSERT INTO account_classes_service_codes (i_account_class, i_service_code, code)
                             VALUES (?, ?, ?)';
                $params = Array($this->i_account_class, $this->i_service_code, trim($code));

                if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
                    throw new Exception(_("Cannot update Service Code."));
                }
            }
        }

        $this->getEntry();
    }

    public static function delete($i_account_class) {
        global $db;

        $sql = 'DELETE FROM account_classes_service_codes
                 WHERE i_account_class = ?';
        $params = Array($i_account_class);
        $db->prepNexec($sql, $params);
    }
}

?>
