<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Esc {
    public static function js($string) {
        // escape quotes and backslashes, newlines, etc.
        return strtr($string, array('\\'=>'\\\\',"'"=>"\\'",'"'=>'\\"',"\r"=>'\\r',"\n"=>'\\n','</'=>'<\/'));
    }
}

class CastBadValue extends Exception {};

class Cast {
    public static function str2bool($val, $allow_empty = TRUE, $default = FALSE) {
        $t = Array('true', 'yes', 'on', 'y', 't', '1');
        $f = Array('false', 'no', 'off', 'n', 'f', '0');

        $val_orig = $val;
        $val = strtolower(trim($val));

        if ($allow_empty && $val == '') {
            return $default;
        }

        if (in_array($val, $t)) {
            return TRUE;
        } elseif (in_array($val, $f)) {
            return FALSE;
        }

        throw new CastBadValue('Unable to cast "' . $val_orig . '" to boolean type.');
    }

    public static function bool2str($val) {
        if ($val === TRUE) {
            return 'true';
        } elseif ($val === FALSE) {
            return 'false';
        }

        throw new CastBadValue('Unable to cast boolean to string type.');
    }
}

class Validator {
    public static function isEmail($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }
        return preg_match('/^\s*[a-z0-9][\w.+-]*@(([a-z0-9][\w\-\.]+\.[a-z0-9]{2,6})|(localhost))\s*$/i', $val);
    }

    public static function isEmailsList($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }
        return preg_match('/^\s*[a-z0-9][\w.+-]*@(([a-z0-9][\w\-\.]+\.[a-z0-9]{2,6})|(localhost))(\s*,\s*[a-z0-9][\w.+-]*@(([a-z0-9][\w\-\.]+\.[a-z0-9]{2,6})|(localhost)))*\s*$/i', $val);
    }

    public static function isFloat($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }
        return preg_match('/^([-+])?\d+(\.\d*)?$/', $val);
    }

    public static function isNumber($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }
        return preg_match('/^([-+])?\d+$/', $val);
    }

    public static function isPrefix($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }
        return preg_match('/^[0-9a-zA-Z_#*]+$/', $val);
    }

    public static function isIncomingPrefix($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }
        return preg_match('/^\+?[a-zA-Z0-9.#_-]+$/', $val);
    }

    public static function isServiceCodesList($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }
        return preg_match('/^\s*\*\d\d(\s*,\s*\*\d\d)*\s*$/', $val);
    }

    public static function isASCII($val, $mandatory = FALSE) {
        if ($mandatory && $val == '') {
            return FALSE;
        }
        return iconv("UTF-8", "ISO-8859-1//IGNORE", $val) === $val;
    }

    public static function isTransRule($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }

        $params = Array(new xmlrpcval(Array(
            "rule" => new xmlrpcval($val, "string"),
            "number" => new xmlrpcval('1234567890', "string")
        ), 'struct'));
        $msg = new xmlrpcmsg('applyTranslationRule', $params);

        $master_addr = get_master_XMLRPC_server();

        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            return FALSE;
        }

        return TRUE;
    }

    public static function isRegularExpression($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }

        $params = Array(new xmlrpcval(Array(
            "reg_exp" => new xmlrpcval($val, "string")
        ), 'struct'));
        $msg = new xmlrpcmsg('isValidRegularExpression', $params);

        $master_addr = get_master_XMLRPC_server();

        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);

        if ($res->faultCode()) {
            return FALSE;
        }

        return TRUE;
    }

    public static function isIPAddress($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }

        if (!preg_match('/^(\d{1,3}\.){3}\d{1,3}$/', $val)) {
            return FALSE;
        }                

        foreach (explode('.', $val) as $o) {
            if (($o < 0) || ($o > 255)) {
                return FALSE;
            }    
        }

        return TRUE;
    }

    public static function isNetmask($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }

        if (!preg_match('/^(\d{1,3}\.){3}\d{1,3}$/', $val)) {
            return FALSE;
        }                

        $bin = '';
        foreach (explode('.', $val) as $o) {
            $bin .= decbin($o);
            if (($o < 0) || ($o > 255)) {
                return FALSE;
            }    
        }

        if (!preg_match('/^(1*0+|1+|0+)$/', $bin)) {
            return FALSE;
        }

        return TRUE;
    }

    public static function isPort($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }

        $ret = preg_match('/^\d+$/', $val);

        return $ret && $val > 0 && $val <= 65535;
    }

    public static function isHostname($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }

        if (strlen($val) > 255) {
            return FALSE;
        }

        // strip exactly one dot from the right, if present
        if (substr($val, -1) == '.') {
            $val = substr_replace($val, "", -1);
        }

        $parts = explode('.', $val);
        foreach($parts as $part) {
            if (!preg_match('/^(?!-)[A-Z\d-]{1,63}(?<!-)$/i', $part)) {
                return FALSE;
            }
        }

        return TRUE;
    }

    public static function isDestination($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }

        if (strpos($val, ':') !== FALSE) {
            list($host, $port) = explode(':', $val, 2);
        } else {
            $host = $val;
            $port = NULL;
        }

        $ret = self::isHostname($host, TRUE);
        if ($ret && $port !== NULL) {
            $ret = self::isPort($port, TRUE);
        }

        return $ret;
    }

    public static function isVMPassword($val, $mandatory = FALSE) {
        if (!$mandatory && $val == '') {
            return TRUE;
        }

        if (!preg_match("/^[0-9]+$/", $val)) {
            return FALSE;
        }

        return TRUE;
    }
}

class Redirector {
    public static function redirect($url) {
        header("Location: $url");
        exit();
    }

    public static function redirect_by_post($url, $params) {
        global $smarty;

        $smarty->assign(array(
            "url" => $url,
            "params" => $params,
        ));
        $smarty->display('redirect_by_post.tpl');
        exit();
    }
}

class Referer {
    public static function get() {
        if (get_par('return_to_referer') && get_par('referer_override')) {
            $referer = get_par('referer_override');
        } elseif (get_par('return_to_referer') && !empty($_SERVER['HTTP_REFERER'])) {
            $referer = $_SERVER['HTTP_REFERER'];
        } elseif (empty($_SERVER['HTTP_REFERER']) ||
                  substr_count($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])) {
            $referer = '/index.php';
        } else {
            $referer = $_SERVER['HTTP_REFERER'];
        }

        return $referer;
    }
}

class Maintenance_Mode {
    public static function check($is_root) {
        global $db;

        $mode = $db->getValue('SELECT web_maintenance_mode FROM system LIMIT 1');

        switch ($mode) {
            case '2':                       /* system update */
                if (!$is_root) {
                    Redirector::redirect('/login.php?show_mntm_msg=1');
                }
                break;

            case '0':                       /* off */
            case '1':                       /* CDRs update */
            default:
                break;
        }

        return $mode;

    }

    public static function set($is_root) {
        $_SESSION['maintenance_mode'] = self::check($is_root);
    }
}

class Start_Page {
    public static function getList($is_root, $type, $subtype = NULL) {
        $ret = Array();
        
        switch ($type) {
        case WEB_Session::TYPE_CUSTOMER:
                if (!$is_root) {
                    array_push($ret, array('val' => '1', 'name' => _('My CDRs'), 'redirect' => 'cdrs_customer_self.php'));
                }

                array_push($ret, array('val' => '3', 'name' => _('Call Records (CDRs)'), 'redirect' => 'cdrs_customer.php'));

                if ($subtype == WEB_Session::TYPE_WEB_USER) {
                    array_push($ret, array('val' => '4', 'name' => _('My Preferences'), 'redirect' => 'web_user_prefs.php'));
                } else {
                    array_push($ret, array('val' => '4', 'name' => _('My Preferences'), 'redirect' => 'customer_prefs.php'));
                }

                if ($is_root) {
                    if (is_root_environment()) {
                        array_push($ret, array('val' => '5', 'name' => _('Monitoring'), 'redirect' => 'show_graphs.php'));
                    }
                    array_push($ret, array('val' => '6', 'name' => _('Active Calls'), 'redirect' => 'activecalls.php'));
                    array_push($ret, array('val' => '7', 'name' => _('Vendors CDRs'), 'redirect' => 'cdrs_vend.php'));
                    if (is_root_environment()) {
                        array_push($ret, array('val' => '8', 'name' => _('Environments'), 'redirect' => 'environments.php'));
                    }
                }

                break;

            case WEB_Session::TYPE_ACCOUNT:
                array_push($ret, array('val' => '1', 'name' => _('Calls History'), 'redirect' => 'cdrs.php'));
                array_push($ret, array('val' => '4', 'name' => _('My Preferences'), 'redirect' => 'account_prefs.php'));
                break;

            case WEB_Session::TYPE_VENDOR:
                array_push($ret, array('val' => '1', 'name' => _('Calls History'), 'redirect' => 'cdrs_vendor.php'));
                array_push($ret, array('val' => '4', 'name' => _('My Preferences'), 'redirect' => 'vendor_prefs.php'));
                break;
        }

        return $ret;
    }
}

class System_Info {
    public static function get() {
        global $db;

        return $db->getAssociatedArray('SELECT * FROM system LIMIT 1');
    }
}

class Access_Level {

    public $i_access_level;
    public $name;
    public $full_access;
    public $menu_template;
    public $rights;

    function __construct($i_access_level, $i_page) {
        $this->i_access_level = $i_access_level;
        $this->name = '';
        $this->full_access = FALSE;
        $this->menu_template = '';
        $this->rights = NULL;

        if ($this->i_access_level !== NULL) {
            $this->getEntry($this->i_access_level, $i_page);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_access_level, $i_page) {
        global $db;

        $sql = 'SELECT *
                  FROM access_levels a
                 WHERE a.i_access_level = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($i_access_level));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_access_level = $entry['i_access_level'];
        $this->name = $entry['name'];
        $this->full_access = Cast::str2bool($entry['full_access']);
        $this->menu_template = $entry['menu_template'];

        $this->rights = new Access_Level_Rights($this, $this->i_access_level, $i_page);
    }

    public function set_menu_template() {
        global $smarty;

        if ($this->menu_template != '') {
            $smarty->assign('menu_template', $this->menu_template);
        }
    }

    public function can_add() {
        return $this->full_access || $this->rights->add;
    }

    public function can_edit() {
        return $this->full_access || $this->rights->edit;
    }

    public function can_del() {
        return $this->full_access || $this->rights->del;
    }

    public static function getList() {
        global $db;

        $sql = 'SELECT a.i_access_level, a.name
                  FROM access_levels a
              ORDER BY a.full_access DESC, a.name';

        $ret = $db->getAll($sql);

        if (!$_SESSION['is_callshop_available']) {
            foreach ($ret as $key => $val) {
                if ($val['i_access_level'] == 'CALLSHOP_OPERATOR') {
                    unset ($ret[$key]);
                }
            }
        }

        return array_merge($ret);       // reindex the array
    }
}

class Access_Level_Rights {

    public $access_level;
    public $i_page;
    public $i_access_level;
    public $add;
    public $edit;
    public $del;

    function __construct(&$access_level, $i_access_level, $i_page) {
        $this->access_level = $access_level;
        $this->i_page = $i_page;
        $this->i_access_level = $i_access_level;
        $this->add = FALSE;
        $this->edit = FALSE;
        $this->del = FALSE;

        if ($this->access_level !== NULL) {
            $this->getEntry($this->i_access_level, $this->i_page);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_access_level, $i_page) {
        global $db;

        $sql = 'SELECT *
                  FROM access_level_rights a
                 WHERE a.i_access_level = ? AND i_page = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($i_access_level, $i_page));

        if (!$this->access_level->full_access && $db->affected_rows != 1) {
            throw new Exception("You have no permissions to view this page.");
        }

        $this->i_page = $i_page;
        $this->i_access_level = $i_access_level;
        $this->add = Cast::str2bool($entry['add']);
        $this->edit = Cast::str2bool($entry['edit']);
        $this->del = Cast::str2bool($entry['del']);
    }
}

class SSP_Module {

    static function get_all_modules() {
        return Array('ani_callback' => Array('desc' => 'ANI Callback', 'url' => 'http://www.sippysoft.com/modules-callback/'),
                'calling_card' => Array('desc' => 'Calling Card', 'url' => 'http://www.sippysoft.com/modules-callingcard/'),
                'hosted' => Array('desc' => 'Environments', 'url' => 'https://www.sippysoft.com/modules-environments'),
                'vpn' => Array('desc' => 'VPN', 'url' => 'https://blog.sippysoft.com/post/release-notes-v4.5/',
                               'deprecated' => TRUE),
                'web_callback_ng' => Array('desc' => 'Web Callback', 'url' => 'http://www.sippysoft.com/modules-callback/'),
                'web_phone' => Array('desc' => 'Web Phone', 'url' => 'https://blog.sippysoft.com/post/release-notes-v4.4/',
                                     'deprecated' => TRUE),
                'conferencing' => Array('desc' => 'Conferencing', 'url' => 'https://blog.sippysoft.com/post/release-notes-v4.5/',
                                        'deprecated' => TRUE),
                'sth' => Array('desc' => 'CDRs Export For Turkish Authorities', 'url' => 'https://blog.sippysoft.com/post/EOL-STH-module/',
                               'deprecated' => TRUE),
                'sth2' => Array('desc' => 'Old TIB Reporting For Turkish Authorities', 'url' => 'https://www.sippysoft.com/turkish-regulation',
                                'deprecated' => TRUE),
                'tib' => Array('desc' => 'TIB Reporting For Turkish Authorities', 'url' => 'https://www.sippysoft.com/turkish-regulation'),
                'dncl' => Array('desc' => 'Do Not Call List', 'url' => 'http://www.sippysoft.com/dncl/')
        );
    }

    static function abbr2desc($abbr) {
        $all_modules = self::get_all_modules();
        return array_key_exists($abbr, $all_modules) ? $all_modules[$abbr]['desc'] : $abbr;
    }
}

class CDRs_View {

    static function create($table, $default_start, $default_end, $include_zero_cdrs = FALSE) {
        $cdrs_zero = Array('cdrs', 'cdrs_customers', 'cdrs_connections', 'cdrs_dids',
                           'cdrs_connections_dids');

        global $db;

        if (get_par('from_form')) {
            $from_date = isset_par('startDate') ? get_par('startDate') : $default_start;
            $to_date = isset_par('endDate') ? get_par('endDate') : $default_end;
        } else {
            $from_date = isset_par('expStartDate') ? get_par('expStartDate') : $default_start;
            $to_date = isset_par('expEndDate') ? get_par('expEndDate') : $default_end;
        }

        $from_date = parse_date($from_date);
        $to_date = parse_date($to_date);

        $calls_select = isset_par('calls_select') ? get_par('calls_select') : 4;  // 4 - non-zero cdrs

        $sql = 'SELECT table_name
                  FROM calls_schedule
                 WHERE (oldest_setup_time <= ? AND newest_setup_time >= ?)
                       OR (oldest_setup_time <= ? AND newest_setup_time >= ?)
                       OR (oldest_setup_time > ? AND newest_setup_time < ?)
              ORDER BY oldest_setup_time';
        $params = Array($from_date, $from_date, $to_date, $to_date, $from_date, $to_date);

        $calls = $db->getCol($sql, $params);

        if ($db->affected_rows == 0) {

            $sql = "CREATE OR REPLACE TEMP VIEW {$table}1 AS SELECT * FROM ONLY {$table}1 LIMIT 0";

        } else {

            $tables = str_replace('calls', $table, $calls);

            $sql = "CREATE OR REPLACE TEMP VIEW $table AS ";

            $add_sql = Array();
            foreach ($tables as $t) {
                $add_sql[] = "SELECT * FROM ONLY $t";
                if (($include_zero_cdrs || $calls_select != 4) && in_array($table, $cdrs_zero) &&
                    is_numeric(substr($t, -1))) {
                    $t = str_replace($table, $table . '_zero', $t);
                    $add_sql[] = "SELECT * FROM ONLY ${t}";
                }
            }

            $sql .= implode(' UNION ALL ', $add_sql);

        }

        $db->prepNexec($sql);
    }
}

class CDRs_Calls_Filter {

    const TYPE_DEFAULT = 1;
    const TYPE_WITH_ERRORS = 2;

    private $table;
    private $type;
    private $error_codes;
    private $default_records;

    function __construct($table, $type = self::TYPE_DEFAULT) {
        $this->table = $table;
        $this->type = $type;
        $this->error_codes = NULL;
        if ($this->type == self::TYPE_WITH_ERRORS) {
            $this->default_records = 3;
        } else {
            $this->default_records = 4;
        }
    }

    private function loadErrorCodes() {
        global $db;

        $this->error_codes = Array();

        $sql = 'SELECT i_call_error_code, description
                  FROM call_error_codes';
        $res = $db->getAll($sql);

        foreach ($res as $row) {
            $this->error_codes[$row['i_call_error_code']] = $row['description'];
        }
    }

    public function getErrorCodeDescription($code) {
        if ($code < 0) {
            if ($this->error_codes === NULL) {
                $this->loadErrorCodes();
            }
            if ($this->error_codes[$code] == '') {
                return _('Unknown');
            }
            return _($this->error_codes[$code]);
        } elseif ($code == 0) {
            return _('OK');
        } elseif ($code > 0 && $code < 200) {
            return _('Timeout');
        } elseif ($code >= 300) {
            return _('SIP error') . ' ' . $code;
        }

        return '';
    }

    public function getFilterOptions() {
        $ret = Array();

        if ($this->type == self::TYPE_WITH_ERRORS) {
            return Array(
                3 => "Non-zero Duration & Errors",
                4 => "Non-zero Duration",
                5 => "Complete",
                1 => "All",
                2 => "Incomplete",
                6 => "Errors"
            );
        }

        /* TYPE_DEFAULT */
        return Array(
                4 => "Non-zero Duration",
                5 => "Complete",
                1 => "All",
                2 => "Incomplete"
        );
    }

    public function getFilterClause() {
        $calls_select = isset_par('calls_select') ? get_par('calls_select') : $this->default_records;

        switch ($calls_select) {
            case 2: /* Incomplete */
                return "{$this->table}.result > 0";           
            case 3: /* Non-zero Duration & Errors */
                return "({$this->table}.duration > 0 OR {$this->table}.result < 0)";           
            case 4: /* Non-zero Duration */
                return "{$this->table}.duration > 0";
            case 5: /* Complete */
                return "{$this->table}.result = 0";
            case 6: /* Errors */
                return "{$this->table}.result < 0";           
            case 1: /* All */
            default:
                return "TRUE";
        }
    }
}

class Caller_Filter {

    const TYPE_DEFAULT = 1;             /* All own accounts, all own subcustomers */
    const TYPE_OWN_ACCOUNTS = 2;        /* Only own accounts */
    const TYPE_WITH_ENVIRONMENTS = 3;   /* As TYPE_DEFAULT plus all environments,
                                         * for non-root environments it works as TYPE_DEFAULT */

    private $type;
    private $envs_availabe;
    private $all_label;

    function __construct($type = self::TYPE_DEFAULT) {
        $this->type = $type;
        $this->envs_availabe = $_SESSION['is_root_customer'] && is_root_environment();
        $this->all_label = 'All';
    }

    public function setAllLabel($label) {
        $this->all_label = $label;
    }
    
    public function getList() {
        global $db;
        $query = get_par('query');
        $query = preg_replace('/^' . _($this->all_label) . '$/', '', $query);
        $query = preg_replace('/^' . _('All Accounts') . '$/', '', $query);
        $query = preg_replace('/^' . _('All Customers') . '$/', '', $query);
        $query = preg_replace('/^' . _('Cust.') . ' ?(.*)/', '$1', $query);
        $query = preg_replace('/^' . _('Acct.') . ' ?(.*)/', '$1', $query);
        if ($this->type == self::TYPE_WITH_ENVIRONMENTS && $this->envs_availabe) {
            $query = preg_replace('/^' . _('[ My Environment ]') . '$/', '', $query);
            $query = preg_replace('/^' . _('Env.') . ' ?(.*)/', '$1', $query);
        }
        $query = '%' . $query . '%';
        $start = get_par('start');
        $limit = get_par('limit');

        /* get total rows in the lists */
        /* accounts */
        $total_a = $db->getValue("SELECT COUNT(i_account)
                                          FROM accounts
                                         WHERE i_customer = ? AND username ILIKE ?",
                                 Array($_SESSION['uid'], $query));

        /* customers */
        if ($this->type != self::TYPE_OWN_ACCOUNTS) {
            $total_c = $db->getValue("SELECT COUNT(i_customer)
                                              FROM customers
                                             WHERE i_wholesaler <> i_customer AND i_wholesaler = ? AND name ILIKE ?",
                                     Array($_SESSION['uid'], $query));
        }

        /* environments */
        if ($this->type == self::TYPE_WITH_ENVIRONMENTS && $this->envs_availabe) {
            $ssp_id = trim(file_get_contents('/SSP_ID'));

            $sql = "SELECT COUNT(*)
                      FROM environments
                     WHERE i_environment <> 1 AND enabled AND pending_action ISNULL
                           AND (primary_node = ? OR primary_node IS NULL OR
                                primary_node = '' OR secondary_node = ?)";
            $total_e = $db->getValue($sql, Array($ssp_id, $ssp_id));
        }

        if ($this->type == self::TYPE_OWN_ACCOUNTS) {
            $total = $total_a;
        } elseif ($this->type == self::TYPE_WITH_ENVIRONMENTS && $this->envs_availabe) {
            $total = $total_a + $total_c + $total_e;
        } else {
            $total = $total_a + $total_c;
        }

        /* prepare the lists */
        if ($this->type == self::TYPE_OWN_ACCOUNTS) {
            $sql = "SELECT 1 AS type, i_account AS id,
                           username AS val
                      FROM accounts
                     WHERE i_customer = ? AND username ILIKE ?
                     ORDER BY type, val
                    OFFSET $start
                     LIMIT $limit";
            $params =  Array($_SESSION['uid'], $query);
        } elseif ($this->type == self::TYPE_WITH_ENVIRONMENTS && $this->envs_availabe) {
            $sql = "(SELECT 3 AS type, i_environment AS id,
                            name AS val
                       FROM environments
                      WHERE i_environment <> 1 AND enabled AND pending_action ISNULL
                            AND (primary_node = ? OR primary_node IS NULL OR
                                 primary_node = '' OR secondary_node = ?)
                            AND name ILIKE ?
                     ORDER BY val
                   ) UNION ALL (
                    SELECT 1 AS type, i_account AS id,
                           username AS val
                      FROM accounts
                     WHERE i_customer = ? AND username ILIKE ?
                     ORDER BY val
                   ) UNION ALL (
                    SELECT 2 AS type, i_customer AS id, name AS val
                      FROM customers
                     WHERE i_customer <> i_wholesaler AND i_wholesaler = ? AND name ILIKE ?
                     ORDER BY val
                  ) OFFSET $start
                     LIMIT $limit";
            $params =  Array($ssp_id, $ssp_id, $query, $_SESSION['uid'], $query, $_SESSION['uid'], $query);
        } else {
            $sql = "SELECT 1 AS type, i_account AS id,
                           username AS val
                      FROM accounts
                     WHERE i_customer = ? AND username ILIKE ?
                     UNION ALL
                    SELECT 2 AS type, i_customer AS id, name AS val
                      FROM customers
                     WHERE i_customer <> i_wholesaler AND i_wholesaler = ? AND name ILIKE ?
                     ORDER BY type, val
                    OFFSET $start
                     LIMIT $limit";
            $params =  Array($_SESSION['uid'], $query, $_SESSION['uid'], $query);
        }

        $rows = $db->getAll($sql, $params);

        header('Content-type: text/xml');

        print "<?xml version=\"1.0\" encoding=\"UTF-8\"" . "?" . "><dataset><total>$total</total>";

        $val = htmlspecialchars(_($this->all_label));
        print "<row><id>0_0</id><value>$val</value></row>";

        if ($this->type == self::TYPE_WITH_ENVIRONMENTS && $this->envs_availabe && $total_e > 0) {
            $val = htmlspecialchars(_('[ My Environment ]'));
            print "<row><id>3_1</id><value>$val</value></row>";
        }

        if ($this->type != self::TYPE_OWN_ACCOUNTS) {
            $val = htmlspecialchars(_('All Accounts'));
            print "<row><id>0_1</id><value>$val</value></row>";

            $val = htmlspecialchars(_('All Customers'));
            print "<row><id>0_2</id><value>$val</value></row>";
        }

        foreach ($rows as $row) {
            if ($row['type'] == 3) {
                $t = _('Env.');
            } elseif ($row['type'] == 2) {
                $t = _('Cust.');
            } else {
                $t = _('Acct.');
            }
            $val = htmlspecialchars($t . ' ' . $row['val']);
            print "<row><id>${row['type']}_${row['id']}</id><value>$val</value></row>";
        }

        print "</dataset>";
    }

    public function getCallerName($caller_type, $i_caller) {
        global $db;

        if ($caller_type == 3 && $this->envs_availabe) {
            return _("Env.") . " " .
                   $db->getValue("SELECT name
                                    FROM environments
                                   WHERE i_environment = ?",
                   Array($i_caller));
        } elseif ($caller_type == 2) {
            return _("Cust.") . " " .
                   $db->getValue("SELECT name
                                    FROM customers
                                   WHERE i_customer <> i_wholesaler AND i_wholesaler = ? AND i_customer = ?",
                   Array($_SESSION['uid'], $i_caller));
        } elseif ($caller_type == 1) {
            return _("Acct.") . " " .
                   $db->getValue("SELECT username
                                    FROM accounts
                                   WHERE i_customer = ? AND i_account = ?",
                   Array($_SESSION['uid'], $i_caller));
        } else {
            return _("All");
        }
    }
}

Class Operator {
    public static function get() {
        global $web_session;

        $ret = FALSE;
        if (!is_object($web_session)) {
            return $ret;
        }

        if ($web_session->type == Web_Session::TYPE_CUSTOMER) {
            if ($web_session->subtype == Web_Session::TYPE_WEB_USER) {
                $ret = sprintf('u:%d:%d:%s', $web_session->user_info['uid'], $web_session->user_info['sub_uid'],
                               $web_session->web_login);
            } else {    /* Web_Session::TYPE_CUSTOMER */
                $ret = sprintf('c:%d:0:%s', $web_session->user_info['uid'], $web_session->web_login);
            }
        } elseif ($web_session->type == Web_Session::TYPE_ACCOUNT) {
            $ret = sprintf('a:%d:0:%s', $web_session->user_info['uid'], $web_session->web_login);
        } elseif ($web_session->type == Web_Session::TYPE_VENDOR) {
            $ret = sprintf('v:%d:0:%s', $web_session->user_info['uid'], $web_session->web_login);
        }

        return $ret;
    }
}

Class Audit_Info {
    public static function get() {
        global $par;

        /* use audit_info if request has it */
        if (array_key_exists('audit_info', $par)) {
            $ret = str_replace("'", '"', $par['audit_info']);
            $ret = json_decode($ret, TRUE);

            if (is_array($ret)) {
                foreach ($ret as $k => $v) {
                    $ret[$k] = new xmlrpcval($v, "string");
                }
                return $ret;
            }

            /* fallback to our default behaviour if something was wrong
             * during processing of passed audit_info
             */
        }

        $ret = Array(
            "datetime"      => new xmlrpcval(gmdate('H:i:s.000 \G\M\T D M d Y'), "string"),
            "user_ip"       => new xmlrpcval($_SERVER['REMOTE_ADDR'], "string"),
            "user_agent"    => new xmlrpcval($_SERVER['HTTP_USER_AGENT'], "string")
        );

        $action_by = Operator::get();
        if ($action_by !== FALSE) {
            $ret['action_by'] = new xmlrpcval($action_by, "string");
        }

        return $ret;
    }

    public static function get_cli($user_agent) {
        $node_id = trim(file_get_contents('/SSP_ID'));

        $ret = Array(
            "cli_mode"      => new xmlrpcval(TRUE, "boolean"),
            "datetime"      => new xmlrpcval(gmdate('H:i:s.000 \G\M\T D M d Y', time()), "string"),
            "user_ip"       => new xmlrpcval($node_id, "string"),
            "user_agent"    => new xmlrpcval($user_agent, "string")
        );

        return $ret;
    }

    public static function get_web_login_resource() {
        global $web_session;

        $ret = sprintf('%s:%s',
                       $web_session->subtype !== NULL ?  $web_session->subtype : $web_session->type,
                       $web_session->user_info['web_login']);

        return $ret;
    }
}

Class Audit_Logger {
    public static function write($action, $resource, $audit_info = NULL) {
        $params = Array(
            'action' => new xmlrpcval($action, "string"),
            'resource' => new xmlrpcval($resource, "string")
        );

        if ($audit_info === NULL) {
            $params['audit_info'] = new xmlrpcval(Audit_Info::get(), "struct");
        } else {
            $params['audit_info'] = $audit_info;
        }

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('writeAuditLog', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg, 10);
        if ($res->faultCode()) {
            /* ignore errors*/
            error_log('Audit_Logger::write(): ' . htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }
    }

    public static function write_cli($action, $resource, $user_agent) {
        $audit_info = Audit_Info::get_cli($user_agent);
        $audit_info = new xmlrpcval($audit_info, "struct");
        Audit_Logger::write($action, $resource, $audit_info);
    }
}

Class System_Dictionary {
    public static function get($name, $opt_params = Array()) {

        $params = Array(
            "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
            "name" => new xmlrpcval($name, "string"),
        );
        $params = array_merge($params, $opt_params);
        $params = array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('getDictionary', $params);

        $master_addr = get_master_XMLRPC_server();

        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            error_log($res->faultString());
            return FALSE;
        }

        return $res->val['dictionary'];
    }
}

class Balanced_Client {
    function __construct($method = '', $params = Array()) {
        $this->method = $method;
        $this->params = $params;
    }

    public function setMethod($method) {
        $this->method = $method;
    }

    public function setParams($params) {
        $this->params = $params;
    }

    public function get() {
        if (!array_key_exists("audit_info", $this->params)) {
            $this->params['audit_info'] = new xmlrpcval(Audit_Info::get(), "struct");
        }

        if (!array_key_exists("l10n_lang", $this->params) && array_key_exists('lang', $_SESSION)) {
            $this->params['l10n_lang'] = new xmlrpcval($_SESSION['lang'], "string");
        }

        $params = array(new xmlrpcval($this->params, 'struct'));

        $msg = new xmlrpcmsg($this->method, $params);

        $master_addr = get_master_XMLRPC_server();

        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);

        if ($res->faultCode()) {
            error_log($res->faultString());
            return FALSE;
        }

        return $res->val;
    }
}

Class X_Rates {
    public static function convert2base_c($i_customer, $currency, $value) {
        global $base_c;

        return self::convert($i_customer, $base_c, $currency, $value);
    }

    public static function convert($i_customer, $base_currency, $currency, $value) {
        global $db;
        static $x_rates = NULL;         /* cache the value */

        if ($base_currency == $currency) {
            return $value;
        }

        if ($x_rates === NULL) {
            $sql = "SELECT x.rate, x.iso_4217 AS currency
                      FROM x_rates x
                     WHERE x.i_customer = ?";
            $params = Array($i_customer);

            $x_rates = $db->getAll($sql, $params);
        }

        foreach ($x_rates as $x_rate) {
            if ($currency == $x_rate['currency']) {
                return $value * $x_rate['rate'];
            }
        }

        return $value;
    }
}

Class CDR_Details_Groups {
    private $groups;

    function __construct() {
        $this->groups = Array();

        $this->groups['call_id'] = Array('call_id');
        $this->groups['cli_cld'] = Array('call_id', 'cld', 'cli', 'cld_in', 'cli_in', 'cld_out', 'cli_out');
        $this->groups['lrn'] = Array('lrn_cld', 'lrn_cli', 'lrn_cld_in', 'lrn_cli_in');
        $this->groups['protocol'] = Array('protocol', 'i_protocol');
        $this->groups['ids'] = Array('i_call', 'i_cdr', 'i_cdr_connection', 'i_cdrs_did');
        $this->groups['did'] = Array('did', 'i_did');
        $this->groups['ip_port'] = Array('remote_ip', 'remote_port');
        $this->groups['media'] = Array('media_relay_configured', 'i_media_relay', 'media_relay_used', 'i_media_relay_outcome', 'media_ip');
    }

    function order_by_groups($cdr) {
        $new_cdr = Array();

        foreach ($this->groups as $group => $members) {
            foreach ($members as $member) {
                if (array_key_exists($member, $cdr)) {
                    $new_cdr[$member] = $cdr[$member];
                }
            }
        }

        foreach ($cdr as $k => $v) {
            if (!array_key_exists($k, $new_cdr)) {
                $new_cdr[$k] = $cdr[$k];
            }
        }

        return $new_cdr;
    }
}

Class Map_CDR_Details {
    const TYPE_STRING = 1;          /* as is */
    const TYPE_MONEY = 2;           /* 1.0000 USD */
    const TYPE_DURATION = 3;        /* 2:03 */
    const TYPE_TIMESTAMP = 4;       /* 7 Apr 2015 23:59:24 (formatted according to $date_format */
    const TYPE_PRICE_PER_MIN = 5;   /* 1.0000 USD/min */
    const TYPE_INTRL = 6;           /* 3 secs */
    const TYPE_PRICE = 7;           /* 1.0000 USD */
    const TYPE_MULTISTRING = 8;     /* SDP and so on */
    const TYPE_ERROR_CODE_DESCRIPTION = 9;  /* Error Code Description */

    private $currency;
    private $x_rate;
    private $calls_filter;
    private $map;

    function __construct() {
        $this->currency = NULL;
        $this->x_rate = 1;
        $this->calls_filter = new CDRs_Calls_Filter('cdrs', CDRs_Calls_Filter::TYPE_WITH_ERRORS);
        $this->map = Array();

        $this->map['call_id'] = Array('title' => _('Call-Id'));
        $this->map['cld'] = Array('title' => _('CLD'));
        $this->map['cli'] = Array('title' => _('CLI'));
        $this->map['cost'] = Array('type' => self::TYPE_MONEY);
        $this->map['delay'] = Array('type' => self::TYPE_DURATION);
        $this->map['duration'] = Array('type' => self::TYPE_DURATION);
        $this->map['billed_duration'] = Array('type' => self::TYPE_DURATION);
        $this->map['connect_time'] = Array('type' => self::TYPE_TIMESTAMP);
        $this->map['disconnect_time'] = Array('type' => self::TYPE_TIMESTAMP);
        $this->map['cld_in'] = Array('title' => _('Incoming CLD'));
        $this->map['cli_in'] = Array('title' => _('Incoming CLI'));
        $this->map['price_1'] = Array('type' => self::TYPE_PRICE_PER_MIN);
        $this->map['price_n'] = Array('type' => self::TYPE_PRICE_PER_MIN);
        $this->map['interval_1'] = Array('type' => self::TYPE_INTRL);
        $this->map['interval_n'] = Array('type' => self::TYPE_INTRL);
        $this->map['post_call_surcharge'] = Array('type' => self::TYPE_PRICE);
        $this->map['connect_fee'] = Array('type' => self::TYPE_PRICE);
        $this->map['free_seconds'] = Array('type' => self::TYPE_INTRL);
        $this->map['remote_ip'] = Array('title' => _('Remote IP'));
        $this->map['grace_period'] = Array('type' => self::TYPE_INTRL);
        $this->map['pdd1xx'] = Array('type' => self::TYPE_DURATION, 'title' => _('PDD 1xx'));
        $this->map['plan_duration'] = Array('type' => self::TYPE_DURATION);
        $this->map['accessibility_cost'] = Array('type' => self::TYPE_PRICE);
        $this->map['lrn_cld'] = Array('title' => _('LRN CLD'));
        $this->map['lrn_cld_in'] = Array('title' => _('Incoming LRN CLD'));
        $this->map['lrn_cli'] = Array('title' => _('LRN CLI'));
        $this->map['lrn_cli_in'] = Array('title' => _('Incoming LRN CLI'));
        $this->map['p_asserted_id'] = Array('title' => _('P-Asserted-Id'));
        $this->map['remote_party_id'] = Array('title' => _('Remote-Party-Id'));
        $this->map['conn_proc_time'] = Array('title' => _('Connect Processing Time'));
        $this->map['result'] = Array('type' => self::TYPE_ERROR_CODE_DESCRIPTION);

        /* cdrs_connections */
        $this->map['setup_time'] = Array('type' => self::TYPE_TIMESTAMP);
        $this->map['call_setup_time'] = Array('type' => self::TYPE_TIMESTAMP);
        $this->map['pdd100'] = Array('type' => self::TYPE_DURATION, 'title' => _('PDD 100'));
        $this->map['remote_ip_bak'] = Array('title' => _('Backup Remote IP'));
        $this->map['cld_out'] = Array('title' => _('Outgoing CLD'));
        $this->map['cli_out'] = Array('title' => _('Outgoing CLI'));
        $this->map['i_media_relay'] = Array('title' => _('I-Media-Relay Configured'));
        $this->map['i_media_relay_outcome'] = Array('title' => _('I-Media-Relay Used'));
        $this->map['media_ip'] = Array('title' => _('Media IP'));

        /* SDP */
        $this->map['sdp'] = Array('type' => self::TYPE_MULTISTRING, 'title' => _('SDP'));
        $this->map['time_stamp'] = Array('title' => _('Time'), 'type' => self::TYPE_TIMESTAMP);
        $this->map['sip_msg_type'] = Array('title' => _('SIP Message Type'));
    }

    public function setMapEntry($field, $opt) {
        $this->map[$field] = $opt;
    }

    public function setCurrency($currency) {
        $this->currency = $currency;
    }

    public function setXRate($x_rate) {
        $this->x_rate = $x_rate;
    }

    public function format_title($field) {
        if (array_key_exists($field, $this->map) &&
            array_key_exists('title', $this->map[$field])) {
            $ret = $this->map[$field]['title'];
        } else {
            $ret = explode('_', $field);
            $delim = ' ';
            if (strtolower($ret[0]) == 'i') {
                $delim = '-';
            }
            $ret = array_map('strtolower', $ret);
            $ret = array_map('ucfirst', $ret);
            $ret = implode($delim, $ret);
        }

        return $ret;
    }

    public function format_val($field, $val) {
        if (array_key_exists($field, $this->map) &&
            array_key_exists('type', $this->map[$field])) {
            $type = $this->map[$field]['type'];
        } else {
            $type = $this::TYPE_STRING;
        }

        $val = htmlspecialchars($val);

        switch ($type) {
            case $this::TYPE_MONEY:
                $ret = sprintf(get_dpf(), $val * $this->x_rate) . ' ' . $this->currency;
                break;

            case $this::TYPE_DURATION:
                $ret = normalize_seconds(round($val));
                break;

            case $this::TYPE_TIMESTAMP:
                $r = strtotime($val);
                if ($r === FALSE) {
                    $ret = $val;
                } else {
                    $ret = strftime($_SESSION['tz_format'], $r);
                }
                break;

            case $this::TYPE_PRICE_PER_MIN:
                $ret = sprintf(get_dpf(), $val * $this->x_rate) . ' ' . $this->currency . '/' . _('min');
                break;

            case $this::TYPE_INTRL:
                $ret = $val . ' ' . _('sec');
                break;

            case $this::TYPE_PRICE:
                $ret = sprintf(get_dpf(), $val * $this->x_rate) . ' ' . $this->currency;
                break;

            case $this::TYPE_MULTISTRING:
                $ret = preg_replace('/\r?\n/', '<br/>', $val);
                break;

            case $this::TYPE_ERROR_CODE_DESCRIPTION:
                $ret = $this->calls_filter->getErrorCodeDescription($val) . ' (' . $val . ')';
                break;

            case $this::TYPE_STRING:
            default:
                $ret = $val;
                break;
        }

        return $ret;
    }
}

/**
 * Convert an xml file to an associative array (including the tag attributes):
 *
 * @param Str $xml file/string.
 */
class xmlToArrayParser {
  /**
   * The array created by the parser which can be assigned to a variable with: $varArr = $domObj->array.
   *
   * @var Array
   */
  public  $array;
  private $parser;
  private $pointer;

  /**
   * $domObj = new xmlToArrayParser($xml);
   *
   * @param Str $xml file/string
   */
  public function __construct($xml, $enc = "UTF-8") {
    $this->pointer =& $this->array;
    $this->parser = xml_parser_create($enc);
    xml_set_object($this->parser, $this);
    xml_parser_set_option($this->parser, XML_OPTION_CASE_FOLDING, false);
    xml_set_element_handler($this->parser, "tag_open", "tag_close");
    xml_set_character_data_handler($this->parser, "cdata");
    xml_parse($this->parser, ltrim($xml));
  }

  private function tag_open($parser, $tag, $attributes) {
    $this->convert_to_array($tag, '_');
    $idx=$this->convert_to_array($tag, 'cdata');
    if(isset($idx)) {
      $this->pointer[$tag][$idx] = Array('@idx' => $idx,'@parent' => &$this->pointer);
      $this->pointer =& $this->pointer[$tag][$idx];
    }else {
      $this->pointer[$tag] = Array('@parent' => &$this->pointer);
      $this->pointer =& $this->pointer[$tag];
    }
    if (!empty($attributes)) { $this->pointer['_'] = $attributes; }
  }

  /**
   * Adds the current elements content to the current pointer[cdata] array.
   */
  private function cdata($parser, $cdata) {
    if(isset($this->pointer['cdata'])) { $this->pointer['cdata'] .= $cdata;}
    else { $this->pointer['cdata'] = $cdata;}
  }

  private function tag_close($parser, $tag) {
    $current = & $this->pointer;
    if(isset($this->pointer['@idx'])) {unset($current['@idx']);}
    $this->pointer = & $this->pointer['@parent'];
    unset($current['@parent']);
    if(isset($current['cdata']) && count($current) == 1) { $current = $current['cdata'];}
    else if(empty($current['cdata'])) { unset($current['cdata']); }
  }

  /**
   * Converts a single element item into array(element[0]) if a second element of the same name is encountered.
   */
  private function convert_to_array($tag, $item) {
    if(isset($this->pointer[$tag][$item])) {
      $content = $this->pointer[$tag];
      $this->pointer[$tag] = array((0) => $content);
      $idx = 1;
    }else if (isset($this->pointer[$tag])) {
      $idx = count($this->pointer[$tag]);
      if(!isset($this->pointer[$tag][0])) {
        foreach ($this->pointer[$tag] as $key => $value) {
            unset($this->pointer[$tag][$key]);
            $this->pointer[$tag][0][$key] = $value;
    }}}else $idx = null;
    return $idx;
  }
}

class Active_Calls_Parser {
    function __construct(&$data) {
        $this->data = &$data;
        $this->offset = 0;
        $this->faultCode = 0;
        $this->faultString = '';

        $this->fp = fopen('data:text/plain,' . urlencode($this->data), 'r');

        $first_entry = $this->get_next_call(TRUE);
        if (is_array($first_entry) && array_key_exists('faultCode', $first_entry)) {
            $this->faultCode = $first_entry['faultCode'];
            $this->faultString = $first_entry['faultString'];
        }
    }

    function __destruct() {
        fclose($this->fp);
    }

    function get_next_call($dry_run = FALSE) {
        $pattern = '/<struct>(.+?)<\/struct>/ms';

        fseek($this->fp, $this->offset);
        $str = fread($this->fp, 2048);

        if (preg_match($pattern, $str, $m, PREG_OFFSET_CAPTURE) != 1) {
            return NULL;
        }

        if (!$dry_run) {
            $this->offset += $m[1][1] + strlen($m[0][0]);
        }

        $pattern = '/<member>.??<name>(.+?)<\/name>.??<value>((<nil\/>)|<.+?>(.*?)<\/.+?>)<\/value>.??<\/member>/ms';
        $offset = 0;
        $ret = Array();

        while(preg_match($pattern, $m[1][0], $m2, PREG_OFFSET_CAPTURE, $offset) == 1) {
            if ($m2[3][0] == '') {
                $ret[$m2[1][0]] = $m2[4][0];
            } else {
                $ret[$m2[1][0]] = NULL;
            }
            $offset = $m2[0][1] + strlen($m2[0][0]);
        };

        return $ret;
    }
}

?>
