<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Contact {

    public $i_contact;
    public $company_name;
    public $salutation;
    public $first_name;
    public $mid_init;
    public $last_name;
    public $street_addr;
    public $state;
    public $postal_code;
    public $city;
    public $country;
    public $contact;
    public $phone;
    public $fax;
    public $alt_phone;
    public $alt_contact;
    public $email;
    public $cc;
    public $bcc;

    function __construct($i_contact = NULL) {

        $this->i_contact = $i_contact;
        $this->company_name = '';
        $this->salutation = '';
        $this->first_name = '';
        $this->mid_init = '';
        $this->last_name = '';
        $this->street_addr = '';
        $this->state = '';
        $this->postal_code = '';
        $this->city = '';
        $this->country = '';
        $this->contact = '';
        $this->phone = '';
        $this->fax = '';
        $this->alt_phone = '';
        $this->alt_contact = '';
        $this->email = '';
        $this->cc = '';
        $this->bcc = '';

        if ($this->i_contact !== NULL) {
            $this->getEntry($this->i_contact);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_contact) {
        global $db;

        $sql = 'SELECT c.*
                  FROM contacts c
                 WHERE c.i_contact = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($i_contact));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_contact = $entry['i_contact'];
        $this->company_name = $entry['company_name'];
        $this->salutation = $entry['salutation'];
        $this->first_name = $entry['first_name'];
        $this->mid_init = $entry['mid_init'];
        $this->last_name = $entry['last_name'];
        $this->street_addr = $entry['street_addr'];
        $this->state = $entry['state'];
        $this->postal_code = $entry['postal_code'];
        $this->city = $entry['city'];
        $this->country = $entry['country'];
        $this->contact = $entry['contact'];
        $this->phone = $entry['phone'];
        $this->fax = $entry['fax'];
        $this->alt_phone = $entry['alt_phone'];
        $this->alt_contact = $entry['alt_contact'];
        $this->email = $entry['email'];
        $this->cc = $entry['cc'];
        $this->bcc = $entry['bcc'];
    }

    public function initFromRequest($par, $can_modify_name = FALSE) {
        if ($can_modify_name) {
            $this->company_name = $par['company_name'];
            $this->salutation = $par['salutation'];
            $this->first_name = $par['first_name'];
            $this->mid_init = $par['mid_init'];
            $this->last_name = $par['last_name'];
        }
        $this->street_addr = $par['street_addr'];
        $this->state = $par['state'];
        $this->postal_code = $par['postal_code'];
        $this->city = $par['city'];
        $this->country = $par['country'];
        $this->contact = $par['contact'];
        $this->phone = $par['phone'];
        $this->fax = $par['fax'];
        $this->alt_phone = $par['alt_phone'];
        $this->alt_contact = $par['alt_contact'];
        $this->email = $par['email'];
        $this->cc = $par['cc'];
        $this->bcc = $par['bcc'];
    }

    public function genID() {
        global $db;

        return $db->nextID('contacts_seq');
    }

    public function validate($par) {
        if (!Validator::isEmail($par['email'])) {
            throw new Exception(_('"E-Mail" field has incorrect format. E-mail in the format username@domain is expected.'));
        }

        if (!Validator::isEmailsList($par['cc'])) {
            throw new Exception(_('"CC E-Mail" field has incorrect format. E-mail in the format username@domain is expected.'));
        }

        if (!Validator::isEmailsList($par['bcc'])) {
            throw new Exception(_('"BCC E-Mail" field has incorrect format. E-mail in the format username@domain is expected.'));
        }
    }

    public function add($par) {
        global $db;

        $this->validate($par);

        $i_contact = $this->genID();

        $sql = "INSERT INTO contacts (company_name, salutation, first_name, last_name, mid_init,
                            street_addr, state, postal_code, country, contact, phone,
                            fax, alt_phone, alt_contact, email, cc, bcc, city, i_contact)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $params = Array($par['company_name'], $par['salutation'], $par['first_name'],
                        $par['last_name'], $par['mid_init'], $par['street_addr'],
                        $par['state'], $par['postal_code'], $par['country'],
                        $par['contact'], $par['phone'], $par['fax'],
                        $par['alt_phone'], $par['alt_contact'], $par['email'],
                        $par['cc'], $par['bcc'], $par['city'],
                        $i_contact);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Contact Info."));
        }

        $this->getEntry($i_contact);
    }

    public function update($par) {
        global $db;

        $this->validate($par);

        $sql = "UPDATE contacts
                   SET company_name = ?, salutation = ?, first_name = ?, last_name = ?,
                       mid_init = ?,  street_addr = ?, state = ?, postal_code = ?,
                       country = ?, contact = ?, phone = ?, fax = ?, alt_phone = ?,
                       alt_contact = ?, email = ?, cc = ?, bcc = ?, city = ?
                 WHERE i_contact = ?";
        $params = Array($par['company_name'], $par['salutation'], $par['first_name'],
                        $par['last_name'], $par['mid_init'], $par['street_addr'],
                        $par['state'], $par['postal_code'], $par['country'],
                        $par['contact'], $par['phone'], $par['fax'],
                        $par['alt_phone'], $par['alt_contact'], $par['email'],
                        $par['cc'], $par['bcc'], $par['city'],
                        $this->i_contact);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Contact Info."));
        }

        $this->getEntry($this->i_contact);
    }

    public function update_self($par) {
        global $db;

        $this->validate($par);

        $sql = "UPDATE contacts
                   SET street_addr = ?, state = ?, postal_code = ?,
                       country = ?, contact = ?, phone = ?, fax = ?, alt_phone = ?,
                       alt_contact = ?, email = ?, cc = ?, bcc = ?, city = ?
                 WHERE i_contact = ?";
        $params = Array($par['street_addr'],
                        $par['state'], $par['postal_code'], $par['country'],
                        $par['contact'], $par['phone'], $par['fax'],
                        $par['alt_phone'], $par['alt_contact'], $par['email'],
                        $par['cc'], $par['bcc'], $par['city'],
                        $this->i_contact);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Contact Info."));
        }

        $this->getEntry($this->i_contact);
    }

    public function delete() {
        global $db;

        $sql = 'DELETE FROM contacts
                 WHERE i_contact = ?';
        $params = Array($this->i_contact);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Contact Info."));
        }
    }
}

?>
