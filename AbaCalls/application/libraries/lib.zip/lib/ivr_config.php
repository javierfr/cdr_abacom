<?php

// Copyright (c) 2018 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Remote_IVR_Config_Entry {

    public $section;
    public $option;
    public $value;
    public $i_ivr_instance;
    public $i_ivr_application;
    public $default_value;
    public $value_type;
    public $name;
    public $description;

    private $_fault;

    private $ip_address;

    function __construct($ip_address, $section, $option, $i_ivr_instance = null, $i_ivr_application = null) {
        $this->ip_address = $ip_address;
        $this->section = $section;
        $this->option = $option;
        $this->i_ivr_instance = $i_ivr_instance;
        $this->i_ivr_application = $i_ivr_application;
    }

    function get() {
        $params = array(new xmlrpcval(array(
            "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
            "section" => new xmlrpcval($this->section, "string"),
            "option" => new xmlrpcval($this->option, "string"),
            "i_ivr_instance" => new xmlrpcval($this->i_ivr_instance, $this->i_ivr_instance === null ? "null" : "int"),
            "i_ivr_application" => new xmlrpcval($this->i_ivr_application, $this->i_ivr_application === null ? "null" : "int"),
        ), 'struct'));
        $msg = new xmlrpcmsg('jailGetIVRConfig', $params);
        $cli = new xmlrpc_client('https://' . $this->ip_address . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';
        $cli->addHeader('X-From-I-Environment', 1);

        $res = $cli->send($msg);

        if ($res->faultCode()) {
            error_log('Unable to get IVR config entry: section = ' . $this->section .
                      ', option = ' . $this->option .
                      ', i_ivr_instance = ' . $this->i_ivr_instance .
                      ', i_ivr_application = ' . $this->i_ivr_application .
                      ', faultCode = ' . $res->faultCode() . ': ' .
                      htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $config = $res->val['config'];
        $this->value = $config['current_value'];
        $this->default_value = $config['default_value'];
        $this->value_type = $config['value_type'];
        $this->name = $config['name'];
        $this->description = $config['description'];

        if ($this->value_type == 'bool') {
            $this->value = Cast::str2bool($this->value);
        }

        return $this->value;
    }

    function set($value) {
        try {
            $this->get();
        } catch (Exception $e) {
            // ignore any errors
        }

        if ($this->value_type == 'bool') {
            $value = Cast::str2bool($value) ? 'true' : 'false';
        }

        $params = array(new xmlrpcval(array(
            "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
            "section" => new xmlrpcval($this->section, "string"),
            "option" => new xmlrpcval($this->option, "string"),
            "i_ivr_instance" => new xmlrpcval($this->i_ivr_instance, $this->i_ivr_instance === null ? "null" : "int"),
            "i_ivr_application" => new xmlrpcval($this->i_ivr_application, $this->i_ivr_application === null ? "null" : "int"),
            "value" => new xmlrpcval($value, "string"),
        ), 'struct'));
        $msg = new xmlrpcmsg('jailSetIVRConfig', $params);
        $cli = new xmlrpc_client('https://' . $this->ip_address . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';
        $cli->addHeader('X-From-I-Environment', 1);

        $res = $cli->send($msg);

        if ($res->faultCode()) {
            error_log('Unable to set IVR config entry: section = ' . $this->section .
                      ', option = ' . $this->option .
                      ', i_ivr_instance = ' . $this->i_ivr_instance .
                      ', i_ivr_application = ' . $this->i_ivr_application .
                      ', value = ' . $value .
                      ', faultCode = ' . $res->faultCode() . ': ' .
                      htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            throw new Exception($this->name . ': ' . htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }
    }
}

?>
