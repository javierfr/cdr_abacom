<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Trunk_Connection {

    const TYPE_MAIN   = 1;
    const TYPE_BACKUP = 2;

    public $i_trunk;
    public $type;
    public $i_connection;
    public $destination;
    public $username;
    public $password;
    public $name;
    public $translation_rule;
    public $from_domain;
    public $outbound_ip;
    public $random_call_id;

    function __construct($i_trunk, $type, $i_connection = NULL) {
        $this->i_trunk = $i_trunk;
        $this->type = $type;
        $this->i_connection = $i_connection;
        $this->destination = '';
        $this->username = '';
        $this->password = '';
        $this->name = ($this->type == Trunk_Connection::TYPE_MAIN) ?
                      'Main connection' :
                      'Backup connection';
        $this->translation_rule = '';
        $this->from_domain = '';
        $this->outbound_ip = '';
        $this->random_call_id = FALSE;

        if ($this->i_connection !== NULL) {
            $this->getEntry($this->i_connection);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_connection) {
        global $db;

        $sql = 'SELECT c.*
                  FROM connections c
                 WHERE c.i_trunk = ? AND c.i_connection = ?
                 LIMIT 1';
        $params = Array($this->i_trunk, $i_connection);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_connection = $i_connection;
        $this->destination = $entry['destination'];
        $this->username = $entry['username'];
        $this->password = $entry['password'];
        $this->translation_rule = $entry['translation_rule'];
        $this->from_domain = $entry['from_domain'];
        $this->outbound_ip = $entry['outbound_ip'];
        $this->random_call_id = Cast::str2bool($entry['random_call_id']);
    }

    public function initFromRequest($par) {
        if ($this->type == Trunk_Connection::TYPE_MAIN) {
            $this->destination = $par['destination'];
            $this->username = $par['username'];
            $this->password = $par['password'];
            $this->outbound_ip = $par['outbound_ip'];
        } else {
            $this->destination = $par['destination_backup'];
            $this->username = $par['username_backup'];
            $this->password = $par['password_backup'];
            $this->outbound_ip = $par['outbound_ip_backup'];
        }
        $this->translation_rule = $par['outbound_cld'];
        $this->from_domain = $par['from_domain'];
        $this->random_call_id = Cast::str2bool($par['random_call_id']);
    }

    public function genID() {
        global $db;

        return $db->nextID('connections_seq');
    }

    public function validate($par) {
        if ($this->type == Trunk_Connection::TYPE_MAIN && $par['destination'] == '') {
            throw new Exception(_('"Main Destination" field is mandatory. Hostname or IP-address is expected.'));
        }

        if (!Validator::isDestination($par['destination'], TRUE)) {
            throw new Exception('"Main Destination" field has incorrect format. Hostname or IP-address is expected.');
        }

        if (!Validator::isDestination($par['destination_backup'])) {
            throw new Exception('"Backup Destination" field has incorrect format. Hostname or IP-address is expected.');
        }

        if (!(Validator::isTransRule($par['outbound_cld']))) {
            throw new Exception(_('"Outbound CLD" has incorrect syntax.'));
        }

        if (trim($par['from_domain']) != '' && !preg_match('/^[a-z0-9.-]+$/', trim($par['from_domain']))) {
            throw new Exception(_('"From Domain" has incorrect value.'));
        }

        if (trim($par['outbound_ip']) != '' && !in_array($par['outbound_ip'], getOutboundIPs())) {
            return _('"Main Outbound IP" has incorrect value.');
        }

        if (trim($par['outbound_ip_backup']) != '' && !in_array($par['outbound_ip_backup'], getOutboundIPs())) {
            return _('"Backup Outbound IP" has incorrect value.');
        }
    }

    public function add($par) {
        global $db;

        if ($this->type == Trunk_Connection::TYPE_BACKUP &&
            $par['destination_backup'] == '') {
            return;
        }

        $i_connection = $this->genID();
        if ($this->type == Trunk_Connection::TYPE_MAIN) {
            $destination = $par['destination'];
            $username = $par['username'];
            $password = $par['password'];
            $outbound_ip = trim($par['outbound_ip']);
        } else {
            $destination = $par['destination_backup'];
            $username = $par['username_backup'];
            $password = $par['password_backup'];
            $outbound_ip = trim($par['outbound_ip_backup']);
        }

        $sql = 'INSERT INTO connections (i_trunk, i_connection, i_media_relay_type, i_media_relay,
                                         name, destination, username, password, translation_rule,
                                         from_domain, outbound_ip, random_call_id)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $params = Array($this->i_trunk, $i_connection, 0, 1, $this->name,
                        $destination, $username, $password, $par['outbound_cld'],
                        trim($par['from_domain']),
                        $outbound_ip == '' ? NULL : $outbound_ip,
                        Cast::str2bool($par['random_call_id'])
                       );

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Connection."));
        }

        $this->getEntry($i_connection);
    }

    public function update($par) {
        global $db;

        if ($this->type == Trunk_Connection::TYPE_BACKUP) {
            if ($this->i_connection !== NULL && $par['destination_backup'] == '') {
                $this->delete($par);
                return;
            } elseif ($this->i_connection === NULL) {
                if ($par['destination_backup'] != '') {
                    $this->add($par);
                }
                return;
            }
        }

        if ($this->type == Trunk_Connection::TYPE_MAIN) {
            $destination = $par['destination'];
            $username = $par['username'];
            $password = $par['password'];
            $outbound_ip = trim($par['outbound_ip']);
        } else {
            $destination = $par['destination_backup'];
            $username = $par['username_backup'];
            $password = $par['password_backup'];
            $outbound_ip = trim($par['outbound_ip_backup']);
        }

        $sql = 'UPDATE connections
                   SET destination = ?, username = ?, password = ?, translation_rule = ?,
                       from_domain = ?, outbound_ip = ?, random_call_id = ?
                 WHERE i_trunk = ? AND i_connection = ?';
        $params = Array($destination, $username, $password, $par['outbound_cld'],
                        trim($par['from_domain']), $outbound_ip == '' ? NULL : $outbound_ip,
                        Cast::str2bool($par['random_call_id']),
                        $this->i_trunk, $this->i_connection);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Connection."));
        }

        $this->getEntry($this->i_connection);
    }

    public function delete($par) {
        global $db;

        $sql = 'DELETE FROM connections
                 WHERE i_trunk = ? AND i_connection = ?';
        $params = Array($this->i_trunk, $this->i_connection);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Connection."));
        }

        $this->i_connection = NULL;
    }
}

class Trunk {

    public $i_customer;
    public $i_account;
    public $i_trunk;
    public $name;
    public $description;
    public $outbound_cld;
    public $from_domain;
    public $random_call_id;
    public $connection;
    public $connection_backup;

    private $_fault;

    function __construct($i_customer, $i_account, $i_trunk = NULL) {
        global $db;

        $this->i_customer = $i_customer;
        $this->i_account = $i_account;
        $this->i_trunk = $i_trunk;
        $this->name = '';
        $this->description = '';
        $this->outbound_cld = '';
        $this->from_domain = '';
        $this->random_call_id = FALSE;
        $this->connection = NULL;
        $this->connection_backup = NULL;

        $this->_fault = FALSE;

        if ($this->i_trunk !== NULL) {
            $this->getEntry($this->i_trunk);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_trunk) {
        global $db;

        $sql = 'SELECT t.*
                  FROM trunks t
                  JOIN accounts a ON (a.i_account = t.i_account)
                 WHERE a.i_customer = ? AND t.i_account = ? AND t.i_trunk = ?
                 LIMIT 1';
        $params = Array($this->i_customer, $this->i_account, $i_trunk);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_trunk = $i_trunk;
        $this->name = $entry['name'];
        $this->description = $entry['description'];
        $this->connection = new Trunk_Connection($this->i_trunk, Trunk_Connection::TYPE_MAIN,
                                                 $entry['i_connection']);
        $this->connection_backup = new Trunk_Connection($this->i_trunk, Trunk_Connection::TYPE_BACKUP,
                                                        $entry['i_connection_backup']);
        $this->outbound_cld = $this->connection->translation_rule;
        $this->from_domain = $this->connection->from_domain;
        $this->random_call_id = $this->connection->random_call_id;
    }

    public function initFromRequest($par) {
        $this->i_trunk = $par['i_trunk'];
        $this->name = $par['name'];
        $this->description = $par['description'];
        $this->connection->initFromRequest($par);
        $this->connection_backup->initFromRequest($par);
        $this->outbound_cld = $this->connection->translation_rule;
        $this->from_domain = $this->connection->from_domain;
        $this->random_call_id = $this->connection->random_call_id;
    }

    public function genID() {
        global $db;

        return $db->nextID('trunks_seq');
    }

    public function buildClause() {
        $fc = (Array) get_par('filter_clause');
        $ret = Array('sql' => '', 'params' => Array());

        if ($fc['name'] != '') {
            $ret['sql'] .= ' AND t.name ' . ($fc['name_clause'] ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = $fc['name'];
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(t.*)
                  FROM trunks t
                  JOIN accounts a ON (a.i_account = t.i_account)
                 WHERE a.i_customer = ? AND t.i_account = ?
                       {$clause['sql']}";
        $params = Array($this->i_customer, $this->i_account);
        $params = array_merge($params, $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT t.i_trunk, t.name, t.description,
                       cn.destination AS destination, cn_bak.destination AS destination_backup
                  FROM trunks t
                  JOIN accounts a ON (a.i_account = t.i_account)
                  JOIN connections cn ON (cn.i_connection = t.i_connection)
             LEFT JOIN connections cn_bak ON (cn_bak.i_connection = t.i_connection_backup)
                 WHERE a.i_customer = ? AND t.i_account = ?
                       {$clause['sql']}
              ORDER BY t.name
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = Array($this->i_customer, $this->i_account);
        $params = array_merge($params, $clause['params']);

        $ret = $db->getAll($sql, $params);

        return $ret;
    }

    private function doesNameExist($name, $i_trunk = 0) {
        global $db;

        $sql = 'SELECT COUNT(t.*)
                  FROM trunks t
                  JOIN accounts a ON (a.i_account = t.i_account)
                 WHERE a.i_customer = ? AND t.i_account = ? AND
                       t.name = ? AND t.i_trunk <> ?';

        $params = Array($this->i_customer, $this->i_account, $name, $i_trunk);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $i_trunk = 0) {
        global $db;

        if ($par['name'] == '') {
            throw new Exception(_('"Name" field is mandatory.'));
        }

        if ($this->doesNameExist($par['name'], $i_trunk)) {
            throw new Exception(_('Another Trunk with conflicting "Name" already exists.'));
        }

        $this->connection->validate($par);
        $this->connection_backup->validate($par);
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $db->begin();

        $i_trunk = $this->genID();

        $this->connection = new Trunk_Connection($i_trunk, Trunk_Connection::TYPE_MAIN);
        $this->connection_backup = new Trunk_Connection($i_trunk, Trunk_Connection::TYPE_BACKUP);

        $this->validate($par);

        $sql = 'INSERT INTO trunks (i_trunk, i_account, name, description)
                     VALUES (?, ?, ?, ?)';
        $params = Array($i_trunk, $this->i_account, $par['name'],
                        $par['description']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Trunk."));
        }

        $this->connection->add($par);
        $this->connection_backup->add($par);

        $sql = 'UPDATE trunks
                   SET i_connection = ?, i_connection_backup = ?
                 WHERE i_trunk = ?';
        $params = Array($this->connection->i_connection, $this->connection_backup->i_connection,
                        $i_trunk);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Trunk."));
        }

        $this->getEntry($i_trunk);

        $db->commit();

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $db->begin();

        $this->validate($par, $this->i_trunk);

        $this->connection->update($par);
        $this->connection_backup->update($par);

        $sql = "UPDATE trunks
                   SET name = ?, description = ?,
                       i_connection = ?, i_connection_backup = ?
                 WHERE i_trunk = ?";
        $params = Array($par['name'], $par['description'],
                        $this->connection->i_connection,
                        $this->connection_backup->i_connection,
                        $this->i_trunk);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Trunk."));
        }

        $this->getEntry($this->i_trunk);

        $db->commit();

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        $sql = 'DELETE FROM trunks
                      WHERE i_trunk = ?';
        $params = Array($this->i_trunk);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Trunk."));
        }
    }

}

?>
