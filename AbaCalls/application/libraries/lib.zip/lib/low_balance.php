<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Low_Balance {

    public $i_low_balance;
    public $i_account;
    public $i_customer;
    public $threshold;
    public $notify_by_email;
    public $charge_card;
    public $charge_amount;
    public $i_debit_credit_card;
    public $br_charge_card;
    public $br_charge_amount;
    public $br_i_debit_credit_card;

    private $_fault;

    function __construct() {
        $this->i_account = NULL;
        $this->i_customer = NULL;

        $this->_fault = FALSE;
    }

    function __destruct() {
        /* nothing here */
    }

    private static function isOwnAccount($i_customer, $i_account) {
        global $db;

        $sql = 'SELECT i_account
                  FROM accounts
                 WHERE i_customer = ? AND i_account = ?
                 LIMIT 1';
        $params = Array($i_customer, $i_account);

        $c = $db->getValue($sql, $params);
        if ($c <= 0) {
            throw new Exception("No such Id.");
        }
    } 

    private static function isOwnSubcustomer($i_wholesaler, $i_customer) {
        global $db;

        $sql = 'SELECT i_customer
                  FROM customers
                 WHERE i_wholesaler = ? AND i_customer = ?
                 LIMIT 1';
        $params = Array($i_wholesaler, $i_customer);

        $c = $db->getValue($sql, $params);
        if ($c <= 0) {
            throw new Exception("No such Id.");
        }
    } 

    public static function getInstance($i_wholesaler, $type, $i_owner) {
        switch ($type) {
            case 'account':
                self::isOwnAccount($i_wholesaler, $i_owner);
                return new Low_Balance_Account($i_owner);
                break;

            case 'customer':
                self::isOwnSubcustomer($i_wholesaler, $i_owner);
                return new Low_Balance_Customer($i_owner);
                break;

            default:
                throw new Exception("Unable to getInstance(), wrong type ('" . $type . "')");
                break;
        }
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function initFromRequest($par) {
        $this->threshold = $par['threshold'] > 0 ? $par['threshold'] : NULL;
        $this->notify_by_email = $par['notify_by_email'] == '1';
        $this->charge_card = $par['charge_card'] == '1';
        $this->charge_amount = $par['charge_amount'];
        $this->i_debit_credit_card = $par['i_debit_credit_card'] > 0 ? $par['i_debit_credit_card'] : NULL;
        $this->br_charge_card = $par['br_charge_card'] == '1';
        $this->br_charge_amount = $par['br_charge_amount'] == '' ? NULL : $par['br_charge_amount'];
        $this->br_i_debit_credit_card = $par['br_i_debit_credit_card'] > 0 ? $par['br_i_debit_credit_card'] : NULL;
    }

    public function validate($par) {
        global $db;

        if ($par['threshold'] != '') {
            if (!(Validator::isFloat($par['threshold'], TRUE) && $par['threshold'] > 0)) {
                throw new Exception(_('"Threshold" field has incorrect number format. Non-negative Fractional number is expected.'));
            }
        }

        if ($par['charge_card']) {
            if (!(Validator::isFloat($par['charge_amount'], TRUE) && $par['charge_amount'] > 0)) {
                throw new Exception(_('"Charge Amount" field has incorrect number format. Non-negative number is expected.'));
            }

            if ($par['i_debit_credit_card'] > 0) {
                $sql = 'SELECT COUNT(*)
                          FROM debit_credit_cards
                         WHERE i_debit_credit_card = ? AND (i_account = ? OR i_customer = ?)';
                $params = Array($par['i_debit_credit_card'], $this->i_account, $this->i_customer);

                $c = $db->getValue($sql, $params);
                if ($c <= 0) {
                    throw new Exception(_('Wrong "Card" field.'));
                }
            }
        }

        if ($par['br_charge_card']) {
            if ($par['br_charge_amount'] != '' &&
                !(Validator::isFloat($par['br_charge_amount'], TRUE) &&
                  $par['br_charge_amount'] > 0)) {
                throw new Exception(_('"Charge Amount" field has incorrect number format. Non-negative number is expected.'));
            }

            if ($par['br_i_debit_credit_card'] > 0) {
                $sql = 'SELECT COUNT(*)
                          FROM debit_credit_cards
                         WHERE i_debit_credit_card = ? AND (i_account = ? OR i_customer = ?)';
                $params = Array($par['br_i_debit_credit_card'], $this->i_account, $this->i_customer);

                $c = $db->getValue($sql, $params);
                if ($c <= 0) {
                    throw new Exception(_('Wrong "Card" field.'));
                }
            }
        }

    }

    public function update($par) {
        global $db;

        $add_sql = '';
        $add_params = Array();

        if ($par['charge_card']) {
            $add_sql .= ', charge_amount = ?, i_debit_credit_card = ?';
            $add_params = array_merge($add_params, Array($par['charge_amount'],
                                $par['i_debit_credit_card'] > 0 ? $par['i_debit_credit_card'] : NULL));
        }

        if ($par['br_charge_card']) {
            $add_sql .= ', br_charge_amount = ?, br_i_debit_credit_card = ?';
            $add_params = array_merge($add_params, Array($par['br_charge_amount'] == '' ? NULL : $par['br_charge_amount'],
                                $par['br_i_debit_credit_card'] > 0 ? $par['br_i_debit_credit_card'] : NULL));
        }

        $sql = "UPDATE low_balances
                   SET threshold = ?, notify_by_email = ?,
                       charge_card = ?, br_charge_card = ?
                       $add_sql
                 WHERE i_low_balance = ?";
        $params = array_merge(Array($par['threshold'] > 0 ? $par['threshold'] : NULL,
                        $par['notify_by_email'] == '1',
                        $par['charge_card'] == '1',
                        $par['br_charge_card'] == '1'),
                        $add_params,
                        Array($this->i_low_balance));

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Low Balance."));
        }
    }

}

class Low_Balance_Account extends Low_Balance {

    function __construct($i_account) {
        global $db;

        parent::__construct();

        $this->getEntry($i_account);
    }

    function __destruct() {
        parent::__destruct();
    }

    public function getEntry($i_account) {
        global $db;

        $sql = 'SELECT lb.i_low_balance, lb.i_account, lb.threshold,
                       lb.notify_by_email,lb.charge_card, lb.charge_amount,
                       lb.i_debit_credit_card, lb.br_charge_card, lb.br_charge_amount,
                       lb.br_i_debit_credit_card
                  FROM low_balances lb
                 WHERE lb.i_account = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($i_account));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_account = $entry['i_account'];
        $this->i_low_balance = $entry['i_low_balance'];
        $this->threshold = $entry['threshold'] > 0 ? $entry['threshold'] : NULL;
        $this->notify_by_email = $entry['notify_by_email'] == 't';
        $this->charge_card = $entry['charge_card'] == 't';
        $this->charge_amount = $entry['charge_amount'];
        $this->i_debit_credit_card = $entry['i_debit_credit_card'] > 0 ? $entry['i_debit_credit_card'] : NULL;
        $this->br_charge_card = $entry['br_charge_card'] == 't';
        $this->br_charge_amount = $entry['br_charge_amount'] > 0 ? $entry['br_charge_amount'] : NULL;
        $this->br_i_debit_credit_card = $entry['br_i_debit_credit_card'] > 0 ? $entry['br_i_debit_credit_card'] : NULL;
    }

    public function update($par) {
        $this->setFault(TRUE);

        $this->validate($par);

        parent::update($par);

        $this->getEntry($this->i_account);

        $this->setFault(FALSE);
    }
}

class Low_Balance_Customer extends Low_Balance {

    function __construct($i_customer) {
        global $db;

        parent::__construct();

        $this->getEntry($i_customer);
    }

    function __destruct() {
        parent::__destruct();
    }

    public function getEntry($i_customer) {
        global $db;

        $sql = 'SELECT lb.i_low_balance, lb.i_customer, lb.threshold,
                       lb.notify_by_email,lb.charge_card, lb.charge_amount,
                       lb.i_debit_credit_card
                  FROM low_balances lb
                 WHERE lb.i_customer = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($i_customer));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_customer = $entry['i_customer'];
        $this->i_low_balance = $entry['i_low_balance'];
        $this->threshold = $entry['threshold'] > 0 ? $entry['threshold'] : NULL;
        $this->notify_by_email = $entry['notify_by_email'] == 't';
        $this->charge_card = $entry['charge_card'] == 't';
        $this->charge_amount = $entry['charge_amount'];
        $this->i_debit_credit_card = $entry['i_debit_credit_card'] > 0 ? $entry['i_debit_credit_card'] : NULL;
    }

    public function update($par) {
        $this->setFault(TRUE);

        $this->validate($par);

        parent::update($par);

        $this->getEntry($this->i_customer);

        $this->setFault(FALSE);
    }
}

?>
