<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Password {
    const PLAIN_TEXT = 0;
    const MD5 = 1;
    const SHA1 = 2;
    const SHA256 = 3;

    public static function crypt($password, $format, $salt = NULL) {
        switch ($format) {
            case self::MD5:
                return md5($password);
                break;

            case self::SHA1:
                return sha1($password);
                break;

            case self::SHA256:
                if ($salt === NULL) {
                    return bin2hex(mhash(MHASH_SHA256, $password));
                }
                return bin2hex(mhash(MHASH_SHA256, $password . $salt));
                break;

            case self::PLAIN_TEXT:
            default:
                return $password;
        }
    }

    public static function crypt_sip($username, $password, $realm) {
        $s = implode(':', array($username, $realm, $password));

        return self::crypt($s, self::MD5);
    }

    public static function gen($len = NULL) {
        if ($len === NULL) {
            $i_customer = $_SESSION['uid'] > 0 ? $_SESSION['uid'] : 1;
            $len = Password_Policy::getMaxPasswordLength($i_customer);
        }

        $template = 'abcdefghijklmnopqrstuvwxyz0123456789';
        do {
            for ($s = '', $i = 0, $z = strlen($template) - 1;
                 $i < $len;
                 $x = rand(0, $z), $s .= $template{$x}, $i++);
        } while (!preg_match('/\d+/', $s) && $len > 0);

        return $s;
    }

    public static function gen_salt($len = 8) {
        $template = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        for ($s = '', $i = 0, $z = strlen($template) - 1;
             $i < $len;
             $x = rand(0, $z), $s .= $template{$x}, $i++);
        return $s;
    }
}


class Web_Password {
    const WEB_USER = 'web_user';
    const CUSTOMER = 'customer';
    const ACCOUNT = 'account';
    const VENDOR = 'vendor';

    private $type;
    private $uid;
    private $web_label;

    function __construct($type, $uid = NULL, $web_label = NULL) {
        $this->type = $type;
        $this->uid = $uid;
        $this->web_label = ($web_label == NULL) ? _('Password') : $web_label;
    }

    public function update($password) {
        global $db;

        $salt = Password::gen_salt();
        $password = Password::crypt($password, Password::SHA256, $salt) . $salt;

        switch ($this->type) {
            case Web_Password::WEB_USER:
                $sql = 'UPDATE web_users
                           SET web_password = ?, last_password_change = now()
                         WHERE i_web_user = ?';
                $params = Array($password, $this->uid);
                break;

            case Web_Password::CUSTOMER:
                $sql = 'UPDATE web_users
                           SET web_password = ?, last_password_change = now()
                         WHERE i_customer = ? AND default_user';
                $params = Array($password, $this->uid);
                break;

            case Web_Password::ACCOUNT:
                $sql = 'UPDATE accounts
                           SET web_password = ?, last_password_change = now()
                         WHERE i_account = ?';
                $params = Array($password, $this->uid);
                break;

            case Web_Password::VENDOR:
                $sql = 'UPDATE vendors
                           SET web_password = ?, last_password_change = now()
                         WHERE i_vendor = ?';
                $params = Array($password, $this->uid);
                break;

            default:
                throw new Exception(_('Unable to update web password.'));
        }

        $db->prepNexec($sql, $params);
    }

    public function update_tmp($password) {
        global $db;

        $salt = Password::gen_salt();
        $password = Password::crypt($password, Password::SHA256, $salt) . $salt;

        switch ($this->type) {
            case Web_Password::WEB_USER:
                $sql = 'UPDATE web_users
                           SET tmp_web_password = ?, tmp_web_password_gen_date = now()
                         WHERE i_web_user = ?';
                $params = Array($password, $this->uid);
                break;

            case Web_Password::CUSTOMER:
                $sql = 'UPDATE web_users
                           SET tmp_web_password = ?, tmp_web_password_gen_date = now()
                         WHERE i_customer = ? AND default_user';
                $params = Array($password, $this->uid);
                break;

            case Web_Password::ACCOUNT:
                $sql = 'UPDATE accounts
                           SET tmp_web_password = ?, tmp_web_password_gen_date = now()
                         WHERE i_account = ?';
                $params = Array($password, $this->uid);
                break;

            case Web_Password::VENDOR:
                $sql = 'UPDATE vendors
                           SET tmp_web_password = ?, tmp_web_password_gen_date = now()
                         WHERE i_vendor = ?';
                $params = Array($password, $this->uid);
                break;

            default:
                throw new Exception(_('Unable to update temporary web password.'));
        }

        $db->prepNexec($sql, $params);
    }
}

class Password_History {
    private $type;
    private $uid;
    private $web_label;

    function __construct($type, $uid = NULL, $web_label = NULL) {
        $this->type = $type;
        $this->uid = $uid;
        $this->web_label = ($web_label == NULL) ? _('Password') : $web_label;
    }

    public function chk_rot_upd($password) {
        $this->check($password);
        $this->rotate($password);
        $p = new Web_Password($this->type, $this->uid, $this->web_label);
        $p->update($password);
    }

    public function check($password) {
        global $db;

        switch ($this->type) {
            case Web_Password::WEB_USER:
                $sql = 'SELECT web_password_history, web_password
                          FROM web_users
                         WHERE i_web_user = ?
                         LIMIT 1';
                $params = Array($this->uid);
                break;

            case Web_Password::CUSTOMER:
                $sql = 'SELECT web_password_history, web_password
                          FROM web_users
                         WHERE i_customer = ? AND default_user
                         LIMIT 1';
                $params = Array($this->uid);
                break;

            case Web_Password::ACCOUNT:
                $sql = 'SELECT web_password_history, web_password
                          FROM accounts
                         WHERE i_account = ?
                         LIMIT 1';
                $params = Array($this->uid);
                break;

            case Web_Password::VENDOR:
                $sql = 'SELECT web_password_history, web_password
                          FROM vendors
                         WHERE i_vendor = ?
                         LIMIT 1';
                $params = Array($this->uid);
                break;

            default:
                throw new Exception(_('Unable to check password history.'));
        }

        $p = $db->getAssociatedArray($sql, $params);
        $ph = ($p['web_password_history'] == '') ? Array() : explode(':', $p['web_password_history']);
        $ph[] = $p['web_password'];

        foreach ($ph as $p) {
            $old_hash = substr($p, 0, 64);
            $old_salt = substr($p, 64, 8);

            if (Password::crypt($password, Password::SHA256, $old_salt) == $old_hash) {
                $msg = sprintf(_('You may not re-use your password. Please select another "%s".'), $this->web_label);
                throw new Exception($msg);
            }
        }
    }

    public function rotate($password) {
        global $db;

        switch ($this->type) {
            case Web_Password::WEB_USER:
                $sql = 'SELECT web_password_history, web_password
                          FROM web_users
                         WHERE i_web_user = ?
                         LIMIT 1';
                $params = Array($this->uid);
                break;

            case Web_Password::CUSTOMER:
                $sql = 'SELECT web_password_history, web_password
                          FROM web_users
                         WHERE i_customer = ? AND default_user
                         LIMIT 1';
                $params = Array($this->uid);
                break;

            case Web_Password::ACCOUNT:
                $sql = 'SELECT web_password_history, web_password
                          FROM accounts
                         WHERE i_account = ?
                         LIMIT 1';
                $params = Array($this->uid);
                break;

            case Web_Password::VENDOR:
                $sql = 'SELECT web_password_history, web_password
                          FROM vendors
                         WHERE i_vendor = ?
                         LIMIT 1';
                $params = Array($this->uid);
                break;

            default:
                throw new Exception(_('Unable to check password history.'));
        }

        $p = $db->getAssociatedArray($sql, $params);

        if ($p['web_password'] == '') {
            return;
        }

        $ph = ($p['web_password_history'] == '') ? Array() : explode(':', $p['web_password_history']);
        if (count($ph) == 3) {
            array_shift($ph);
        }
        $ph[] = $p['web_password'];

        switch ($this->type) {
            case Web_Password::WEB_USER:
                $sql = 'UPDATE web_users
                           SET web_password_history = ?
                         WHERE i_web_user = ?';
                $params = Array(implode(':', $ph), $this->uid);
                break;

            case Web_Password::CUSTOMER:
                $sql = 'UPDATE web_users
                           SET web_password_history = ?
                         WHERE i_customer = ? AND default_user';
                $params = Array(implode(':', $ph), $this->uid);
                break;

            case Web_Password::ACCOUNT:
                $sql = 'UPDATE accounts
                           SET web_password_history = ?
                         WHERE i_account = ?';
                $params = Array(implode(':', $ph), $this->uid);
                break;

            case Web_Password::VENDOR:
                $sql = 'UPDATE vendors
                           SET web_password_history = ?
                         WHERE i_vendor = ?';
                $params = Array(implode(':', $ph), $this->uid);
                break;

            default:
                throw new Exception(_('Unable to rotate password history.'));
        }

        $db->prepNexec($sql, $params);
    }
}
?>
