<?php

// Copyright (c) 2003-2005 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class SharedPaymentProcessors_View {
    private $uid;
    private $acct_type;
    private $i_owner;
    private $i_wholesalers;
    private $payment_currency;
    private $pps;
    private $root_payment_processor;
    private $last_payment_processor;

    function __construct($uid, $acct_type) {
        global $db;

        $this->uid = $uid;
        $this->acct_type = $acct_type;

        if ($this->acct_type == 'customer') {
            $sql = 'SELECT i_wholesaler AS i_owner, payment_currency
                      FROM customers
                     WHERE i_customer = ?
                     LIMIT 1';
        } else {
            $sql = 'SELECT i_customer AS i_owner, payment_currency
                      FROM accounts
                     WHERE i_account = ?
                     LIMIT 1';
        }

        $params = Array($uid);
        $ret = $db->getAssociatedArray($sql, $params);
        $this->i_owner = $ret['i_owner'];
        $this->payment_currency = $ret['payment_currency'];

        $sql = 'SELECT get_customer_i_wholesalers(?)';
        $params = Array($this->i_owner);
        $this->i_wholesalers = $db->getValue($sql, $params);
    }

    function create() {
        global $db;

        $sql = 'CREATE TEMP TABLE payment_processors (
                       LIKE payment_processors,
                       orig_iso_4217   CHARACTER(3),
                       x_rate_base2pp DOUBLE PRECISION,
                       x_rate_base2wholesaler DOUBLE PRECISION,
                       x_rate_base2orig_pp DOUBLE PRECISION
                      )';
        $res = $db->prepNexec($sql);

        if ($res !== TRUE) {
            error_log('Unable to CREATE temp table payment_processors.');
            exit(1);
        }

        $sql = 'INSERT INTO payment_processors (
                            SELECT pp.*, pp.iso_4217, x.rate, x2.rate, x.rate
                              FROM public.payment_processors pp
                              JOIN x_rates x ON (x.i_customer = pp.i_customer AND x.iso_4217 = pp.iso_4217)
                              JOIN customers c ON (c.i_customer = pp.i_customer)
                              JOIN x_rates x2 ON (x2.i_customer = c.i_wholesaler AND x2.iso_4217 = c.base_currency)
                             WHERE pp.i_customer = ANY(get_customer_i_wholesalers(?)))';
        $params = Array($this->i_owner);
        $db->prepNexec($sql, $params);

        $sql = 'SELECT *
                  FROM payment_processors
              ORDER BY i_payment_processor';
        $res = $db->getAll($sql);

        $pps = Array();
        foreach ($res as $row) {
            $pps[$row['i_payment_processor']] = $row;

            if ($row['inherited_from'] > 0) {
                $sql = 'UPDATE payment_processors
                           SET i_merchant = ?,
                               password = ?,
                               env = ?,
                               cert_password = ?,
                               certificate = ?,
                               login = ?,
                               iso_4217 = ?,
                               manual_charge = ?,
                               x_rate_base2pp = x_rate_base2wholesaler / ? * ? * ?
                         WHERE i_payment_processor = ?';
                $i_pp = $row['inherited_from'];
                $params = Array($pps[$i_pp]['i_merchant'],
                                $pps[$i_pp]['password'],
                                $pps[$i_pp]['env'],
                                $pps[$i_pp]['cert_password'],
                                $pps[$i_pp]['certificate'],
                                $pps[$i_pp]['login'],
                                $pps[$i_pp]['iso_4217'],
                                $pps[$i_pp]['manual_charge'],
                                $pps[$i_pp]['x_rate_base2orig_pp'],
                                $pps[$i_pp]['inherited_from'] > 0 ? $pps[$i_pp]['x_rate_base2pp'] : 1,
                                $pps[$i_pp]['inherited_from'] > 0 ? $pps[$i_pp]['x_rate_base2orig_pp'] : 1,
                                $row['i_payment_processor']
                               );
                $db->prepNexec($sql, $params);

                $sql = 'SELECT *
                          FROM payment_processors
                         WHERE i_payment_processor = ?
                         LIMIT 1';
                $params = Array($row['i_payment_processor']);
                $pps[$row['i_payment_processor']] = $db->getAssociatedArray($sql, $params);
            }
        }

        $sql = 'DELETE FROM payment_processors
                      WHERE orig_iso_4217 <> ? AND i_customer = ?';
        $params = Array($this->payment_currency, $this->i_owner);
        $db->prepNexec($sql, $params);
    }

    function drop() {
        global $db;

        $sql = 'SELECT nspname
                  FROM pg_class
                  JOIN pg_namespace ON (pg_namespace.oid = relnamespace)
                 WHERE relname = ? AND nspname <> ?
                 LIMIT 1';
        $params = Array('payment_processors', 'public');
        $tmp_schema = $db->getValue($sql, $params);

        if ($db->affected_rows == 1) {
            $sql = "DROP TABLE $tmp_schema.payment_processors";
            $db->prepNexec($sql);
        }
    }

    function getAll($i_payment_processor, $currency, $amount, $fee) {
        global $db;

        $sql = 'SELECT p.*, c.base_currency
                  FROM payment_processors p
                  JOIN customers c USING (i_customer)
              ORDER BY p.i_payment_processor';
        $res = $db->getAll($sql);

        $this->pps = Array();
        foreach ($res as $row) {
            $this->pps[$row['i_payment_processor']] = $row;
        }

        $pp = &$this->pps[$i_payment_processor];

        $sql = 'SELECT rate
                  FROM x_rates
                 WHERE i_customer = ? AND iso_4217 = ?';
        $params = Array($pp['i_customer'], $currency);
        $x_rate_base2payer = $db->getValue($sql, $params);

        // last level
        $pp['amount'] = $amount * $x_rate_base2payer;
        $pp['fee'] = $fee * $x_rate_base2payer;

        $this->last_payment_processor = $i_payment_processor;
        $this->set_root_payment_processor($pp['i_payment_processor']);

        // first level
        $sql = 'SELECT rate
                  FROM x_rates
                 WHERE i_customer = ? AND iso_4217 = ?';
        $params = Array($this->pps[$this->root_payment_processor]['i_customer'],
                        $this->pps[$this->root_payment_processor]['iso_4217']);
        $x_rate_base2pp = $db->getValue($sql, $params);

        $amount = $pp['amount'] * $pp['x_rate_base2pp'] * $x_rate_base2pp;
        $fee = 0;

        $this->set_payment_details($this->pps[$this->root_payment_processor], $amount);

        return $this->pps;
    }

    private function set_root_payment_processor($i_payment_processor) {
        $pp = &$this->pps[$i_payment_processor];
        if ($pp['inherited_from'] > 0) {
            $this->pps[$pp['inherited_from']]['next_i_payment_processor'] = $i_payment_processor;
            $this->set_root_payment_processor($pp['inherited_from']);
        } else {
            $this->root_payment_processor = $i_payment_processor;
        }
    }

    private function set_payment_details(&$parent_pp, $amount) {
        if (!array_key_exists('next_i_payment_processor', $parent_pp)) {
            return;
        }

        $pp = &$this->pps[$parent_pp['next_i_payment_processor']];
        $parent_pp['amount'] = $amount;
        $parent_pp['fee'] = $parent_pp['amount'] + 
                            $parent_pp['shared_fixed_fee'] * $parent_pp['x_rate_base2orig_pp'] -
                            $parent_pp['amount'] / (1 + $parent_pp['shared_variable_fee']);

        $this->set_payment_details($pp, $parent_pp['amount'] / $pp['x_rate_base2wholesaler']);
    }
}

function get_private_dir() {
    $i_env = get_my_i_env();

    $dir = '/var/env' . $i_env . '/payment_processors/';
    if (!is_dir($dir)) {
        $umask = umask();
        umask(0007);
        @mkdir($dir);
        umask($umask);
    }

    return $dir;
}

function can_share_pp($i_customer) {
    global $db;

    $sql = 'SELECT share_payment_processors
              FROM customers
             WHERE i_customer = ?';
    $params = Array($i_customer);
    $res = $db->getValue($sql, $params);

    return Cast::str2bool($res);
}

/* get paymet processor info */
function get_pp($pp_id, $i_customer, $ignore_inherited_from = FALSE) {
    global $db;

    $sql = "SELECT *, variable_fee * 100.0 AS variable_fee,
                   shared_variable_fee * 100.0 AS shared_variable_fee
              FROM payment_processors
             WHERE i_payment_processor = ? AND i_customer = ?";

    $ret = $db->getAssociatedArray($sql, Array($pp_id, $i_customer));

    $ret['shared'] = Cast::str2bool($ret['shared']);
    if (!$ignore_inherited_from && $ret['inherited_from'] > 0) {
        $ret['i_merchant'] = -$ret['inherited_from'];
    }
    $ret['manual_charge'] = Cast::str2bool($ret['manual_charge']);

    if (!is_null($ret['certificate'])) {
        $ret['key_file'] = 'keyfile_' . $pp_id . '.pem';
        $umask = umask();
        umask(0177);

        $fname = get_private_dir() . 'keyfile_' . 
                $pp_id . '.pem';
        $f_out = fopen($fname.'.tmp', 'w+');
        fwrite($f_out, base64_decode($ret['certificate']));
        fclose($f_out);
        rename($fname.'.tmp', $fname);
        umask($umask);
    }

    gen_additional_configs($ret);

    return $ret;
}

function process_redirect($tx) {

    if ($tx['type'] == 'Turkish Garanti Bank (3D FULL)') {

        include_once('lib/payment_processors/turkish_garanti_3D_full.php');

        return pp_redirect($tx);

    } elseif ($tx['type'] == 'PayPal REST API (PayPal)') {

        include_once('lib/payment_processors/paypal_rest_paypal.php');

        return pp_redirect($tx);

    } elseif ($tx['type'] == 'Turkish IsBank (3D)') {

        include_once('lib/payment_processors/turkish_IsBank_3D.php');

        return pp_redirect($tx);

    } elseif ($tx['type'] == 'Turkish DenizBank (3D)') {

        include_once('lib/payment_processors/turkish_DenizBank_3D.php');

        return pp_redirect($tx);

    } else

        return array('FAIL', 'payment processor not found or does not support this method');

}

function process_return_cancel($tx) {

    if ($tx['type'] == 'PayPal REST API (PayPal)') {

        include_once('lib/payment_processors/paypal_rest_paypal.php');

        return pp_return_cancel($tx);

    } else

        return array('FAIL', 'payment processor not found or does not support this method');

}

function process_return_ok(&$tx) {

    if ($tx['type'] == 'Turkish Garanti Bank (3D FULL)') {

        include_once('lib/payment_processors/turkish_garanti_3D_full.php');

        return pp_return_ok($tx);

    } elseif ($tx['type'] == 'PayPal REST API (PayPal)') {

        include_once('lib/payment_processors/paypal_rest_paypal.php');

        return pp_return_ok($tx);

    } elseif ($tx['type'] == 'Turkish IsBank (3D)') {

        include_once('lib/payment_processors/turkish_IsBank_3D.php');

        return pp_return_ok($tx);

    } elseif ($tx['type'] == 'Turkish DenizBank (3D)') {

        include_once('lib/payment_processors/turkish_DenizBank_3D.php');

        return pp_return_ok($tx);

    } else

        return array('FAIL', 'payment processor not found or does not support this method');

}

function process_payment(&$tx) {

    if ($tx['type'] == 'Turkish Garanti Bank (3D FULL)') {

        include_once('lib/payment_processors/turkish_garanti_3D_full.php');

        return pp_process($tx);

    } elseif ($tx['type'] == 'Bank Asya') {

        include_once('lib/payment_processors/bank_asya.php');

        return pp_process($tx);

    } elseif ($tx['type'] == 'Authorize.Net') {

        include_once('lib/payment_processors/authorize_net.php');

        return pp_process($tx);

    } elseif ($tx['type'] == 'PayPal REST API (PayPal)') {

        include_once('lib/payment_processors/paypal_rest_paypal.php');

        return pp_process($tx);

    } elseif ($tx['type'] == 'PayPal REST API (Credit Cards)') {

        include_once('lib/payment_processors/paypal_rest_cc.php');

        return pp_process($tx);

    } elseif ($tx['type'] == 'Turkish IsBank (3D)') {

        include_once('lib/payment_processors/turkish_IsBank_3D.php');

        return pp_process($tx);

    } elseif ($tx['type'] == 'Turkish DenizBank (3D)') {

        include_once('lib/payment_processors/turkish_DenizBank_3D.php');

        return pp_process($tx);

    } else

        return array('FAIL', 'payment processor not found or does not support this method');

}


function check_key_file($pp) {

    /* it is a placeholder now as no processors use it */

    //if ($pp['i_merchant'] == 1) {               /* Linkpoint */
    //
    //    include_once('lib/payment_processors/linkpoint.php');
    //
    //    return pp_check_key_file($pp['key_file']);
    //
    //} else

        return 'FAIL: payment processor not found or does not support this method';

}


function complete_pending_transaction($pp, $p) {

    if ($pp['i_merchant'] == 18) {               /* PayPal REST API (PayPal) */

        include_once('lib/payment_processors/paypal_rest_paypal.php');

        return pp_complete_pending_transaction($pp, $p);

    } elseif ($pp['i_merchant'] == 19) {               /* PayPal REST API (Credit Cards) */

        include_once('lib/payment_processors/paypal_rest_cc.php');

        return pp_complete_pending_transaction($pp, $p);

    }

    return Array('FAIL', 'Payment processor not found or does not support this method');
}

function gen_additional_configs($pp) {

    /* it is a placeholder now as no processors use it */

    //if ($pp['i_merchant'] == 4) {               /* ECOMM */
    //
    //    include_once('lib/payment_processors/ecomm.php');
    //
    //    return pp_gen_additional_configs($pp);
    //
    //}

    return;                                     /* default is OK */

}


function del_additional_configs($pp) {

    /* it is a placeholder now as no processors use it */

    //if ($pp['i_merchant'] == 4) {               /* ECOMM */
    //
    //    include_once('lib/payment_processors/ecomm.php');
    //
    //    return pp_del_additional_configs($pp);
    //
    //}

    return;                                     /* default is OK */

}

?>
