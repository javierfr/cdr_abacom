<?php

// Copyright (c) 2017 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Tariff {

    public $i_tariff;
    public $name;
    public $iso_4217;
    public $local_calling;
    public $lock_for_upload;

    private $_fault;

    function __construct($i_tariff = NULL) {

        $this->i_tariff = $i_tariff;
        $this->name = NULL;
        $this->iso_4217 = NULL;
        $this->local_calling = FALSE;
        $this->lock_for_upload = FALSE;

        $this->_fault = FALSE;

        if ($this->i_tariff !== NULL) {
            $this->getEntry($this->i_tariff);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_tariff) {
        global $db;

        $sql = "SELECT t.i_tariff, t.name,
                       t.iso_4217,
                       t.local_calling, t.lock_for_upload
                  FROM tariffs t
                 WHERE t.i_tariff = ?
                 LIMIT 1";
        $params = Array($i_tariff);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_tariff = $entry['i_tariff'];
        $this->name = $entry['name'];
        $this->iso_4217 = $entry['iso_4217'];
        $this->local_calling = Cast::str2bool($entry['local_calling']);
        $this->lock_for_upload = Cast::str2bool($entry['lock_for_upload']);
    }

    public function get_upload_status() {
        global $db;

        $sql = "SELECT EXTRACT(EPOCH FROM started_on) AS started_on,
                       EXTRACT(EPOCH FROM finished_on) AS finished_on,
                       progress, errors_found
                  FROM upload_reports
                 WHERE i_tariff = ?
                 LIMIT 1";
        $params = Array($this->i_tariff);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($entry === FALSE) {
            $ret = Array(
                'lock_for_upload' => $this->lock_for_upload,
                'status' => 'error',
                'err_msg' => 'Unable to get upload status'
            );
        }

        if ($db->affected_rows == 0) {
            $ret = Array(
                'lock_for_upload' => $this->lock_for_upload,
                'status' => 'not_uploaded'
            );
        } else {
            $ret = Array(
                'lock_for_upload' => $this->lock_for_upload,
                'started_on' => strftime($_SESSION['tz_format_no_seconds'], $entry['started_on']),
                'finished_on' => strftime($_SESSION['tz_format_no_seconds'], $entry['finished_on']),
                'progress' => sprintf("%d", $entry['progress'] * 100),
                'errors_found' => Cast::str2bool($entry['errors_found'])
            );
        }

        return $ret;
    }

    public function get_upload_report() {
        global $db;

        $sql = "SELECT content_name, content_type, data, errors_found
                  FROM upload_reports
                 WHERE progress = 1
                       AND i_tariff = ?
                 LIMIT 1";
        $params = Array($this->i_tariff);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows == 0) {
            return NULL;
        }

        $entry['data'] = base64_decode($entry['data']);

        return $entry;
    }
}

?>
