<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class DID_Authorization {

    public $i_customer;
    public $i_did;
    public $i_did_authorization;
    public $incoming_did;
    public $cli_translation_rule;
    public $i_vendor;
    public $i_connection;
    public $buying_i_dids_charging_group;

    public $is_main_rule;

    private $_fault;

    function __construct($i_customer, $i_did, $i_did_authorization = NULL) {
        global $db;

        $this->i_customer = $i_customer;
        $this->i_did = $i_did;
        $this->i_did_authorization = $i_did_authorization;
        $this->incoming_did = '';
        $this->cli_translation_rule = '';
        $this->i_vendor = NULL;
        $this->i_connection = NULL;
        $this->buying_i_dids_charging_group = NULL;

        $this->is_main_rule = TRUE;

        $this->_fault = FALSE;

        if ($this->i_did_authorization !== NULL) {
            $this->getEntry($this->i_did_authorization);
        } else {
            /* check if DID belongs to this customer */
            $sql = 'SELECT COUNT(*)
                      FROM dids
                     WHERE i_did = ? AND i_customer = ?';
            $params = Array($this->i_did, $this->i_customer);

            if ($db->getValue($sql, $params) != 1) {
                throw new Exception(_('Wrong i_did.'));
            }
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_did_authorization) {
        global $db;

        $sql = 'SELECT da.*,
                       (SELECT MIN(da2.i_did_authorization) = da.i_did_authorization
                          FROM did_authorizations da2
                         WHERE da2.i_did = da.i_did) AS is_main_rule
                  FROM did_authorizations da
                 WHERE da.i_did = ? AND da.i_did_authorization = ?
                 LIMIT 1';
        $params = Array($this->i_did, $i_did_authorization);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_did_authorization = $i_did_authorization;
        $this->incoming_did = $entry['incoming_did'];
        $this->cli_translation_rule = $entry['cli_translation_rule'];
        $this->i_vendor = $entry['i_vendor'];
        $this->i_connection = $entry['i_connection'];
        $this->buying_i_dids_charging_group = $entry['i_dids_charging_group'];

        $this->is_main_rule = Cast::str2bool($entry['is_main_rule']);
    }

    public function initFromRequest($par) {
        $this->i_did_authorization = $par['i_did_authorization'];
        $this->incoming_did = $par['incoming_did'];
        $this->cli_translation_rule = $par['cli_translation_rule'];
        $this->i_vendor = $par['i_vendor'];
        $this->i_connection = $par['i_connection'];
        $this->buying_i_dids_charging_group = $par['buying_i_dids_charging_group'];
    }

    public function genID() {
        global $db;

        return $db->nextID('did_authorizations_seq');
    }

    public function getList() {
        global $db;

        $sql = "SELECT da.*, v.name AS v_name, cn.name AS cn_name, dcg.name AS dcg_name
                  FROM did_authorizations da
             LEFT JOIN vendors v ON (v.i_vendor = da.i_vendor)
             LEFT JOIN connections cn ON (cn.i_connection = da.i_connection)
             LEFT JOIN dids_charging_groups dcg ON (dcg.i_dids_charging_group = da.i_dids_charging_group)
                 WHERE da.i_did = ?
              ORDER BY da.i_did_authorization";

        $params = Array($this->i_did);

        $ret = $db->getAll($sql, $params);

        return $ret;
    }

    public function validate($par, $i_did_authorization = 0) {
        global $db;

        if (trim($par['incoming_did']) == '') {
            throw new Exception(_('"Incoming DID/CLD" field is mandatory.'));
        }

        if (!Validator::isIncomingPrefix(trim($par['incoming_did']))) {
            throw new Exception(_('"Incoming DID/CLD" field has incorrect format.'));
        }

        if (!Validator::isTransRule($par['cli_translation_rule'])) {
            throw new Exception(_('"CLI Translation Rule" field has incorrect syntax.'));
        }

        if ($this->i_customer == 1 && $par['i_vendor'] > 0) {
            $sql = 'SELECT COUNT(*) 
                      FROM vendors 
                     WHERE i_vendor = ?';
            $params = Array($par['i_vendor']);

            if ($db->getValue($sql, $params) != 1) {
                throw new Exception(_('You cannot assign this Vendor.'));
            }
        }

        if ($this->i_customer == 1 && $par['i_connection'] > 0) {
            $sql = 'SELECT COUNT(*) 
                      FROM connections 
                     WHERE i_connection = ? AND i_vendor = ?';
            $params = Array($par['i_connection'], $par['i_vendor']);

            if ($db->getValue($sql, $params) != 1) {
                throw new Exception(_('You cannot assign this Connection.'));
            }
        }

        if ($this->i_customer == 1 && $par['buying_i_dids_charging_group'] > 0) {
            $sql = 'SELECT COUNT(*)
                      FROM dids_charging_groups dcg 
                      JOIN vendors v ON (v.i_vendor = ? AND dcg.iso_4217 = v.base_currency)
                     WHERE dcg.i_customer = ? AND dcg.type = 2 AND dcg.i_dids_charging_group = ?';
            $params = Array($par['i_vendor'], $this->i_customer,
                            $par['buying_i_dids_charging_group']);

            if ($db->getValue($sql, $params) != 1) {
                throw new Exception(_('Vendor and Buying Charging Group currencies must match.'));
            }
        }

        /* chech auth rule */
        $add_sql = '';
        $add_params = Array();

        if ($this->i_customer == 1) {
            $keys = Array('incoming_did', 'i_vendor', 'i_connection');
        } else {
            $keys = Array('incoming_did');
        }
        foreach ($keys as $key) {
            if ($par[$key] > 0) {
                $add_sql .= ' AND ' . $key . ' = ?';
                $add_params[] = $par[$key];
            } else {
                $add_sql .= ' AND ' . $key . ' IS NULL';
            }
        }

        $sql = "SELECT COUNT(*) 
                  FROM did_authorizations da 
                 WHERE da.i_did_authorization <> ?
                       $add_sql";
        $params = Array($i_did_authorization);
        $params = array_merge($params, $add_params);

        if ($db->getValue($sql, $params) != 0) {
            throw new Exception(_('Conflicting DID authorizations already exists.'));
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $i_did_authorization = $this->genID();

        $sql = 'INSERT INTO did_authorizations (i_did_authorization, i_did, incoming_did,
                                                cli_translation_rule, i_vendor, i_connection,
                                                i_dids_charging_group)
                     VALUES (?, ?, ?, ?, ?, ?, ?)';

        $params = Array($i_did_authorization,
                        $this->i_did,
                        trim($par['incoming_did']),
                        $par['cli_translation_rule']);
        if ($this->i_customer == 1) {
            $add_params = Array($par['i_vendor'] > 0 ? $par['i_vendor'] : NULL,
                                $par['i_vendor'] > 0 && $par['i_connection'] > 0 ?
                                    $par['i_connection'] : NULL,
                                $par['i_vendor'] > 0 && $par['i_connection'] && $par['buying_i_dids_charging_group'] > 0 ?
                                    $par['buying_i_dids_charging_group'] : NULL);
        } else {
            $add_params = Array(NULL, NULL, NULL);
        }
        $params = array_merge($params, $add_params);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert DID authorizations."));
        }

        $this->getEntry($i_did_authorization);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $this->i_did_authorization);

        $sql = "UPDATE did_authorizations
                   SET incoming_did = ?, cli_translation_rule = ?, i_vendor = ?,
                       i_connection = ?, i_dids_charging_group = ?
                 WHERE i_did_authorization = ? AND i_did = ?";

        $params = Array(trim($par['incoming_did']), $par['cli_translation_rule']);

        if ($this->i_customer == 1) {
            $add_params = Array($par['i_vendor'] > 0 ? $par['i_vendor'] : NULL,
                                $par['i_vendor'] > 0 && $par['i_connection'] > 0 ?
                                    $par['i_connection'] : NULL,
                                $par['i_vendor'] > 0 && $par['i_connection'] && $par['buying_i_dids_charging_group'] > 0 ?
                                    $par['buying_i_dids_charging_group'] : NULL);
        } else {
            $add_params = Array(NULL, NULL, NULL);
        }
        $params = array_merge($params, (Array)$add_params);

        $params = array_merge($params, Array($this->i_did_authorization, $this->i_did));

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update DID authorizations."));
        }

        $this->getEntry($this->i_did_authorization);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        if ($this->is_main_rule) {
            throw new Exception(_("Cannot delete DID authorizations."));
        }

        $sql = 'DELETE FROM did_authorizations
                 WHERE i_did_authorization = ? AND i_did = ?';
        $params = Array($this->i_did_authorization, $this->i_did);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete DID authorizations."));
        }
    }

}

?>
