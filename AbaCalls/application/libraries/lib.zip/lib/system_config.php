<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class System_Config_Entry {

    public $key;
    public $value;
    public $validator;
    public $label;
    public $akey;       /* access key */

    private $_record_exists;
    private $_fault;

    function __construct($key, $default_value = '') {
        $this->key = $key;
        $this->value = $default_value;
        $this->validator = NULL;
        $this->label = '';
        $this->akey = str_replace('/', '__', $key);

        $this->_record_exists = TRUE;
        $this->_fault = FALSE;

        $this->getEntry($this->key);
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function setValidator($validator) {
        if ($validator !== NULL) {
            $this->validator = 'Validator::' . $validator;
        }
    }

    public function setLabel($label) {
        $this->label = $label;
    }

    public function getEntry($key) {
        global $db;

        $sql = "SELECT COALESCE(sc.value, scd.value) AS value,
                       sc.key IS NOT NULL AS _record_exists
                  FROM system_config_defaults scd
             LEFT JOIN system_config sc USING (key)
                 WHERE key = ?
                 LIMIT 1";
        $params = Array($key);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            /* use defaults */
            $this->_record_exists = FALSE;
            return;
        }

        $this->key = $key;
        $this->value = $entry['value'];
        $this->_record_exists = Cast::str2bool($entry['_record_exists']);
    }

    public function initFromRequest($par) {
        $this->value = $par[$this->akey];
    }

    public function validate($par) {
        if ($this->validator !== NULL && !call_user_func($this->validator, $par[$this->akey])) {
            throw new Exception(sprintf(_('"%s" field has incorrect syntax.'), $this->label));
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $sql = 'INSERT INTO system_config (key, value)
                     VALUES (?, ?)';
        $params = Array($this->key, $par[$this->akey]);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert System Config entry."));
        }

        $this->getEntry($this->key);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $sql = "UPDATE system_config
                   SET value = ?
                 WHERE key = ?";
        $params = Array($par[$this->akey], $this->key);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update System Config entry."));
        }

        $this->getEntry($this->key);

        $this->setFault(FALSE);
    }

    public function updateOrAdd($par) {
        if ($this->_record_exists) {
            $this->update($par);
        } else {
            $this->add($par);
        }
    }
}

?>
