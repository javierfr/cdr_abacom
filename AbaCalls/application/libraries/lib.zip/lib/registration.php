<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Registration {

    public $i_registration;
    public $name;
    public $description;
    public $i_connection;
    public $i_vendor;
    public $contact;
    public $username;
    public $domain;

    private $_fault;

    function __construct($i_registration = NULL) {
        global $db;

        $this->i_registration = $i_registration;
        $this->name = '';
        $this->description = '';
        $this->i_connection = NULL;
        $this->i_vendor = -1;
        $this->contact = '';
        $this->username = '';
        $this->domain = '';

        $this->_fault = FALSE;

        if ($this->i_registration !== NULL) {
            $this->getEntry($this->i_registration);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_registration) {
        global $db;

        $sql = 'SELECT r.*, cn.i_vendor
                  FROM registrations r
                  JOIN connections cn ON (cn.i_connection = r.i_connection)
                 WHERE r.i_registration = ?
                 LIMIT 1';
        $params = Array($i_registration);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_registration = $i_registration;
        $this->name = $entry['name'];
        $this->description = $entry['description'];
        $this->i_connection = $entry['i_connection'];
        $this->i_vendor = $entry['i_vendor'];
        $this->contact = $entry['contact'];
        $this->username = $entry['username'];
        $this->domain = $entry['domain'];
    }

    public function initFromRequest($par) {
        $this->i_registration = $par['i_registration'];
        $this->name = $par['name'];
        $this->description = $par['description'];
        $this->i_connection = $par['i_connection'];
        $this->i_vendor = $par['i_vendor'];
        $this->contact = $par['contact'];
        $this->username = $par['username'];
        $this->domain = $par['domain'];
    }

    public function genID() {
        global $db;

        return $db->nextID('registrations_seq');
    }

    public function buildClause() {
        $fc = (Array) get_par('filter_clause');
        $ret = Array('sql' => 'TRUE', 'params' => Array());

        if ($fc['name'] != '') {
            $ret['sql'] .= ' AND r.name ' . ($fc['name_clause'] ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = $fc['name'];
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(r.*)
                  FROM registrations r
                 WHERE {$clause['sql']}";
        $params = $clause['params'];

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT r.i_registration, r.name, r.description,
                       r.contact, r.username, r.domain,
                       cn.name AS cn_name, v.name AS v_name,
                       v.i_vendor, cn.i_connection,
                       EXTRACT(EPOCH FROM r.expires) AS expires,
                       r.status, r.extended_status
                  FROM registrations r
                  JOIN connections cn ON (cn.i_connection = r.i_connection)
                  JOIN vendors v ON (v.i_vendor = cn.i_vendor)
                 WHERE {$clause['sql']}
              ORDER BY r.name
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = $clause['params'];

        $ret = $db->getAll($sql, $params);

        return $ret;
    }

    private function doesNameExist($name, $i_registration = 0) {
        global $db;

        $sql = 'SELECT COUNT(r.*)
                  FROM registrations r
                 WHERE r.name = ? AND r.i_registration <> ?';

        $params = Array($name, $i_registration);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $i_registration = 0) {
        global $db;

        if ($par['name'] == '') {
            throw new Exception(_('"Name" field is mandatory.'));
        }

        if ($this->doesNameExist($par['name'], $i_registration)) {
            throw new Exception(_('Another Registration with conflicting "Name" already exists.'));
        }

        if ($par['i_connection'] == '' || $par['i_connection'] <= 0) {
            throw new Exception(_('"Connection" field is mandatory.'));
        }

        if ($par['contact'] == '' && $par['username'] == '' && $par['domain'] == '') {
            throw new Exception(_('At least one of "Contact", "Username" or "Domain" fields has to be specified.'));
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $i_registration = $this->genID();

        $this->validate($par);

        $sql = 'INSERT INTO registrations
                            (i_registration, name, description, i_connection,
                             contact, username, domain)
                     VALUES (?, ?, ?, ?, ?, ?, ?)';
        $params = Array($i_registration, $par['name'], $par['description'],
                        $par['i_connection'], $par['contact'], $par['username'],
                        $par['domain']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Registration."));
        }

        $this->getEntry($i_registration);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $this->i_registration);

        $sql = "UPDATE registrations
                   SET name = ?, description = ?,
                       i_connection = ?, contact = ?,
                       username = ?, domain = ?
                 WHERE i_registration = ?";
        $params = Array($par['name'], $par['description'],
                        $par['i_connection'], $par['contact'], $par['username'],
                        $par['domain'], $this->i_registration);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Registration."));
        }

        $this->getEntry($this->i_registration);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        $sql = 'DELETE FROM registrations
                      WHERE i_registration = ?';
        $params = Array($this->i_registration);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Registration."));
        }
    }
}

?>
