<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Account_Lookup {

    public $i_customer;
    public $accounts;
    public $make_search;

    private $_fault;

    function __construct($i_customer, $make_search = TRUE) {
        $this->i_customer = $i_customer;
        $this->make_search = $make_search;
        $this->accounts = Array();

        $this->_fault = FALSE;
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function buildClause() {
        $ret = Array('sql' => '', 'params' => Array(), 'add_sql' => '');

        if (get_par('acct_name_pattern') != '') {
            $ret['sql'] .= ' AND a.username ' . (get_par('acct_name_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('acct_name_pattern');
        }

        if (get_par('voip_login_pattern') != '') {
            $ret['sql'] .= ' AND a.authname ' . (get_par('voip_login_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('voip_login_pattern');
        }

        if (get_par('auth_proto') > 0 || get_par('auth_ip_pattern') != '' ||
            get_par('auth_cld_pattern') || get_par('auth_cli_pattern')) {
            $ret['add_sql'] .= ' JOIN authentications auth USING (i_account)';
        }

        if (get_par('auth_proto') > 0) {
            $ret['sql'] .= ' AND auth.i_protocol ' . (get_par('auth_proto_clause') ? '<>' : '=') . ' ?';
            $ret['params'][] = get_par('auth_proto');
        }

        if (get_par('auth_ip_pattern') != '') {
            $ret['sql'] .= ' AND auth.remote_ip ' . (get_par('auth_ip_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('auth_ip_pattern');
        }

        if (get_par('auth_cld_pattern') != '') {
            $ret['sql'] .= ' AND auth.incoming_cld ' . (get_par('auth_cld_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('auth_cld_pattern');
        }

        if (get_par('auth_cli_pattern') != '') {
            $ret['sql'] .= ' AND auth.incoming_cli ' . (get_par('auth_cli_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('auth_cli_pattern');
        }

        if (get_par('tn_cli_pattern') != '') {
            $ret['add_sql'] .= ' JOIN calling_card_cli_map tn USING (i_account)';
            $ret['sql'] .= ' AND tn.cli ' . (get_par('tn_cli_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('tn_cli_pattern');
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        if (!$this->make_search) {
            return 0;
        }

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(*) FROM (
                SELECT DISTINCT a.i_account
                  FROM accounts a
                       {$clause['add_sql']}
                 WHERE (a.i_customer = ? OR is_subcustomer(?, a.i_customer))
                       {$clause['sql']}) AS foo";
        $params = array_merge(Array($this->i_customer, $this->i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;
        global $web_session;

        if (!$this->make_search) {
            return Array();
        }

        $clause = $this->buildClause();

        $sql = "SELECT DISTINCT a.i_account, a.username, a.i_customer = ? AS is_account,
                       c.name AS customer_name, wu.web_login AS customer_web_login
                  FROM accounts a
                  JOIN customers c ON (get_nearest_i_customer(?, a.i_customer) = c.i_customer)
                  JOIN web_users wu ON (wu.i_customer = c.i_customer AND wu.default_user)
                       {$clause['add_sql']}
                 WHERE (a.i_customer = ? OR is_subcustomer(?, a.i_customer))
                       {$clause['sql']}
              ORDER BY is_account DESC, c.name, a.username
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($this->i_customer, $this->i_customer, $this->i_customer,
                                    $this->i_customer), $clause['params']);

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$r) {
            $r['is_account'] = Cast::str2bool($r['is_account']);
            if ($r['is_account']) {
                $r['customer_web_login'] = $web_session->user_info['web_login'];
            }
        }

        return $ret;
    }

    public function getAccountTree($i_account) {
        global $db;

        $customers = $db->getValue('SELECT get_account_i_customers(?)', Array($i_account));
        if ($customers == '') {
            return;
        }
        $customers = str_replace('{', '', $customers);
        $customers = str_replace('}', '', $customers);
        $customers = explode(',', $customers);

        $ret = $this->getAccountInfo($i_account);

        $i_customer = array_pop($customers);
        while ($i_customer < $this->i_customer) {
            $i_customer = array_pop($customers);
        };

        while (count($customers) > 1) {
            $ret = $this->getCustomerInfo(array_shift($customers), $ret);
        }

        return '[' . $ret . ']';
    }

    private function getAccountInfo($i_account) {
        global $db;

        $sql = 'SELECT a.i_account, a.username, wu.web_login
                  FROM accounts a
                  JOIN customers c USING (i_customer)
                  JOIN web_users wu ON (wu.i_customer = c.i_customer AND wu.default_user)
                 WHERE i_account = ?
                 LIMIT 1';
        $params = Array($i_account);
        $a = $db->getAssociatedArray($sql, $params);

        $ret = "{text: '" . Esc::js($a['username']) . "', i_account: " . Esc::js($a['i_account']) .", leaf: true, listeners: { contextmenu: function(node, event) { showMenu(node, " . Esc::js($a['i_account']) . ", '" . Esc::js($a['username']) ."', '" . Esc::js($a['web_login']) . "'); } }, qtip: '" . Esc::js('Click right button to see more options.') . "' }";

        return $ret;
    }

    private function getCustomerInfo($i_customer, $children) {
        global $db;

        $sql = 'SELECT c.name, wu.web_login
                  FROM customers c
                  JOIN web_users wu ON (wu.i_customer = c.i_customer AND wu.default_user)
                 WHERE c.i_customer = ?
                 LIMIT 1';
        $params = Array($i_customer);
        $c = $db->getAssociatedArray($sql, $params);

        $ret = "{text: '" . Esc::js($c['name']) . "', listeners: { contextmenu: function(node, event) { showCustomerMenu(node, '" . Esc::js($c['web_login']) . "'); } }, qtip: '" . Esc::js('Click right button to see more options.') . "', children: [ $children ]}";

        return $ret;
    }

}

?>
