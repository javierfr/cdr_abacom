<?php

// Copyright (c) 2016 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Test_Dial_Plan {
    public $i_customer;
    public $routing_info;
    public $account_info;
    public $minute_plan_info;
    public $auth_info;
    public $routes;
    public $is_onnet;
    public $is_ivr;

    private $_fault;

    function __construct($i_customer) {
        $this->i_customer = $i_customer;
        $this->routing_info = Array();
        $this->account_info = Array();
        $this->minute_plan_info = Array();
        $this->auth_info = Array();
        $this->routes = Array();
        $this->is_onnet = FALSE;
        $this->is_ivr = FALSE;

        $this->_fault = FALSE;
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getRoutingInfo($mode, $cli, $cld, $i_account, $i_protocol, $remote_addr,
                                   $remote_port, $nated) {
        $cli = str_replace(" ", "", $cli);
        $cld = str_replace(" ", "", $cld);
        $remote_addr = str_replace(" ", "", $remote_addr);
        $remote_port = str_replace(" ", "", $remote_port);

        /* check input */
        if ($cld == '') {
            throw new Exception(_('"CLD" field is mandatory.'));
        }

        if ($mode == 'auth_call' && $i_account === '') {
            throw new Exception(_('"Authenticated as" field is mandatory.'));
        }

        /* all looks good */
        $this->routing_info = Array();
        $this->routes = Array();
        $this->is_onnet = FALSE;

        $params = Array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),

            "nated" => new xmlrpcval($nated, "boolean"),
            "cli" => new xmlrpcval($cli, "string"),
            "cld" => new xmlrpcval($cld, "string"),
        );

        if ($mode == 'auth_call') {
            $params = array_merge($params, Array(
                "fallback_i_account" => new xmlrpcval($i_account, "int"),
                "is_ivr_originated" => new xmlrpcval(TRUE, "boolean"),
                ));
        } else {  // 'not_auth_call'
            $params = array_merge($params, Array(
                "remote_ip" => new xmlrpcval($remote_addr, "string"),
                "i_protocol" => new xmlrpcval($i_protocol, "int"),
                ));
            if (strlen($remote_port) > 0) {
                $params = array_merge($params, Array(
                    "remote_udp_port" => new xmlrpcval($remote_port, "string"),
                    ));
            }
        }


        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('testDialplan', $params);
        $master_addr = get_master_XMLRPC_server();
        $client = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $client->request_charset_encoding = 'UTF-8';
        $client->setSSLVerifyPeer(false);
        $client->return_type = 'phpvals';

        $res = $client->send($msg);

        if ($res->faultCode() == 407) {
            /* cannot authenticate the call */
            throw new Exception(407);
        } elseif ($res->faultCode()) {
            error_log("Unable to fetch routing info: error code " . $res->faultCode() . ": " .
                      htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            if ($res->faultCode() == 500) {
                throw new Exception(_("Unable to fetch routing info. Please contact system administrator for a help."));
            } else {
                throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            }
        }

        $this->routing_info = $res->val;

        if ($this->routing_info['result'] == 'OK') {
            if ($this->routing_info['onnet_account']) {
                $this->routes = $this->routing_info['onnet_account']['routes'];
                $this->is_onnet = TRUE;

                /* clean up the routing_info structure */
                unset($this->routing_info['onnet_account']['routes']);
            } else {
                $this->routes = $this->routing_info['routes'];

                /* clean up the routing_info structure */
                unset($this->routing_info['routes']);
            }
            $this->routes = (Array) $this->routes;

            foreach ($this->routes as &$route) {
                if ($route['quality_monitor_enabled']) {
                    if ($route['connection_quality'] == 1) {
                        $route['status_image'] = 'link_go.png';
                        $route['status_description'] = _("Connection quality is good");
                    } else {
                        if ($route['quality_monitor_action'] == 'block') {
                            $route['status_image'] = 'link_delete.png';
                            $route['status_description'] = _("Connection blocked due to bad quality");
                        } else {
                            $route['status_image'] = 'link_error.png';
                            $route['status_description'] = _("Connection preference lowered due to bad quality");
                        }
                    }
                }

                /* check if calls has been routed to trunk */
                $trunk_info = $this->getTrunkInfo($route['i_connection']);
                if (is_array($trunk_info)) {
                    $route['is_trunk'] = TRUE;
                    $route['trunk_name'] = $trunk_info['name'];
                    $route['i_trunk'] = $trunk_info['i_trunk'];
                    $route['is_main_trunk'] = $trunk_info['is_main_trunk'];
                } else {
                    $route['is_trunk'] = FALSE;
                }
            }

        } elseif ($this->routing_info['result'] == 'Failure') {

            if ($this->routing_info['cause'] == 'Invalid CLD length') {
                $min_len = $this->routing_info['min_length'] == 'None' ? NULL : $this->routing_info['min_length'];
                $max_len = $this->routing_info['max_length'] == 'None' ? NULL : $this->routing_info['max_length'];
                $prefix = '<a href="destinations.php?i_destination=' . $this->routing_info['i_destination'] . '&action=edit&prefix_clause=0&prefix_pattern=' . $this->routing_info['dest_prefix'] . '">' . $this->routing_info['dest_prefix'] . '</a>';
                if ($min_len !== NULL && $min_len == $max_len) {
                    $msg = sprintf(_('Invalid CLD length, number with prefix %s should be exactly %d digits long'), $prefix, $min_len);
                } elseif ($min_len !== NULL && $max_len !== NULL) {
                    $msg = sprintf(_('Invalid CLD length, number with prefix %s should be from %d to %d digits long'), $prefix, $min_len, $max_len);
                } elseif ($min_len === NULL && $max_len !== NULL) {
                    $msg = sprintf(_('Invalid CLD length, number with prefix %s should be no more than %d digits long'), $prefix, $max_len);
                } else { // ($min_len !== NULL && $max_len === NULL)
                    $msg = sprintf(_('Invalid CLD length, number with prefix %s should be at least %d digits long'), $prefix, $min_len);
                }
                $this->routing_info['error_msg'] = $msg;
            }

        };
    }

    public function getAuthInfo() {
        global $db;

        if ($this->routing_info['i_ivr_application'] > 0) {
            $this->is_ivr = TRUE;
            $this->auth_info['i_ivr_application'] = $this->routing_info['i_ivr_application'];

            $sql = "SELECT name AS ivr_name, i_customer = ? AS ivr_can_edit
                      FROM ivr_applications
                     WHERE i_ivr_application = ?
                     LIMIT 1";
            $params = Array($this->i_customer, $this->routing_info['i_ivr_application']);

            $this->auth_info = array_merge($this->auth_info, $db->getAssociatedArray($sql, $params));
            $this->auth_info['ivr_can_edit'] = Cast::str2bool($this->auth_info['ivr_can_edit']);
        }

        if ($this->routing_info['i_did_authorization'] > 0) {
            $this->auth_info['i_did_authorization'] = $this->routing_info['i_did_authorization'];

            $sql = "SELECT incoming_did, v.name AS v_name, conn.name AS c_name,
                           dids.i_customer = ? AS did_auth_can_edit
                      FROM did_authorizations
                      JOIN dids USING (i_did)
                 LEFT JOIN vendors v USING (i_vendor)
                 LEFT JOIN connections conn USING (i_connection)
                     WHERE i_did_authorization = ?
                     LIMIT 1";
            $params = Array($this->i_customer, $this->auth_info['i_did_authorization']);
            $rule = $db->getAssociatedArray($sql, $params);

            $this->auth_info['did_authorization_name'] =
                (strlen($rule['incoming_did']) > 0 ? $rule['incoming_did'] : 'Any') . '/' .
                (strlen($rule['v_name']) > 0 ? $rule['v_name'] : 'Any') . '/' .
                (strlen($rule['c_name']) > 0 ? $rule['c_name'] : 'Any');
            $this->auth_info['did_auth_can_edit'] = Cast::str2bool($rule['did_auth_can_edit']);
        }

        if ($this->routing_info['i_did'] > 0) {
            $this->auth_info['i_did'] = $this->routing_info['i_did'];

            $sql = "SELECT did, i_customer = ? AS did_can_edit
                      FROM dids
                     WHERE i_did = ?
                     LIMIT 1";
            $params = Array($this->i_customer, $this->auth_info['i_did']);

            $this->auth_info = array_merge($this->auth_info, $db->getAssociatedArray($sql, $params));
            $this->auth_info['did_can_edit'] = Cast::str2bool($this->auth_info['did_can_edit']);

            if (!$this->auth_info['did_can_edit']) {
                $sql = "SELECT delegated_to = ? AS did_can_edit
                          FROM did_delegations
                         WHERE i_did = ?
                         LIMIT 1";
                $params = Array($this->i_customer, $this->auth_info['i_did']);

                $this->auth_info['did_can_edit'] = Cast::str2bool($db->getValue($sql, $params));
            }
        }

        if ($this->routing_info['onnet_account']['i_did'] > 0) {
            $sql = "SELECT did, i_customer = ? AS did_can_edit
                      FROM dids
                     WHERE i_did = ?
                     LIMIT 1";
            $params = Array($this->i_customer, $this->routing_info['onnet_account']['i_did']);

            $this->routing_info['onnet_account'] = array_merge($this->routing_info['onnet_account'],
                                                               $db->getAssociatedArray($sql, $params));
            $this->routing_info['onnet_account']['did_can_edit'] = Cast::str2bool($this->routing_info['onnet_account']['did_can_edit']);

            if (!$this->routing_info['onnet_account']['did_can_edit']) {
                $sql = "SELECT delegated_to = ? AS did_can_edit
                          FROM did_delegations
                         WHERE i_did = ?
                         LIMIT 1";
                $params = Array($this->i_customer, $this->routing_info['onnet_account']['i_did']);

                $this->routing_info['onnet_account']['did_can_edit'] = Cast::str2bool($db->getValue($sql, $params));
            }
        }

        if ($this->routing_info['i_authentication'] > 0) {
            $this->auth_info['i_authentication'] = $this->routing_info['i_authentication'];

            $sql = "SELECT remote_ip, incoming_cld, incoming_cli
                      FROM authentications
                     WHERE i_authentication = ?
                     LIMIT 1";
            $params = Array($this->routing_info['i_authentication']);
            $rule = $db->getAssociatedArray($sql, $params);

            $this->auth_info['authentication_name'] =
                (strlen($rule['remote_ip']) > 0 ? $rule['remote_ip'] : 'Any') . '/' .
                (strlen($rule['incoming_cld']) > 0 ? $rule['incoming_cld'] : 'Any') . '/' .
                (strlen($rule['incoming_cli']) > 0 ? $rule['incoming_cli'] : 'Any');
        }
    }

    public function getAccountInfo($i_account) {
        global $db;

        if ($i_account > 0) {
            $sql = "SELECT i_account, username, base_currency,
                           i_customer = ? AS can_edit
                      FROM accounts
                     WHERE i_account = ?
                     LIMIT 1";
            $params = Array($this->i_customer, $i_account);

            $this->account_info = $db->getAssociatedArray($sql, $params);
            $this->account_info['can_edit'] = Cast::str2bool($this->account_info['can_edit']);
        } else {
            $this->account_info = Array('i_account' => 0, 'username' => '', 'base_currency' => 'N/A',
                                        'can_edit' => FALSE);
        }
    }

    public function getOnnetAccountInfo($i_account) {
        global $db;

        if ($i_account > 0) {
            $sql = "SELECT i_customer = ? AS can_edit
                      FROM accounts
                     WHERE i_account = ?
                     LIMIT 1";
            $params = Array($this->i_customer, $i_account);

            $this->routing_info['onnet_account']['can_edit'] = $db->getValue($sql, $params);
            $this->routing_info['onnet_account']['can_edit'] = Cast::str2bool($this->routing_info['onnet_account']['can_edit']);
        }
    }

    public function getMinutePlanInfo($i_account, $cld) {
        global $db;

        if ($i_account > 0) {
            $params = Array(new xmlrpcval(Array(
                "i_account" => new xmlrpcval($i_account, "int"),
                "cld" => new xmlrpcval($cld, "string")
            ), 'struct'));
            $msg = new xmlrpcmsg('matchAccountMinutePlan', $params);

            $master_addr = get_master_XMLRPC_server();

            $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
            $cli->setSSLVerifyPeer(false);
            $cli->return_type = 'phpvals';

            $res = $cli->send($msg);
            if ($res->faultCode()) {
                error_log("Unable to fetch minute plan info: " .
                          htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
                return;
            }
            if (count($res->val['service_plans']) > 0) {
                if (count($res->val['service_plans']) == 1) {
                    $i_service_plan = $res->val['service_plans'][0]['i_service_plan'];
                    $sql = 'SELECT description
                              FROM service_plans
                             WHERE i_service_plan = ?';
                    $params = Array($i_service_plan);

                    $this->minute_plan_info['name'] = $db->getValue($sql, $params);
                } else {
                    $this->minute_plan_info['name'] = sprintf(_("Sum of %d minute plans"), count($res->val['service_plans']));
                }
                $this->minute_plan_info['total'] = $this->minute_plan_info['left'] = 0;
                foreach ($res->val['service_plans'] as $splan) {
                    if ($splan['seconds_total'] == -1) {
                        $this->minute_plan_info['total'] = $this->minute_plan_info['left'] = -1;
                        break;
                    }
                    $this->minute_plan_info['total'] += $splan['seconds_total'];
                    $this->minute_plan_info['left'] += $splan['seconds_left'];
                }
            }
        }
    }

    public function getTrunkInfo($i_connection) {
        global $db;

        if ($i_connection <= 0) {
            return FALSE;
        }

        $sql = 'SELECT name AS name, i_trunk AS i_trunk,
                       i_connection = ? AS is_main_trunk
                  FROM trunks
                 WHERE i_connection = ? OR i_connection_backup = ?
                 LIMIT 1';
        $params = Array($i_connection, $i_connection, $i_connection);

        $ret = $db->getAssociatedArray($sql, $params);

        if (is_array($ret)) {
            $ret['is_main_trunk'] = Cast::str2bool($ret['is_main_trunk']);
        }

        return $ret;
    }
}

?>
