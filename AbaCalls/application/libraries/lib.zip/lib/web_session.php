<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Web_Session {
    const REMOTE_ASSISTANCE_LOGIN = 'remote-assistance';

    const TYPE_CUSTOMER = 'customer';
    const TYPE_ACCOUNT = 'account';
    const TYPE_VENDOR = 'vendor';
    const TYPE_WEB_USER = 'web_user';

    const AUTH_OK = 1;
    const AUTH_FAIL = 2;
    const AUTH_BLOCKED = 3;
    const AUTH_NEED_CHANGE_PASSWORD = 4;
    const AUTH_PASSWORD_RECOVERY = 5;
    const AUTH_SSP_MAINTAIN_FAILED = 6;
    const AUTH_FIRST_LOGIN_PASSWORD_CHANGE = 7;

    public $type;
    public $web_login;
    public $web_password;
    public $subtype;
    public $user_info;
    public $is_root;
    public $path_prefix;
    public $redirect_page;
    public $is_sippy_support_user;
    public $parent_web_session;

    function __construct($type, $web_login, $web_password = NULL) {
        $this->type = $type;
        $this->web_login = $web_login;
        $this->web_password = $web_password;
        $this->subtype = NULL;
        $this->user_info = Array();
        $this->is_root = FALSE;
        $this->blocked = FALSE;
        $this->selfcare_enabled = TRUE;
        $this->path_prefix = '';
        $this->redirect_page = 'index.php';
        $this->is_sippy_support_user = FALSE;
        $this->parent_web_session = NULL;

        if (!in_array($this->type, Array(self::TYPE_CUSTOMER, self::TYPE_ACCOUNT, self::TYPE_VENDOR))) {
            $this->type = self::TYPE_ACCOUNT;           /* use default type */
        }
    }

    function __destruct() {
        /* nothing here */
    }

    function auth() {
        if ($this->web_login == self::REMOTE_ASSISTANCE_LOGIN && $this->type == self::TYPE_CUSTOMER) {
            try {
                $this->auth_remote_assistance();
            } catch (Exception $e) {
                error_log($e->getMessage());
                return self::AUTH_SSP_MAINTAIN_FAILED;
            }
        }
        
        $this->get_user_info();
        
        /* check web_allowed_hosts */
        $send_web_allow_host_mail = FALSE;
        if (!defined('CLI_MODE') &&
            in_array($this->type, Array(self::TYPE_CUSTOMER, self::TYPE_WEB_USER))&&
            is_array($this->user_info['web_allowed_hosts']) &&
            count($this->user_info['web_allowed_hosts']) > 0 &&
            !in_array($_SERVER['REMOTE_ADDR'], $this->user_info['web_allowed_hosts'])
           ) {
            if ($this->subtype !== NULL) {
                $msg = sprintf("%s '%s' (uid = %d, sub_uid = %d): access denied from %s",
                               $this->subtype, $this->user_info['web_login'],
                               $this->user_info['uid'], $this->user_info['sub_uid'],
                               $_SERVER['REMOTE_ADDR']);
            } else {
                $msg = sprintf("%s '%s' (uid = %d): access denied from %s",
                               $this->type, $this->user_info['web_login'],
                               $this->user_info['uid'], $_SERVER['REMOTE_ADDR']);
            }
            Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
            $this->log_activity($msg);

            $send_web_allow_host_mail = TRUE;
        }

        /* check account class for account */
        if (!$this->selfcare_enabled) {
            $msg = sprintf("%s '%s' (uid = %d): web self-care is disabled, remote IP = %s",
                           $this->type, $this->user_info['web_login'],
                           $this->user_info['uid'], $_SERVER['REMOTE_ADDR']);
            Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
            $this->log_activity($msg);
            return self::AUTH_FAIL;
        }

        /* check main password */
        $hash = substr($this->user_info['web_password'], 0, 64);
        $salt = substr($this->user_info['web_password'], 64, 8);
        $hash2 = Password::crypt($this->web_password, Password::SHA256, $salt);

        if ($hash == $hash2) {
            $pp = new Password_Policy($this->user_info['i_password_policy']);

            if ($send_web_allow_host_mail) {

                $this->send_web_allow_host_mail();
                /* do not write audit log entry as it has been already written */
                return self::AUTH_FAIL;

            } elseif ($pp->change_first_login && !isset($this->user_info['ll'])) {

                Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                return self::AUTH_FIRST_LOGIN_PASSWORD_CHANGE;

            } elseif (isset($pp->expires) && $this->user_info['lp'] > $pp->expires) {

                Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                return self::AUTH_NEED_CHANGE_PASSWORD;

            } elseif (isset($pp->block_idle_in) && $this->user_info['ll'] > $pp->block_idle_in &&
                      $this->user_info['lp'] > $this->user_info['ll']) {

                Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                return self::AUTH_BLOCKED;

            } elseif ($this->blocked) {

                Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                return self::AUTH_BLOCKED;

            } else {

                /* do not write audit log entry as it will be written later */
                return self::AUTH_OK;

            }
        }

        /* check temporary password */
        if (isset($this->user_info['tlp']) && $this->user_info['tlp'] == 0) {   /* 1 day expiration */
            $hash = substr($this->user_info['tmp_web_password'], 0, 64);
            $salt = substr($this->user_info['tmp_web_password'], 64, 8);
            $hash2 = Password::crypt($this->web_password, Password::SHA256, $salt);

            if ($hash == $hash2) {
                if ($send_web_allow_host_mail) {
                    $this->send_web_allow_host_mail();
                    /* do not write audit log entry as it has been already written */
                    return self::AUTH_FAIL;
                }

                Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                return self::AUTH_PASSWORD_RECOVERY;
            }
        }

        Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
        return self::AUTH_FAIL;
    }

    function create() {
        $is_root = $this->is_root && $this->subtype === NULL || $this->is_sippy_support_user;
        if (Maintenance_Mode::check($is_root) > 0 && $is_root) {
            $this->redirect_page = 'show_graphs.php';
        }

        if (session_status() == PHP_SESSION_ACTIVE) {
            session_write_close();
        }
        session_set_cookie_params(0, $this->path_prefix);
        session_start();
        session_regenerate_id();
        session_unset();

        $this->set_expiration();
        $this->set_referer();

        if ($this->subtype !== NULL) {
            $_SESSION['username'] = $this->user_info['owner_web_login'];
            $_SESSION['sub_web_login'] = $this->user_info['web_login'];
            $_SESSION['account_subtype'] = $this->subtype;
            $_SESSION['is_sippy_support_user'] = $this->is_sippy_support_user;
        } else {
            $_SESSION['username'] = $this->user_info['web_login'];
        }
        $_SESSION['password']     = $this->user_info['web_password'];
        $_SESSION['account_type'] = $this->type;
        $_SESSION['uid']          = $this->user_info['uid'];
        $_SESSION['sub_uid']      = $this->user_info['sub_uid'];
        $_SESSION['lang']         = $this->user_info['i_lang'];

        $this->update_last_login();
        if (!isset($this->user_info['lp'])) {
            $this->update_last_password_change();
        }

        $this->log_activity();

        Redirector::redirect($this->path_prefix . $this->redirect_page);
        /* never reach here */
    }

    function login_as($redirect_page = NULL, $enforce_new_session = FALSE) {
        global $db;

        $this->log_activity("an attempt to use 'Login as' functionality");

        $uid = $_SESSION['uid'];

        /* detach original session */
        session_write_close();
        session_unset();

        $this->get_user_info();

        if ($redirect_page !== NULL && $redirect_page != '') {
            $this->redirect_page = $redirect_page;
        }

        if ($enforce_new_session ||
            ($this->parent_web_session !== NULL &&
             $this->user_info != $this->parent_web_session->user_info)
           ) {
            /* do all checks only when new web session differs from parent one */

            switch ($this->type) {
                case self::TYPE_CUSTOMER:
                    if ($this->is_sippy_support_user) {
                        Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                        throw new Exception(sprintf('Unable to login as customer "%s": web_user is denied to login', $this->web_login));
                    }
                    $sql = 'SELECT is_subcustomer(?, ?)';
                    $params = Array($uid, $this->user_info['uid']);
                    $is_subcustomer = Cast::str2bool($db->getValue($sql, $params));

                    $from_web_user = $_SESSION['account_subtype'] !== NULL;
                    $to_customer = $this->subtype === NULL;
                    /* deny web_user to login to its customer owner */
                    if ($uid == $this->user_info['uid'] && $from_web_user && $to_customer) {
                        Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                        throw new Exception(sprintf('Unable to login as customer "%s": web_user is denied to login as its customer owner', $this->web_login));
                    }
                    if ($this->subtype === NULL && !$is_subcustomer && $uid != $this->user_info['uid']) {
                        Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                        throw new Exception(sprintf('Unable to login as customer "%s": wrong owner', $this->web_login));
                    } elseif ($this->subtype == self::TYPE_WEB_USER && !$is_subcustomer &&
                              $uid != $this->user_info['uid']) {
                        Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                        throw new Exception(sprintf('Unable to login as web-user "%s": wrong owner', $this->web_login));
                    }
                    break;

                case self::TYPE_ACCOUNT:
                    $sql = 'SELECT is_subcustomer(?, ?)';
                    $params = Array($uid, $this->user_info['i_customer']);
                    $is_subcustomer = Cast::str2bool($db->getValue($sql, $params));

                    if (!$is_subcustomer && $uid != $this->user_info['i_customer']) {
                        Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                        throw new Exception(sprintf('Unable to login as account "%s": wrong owner', $this->web_login));
                    }
                    break;

                case self::TYPE_VENDOR:
                    if (!$_SESSION['is_root_customer']) {
                        Audit_Logger::write('AUTH_FAIL', Audit_Info::get_web_login_resource());
                        throw new Exception(sprintf('Unable to login as vendor "%s": not root user', $this->web_login));
                    }
                    break;
            }

            $is_root = $this->is_root && $this->subtype === NULL;
            if (Maintenance_Mode::check($is_root) > 0 && $is_root) {
                $this->redirect_page = 'show_graphs.php';
            }

            /* create new session */
            if (session_status() == PHP_SESSION_ACTIVE) {
                session_write_close();
            }
            session_set_cookie_params(0, $this->path_prefix);
            session_start();
            session_regenerate_id();
            session_unset();

            $this->set_expiration();
            $this->set_referer();

            if ($this->subtype !== NULL) {
                $_SESSION['username'] = $this->user_info['owner_web_login'];
                $_SESSION['sub_web_login'] = $this->user_info['web_login'];
                $_SESSION['account_subtype'] = $this->subtype;
                $_SESSION['is_sippy_support_user'] = $this->is_sippy_support_user;
            } else {
                $_SESSION['username'] = $this->user_info['web_login'];
            }
            $_SESSION['password']     = $this->user_info['web_password'];
            $_SESSION['account_type'] = $this->type;
            $_SESSION['uid']          = $this->user_info['uid'];
            $_SESSION['sub_uid']      = $this->user_info['sub_uid'];
            $_SESSION['lang']         = $this->user_info['i_lang'];

            $this->update_last_login();
            /* do not update last_password_change as a real user cannot use login_as facility to log in */

            $this->log_activity();
        } else {
            $this->log_activity("the same credentials have been detected - do not change current web session");
        }

        Redirector::redirect($this->path_prefix . $this->redirect_page);
        /* never reach here */
    }

    function log_activity($msg = NULL) {
        if ($msg !== NULL) {
             error_log($msg);
             return;
        }

        /* by default log who has logged in */
        if ($this->subtype !== NULL) {
            $msg = sprintf("%s '%s' (uid = %d, sub_uid = %d) has logged in",
                           $this->subtype, $this->user_info['web_login'],
                           $this->user_info['uid'], $this->user_info['sub_uid']);
        } else {
            $msg = sprintf("%s '%s' (uid = %d) has logged in",
                           $this->type, $this->user_info['web_login'],
                           $this->user_info['uid']);
        }
        error_log($msg);
        Audit_Logger::write('AUTH_OK', Audit_Info::get_web_login_resource());
    }

    function get_user_info() {
        switch ($this->type) {
            case self::TYPE_CUSTOMER:
                $this->get_customer_info();
                break;

            case self::TYPE_ACCOUNT:
                $this->get_account_info();
                break;

            case self::TYPE_VENDOR:
                $this->get_vendor_info();
                break;
        }
    }

    function get_customer_info() {
        global $db;

        $sql = 'SELECT c.i_customer AS uid, wu.web_login, wu.web_password, wu.i_lang,
                       c.i_password_policy, wu.start_page, wu.tmp_web_password,
                       c.i_customer = c.i_wholesaler AS is_root,
                       is_subcustomer_blocked(c.i_customer) AS blocked,
                       c.i_wholesaler, wu.i_time_zone, con.first_name, con.last_name, 
                       (CAST(now() AS DATE) - CAST(wu.last_login AS DATE)) AS ll,
                       (CAST(now() AS DATE) - CAST(wu.last_password_change AS DATE)) AS lp,
                       (CAST(now() AS DATE) - CAST(wu.tmp_web_password_gen_date AS DATE)) AS tlp,
                       wu.i_access_level AS i_access_level, wu.i_web_user AS i_web_user,
                       wu.sippy_support_user AS sippy_support_user
                  FROM customers c
                  JOIN web_users wu ON (wu.i_customer = c.i_customer AND wu.default_user)
                  JOIN contacts con USING(i_contact)
                 WHERE wu.web_login = ?
                 LIMIT 1';

        $user_info = $db->getAssociatedArray($sql, Array($this->web_login));

        if ($db->affected_rows != 1) {
            /* check web_users */
            $sql = 'SELECT wu.i_customer AS uid, wu.web_login, wu.web_password, wu.i_lang,
                           c.i_password_policy, wu.start_page, wu.tmp_web_password,
                           wu.i_web_user AS sub_uid, wu2.web_login AS owner_web_login,
                           wu.name AS first_name, wu.i_time_zone,
                           c.i_customer = c.i_wholesaler AS is_root,
                           is_subcustomer_blocked(c.i_customer) AS blocked,
                           (CAST(now() AS DATE) - CAST(wu.last_login AS DATE)) AS ll,
                           (CAST(now() AS DATE) - CAST(wu.last_password_change AS DATE)) AS lp,
                           (CAST(now() AS DATE) - CAST(wu.tmp_web_password_gen_date AS DATE)) AS tlp,
                           wu.i_access_level AS i_access_level, wu.i_web_user AS i_web_user,
                           wu.sippy_support_user AS is_sippy_support_user
                      FROM web_users wu
                      JOIN customers c USING (i_customer)
                      JOIN web_users wu2 ON (wu2.i_customer = wu.i_customer AND wu2.default_user)
                     WHERE wu.web_login = ?
                     LIMIT 1';
            $user_info = $db->getAssociatedArray($sql, Array($this->web_login));

            if ($db->affected_rows != 1) {
                throw new Exception('Unable to get user info');
            }

            /* web_user specific */
            $this->user_info = $user_info;
            $this->blocked  = Cast::str2bool($this->user_info['blocked']);
            $this->path_prefix = '/u' . $this->user_info['sub_uid'] . '/';
            $this->subtype = self::TYPE_WEB_USER;

        } else {

            /* customer specific */
            $this->user_info = $user_info;
            $this->blocked  = Cast::str2bool($this->user_info['blocked']);
            $this->path_prefix = '/c' . $this->user_info['uid'] . '/';
        }

        $this->is_root = Cast::str2bool($user_info['is_root']);
        $this->is_sippy_support_user = Cast::str2bool($user_info['is_sippy_support_user']);

        /* get web_allowed_hosts list */
        $sql = 'SELECT ip
                  FROM web_allowed_hosts
                 WHERE i_web_user = ?';
        $params = Array($user_info['i_web_user']);
        $this->user_info['web_allowed_hosts'] = $db->getCol($sql, $params);

        /* start pages */
        $start_pages = Start_Page::getList($this->is_root, $this->type, $this->subtype);
        $found = FALSE;
        foreach ($start_pages as $start_page) {
            if ($start_page['val'] == $this->user_info['start_page']) {
                $this->redirect_page = $start_page['redirect'];
                $found = TRUE;
                break;
            }
        }

        if (!$found) {
            if (!is_root_environment() && !$this->is_sippy_support_user) {
                /* do not spoil the logs */
                error_log('Unable to redirect to start page ' . $this->user_info['start_page'] . '. Use default one.');
            }
            $this->redirect_page = $start_pages[0]['redirect'];
        }
    }

    function get_account_info() {
        global $db;

        $sql = 'SELECT a.i_account AS uid, a.username AS web_login, a.web_password, a.i_lang,
                       a.i_password_policy, a.blocked, a.tmp_web_password,
                       is_subcustomer_blocked(a.i_customer) AS subcustomer_blocked,
                       a.i_customer, a.vm_enabled, a.i_time_zone, con.first_name, con.last_name,
                       (CAST(now() AS DATE) - CAST(a.last_login AS DATE)) AS ll,
                       (CAST(now() AS DATE) - CAST(a.last_password_change AS DATE)) AS lp,
                       (CAST(now() AS DATE) - CAST(a.tmp_web_password_gen_date AS DATE)) AS tlp,
                       ac.selfcare_enabled AS selfcare_enabled, a.start_page
                  FROM accounts a
                  JOIN contacts con USING(i_contact)
                  JOIN account_classes ac USING(i_account_class)
                 WHERE username = ?
                 LIMIT 1';

        $user_info = $db->getAssociatedArray($sql, Array($this->web_login));

        if ($db->affected_rows != 1) {
            throw new Exception('Unable to get user info');
        }
        $this->user_info = $user_info;
        $this->blocked = $this->user_info['blocked'] != 0 || Cast::str2bool($this->user_info['subcustomer_blocked']);
        $this->selfcare_enabled  = Cast::str2bool($this->user_info['selfcare_enabled']);
        $this->path_prefix = '/a' . $this->user_info['uid'] . '/';

        /* start pages */
        $start_pages = Start_Page::getList(FALSE, $this->type);
        $found = FALSE;
        foreach ($start_pages as $start_page) {
            if ($start_page['val'] == $this->user_info['start_page']) {
                $this->redirect_page = $start_page['redirect'];
                $found = TRUE;
                break;
            }
        }

        if (!$found) {
            /* do not spoil the logs */
            // error_log('Unable to redirect to start page ' . $this->user_info['start_page'] . '. Use default one.');
            $this->redirect_page = $start_pages[0]['redirect'];
        }
    }

    function get_vendor_info() {
        global $db;

        $sql = 'SELECT v.i_vendor AS uid, v.web_login, v.web_password, v.i_lang,
                       v.i_password_policy, v.tmp_web_password,
                       v.i_time_zone, con.first_name, con.last_name, 
                       (CAST(now() AS DATE) - CAST(v.last_login AS DATE)) AS ll,
                       (CAST(now() AS DATE) - CAST(v.last_password_change AS DATE)) AS lp,
                       (CAST(now() AS DATE) - CAST(v.tmp_web_password_gen_date AS DATE)) AS tlp
                  FROM vendors v
                  JOIN contacts con USING(i_contact)
                 WHERE web_login = ?
                 LIMIT 1';

        $user_info = $db->getAssociatedArray($sql, Array($this->web_login));

        if ($db->affected_rows != 1) {
            throw new Exception('Unable to get user info');
        }

        $this->user_info = $user_info;
        $this->path_prefix = '/v' . $this->user_info['uid'] . '/';
        $this->redirect_page = 'cdrs_vendor.php';
    }

    function set_expiration() {
        global $db;

        $t = $db->getValue('SELECT web_session_timeout * 60 FROM system LIMIT 1');
        $t = $t > 0 ? time() + $t : 0;
        $_SESSION['session_expiration_time'] = $t;
    }

    function set_referer() {
        $_SESSION['referer'] = Referer::get();
    }

    function set_parent_web_session($web_session) {
        $this->parent_web_session = $web_session;
    }

    function auth_remote_assistance() {
        global $db;

        /* substitute remote-assistance login to real one */
        $web_login = $db->getValue("SELECT wu.web_login
                                      FROM customers c
                                      JOIN web_users wu ON (wu.i_customer = c.i_customer AND wu.sippy_support_user)
                                     WHERE c.i_customer = c.i_wholesaler
                                     LIMIT 1");

        $this->log_activity("remote assistance login '" . $this->web_login . "' has been detected, substitute it by '" .
                            $web_login . "'");

        $this->web_login = $web_login;

        $a = $db->getValue("SELECT allow_remote_assistance FROM system LIMIT 1");
        if ($a == 0) {
            Audit_Logger::write('AUTH_FAIL', sprintf('customer:%s', $this->web_login));
            throw new Exception($this->web_login . ' remote assistance is not allowed');
        }

        $installation_id = $db->getValue("SELECT installation_id FROM system LIMIT 1");

        $params = array(new xmlrpcval(Array("password" => new xmlrpcval($this->web_password, "string"),
                                            "installation_id" => new xmlrpcval($installation_id, "string"),
                                            "version" => new xmlrpcval(2, "int"),
                                       ), 'struct'));
        $msg = new xmlrpcmsg('authRemoteAssistance', $params);

        $cli = new xmlrpc_client('https://apps.sippysoft.com/ssp');
        $cli->return_type = 'phpvals';

        $r = $cli->send($msg, 10);       /* 10 seconds timeout */

        if ($r->faultCode()) {
            Audit_Logger::write('AUTH_FAIL', sprintf('customer:%s', $this->web_login));
            throw new Exception($this->web_login . ' login failed, code: ' . $r->faultCode() .
                                ', reason: ' . $r->faultString());
        }

        if ('ACCEPT' != $r->val['result']) {
            Audit_Logger::write('AUTH_FAIL', sprintf('customer:%s', $this->web_login));
            throw new Exception($this->web_login . ' login failed, result: ' . $r->val['result']);
        }

        $this->log_activity("'" . $this->web_login . "' customer has been authenticated");

        $this->get_customer_info();
        if (count($this->user_info) <= 0) {
            throw new Exception('Unable to get user info');
        }

        $this->create();
    }

    function update_last_login() {
        global $db;

        switch ($this->type) {
            case self::TYPE_CUSTOMER:
                if ($this->subtype == self::TYPE_WEB_USER) {
                    $sql = 'UPDATE web_users SET last_login = NOW() WHERE i_web_user = ?';
                    $params = Array($this->user_info['sub_uid']);
                } else {
                    $sql = 'UPDATE web_users SET last_login = NOW() WHERE i_customer = ? AND default_user';
                    $params = Array($this->user_info['uid']);
                }
                break;

            case self::TYPE_ACCOUNT:
                $sql = 'UPDATE accounts SET last_login = NOW() WHERE i_account = ?';
                $params = Array($this->user_info['uid']);
                break;

            case self::TYPE_VENDOR:
                $sql = 'UPDATE vendors SET last_login = NOW() WHERE i_vendor = ?';
                $params = Array($this->user_info['uid']);
                break;

            default:
                throw new Exception('Unable to update last_login.');
        }

        $db->prepNexec($sql, $params);
    }

    function update_last_password_change() {
        global $db;

        switch ($this->type) {
            case self::TYPE_CUSTOMER:
                if ($this->subtype == self::TYPE_WEB_USER) {
                    $sql = 'UPDATE web_users SET last_password_change = NOW() WHERE i_web_user = ?';
                    $params = Array($this->user_info['sub_uid']);
                } else {
                    $sql = 'UPDATE web_users SET last_password_change = NOW() WHERE i_customer = ? AND default_user';
                    $params = Array($this->user_info['uid']);
                }
                break;

            case self::TYPE_ACCOUNT:
                $sql = 'UPDATE accounts SET last_password_change = NOW() WHERE i_account = ?';
                $params = Array($this->user_info['uid']);
                break;

            case self::TYPE_VENDOR:
                $sql = 'UPDATE vendors SET last_password_change = NOW() WHERE i_vendor = ?';
                $params = Array($this->user_info['uid']);
                break;

            default:
                throw new Exception('Unable to update last_password_change.');
        }

        $db->prepNexec($sql, $params);
    }

    function check($password, $expiration_time) {
        global $db;

        if (!strlen($this->web_login) || !strlen($password)) {
            throw new Exception('Wrong web session.');
        }

        switch ($this->type) {
            case self::TYPE_CUSTOMER:
                if ($this->subtype == self::TYPE_WEB_USER) {
                    $sql = 'SELECT i_web_user
                              FROM web_users
                             WHERE web_login = ? AND web_password = ?
                                   AND NOT is_subcustomer_blocked(i_customer)
                             LIMIT 1';
                } else {
                    $sql = 'SELECT i_customer
                              FROM web_users
                             WHERE web_login = ? AND web_password = ? AND default_user
                                   AND NOT is_subcustomer_blocked(i_customer)
                             LIMIT 1';
                }
                $params = Array($this->web_login, $password);
                break;

            case self::TYPE_ACCOUNT:
                $sql = 'SELECT i_account
                          FROM accounts
                         WHERE username = ? AND web_password = ? AND blocked = 0
                               AND NOT is_subcustomer_blocked(i_customer)
                         LIMIT 1';
                $params = Array($this->web_login, $password);
                break;

            case self::TYPE_VENDOR:
                $sql = 'SELECT i_vendor
                          FROM vendors
                         WHERE web_login = ? AND web_password = ?
                         LIMIT 1';
                $params = Array($this->web_login, $password);
                break;

            default:
                throw new Exception(sprintf('Web session check failed for %s "%s"', $this->type, $this->web_login));
        }

        $db->prepNexec($sql, $params);
        if ($db->affected_rows != 1) {
            throw new Exception(sprintf('Wrong web session password for %s "%s"', $this->type, $this->web_login));
        }

        if ($expiration_time > 0 && $expiration_time <= time()) {
            throw new Exception(sprintf('Web session expired for %s "%s"', $this->type, $this->web_login));
        }

        $session_timeout = $db->getValue('SELECT web_session_timeout * 60 FROM system LIMIT 1');
        $t = $session_timeout > 0 ? time() + $session_timeout : 0;
        $_SESSION['session_expiration_time'] = $t;
    }

    function update_user_info() {
        global $db;

        $_SESSION['is_root_customer'] = $this->is_root ? 1 : 0;
        $_SESSION['first_name'] = $this->user_info['first_name'];
        $_SESSION['last_name'] = $this->user_info['last_name'];
        $_SESSION['i_time_zone'] = $this->user_info['i_time_zone'];
        $_SESSION['i_password_policy'] = $this->user_info['i_password_policy'];
        if (isset($this->user_info['lp'])) {
            $_SESSION['last_pass_change'] = $this->user_info['lp'];
        }
        if ($this->type == self::TYPE_ACCOUNT) {
            $i_customer = $this->user_info['i_customer'];
            $row = $db->getAssociatedArray("SELECT wu.web_login, cm.css
                                              FROM customers c
                                         LEFT JOIN customer_mods cm USING(i_customer)
                                              JOIN web_users wu ON (wu.i_customer = c.i_customer AND wu.default_user)
                                             WHERE c.i_customer = ?
                                             LIMIT 1", Array($i_customer));
            $_SESSION['customer_name'] = $row['web_login'];
            $_SESSION['css'] = $row['css'];
            $_SESSION['customer_id'] = $this->user_info['i_customer'];
            $_SESSION['vm_enabled'] = $this->user_info['vm_enabled'];
        } else {
            $_SESSION['customer_name'] = $_SESSION['username'];
            $_SESSION['customer_id'] = $_SESSION['uid'];
        }
    }

    function send_web_allow_host_mail() {
        global $db;

        $email_from = get_own_mail_from($_SERVER['SERVER_NAME'], $this);
        $email_to = get_own_mail_address($this);
        if ($email_to == '') {
            /* ignore it */
            error_log('e-mail is not defined, do nothing');
            return;
        }

        /* get template */
        $email_msg = '';
        $email_subject = 'An attempt to access web-interface has been detected';
        $email_charset = 'ISO-8859-1';

        $tpl_file = PATH_EMAIL_TEMPLATES . $this->user_info['i_lang'] . '/web_allow_host.txt';
        
        if (!file_exists($tpl_file)) {
            $tpl_file = PATH_EMAIL_TEMPLATES . 'en/web_allow_host.txt';
        }

        $h = @fopen($tpl_file, 'r');
        if ($h === FALSE) {
            error_log('unable to open e-mail template, do nothing');
            return;
        }
            
        while (!feof($h)) {
            $tmp_buf = fgets($h, 16384);
            if (preg_match('/^From:/i', $tmp_buf) || preg_match('/^To:/i', $tmp_buf)) {
                continue;
            } elseif (preg_match('/Subject: (.+)/i', $tmp_buf, $matches)) {
                $email_subject = $matches[1];
                continue;       
            } elseif (preg_match('/Charset: (.+)/i', $tmp_buf, $matches)) {
                $email_charset = $matches[1];
                continue;       
            }
            $email_msg .= $tmp_buf;
        }
        
        fclose($h);

        $key = Password::gen(15);
        
        $email_subject = '=?' . $email_charset . '?B?' . base64_encode($email_subject) . '?=';
        $email_msg = str_replace('${ssp_url}', 'https://' . $_SERVER['SERVER_NAME'] . '/web_allow_host.php', $email_msg);
        $email_msg = str_replace('${key}', '?key=' . $key, $email_msg);
        $email_msg = str_replace('${customer_ip}', $_SERVER['REMOTE_ADDR'], $email_msg);
        $email_msg = str_replace('${ssp_login}', $this->user_info['web_login'], $email_msg);
        
        if (empty($email_msg)) {
            /* ignore an empty mail */
            error_log('e-mail message is empty, do nothing');
            return;
        }

        /* store the key and clean-up expired keys */
        $sql = 'INSERT INTO web_allow_host_keys (i_web_user, ip, key) VALUES (?, ?, ?)';
        $params = Array($this->user_info['i_web_user'], $_SERVER['REMOTE_ADDR'], $key);
        $db->prepNexec($sql, $params);

        $sql = 'DELETE FROM web_allow_host_keys WHERE expiretime <= now()';
        $db->prepNexec($sql);

        /* send the e-mail */
        $sql = "INSERT INTO mails (mail_from, mail_to, subject, message, message_charset, status)
                     VALUES (?, ?, ?, ?, ?, 1)";
        $params = Array($email_from, $email_to, $email_subject, $email_msg, $email_charset);

        $db->prepNexec($sql, $params);

        $this->log_activity('e-mail has been sent to ' . $email_to);
    }
}

?>
