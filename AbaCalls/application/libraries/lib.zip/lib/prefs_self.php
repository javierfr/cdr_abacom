<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Customer_Self {

    public $i_customer;
    public $web_password;
    public $i_web_user;
    public $balance;
    public $i_time_zone;
    public $base_currency;
    public $i_lang;
    public $i_export_type;
    public $mail_from;
    public $start_page;
    public $api_access;
    public $allowed_hosts;
    public $contact;

    public $can_change_base_currency;
    public $i_password_policy;

    private $i_contact;

    function __construct($i_customer) {
        $this->i_customer = $i_customer;

        $this->web_password = '';
        $this->i_web_user = NULL;
        $this->balance = 0;
        $this->i_time_zone = NULL;
        $this->base_currency = NULL;
        $this->i_lang = NULL;
        $this->i_export_type = NULL;
        $this->mail_from = '';
        $this->start_page = NULL;
        $this->api_access = FALSE;
        $this->allowed_hosts = 'Any';
        $this->contact = NULL;

        $this->i_password_policy = Password_Policy::get($this->i_customer);
        $this->i_contact = NULL;
        $this->can_change_base_currency = $this->set_can_change_base_currency();

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;

        $sql = "SELECT wu.web_password, wu.i_web_user,
                       c.i_balance, wu.i_time_zone, c.base_currency,
                       wu.i_lang, wu.i_export_type, c.mail_from, wu.start_page,
                       c.api_access, c.i_contact
                  FROM customers c
                  JOIN web_users wu ON (wu.i_customer = c.i_customer AND default_user)
                 WHERE c.i_customer = ?
                 LIMIT 1";
        $params = Array($this->i_customer);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception(_("No such Id."));
        }

        $this->web_password = $entry['web_password'];
        $this->i_web_user = $entry['i_web_user'];
        $this->i_time_zone = $entry['i_time_zone'];
        $this->base_currency = $entry['base_currency'];
        $this->i_lang = $entry['i_lang'];
        $this->i_export_type = $entry['i_export_type'];
        $this->mail_from = $entry['mail_from'];
        $this->start_page = $entry['start_page'];
        $this->api_access = Cast::str2bool($entry['api_access']);

        $this->i_contact = $entry['i_contact'];

        /***/
        $params = Array("i_customer" => new xmlrpcval(1, "int"),
                        "i_balance" => new xmlrpcval($entry['i_balance'], "int"),
                       );
        $bal_clnt = new Balanced_Client('getBalanceInfo', $params);
        $ret = $bal_clnt->get();
        $this->balance = $ret['balance_info']['balance'];

        /***/
        $sql = 'SELECT ip
                  FROM web_allowed_hosts
                 WHERE i_web_user = ?
              ORDER BY i_web_allowed_host';
        $params = Array($this->i_web_user);

        $rows = $db->getCol($sql, $params);
        if ($db->affected_rows == 0) {
            $this->allowed_hosts = 'Any';
        } else {
            $this->allowed_hosts = implode(', ', $rows);
        }

        /***/
        $this->contact = new Contact($this->i_contact);
    }

    public function initFromRequest($par) {
        $this->i_time_zone = $par['i_time_zone'];
        if ($this->can_change_base_currency) {
            $this->base_currency = $par['base_currency'];
        };
        $this->start_page = $par['start_page'];
        $this->i_lang = $par['i_lang'];
        $this->i_export_type = $par['i_export_type'];
        $this->mail_from = $par['mail_from'];
        $this->api_access = Cast::str2bool($par['api_access']);
        $this->allowed_hosts = $par['allowed_hosts'];

        $this->contact->initFromRequest($par);
    }

    public function validate($par) {
        if ($par['web_password'] != '' || $par['confirm_web_password'] != '') {
            if (strcmp($par['web_password'], $par['confirm_web_password'])) {
                throw new Exception(_("Password mismatch."));
            }
        }

        /*
         * $par['web_password'] is validated in Web_User_Default_User_Self::validate_default_user()
         */

        if ($par['api_password'] != '') {
            $pp = new Password_Policy($this->i_password_policy, _('API Password'));
            $pp->validate_by_owner($par['api_password']);
        }

        /***/
        if ($par['mail_from'] != '') {
            if (!Validator::isEmail($par['mail_from']))
                throw new Exception(_("Mail \"From\" field has incorrect format. E-mail in the format username@domain is expected."));
        }

        /*
         * $par['allowed_hosts'] is validated in Web_User_Default_User_Self::validate_default_user()
         */

        $this->contact->validate($par);
    }

    public function update($par) {
        global $db;

        $this->validate($par);

        $db->begin();

        try {
            $sql = "UPDATE customers
                         SET mail_from = ?,
                             api_access = ?
                       WHERE i_customer = ?";
            $params = Array($par['mail_from'],
                            Cast::str2bool($par['api_access']) ? 1 : 0,
                            $this->i_customer
                           );
            $db->prepNexec($sql, $params);

            $wu = new Web_User_Default_User_Self($this->i_customer);
            $wu->update_self_default_user($par);

            /* if root customer has changed own base currency */
            if ($this->can_change_base_currency) {
                $sql = "UPDATE customers
                           SET base_currency = ?,
                               payment_currency = ?
                         WHERE i_customer = ?";
                $params = Array($par['base_currency'], $par['base_currency'], $this->i_customer);
                $db->prepNexec($sql, $params);

                $sql = "UPDATE tariffs
                           SET iso_4217 = ?
                          FROM customers
                         WHERE customers.i_tariff = tariffs.i_tariff AND i_customer = ?";
                $params = Array($par['base_currency'], $this->i_customer);
                $db->prepNexec($sql, $params);

                $sql = "UPDATE x_rates
                           SET iso_4217 = ?,
                               last_update = now()
                         WHERE i_customer = ?";
                $params = Array($par['base_currency'], $this->i_customer);
                $db->prepNexec($sql, $params);

                $sql = "UPDATE vendors
                           SET base_currency = ?
                         WHERE system";
                $params = Array($par['base_currency']);
                $db->prepNexec($sql, $params);
            }

            if ($par['api_password'] != '') {
                $sql = "UPDATE customers
                             SET api_password = ?
                           WHERE i_customer = ?";
                $passwd = Password::crypt($_SESSION['username'] . ':XML API:' . $par['api_password'], Password::MD5);
                $params = Array($passwd, $this->i_customer);

                $db->prepNexec($sql, $params);
            }

            if ($_SESSION['is_root_customer']) {
                $this->contact->update($par);
            } else {
                $this->contact->update_self($par);
            }

            Audit_Logger::write('U', sprintf('customers:i_customer=%d', $this->i_customer));

        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }

        $db->commit();

        $this->getEntry();
    }

    private function set_can_change_base_currency() {
        global $db, $smarty;

        $smarty->assign('can_change_base_currency', FALSE);

        if (!$_SESSION['is_root_customer']) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM x_rates") > 1) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM tariffs") > 1) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM accounts") > 0) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM vendors WHERE NOT system") > 0) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM customers") > 1) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM payment_processors") > 0) {
            return FALSE;
        }

        $smarty->assign('can_change_base_currency', TRUE);
        return TRUE;
    }
}

class Root_Customer_Prefs {

    public $i_customer;
    public $web_password;
    public $i_web_user;
    public $balance;
    public $i_time_zone;
    public $base_currency;
    public $i_lang;
    public $i_export_type;
    public $mail_from;
    public $start_page;
    public $api_access;
    public $allowed_hosts;
    public $contact;

    public $can_change_base_currency;
    public $i_password_policy;

    private $i_contact;

    function __construct($i_customer = 1) {
        $this->i_customer = $i_customer;

        $this->web_login = '';
        $this->web_password = '';
        $this->i_web_user = NULL;
        $this->balance = 0;
        $this->i_time_zone = NULL;
        $this->base_currency = NULL;
        $this->i_lang = NULL;
        $this->i_export_type = NULL;
        $this->mail_from = '';
        $this->start_page = NULL;
        $this->api_access = FALSE;
        $this->allowed_hosts = 'Any';
        $this->contact = NULL;

        $this->i_password_policy = Password_Policy::get($this->i_customer);
        $this->i_contact = NULL;
        $this->can_change_base_currency = $this->set_can_change_base_currency();

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;

        $sql = "SELECT wu.web_login, wu.web_password, wu.i_web_user,
                       c.i_balance, wu.i_time_zone, c.base_currency,
                       wu.i_lang, wu.i_export_type, c.mail_from, wu.start_page,
                       c.api_access, c.i_contact
                  FROM customers c
                  JOIN web_users wu ON (wu.i_customer = c.i_customer AND default_user)
                 WHERE c.i_customer = ?
                 LIMIT 1";
        $params = Array($this->i_customer);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception(_("No such Id."));
        }

        $this->web_login = $entry['web_login'];
        $this->web_password = $entry['web_password'];
        $this->i_web_user = $entry['i_web_user'];
        $this->i_time_zone = $entry['i_time_zone'];
        $this->base_currency = $entry['base_currency'];
        $this->i_lang = $entry['i_lang'];
        $this->i_export_type = $entry['i_export_type'];
        $this->mail_from = $entry['mail_from'];
        $this->start_page = $entry['start_page'];
        $this->api_access = Cast::str2bool($entry['api_access']);

        $this->i_contact = $entry['i_contact'];

        /***/
        $params = Array("i_customer" => new xmlrpcval(1, "int"),
                        "i_balance" => new xmlrpcval($entry['i_balance'], "int"),
                       );
        $bal_clnt = new Balanced_Client('getBalanceInfo', $params);
        $ret = $bal_clnt->get();
        $this->balance = $ret['balance_info']['balance'];

        /***/
        $sql = 'SELECT ip
                  FROM web_allowed_hosts
                 WHERE i_web_user = ?
              ORDER BY i_web_allowed_host';
        $params = Array($this->i_web_user);

        $rows = $db->getCol($sql, $params);
        if ($db->affected_rows == 0) {
            $this->allowed_hosts = 'Any';
        } else {
            $this->allowed_hosts = implode(', ', $rows);
        }

        /***/
        $this->contact = new Contact($this->i_contact);
    }

    public function initFromRequest($par) {
        $this->i_time_zone = $par['i_time_zone'];
        if ($this->can_change_base_currency) {
            $this->base_currency = $par['base_currency'];
        };
        $this->start_page = $par['start_page'];
        $this->i_lang = $par['i_lang'];
        $this->i_export_type = $par['i_export_type'];
        $this->mail_from = $par['mail_from'];
        $this->api_access = Cast::str2bool($par['api_access']);
        $this->allowed_hosts = $par['allowed_hosts'];

        $this->contact->initFromRequest($par, TRUE);
    }

    public function validate($par) {
        if ($par['web_password'] != '' || $par['confirm_web_password'] != '') {
            if (strcmp($par['web_password'], $par['confirm_web_password'])) {
                throw new Exception(_("Password mismatch."));
            }
        }

        /*
         * $par['web_password'] is validated in Web_User_Default_User_Self::validate_default_user()
         */

        if ($par['api_password'] != '') {
            $pp = new Password_Policy($this->i_password_policy, _('API Password'));
            $pp->validate_by_owner($par['api_password']);
        }

        /***/
        if ($par['mail_from'] != '') {
            if (!Validator::isEmail($par['mail_from']))
                throw new Exception(_("Mail \"From\" field has incorrect format. E-mail in the format username@domain is expected."));
        }

        /*
         * $par['allowed_hosts'] is validated in Web_User_Default_User_Self::validate_default_user()
         */

        $this->contact->validate($par);
    }

    public function update($par) {
        global $db;

        $this->validate($par);

        $db->begin();

        try {
            $sql = "UPDATE customers
                         SET mail_from = ?,
                             api_access = ?
                       WHERE i_customer = ?";
            $params = Array($par['mail_from'],
                            Cast::str2bool($par['api_access']) ? 1 : 0,
                            $this->i_customer
                           );
            $db->prepNexec($sql, $params);

            $wu = new Web_User_Default_User_Self($this->i_customer);
            $wu->update_self_default_user($par, FALSE);

            /* if root customer has changed own base currency */
            if ($this->can_change_base_currency) {
                $sql = "UPDATE customers
                           SET base_currency = ?,
                               payment_currency = ?
                         WHERE i_customer = ?";
                $params = Array($par['base_currency'], $par['base_currency'], $this->i_customer);
                $db->prepNexec($sql, $params);

                $sql = "UPDATE tariffs
                           SET iso_4217 = ?
                          FROM customers
                         WHERE customers.i_tariff = tariffs.i_tariff AND i_customer = ?";
                $params = Array($par['base_currency'], $this->i_customer);
                $db->prepNexec($sql, $params);

                $sql = "UPDATE x_rates
                           SET iso_4217 = ?,
                               last_update = now()
                         WHERE i_customer = ?";
                $params = Array($par['base_currency'], $this->i_customer);
                $db->prepNexec($sql, $params);

                $sql = "UPDATE vendors
                           SET base_currency = ?
                         WHERE system";
                $params = Array($par['base_currency']);
                $db->prepNexec($sql, $params);
            }

            if ($par['api_password'] != '') {
                $sql = "UPDATE customers
                             SET api_password = ?
                           WHERE i_customer = ?";
                $passwd = Password::crypt($this->web_login . ':XML API:' . $par['api_password'], Password::MD5);
                $params = Array($passwd, $this->i_customer);

                $db->prepNexec($sql, $params);
            }

            if ($_SESSION['is_root_customer']) {
                $this->contact->update($par);
            } else {
                $this->contact->update_self($par);
            }

            Audit_Logger::write('U', sprintf('customers:i_customer=%d', $this->i_customer));

        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }

        $db->commit();

        $this->getEntry();
    }

    private function set_can_change_base_currency() {
        global $db, $smarty;

        $smarty->assign('can_change_base_currency', FALSE);

        if ($db->getValue("SELECT COUNT(*) FROM x_rates") > 1) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM tariffs") > 1) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM accounts") > 0) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM vendors WHERE NOT system") > 0) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM customers") > 1) {
            return FALSE;
        } elseif ($db->getValue("SELECT COUNT(*) FROM payment_processors") > 0) {
            return FALSE;
        }

        $smarty->assign('can_change_base_currency', TRUE);
        return TRUE;
    }
}

class Account_Self {

    public $i_account;
    public $web_password;
    public $balance;
    public $i_time_zone;
    public $base_currency;
    public $i_lang;
    public $i_export_type;
    public $vm_enabled;
    public $vm_password;
    public $vm_notify_emails;
    public $vm_forward_emails;
    public $vm_del_after_fwd;
    public $vpn_enabled;
    public $vpn_password;
    public $hide_own_cli;
    public $block_incoming_anonymous;
    public $i_incoming_anonymous_action;
    public $dnd_enabled;

    public $can_modify_own_address_info;
    public $contact;
    public $i_password_policy;
    public $start_page;

    private $i_contact;
    private $password_policy;

    function __construct($i_account) {
        $this->i_account = $i_account;

        $this->web_password = '';
        $this->balance = 0;
        $this->i_time_zone = NULL;
        $this->base_currency = NULL;
        $this->i_lang = NULL;
        $this->i_export_type = NULL;
        $this->vm_enabled = TRUE;
        $this->vm_password = '';
        $this->vm_notify_emails = '';
        $this->vm_forward_emails = '';
        $this->vm_del_after_fwd = FALSE;
        $this->vpn_enabled = FALSE;
        $this->vpn_password = '';
        $this->hide_own_cli = FALSE;
        $this->block_incoming_anonymous = FALSE;
        $this->i_incoming_anonymous_action = 1;
        $this->dnd_enabled = FALSE;

        $this->can_modify_own_address_info = TRUE;
        $this->contact = NULL;
        $this->i_password_policy = 1;
        $this->start_page = NULL;

        $this->i_contact = NULL;
        $this->password_policy = NULL;

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;

        $sql = "SELECT web_password, i_balance,
                       i_time_zone, base_currency,
                       i_lang, i_export_type, vm_enabled, vm_password,
                       vm_notify_emails, vm_forward_emails, vm_del_after_fwd,
                       vpn_enabled, vpn_password, hide_own_cli, block_incoming_anonymous,
                       i_incoming_anonymous_action, dnd_enabled, i_contact,
                       i_password_policy, start_page
                  FROM accounts
                 WHERE i_account = ?
                 LIMIT 1";
        $params = Array($this->i_account);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception(_("No such Id."));
        }

        $this->web_password = $entry['web_password'];
        $this->i_time_zone = $entry['i_time_zone'];
        $this->base_currency = $entry['base_currency'];
        $this->i_lang = $entry['i_lang'];
        $this->i_export_type = $entry['i_export_type'];
        $this->vm_enabled = Cast::str2bool($entry['vm_enabled']);
        $this->vm_password = $entry['vm_password'];
        $this->vm_notify_emails = $entry['vm_notify_emails'];
        $this->vm_forward_emails = $entry['vm_forward_emails'];
        $this->vm_del_after_fwd = Cast::str2bool($entry['vm_del_after_fwd']);
        $this->vpn_enabled = Cast::str2bool($entry['vpn_enabled']);
        $this->vpn_password = $entry['vpn_password'];
        $this->hide_own_cli = Cast::str2bool($entry['hide_own_cli']);
        $this->block_incoming_anonymous = Cast::str2bool($entry['block_incoming_anonymous']);
        $this->i_incoming_anonymous_action = $entry['i_incoming_anonymous_action'];
        $this->dnd_enabled = Cast::str2bool($entry['dnd_enabled']);
        $this->i_contact = $entry['i_contact'];
        $this->i_password_policy = $entry['i_password_policy'];
        $this->start_page = $entry['start_page'];

        $this->can_modify_own_address_info = check_account_class_acl('modify_own_address_info', $this->i_account);

        /***/
        $params = Array("i_customer" => new xmlrpcval(1, "int"),
                        "i_balance" => new xmlrpcval($entry['i_balance'], "int"),
                       );
        $bal_clnt = new Balanced_Client('getBalanceInfo', $params);
        $ret = $bal_clnt->get();
        $this->balance = $ret['balance_info']['balance'];

        /***/
        $this->contact = new Contact($this->i_contact);
    }

    public function initFromRequest($par) {
        $this->i_time_zone = $par['i_time_zone'];
        $this->i_lang = $par['i_lang'];
        $this->i_export_type = $par['i_export_type'];
        $this->api_access = Cast::str2bool($par['api_access']);

        if ($this->vm_enabled) {
            $this->vm_password = $par['vm_password'];
            $this->vm_notify_emails = $par['vm_notify_emails'];
            $this->vm_forward_emails = $par['vm_forward_emails'];
            $this->vm_del_after_fwd = Cast::str2bool($par['vm_del_after_fwd']);
        }
        if ($this->vpn_enabled) {
            $this->vpn_password = $par['vpn_password'];
        }
        $this->hide_own_cli = Cast::str2bool($par['hide_own_cli']);
        $this->block_incoming_anonymous = Cast::str2bool($par['block_incoming_anonymous']);
        $this->i_incoming_anonymous_action = $par['i_incoming_anonymous_action'];
        $this->dnd_enabled = Cast::str2bool($par['dnd_enabled']);

        if ($this->can_modify_own_address_info) {
            $this->contact->initFromRequest($par);
        }
    }

    public function validate($par) {
        global $db;

        if ($par['web_password'] != '' || $par['confirm_web_password'] != '') {
            if (strcmp($par['web_password'], $par['confirm_web_password'])) {
                throw new Exception(_("Password mismatch."));
            }
        }

        if ($par['web_password'] != '') {
            $pp = new Password_Policy($this->i_password_policy, _('Web Password'));
            $pp->validate_by_owner($par['web_password']);
        }

        /***/
        if ($this->vpn_enabled) {
            if (get_par('vpn_password') != '') {
                $pp = new Password_Policy($this->i_password_policy, _('VPN Password'));
                $pp->validate_by_owner(get_par('vpn_password'));
            }
        }

        /***/
        if ($this->vm_enabled) {
            if ($par['vm_password'] != '') {
                if (!Validator::isVMPassword($par['vm_password']))
                    throw new Exception(_('"PIN Code" field has incorrect format. Sequence of decimal digits is expected.'));
            }

            /***/
            if ($par['vm_notify_emails'] != '') {
                if (!Validator::isEmailsList($par['vm_notify_emails']))
                    throw new Exception(_("E-Mail Notification field has incorrect format. Comma separated E-mails list in the format username@domain is expected."));
            }

            if ($par['vm_forward_emails'] != '') {
                if (!Validator::isEmailsList($par['vm_forward_emails']))
                    throw new Exception(_("E-Mail Forwarding field has incorrect format. Comma separated E-mails list in the format username@domain is expected."));
            }
        }

        if (Cast::str2bool($par['block_incoming_anonymous'])) {
            if ($par['i_incoming_anonymous_action'] == '') {
                throw new Exception(_("Incoming Anonymous Action is mandatory."));
            }

            $sql = "SELECT COUNT(*)
                      FROM incoming_anonymous_actions
                     WHERE i_incoming_anonymous_action = ?";
            $params = Array($par['i_incoming_anonymous_action']);
            $count = $db->getValue($sql, $params);
            if ($count == 0) {
                throw new Exception(_("There is no such Incoming Anonymous Action."));
            }
        }

        if ($this->can_modify_own_address_info) {
            $this->contact->validate($par);
        }
    }

    public function update($par) {
        global $db;

        $this->validate($par);

        $this->update_session = FALSE;

        $db->begin();

        try {
            $sql = "UPDATE accounts
                       SET  i_time_zone = ?
                           ,i_lang = ?
                           ,i_export_type = ?
                           ,start_page = ?
                           ,hide_own_cli = ?
                           ,block_incoming_anonymous = ?
                           ,dnd_enabled = ?";
            $params = Array($par['i_time_zone'],
                            $par['i_lang'],
                            $par['i_export_type'],
                            $par['start_page'],
                            Cast::str2bool($par['hide_own_cli']),
                            Cast::str2bool($par['block_incoming_anonymous']),
                            Cast::str2bool($par['dnd_enabled']),
                           );

            /***/
            if ($par['web_password'] != '') {
                $ph = new Password_History(Web_Password::ACCOUNT, $this->i_account, _('Web Password'));
                $ph->chk_rot_upd($par['web_password']);

                $this->update_session = TRUE;
            }

            /***/
            if ($this->vpn_enabled) {
                if (get_par('vpn_password') != '') {
                    $sql .= " ,vpn_password = ?";
                    $params = array_merge($params, Array($par['vpn_password']));
                }
            }

            /***/
            if ($this->vm_enabled) {
                if ($par['vm_password'] != '') {
                    $salt = Password::gen_salt();
                    $password = Password::crypt($par['vm_password'], Password::SHA256, $salt) . $salt;

                    $sql .= " ,vm_password = ?";
                    $params = array_merge($params, Array($password));
                }

                $sql .= " ,vm_notify_emails = ?
                          ,vm_forward_emails = ?
                          ,vm_del_after_fwd = ?";
                $params = array_merge($params,
                                      Array($par['vm_notify_emails'],
                                            $par['vm_forward_emails'],
                                            Cast::str2bool($par['vm_del_after_fwd'])
                                            ));
            }

            if (Cast::str2bool($par['block_incoming_anonymous'])) {
                $sql .= " ,i_incoming_anonymous_action = ?";
                $params = array_merge($params, Array($par['i_incoming_anonymous_action']));
            }

            /* all parameters are collected */
            $sql .= " WHERE i_account = ?";
            $params = array_merge($params, Array($this->i_account));

            $db->prepNexec($sql, $params);

            /***/
            if ($this->can_modify_own_address_info) {
                $this->contact->update_self($par);
            }

            /***/
            if ($this->update_session) {
                $this->getEntry();
                $_SESSION['password'] = $this->web_password;
            }

            Audit_Logger::write('U', sprintf('accounts:i_account=%d', $this->i_account));

        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }

        $db->commit();

        /*
         * do not call $this->getEntry() twice
         */
        if (!$this->update_session) {
            $this->getEntry();
        }
    }
}

class Vendor_Self {

    public $i_vendor;
    public $web_password;
    public $balance;
    public $i_time_zone;
    public $base_currency;
    public $i_lang;
    public $i_export_type;

    public $contact;
    public $i_password_policy;

    private $i_contact;
    private $password_policy;

    function __construct($i_vendor) {
        $this->i_vendor = $i_vendor;

        $this->web_password = '';
        $this->balance = 0;
        $this->i_time_zone = NULL;
        $this->base_currency = NULL;
        $this->i_lang = NULL;
        $this->i_export_type = NULL;

        $this->contact = NULL;
        $this->i_password_policy = 1;

        $this->i_contact = NULL;
        $this->password_policy = NULL;

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;
        global $base_c;

        $sql = "SELECT web_password, i_balance,
                       i_time_zone, i_lang,
                       i_export_type, i_contact,
                       i_password_policy
                  FROM vendors
                 WHERE NOT system AND i_vendor = ?
                 LIMIT 1";
        $params = Array($this->i_vendor);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception(_("No such Id."));
        }

        $this->web_password = $entry['web_password'];
        $this->i_time_zone = $entry['i_time_zone'];
        $this->i_lang = $entry['i_lang'];
        $this->i_export_type = $entry['i_export_type'];

        $this->i_contact = $entry['i_contact'];
        $this->i_password_policy = $entry['i_password_policy'];

        $this->contact = new Contact($this->i_contact);

        /***/
        $params = Array("i_customer" => new xmlrpcval(1, "int"),
                        "i_balance" => new xmlrpcval($entry['i_balance'], "int"),
                       );
        $bal_clnt = new Balanced_Client('getBalanceInfo', $params);
        $ret = $bal_clnt->get();
        $this->balance = $ret['balance_info']['balance'];

        $this->base_currency = $base_c;
    }

    public function initFromRequest($par) {
        $this->i_time_zone = $par['i_time_zone'];
        $this->i_lang = $par['i_lang'];
        $this->i_export_type = $par['i_export_type'];

        $this->contact->initFromRequest($par);
    }

    public function validate($par) {
        global $db;

        if ($par['web_password'] != '' || $par['confirm_web_password'] != '') {
            if (strcmp($par['web_password'], $par['confirm_web_password'])) {
                throw new Exception(_("Password mismatch."));
            }
        }

        if ($par['web_password'] != '') {
            $pp = new Password_Policy($this->i_password_policy, _('Web Password'));
            $pp->validate_by_owner($par['web_password']);
        }

        $this->contact->validate($par);
    }

    public function update($par) {
        global $db;

        $this->validate($par);

        $this->update_session = FALSE;

        $db->begin();

        try {
            $sql = "UPDATE vendors
                       SET  i_time_zone = ?
                           ,i_lang = ?
                           ,i_export_type = ?";
            $params = Array($par['i_time_zone'],
                            $par['i_lang'],
                            $par['i_export_type']
                           );

            /***/
            if ($par['web_password'] != '') {
                $ph = new Password_History(Web_Password::VENDOR, $this->i_vendor, _('Web Password'));
                $ph->chk_rot_upd($par['web_password']);

                $this->update_session = TRUE;
            }

            /* all parameters are collected */
            $sql .= " WHERE i_vendor = ?";
            $params = array_merge($params, Array($this->i_vendor));

            $db->prepNexec($sql, $params);

            /***/
            $this->contact->update_self($par);

            /***/
            if ($this->update_session) {
                $this->getEntry();
                $_SESSION['password'] = $this->web_password;
            }

            Audit_Logger::write('U', sprintf('vendors:i_vendor=%d', $this->i_vendor));

        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }

        $db->commit();

        /*
         * do not call $this->getEntry() twice
         */
        if (!$this->update_session) {
            $this->getEntry();
        }
    }
}

?>
