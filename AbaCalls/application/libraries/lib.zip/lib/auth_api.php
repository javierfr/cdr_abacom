<?

// Copyright (c) 2003-2006 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

define('CRYPTO_TYPE_PLAIN_TEXT',0);
define('CRYPTO_TYPE_MD5',1);
define('CRYPTO_TYPE_SHA1',2);
define('CRYPTO_TYPE_3DES',3);
define('CRYPTO_TYPE_SHA256',4);


function auth_crypt_password( $p_password, $p_crypto_type, $p_salt = null ) {

    switch ( $p_crypto_type ) {
    
	case CRYPTO_TYPE_MD5:
	    $t_crypted_password = md5($p_password);
	    break;

	case CRYPTO_TYPE_SHA1:
	    $t_crypted_password = sha1($p_password);
	    break;

	case CRYPTO_TYPE_SHA256:
	    if (is_null($p_salt))
		$t_crypted_password = bin2hex(mhash(MHASH_SHA256,$p_password));
	    else
		$t_crypted_password = bin2hex(mhash(MHASH_SHA256,$p_password.$p_salt));
	    break;
	        
	case CRYPTO_TYPE_PLAIN_TEXT:
	default:
	    $t_crypted_password = $p_password;	    
    }

    return $t_crypted_password;
}

function auth_key_gen(){
    return substr(md5(mt_rand()), 0, 8);
}
?>
