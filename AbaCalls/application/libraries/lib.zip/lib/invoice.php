<?php

// Copyright (c) 2006-2013 Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Invoice {

    public $i_invoice_history;
    public $i_customer;
    public $i_account;
    public $timestamp;
    public $data;

    private $_fault;

    function __construct($i_customer, $i_account = NULL, $i_invoice_history = NULL) {
        $this->i_invoice_history = $i_invoice_history;
        $this->i_customer = $i_customer;
        $this->i_account = $i_account;
        $this->timestamp = NULL;
        $this->data = NULL;

        $this->_fault = FALSE;

        if ($this->i_invoice_history !== NULL) {
            $this->getEntry($this->i_invoice_history);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_invoice_history) {
        global $db;

        $sql = 'SELECT ih.i_invoice_history, ih.tstamp AS timestamp, ih.data
                  FROM invoice_history ih
                  JOIN accounts a ON (a.i_account = ih.i_account)
                  JOIN customers c ON (c.i_customer = a.i_customer)
                 WHERE c.i_customer = ? AND ih.i_account = ? AND ih.i_invoice_history = ?
                 LIMIT 1';
        $params = Array($this->i_customer, $this->i_account, $i_invoice_history);
        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_invoice_history = $entry['i_invoice_history'];
        $this->timestamp = $entry['timestamp'];
        $this->data = base64_decode($entry['data']);
    }

    public function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if ($this->i_account !== NULL) {
            $ret['sql'] .= ' AND ih.i_account = ?';
            $ret['params'][] = $this->i_account;
        }

        $from_date = isset_par('startDate') ? get_par('startDate') : parse_date(date('Y-m-01 00:00:00'));
        $from_date = parse_date($from_date);
        $ret['sql'] .= ' AND ih.tstamp >= ?';
        $ret['params'][] = $from_date;

        $to_date = isset_par('endDate') ? get_par('endDate') : 'now';
        $to_date = parse_date($to_date);
        $ret['sql'] .= ' AND ih.tstamp <= ?';
        $ret['params'][] = $to_date;

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(ih.*)
                  FROM invoice_history ih
                  JOIN accounts a ON (a.i_account = ih.i_account)
                  JOIN customers c ON (c.i_customer = a.i_customer)
                 WHERE c.i_customer = ?
                        {$clause['sql']}";
        $params = array_merge(Array($this->i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT ih.i_invoice_history, ih.data, ih.i_account, a.username,
                       EXTRACT(epoch FROM ih.tstamp) AS issued_on,
                       CHAR_LENGTH(data) = 0 AS is_empty
                  FROM invoice_history ih
                  JOIN accounts a ON (a.i_account = ih.i_account)
                  JOIN customers c ON (c.i_customer = a.i_customer)
                 WHERE c.i_customer = ?
                       {$clause['sql']}
              ORDER BY ih.tstamp DESC, a.username
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($this->i_customer), $clause['params']);

        $rows = $db->getAll($sql, $params);

        foreach ($rows as &$row) {
           $row['is_empty'] = Cast::str2bool($row['is_empty']);
        }

        return $rows;
    }
}

?>
