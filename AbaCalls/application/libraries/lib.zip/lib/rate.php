<?php

// Copyright (c) 2017 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Rate {

    public $i_rate;
    public $i_tariff;
    public $prefix;
    public $price_1;
    public $price_n;
    public $interval_1;
    public $interval_n;
    public $forbidden;
    public $grace_period_enable;
    public $local_price_1;
    public $local_price_n;
    public $local_interval_1;
    public $local_interval_n;
    public $area_name;
    public $activation_date;
    public $expiration_date;

    public $future;
    public $discontinued;

    protected $parsed_activation_date;
    protected $parsed_expiration_date;
    protected $tariff;

    protected $_fault;

    function __construct($i_tariff, $i_rate = NULL) {

        $this->i_rate = $i_rate;
        $this->i_tariff = $i_tariff;
        $this->prefix = NULL;
        $this->grace_period_enable = TRUE;
        $this->price_1 = 0;
        $this->price_n = 0;
        $this->interval_1 = 1;
        $this->interval_n = 1;
        $this->forbidden = FALSE;
        $this->local_price_1 = 0;
        $this->local_price_n = 0;
        $this->local_interval_1 = 1;
        $this->local_interval_n = 1;
        $this->area_name = NULL;
        $this->activation_date = NULL;
        $this->expiration_date = NULL;

        $this->future = FALSE;
        $this->discontinued = FALSE;

        $this->parsed_activation_date = NULL;
        $this->parsed_expiration_date = NULL;
        $this->tariff = NULL;

        $this->_fault = FALSE;

        if ($this->i_rate !== NULL) {
            $this->getEntry($this->i_rate);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_rate) {
        global $db;

        $sql = "SELECT r.i_rate, r.prefix,
                       r.grace_period_enable, r.price_1,
                       r.price_n, r.interval_1, r.interval_n,
                       r.forbidden,
                       r.local_price_1, r.local_price_n, r.local_interval_1,
                       r.local_interval_n, r.area_name,
                       TO_CHAR(r.activation_date, 'YYYY-MM-DD HH24:MI:SS') AS activation_date,
                       TO_CHAR(r.expiration_date, 'YYYY-MM-DD HH24:MI:SS') AS expiration_date,
                       r.activation_date > now() AS future,
                       r.expiration_date < now() AS discontinued 
                  FROM rates r
                 WHERE r.i_tariff = ? AND r.i_rate = ?
                 LIMIT 1";
        $params = Array($this->i_tariff, $i_rate);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_rate = $entry['i_rate'];
        $this->prefix = $entry['prefix'];
        $this->grace_period_enable = Cast::str2bool($entry['grace_period_enable']);
        $this->price_1 = $entry['price_1'];
        $this->price_n = $entry['price_n'];
        $this->interval_1 = $entry['interval_1'];
        $this->interval_n = $entry['interval_n'];
        $this->forbidden = Cast::str2bool($entry['forbidden']);
        $this->local_price_1 = $entry['local_price_1'];
        $this->local_price_n = $entry['local_price_n'];
        $this->local_interval_1 = $entry['local_interval_1'];
        $this->local_interval_n = $entry['local_interval_n'];
        $this->area_name = $entry['area_name'];
        $this->activation_date = $entry['activation_date'];
        $this->expiration_date = $entry['expiration_date'];
        $this->future = Cast::str2bool($entry['future']);
        $this->discontinued = Cast::str2bool($entry['discontinued']);
    }

    public function initFromRequest($par) {
        $this->i_rate = $par['i_rate'];
        $this->prefix = $par['prefix'];
        $this->grace_period_enable = Cast::str2bool($par['grace_period_enable']);
        $this->price_1 = Cast::str2bool($par['forbidden']) ? $this->price_1 : $par['price_1'];
        $this->price_n = Cast::str2bool($par['forbidden']) ? $this->price_n : $par['price_n'];
        $this->interval_1 = Cast::str2bool($par['forbidden']) ? $this->interval_1 : $par['interval_1'];
        $this->interval_n = Cast::str2bool($par['forbidden']) ? $this->interval_n : $par['interval_n'];
        $this->forbidden = Cast::str2bool($par['forbidden']);
        $this->local_price_1 = Cast::str2bool($par['forbidden']) ? $this->local_price_1 : $par['local_price_1'];
        $this->local_price_n = Cast::str2bool($par['forbidden']) ? $this->local_price_n : $par['local_price_n'];
        $this->local_interval_1 = Cast::str2bool($par['forbidden']) ? $this->local_interval_1 : $par['local_interval_1'];
        $this->local_interval_n = Cast::str2bool($par['forbidden']) ? $this->local_interval_n : $par['local_interval_n'];
        $this->area_name = Cast::str2bool($par['forbidden']) ? $this->area_name : $par['area_name'];
        $this->activation_date = $par['activation_date'] == '' ? $this->activation_date : $par['activation_date'];
        $this->expiration_date = $par['expiration_date'];
    }

    public function genID() {
        global $db;

        return $db->nextID('rates_seq');
    }

    public function init_filter_clause() {
        $fc = isset_par('filter_clause') ? get_par('filter_clause') : Array();

        $fc['prefix'] = array_key_exists('prefix', $fc) ? $fc['prefix'] : '';
        $fc['prefix_clause'] = array_key_exists('prefix_clause', $fc) ? $fc['prefix_clause'] : 0;
        $fc['act_clause'] = array_key_exists('act_clause', $fc) ? $fc['act_clause'] : 0;
        $fc['act_pattern'] = array_key_exists('act_pattern', $fc) ? $fc['act_pattern'] : 'Any';
        $fc['exp_clause'] = array_key_exists('exp_clause', $fc) ? $fc['exp_clause'] : 0;
        $fc['exp_pattern'] = array_key_exists('exp_pattern', $fc) ? $fc['exp_pattern'] : 'Any';

        set_par('filter_clause', $fc);
    }

    public function buildClause() {
        $this->init_filter_clause();

        $fc = get_par('filter_clause');
        $ret = Array('sql' => '', 'params' => Array());

        /* Prefix */
        if ($fc['prefix'] != '') {
            $ret['sql'] .= ' AND r.prefix ' . ($fc['prefix_clause'] ? ' NOT' : '') . ' LIKE ?';
            $ret['params'][] = $fc['prefix'];
        }

        /* Expiration */
        $a = strtoupper(trim($fc['exp_pattern']));
        $b = $fc['exp_clause'];
        $d = parse_date($a);

        switch($a) {
            case 'ANY':
                /* do not apply this clause */
                break;
            case 'NEVER':
                $ret['sql'] .= " AND r.expiration_date IS NULL ";
                break;

            default:
                /* try to parse user's input */
                $a = preg_replace('/(.*)\s+FROM\s+NOW$/', '${1}', $a);
                if (strtotime($a) == false) {       /* unparsable value */
                    $ret['sql'] .= " AND FALSE";
                    break;
                }
                switch($b) {
                    case 1:         /* Expired before */
                        $ret['sql'] .= " AND r.expiration_date <= ?";
                        $ret['params'][] = $d;
                        break;
                    case 2:         /* Expired after */
                        $ret['sql'] .= " AND r.expiration_date > ?";
                        $ret['params'][] = $d;
                        break;
                    case 0:         /* Expiration Date */
                    default:
                        $ret['sql'] .= " AND DATE(r.expiration_date) = ?
                                         AND NOT r.expiration_date < now()";
                        $ret['params'][] = $d;
                        break;
                }
                break;
        }

        /* Activation */
        $a = strtoupper(trim($fc['act_pattern']));
        $b = $fc['act_clause'];
        $d = parse_date($a);

        switch($a) {
            case 'ANY':
                /* do not apply this clause */
                break;
            case 'NEVER':
                $ret['sql'] .= " AND r.activation_date IS NULL ";
                break;

            default:
                /* try to parse user's input */
                $a = preg_replace('/(.*)\s+FROM\s+NOW$/', '${1}', $a);
                if (strtotime($a) == false) {       /* unparsable value */
                    $ret['sql'] .= " AND FALSE";
                    break;
                }
                switch($b) {
                    case 1:         /* Activation before */
                        $ret['sql'] .= " AND r.activation_date <= ?";
                        $ret['params'][] = $d;
                        break;
                    case 2:         /* Activation since */
                        $ret['sql'] .= " AND r.activation_date > ?";
                        $ret['params'][] = $d;
                        break;
                    case 0:         /* Activation Date */
                    default:
                        $ret['sql'] .= " AND DATE(r.activation_date) = ?
                                         AND NOT r.activation_date < now()";
                        $ret['params'][] = $d;
                        break;
                }
                break;
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(*)
                  FROM rates r
                 WHERE r.i_tariff = ?
                       {$clause['sql']}";
        $params = array_merge(Array($this->i_tariff), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT r.*,
                       r.activation_date > now() AS future,
                       r.expiration_date < now() AS discontinued 
                  FROM rates r
                 WHERE r.i_tariff = ?
                       {$clause['sql']}
              ORDER BY r.prefix, r.activation_date DESC
                 LIMIT " . ROW_PER_PAGE . "
                OFFSET $off
             ";
        $params = array_merge(Array($this->i_tariff), $clause['params']);

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$r) {
            list($r['name'], $r['description']) = get_description($r['prefix']);
            $r['grace_period_enable'] = Cast::str2bool($r['grace_period_enable']);
            $r['forbidden'] = Cast::str2bool($r['forbidden']);
            $r['future'] = Cast::str2bool($r['future']);
            $r['discontinued'] = Cast::str2bool($r['discontinued']);
        }

        return $ret;
    }

    public function getExportQuery() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT r.*,
                       TO_CHAR(r.activation_date, 'YYYY-MM-DD HH24:MI:SS') AS activation_date,
                       TO_CHAR(r.expiration_date, 'YYYY-MM-DD HH24:MI:SS') AS expiration_date
                  FROM rates r
                 WHERE r.i_tariff = ?
                       {$clause['sql']}
              ORDER BY r.prefix, r.activation_date DESC";
        $params = array_merge(Array($this->i_tariff), $clause['params']);

        return Array($sql, $params);
    }

    protected function doesRateExist($par, $i_rate = 0) {
        global $db;

        $act_date = $this->parsed_activation_date['date'];

        $exp_date = $this->parsed_expiration_date['date'];
        if ($exp_date == 'NULL') {
            $exp_date = "NOW() + interval '1 year'";
        }

        if ($i_rate == 0) {
            $exp_date2 = 'expiration_date';
        } else {
            $exp_date2 = "COALESCE(expiration_date, NOW() + interval '1 year')";
        }

        $sql = "SELECT COUNT(*)
                  FROM rates
                 WHERE prefix = ? AND i_tariff = ? AND i_rate <> ?
                       AND ($act_date, $exp_date) OVERLAPS (activation_date, $exp_date2)";

        $params = Array($par['prefix'], $this->i_tariff, $i_rate);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $i_rate = 0) {
        global $db;

        $tariff = $this->getTariff();
        $is_rate_uploader = in_array(get_class($this), Array('RateUploader', 'BinaryRateUploader'));

        if (!$is_rate_uploader && $tariff->lock_for_upload) {
            throw new Exception(_('Tariff is locked for making changes, processing of uploaded file is in progress.'));
        };

        if ($this->discontinued) {
            throw new Exception(_('Cannot modify discontinued rate.'));
        }

        if ($par['prefix'] == '') {
            throw new Exception(_('"Prefix" field is mandatory.'));
        }

        if (!Validator::isPrefix($par['prefix'], TRUE)) {
            throw new Exception(_('"Prefix" field has incorrect format. Symbols from [0-9a-zA-Z_#] range are expected.'));
        }

        if (!Cast::str2bool($par['forbidden']) || $is_rate_uploader) {
            if (!Validator::isNumber($par['interval_1'], TRUE) || $par['interval_1'] < 0) {
                throw new Exception(_('"Interval 1" field has incorrect number format. Non-negative number is expected.'));
            }

            if (!Validator::isNumber($par['interval_n'], TRUE) || $par['interval_n'] <= 0) {
                throw new Exception(_('"Interval N" field has incorrect number format. Non-negative number is expected.'));
            }

            if (!Validator::isFloat($par['price_1'], TRUE) || $par['price_1'] < 0) {
                throw new Exception(_('"Price 1" field has incorrect number format. Non-negative number is expected.'));
            }

            if (!Validator::isFloat($par['price_n'], TRUE) || $par['price_n'] < 0) {
                throw new Exception(_('"Price N" field has incorrect number format. Non-negative number is expected.'));
            }
        }

        if (!Cast::str2bool($par['forbidden']) && $tariff->local_calling &&
            ($par['area_name'] != '' || $is_rate_uploader)) {

            if (!Validator::isNumber($par['local_interval_1'], TRUE) || $par['local_interval_1'] < 0) {
                throw new Exception(_('"Local Interval 1" field has incorrect number format. Non-negative number is expected.'));
            }

            if (!Validator::isNumber($par['local_interval_n'], TRUE) || $par['local_interval_n'] <= 0) {
                throw new Exception(_('"Local Interval N" field has incorrect number format. Non-negative number is expected.'));
            }

            if (!Validator::isFloat($par['local_price_1'], TRUE) || $par['local_price_1'] < 0) {
                throw new Exception(_('"Local Price 1" field has incorrect number format. Non-negative number is expected.'));
            }

            if (!Validator::isFloat($par['local_price_n'], TRUE) || $par['local_price_n'] < 0) {
                throw new Exception(_('"Local Price N" field has incorrect number format. Non-negative number is expected.'));
            }
        }

        /* dates */
        if ($i_rate == 0 || $this->future) {
            $this->parsed_activation_date = parse_future_date($par['activation_date']);
        } else {
            $this->parsed_activation_date = parse_future_date($this->activation_date);
        }

        $this->parsed_expiration_date = parse_future_date($par['expiration_date']);

        /* activation date */
        if ($i_rate == 0 || $this->future) {
            if (!$this->parsed_activation_date['is_future']) {
                throw new Exception(_('"Activation Date" cannot be in the past.'));
            }
            if ($this->parsed_activation_date['utime'] === NULL) {
                throw new Exception(_('"Activation Date" field has incorrect value.'));
            }
            if ($this->parsed_expiration_date['utime'] !== NULL &&
                $this->parsed_activation_date['utime'] >= $this->parsed_expiration_date['utime']) {
                throw new Exception(_('"Activation Date" cannot be later than "Expiration Date".'));
            }
        }

        /* expiration date */
        if (!$this->parsed_expiration_date['is_future']) {
            throw new Exception(_('"Expiration Date" cannot be in the past.'));
        }

        /*** *** ***/
        if ($this->doesRateExist($par, $i_rate)) {
            throw new Exception(_('Another Rate with conflicting "Prefix" or "Activation/Expiration Date" already exists.'));
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $db->begin();

        $act_date = $this->parsed_activation_date['date'];
        $exp_date = $this->parsed_expiration_date['date'];

        $sql = "UPDATE rates
                   SET expiration_date = $act_date
                 WHERE prefix = ?
                       AND i_tariff = ?
                       AND expiration_date is NULL
                       AND activation_date < $act_date";
        $params = Array($par['prefix'], $this->i_tariff);
        $db->prepNexec($sql, $params);

        $tariff = $this->getTariff();

        if ($tariff->local_calling && $par['area_name'] != '') {
            $sub_sql1 = ', local_interval_1, local_interval_n, local_price_1, local_price_n, area_name';
            $sub_sql2 = ', ?, ?, ?, ?, ?';
        }

        $i_rate = $this->genID();

        $sql = "INSERT INTO rates (i_rate, prefix, i_tariff, grace_period_enable, interval_1,
                                    interval_n, price_1, price_n, forbidden,
                                    activation_date, expiration_date ${sub_sql1})
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, $act_date, $exp_date ${sub_sql2})";
        $params = Array($i_rate,
                        $par['prefix'],
                        $this->i_tariff,
                        Cast::str2bool($par['grace_period_enable']),
                        Cast::str2bool($par['forbidden']) ? $this->interval_1 : $par['interval_1'],
                        Cast::str2bool($par['forbidden']) ? $this->interval_n : $par['interval_n'],
                        Cast::str2bool($par['forbidden']) ? $this->price_1 : $par['price_1'],
                        Cast::str2bool($par['forbidden']) ? $this->price_n : $par['price_n'],
                        Cast::str2bool($par['forbidden'])
                       );

        if ($tariff->local_calling && $par['area_name'] != '') {
            $params2 = Array($par['local_interval_1'],
                             $par['local_interval_n'],
                             $par['local_price_1'],
                             $par['local_price_n'],
                             $par['area_name']
                            );
            $params = array_merge($params, $params2);
        }

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_("Cannot insert Rate."));
        }

        $this->notify_cached();

        $db->commit();

        $this->getEntry($i_rate);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $tariff = $this->getTariff();

        $this->validate($par, $this->i_rate);

        $db->begin();

        $act_date = '';
        if ($par['activation_date'] != '') {
            $act_date = ', activation_date = ' . $this->parsed_activation_date['date'];
        }

        $exp_date = '';
        if ($par['expiration_date'] != '') {
            $exp_date = ', expiration_date = ' . $this->parsed_expiration_date['date'];
        }

        $sub_sql1 = '';
        if ($tariff->local_calling && !Cast::str2bool($par['forbidden'])) {
            if ($par['area_name'] != '') {
                $sub_sql1 = ', local_interval_1 = ?, local_interval_n = ?, local_price_1 = ?,
                             local_price_n = ?, area_name = ? ';
            } else {
                $sub_sql1 = ', area_name = ?';
            }
        }

        if (Cast::str2bool($par['forbidden'])) {
            $sql = "UPDATE rates
                       SET prefix = ?, grace_period_enable = ?,
                           forbidden = ?  $act_date $exp_date
                        WHERE i_rate = ? AND i_tariff = ?";
            $params = Array($par['prefix'],
                            Cast::str2bool($par['grace_period_enable']),
                            Cast::str2bool($par['forbidden'])
                           );

        } else {
            $sql = "UPDATE rates
                       SET prefix = ?, grace_period_enable = ?,
                           interval_1 = ?, interval_n = ?, price_1 = ?, price_n = ?,
                           forbidden = ? ${sub_sql1} $act_date $exp_date
                     WHERE i_rate = ? AND i_tariff = ?";
            $params = Array($par['prefix'],
                            Cast::str2bool($par['grace_period_enable']),
                            Cast::str2bool($par['forbidden']) ? $this->interval_1 : $par['interval_1'],
                            Cast::str2bool($par['forbidden']) ? $this->interval_n : $par['interval_n'],
                            Cast::str2bool($par['forbidden']) ? $this->price_1 : $par['price_1'],
                            Cast::str2bool($par['forbidden']) ? $this->price_n : $par['price_n'],
                            Cast::str2bool($par['forbidden'])
                           );
        }

        if ($tariff->local_calling && !Cast::str2bool($par['forbidden'])) {
            $params2 = Array();

            if ($par['area_name'] != '') {
                $params2 = Array($par['local_interval_1'],
                                 $par['local_interval_n'],
                                 $par['local_price_1'],
                                 $par['local_price_n'],
                                 $par['area_name']
                                );
            } else {
                $params2 = Array(NULL);
            }

            $params = array_merge($params, $params2);
        }

        $params = array_merge($params, Array($this->i_rate, $this->i_tariff));

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_("Cannot update Rate."));
        }

        $this->notify_cached();

        $db->commit();

        $this->getEntry($this->i_rate);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        $tariff = $this->getTariff();
        if ($tariff->lock_for_upload) {
            throw new Exception(_('Tariff is locked for making changes, processing of uploaded file is in progress.'));
        };

        $db->begin();

        $sql = 'DELETE FROM rates
                 WHERE i_rate = ? AND i_tariff = ?';
        $params = Array($par['i_rate'], $par['i_tariff']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Rate."));
        }

        $this->notify_cached();

        $db->commit();
    }

    public function getTariff() {
        if ($this->tariff === NULL) {
            $this->tariff = new Tariff($this->i_tariff);
        }

        return $this->tariff;
    }

    /* notify cache sybsystems that rates have changed */
    public function notify_cached() {
        global $db;

        $sql = "UPDATE tariffs
                   SET last_change_count = last_change_count + 1
                 WHERE i_tariff = ?";
        $params = Array($this->i_tariff);
        $db->prepNexec($sql, $params);

    }
}

class RateUploader extends Rate {

    public $import_processed = 0;
    public $import_recognized = 0;
    public $import_added = 0;
    public $import_updated = 0;
    public $import_deleted = 0;
    public $import_errors = 0;

    private $tmp_table_suffix = '';
    private $tmp_table = NULL;

    function __construct($i_tariff) {
        global $db;

        parent::__construct($i_tariff);

        load_prefixes();

        $this->getTariff();

        $this->tmp_table_suffix = strftime('_%s');
        $this->tmp_table = "tmp_rates" . $this->tmp_table_suffix;

        $sql = "CREATE TEMPORARY TABLE " . $this->tmp_table . " AS
                    (SELECT * FROM rates
                      WHERE i_tariff = ?
                     )";
        $params = Array($this->i_tariff);
        $db->prepNexec($sql, $params);

        $sql = "ALTER TABLE " . $this->tmp_table . " ADD CONSTRAINT " .
                    $this->tmp_table . "_pkey PRIMARY KEY (i_rate)";
        $db->prepNexec($sql);
        $sql = "CREATE UNIQUE INDEX " . $this->tmp_table . "_prf_act ON " . $this->tmp_table . "(prefix, activation_date)";
        $db->prepNexec($sql);
        $sql = "ANALYZE " . $this->tmp_table;
        $db->prepNexec($sql);
    }

    function __destruct() {
        global $db;

        parent::__destruct();

        try {
            $sql = "DROP TABLE " . $this->tmp_table;
            $db->prepNexec($sql);
        } catch (Exception $e) {
            /* ignore any error */
        };
    }

    public function getEntry($i_rate) {
        global $db;

        $sql = "SELECT r.i_rate, r.prefix,
                       r.grace_period_enable, r.price_1,
                       r.price_n, r.interval_1, r.interval_n,
                       r.forbidden,
                       r.local_price_1, r.local_price_n, r.local_interval_1,
                       r.local_interval_n, r.area_name,
                       TO_CHAR(r.activation_date, 'YYYY-MM-DD HH24:MI:SS') AS activation_date,
                       TO_CHAR(r.expiration_date, 'YYYY-MM-DD HH24:MI:SS') AS expiration_date,
                       r.activation_date > now() AS future,
                       r.expiration_date < now() AS discontinued 
                  FROM " . $this->tmp_table . " r
                 WHERE r.i_rate = ?
                 LIMIT 1";
        $params = Array($i_rate);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_rate = $entry['i_rate'];
        $this->prefix = $entry['prefix'];
        $this->grace_period_enable = Cast::str2bool($entry['grace_period_enable']);
        $this->price_1 = $entry['price_1'];
        $this->price_n = $entry['price_n'];
        $this->interval_1 = $entry['interval_1'];
        $this->interval_n = $entry['interval_n'];
        $this->forbidden = Cast::str2bool($entry['forbidden']);
        $this->local_price_1 = $entry['local_price_1'];
        $this->local_price_n = $entry['local_price_n'];
        $this->local_interval_1 = $entry['local_interval_1'];
        $this->local_interval_n = $entry['local_interval_n'];
        $this->area_name = $entry['area_name'];
        $this->activation_date = $entry['activation_date'];
        $this->expiration_date = $entry['expiration_date'];
        $this->future = Cast::str2bool($entry['future']);
        $this->discontinued = Cast::str2bool($entry['discontinued']);
    }

    public function getEntryByPrefix($prefix) {
        global $db;

        $sql = "SELECT r.i_rate, r.prefix,
                       r.grace_period_enable, r.price_1,
                       r.price_n, r.interval_1, r.interval_n,
                       r.forbidden,
                       r.local_price_1, r.local_price_n, r.local_interval_1,
                       r.local_interval_n, r.area_name,
                       TO_CHAR(r.activation_date, 'YYYY-MM-DD HH24:MI:SS') AS activation_date,
                       TO_CHAR(r.expiration_date, 'YYYY-MM-DD HH24:MI:SS') AS expiration_date,
                       r.activation_date > now() AS future,
                       r.expiration_date < now() AS discontinued 
                  FROM " . $this->tmp_table . " r
                 WHERE r.prefix = ?
                       AND NOW() > r.activation_date
                       AND (NOW() < r.expiration_date OR r.expiration_date IS NULL)
                 LIMIT 1";
        $params = Array($prefix);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Prefix.");
        }

        $this->i_rate = $entry['i_rate'];
        $this->prefix = $entry['prefix'];
        $this->grace_period_enable = Cast::str2bool($entry['grace_period_enable']);
        $this->price_1 = $entry['price_1'];
        $this->price_n = $entry['price_n'];
        $this->interval_1 = $entry['interval_1'];
        $this->interval_n = $entry['interval_n'];
        $this->forbidden = Cast::str2bool($entry['forbidden']);
        $this->local_price_1 = $entry['local_price_1'];
        $this->local_price_n = $entry['local_price_n'];
        $this->local_interval_1 = $entry['local_interval_1'];
        $this->local_interval_n = $entry['local_interval_n'];
        $this->area_name = $entry['area_name'];
        $this->activation_date = $entry['activation_date'];
        $this->expiration_date = $entry['expiration_date'];
        $this->future = Cast::str2bool($entry['future']);
        $this->discontinued = Cast::str2bool($entry['discontinued']);
    }

    protected function doesRateExist($par, $i_rate = 0) {
        global $db;

        $act_date = $this->parsed_activation_date['date'];

        $exp_date = $this->parsed_expiration_date['date'];
        if ($exp_date == 'NULL') {
            $exp_date = "NOW() + interval '1 year'";
        }

        if ($i_rate == 0) {
            $exp_date2 = 'expiration_date';
        } else {
            $exp_date2 = "COALESCE(expiration_date, NOW() + interval '1 year')";
        }

        $sql = "SELECT COUNT(*)
                  FROM " . $this->tmp_table . "
                 WHERE prefix = ? AND i_rate <> ?
                       AND ($act_date, $exp_date) OVERLAPS (activation_date, $exp_date2)";

        $params = Array($par['prefix'], $i_rate);

        return $db->getValue($sql, $params) > 0;
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $act_date = $this->parsed_activation_date['date'];
        $exp_date = $this->parsed_expiration_date['date'];

        $sql = "UPDATE " . $this->tmp_table . "
                   SET expiration_date = $act_date
                 WHERE prefix = ?
                       AND expiration_date is NULL
                       AND activation_date < $act_date";
        $params = Array($par['prefix']);
        $db->prepNexec($sql, $params);

        $tariff = $this->getTariff();

        $i_rate = $this->genID();

        $sql = "INSERT INTO " . $this->tmp_table . "
                                    (i_rate, prefix, i_tariff, grace_period_enable, interval_1,
                                    interval_n, price_1, price_n, forbidden,
                                    activation_date, expiration_date, local_interval_1, local_interval_n,
                                    local_price_1, local_price_n, area_name)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, $act_date, $exp_date, ?, ?, ?, ?, ?)";
        $params = Array($i_rate,
                        $par['prefix'],
                        $this->i_tariff,
                        Cast::str2bool($par['grace_period_enable']),
                        Cast::str2bool($par['forbidden']) ? $this->interval_1 : $par['interval_1'],
                        Cast::str2bool($par['forbidden']) ? $this->interval_n : $par['interval_n'],
                        Cast::str2bool($par['forbidden']) ? $this->price_1 : $par['price_1'],
                        Cast::str2bool($par['forbidden']) ? $this->price_n : $par['price_n'],
                        Cast::str2bool($par['forbidden'])
                       );

        if ($tariff->local_calling) {
            $params2 = Array($par['local_interval_1'],
                             $par['local_interval_n'],
                             $par['local_price_1'],
                             $par['local_price_n'],
                             get_area_name($par['prefix'], $par['area_name'])
                            );
        } else {
            $params2 = Array(1,     /* local_interval_1 */
                             1,     /* local_interval_n */
                             0,     /* local_price_1    */
                             0,     /* local_price_n    */
                             NULL   /* area_name        */
                            );
        }
        $params = array_merge($params, $params2);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Rate."));
        }

        $this->setFault(FALSE);
    }

    public function update($par, $do_getEntry = TRUE) {
        global $db;

        $this->setFault(TRUE);

        if ($do_getEntry) {
            $this->getEntry($par['i_rate']);
        }

        $tariff = $this->getTariff();

        $this->validate($par, $this->i_rate);

        $act_date = '';
        if ($par['activation_date'] != '') {
            $act_date = ', activation_date = ' . $this->parsed_activation_date['date'];
        }

        $exp_date = '';
        if ($par['expiration_date'] != '') {
            $exp_date = ', expiration_date = ' . $this->parsed_expiration_date['date'];
        }

        $sub_sql1 = '';
        if ($tariff->local_calling && !Cast::str2bool($par['forbidden'])) {
            $sub_sql1 = ', local_interval_1 = ?, local_interval_n = ?, local_price_1 = ?,
                         local_price_n = ?, area_name = ? ';
        }

        if (Cast::str2bool($par['forbidden'])) {
            $sql = "UPDATE " . $this->tmp_table . "
                       SET prefix = ?, grace_period_enable = ?,
                           forbidden = ?  $act_date $exp_date
                        WHERE i_rate = ?";
            $params = Array($par['prefix'],
                            Cast::str2bool($par['grace_period_enable']),
                            Cast::str2bool($par['forbidden'])
                           );

        } else {
            $sql = "UPDATE " . $this->tmp_table . "
                       SET prefix = ?, grace_period_enable = ?,
                           interval_1 = ?, interval_n = ?, price_1 = ?, price_n = ?,
                           forbidden = ? ${sub_sql1} $act_date $exp_date
                     WHERE i_rate = ?";
            $params = Array($par['prefix'],
                            Cast::str2bool($par['grace_period_enable']),
                            Cast::str2bool($par['forbidden']) ? $this->interval_1 : $par['interval_1'],
                            Cast::str2bool($par['forbidden']) ? $this->interval_n : $par['interval_n'],
                            Cast::str2bool($par['forbidden']) ? $this->price_1 : $par['price_1'],
                            Cast::str2bool($par['forbidden']) ? $this->price_n : $par['price_n'],
                            Cast::str2bool($par['forbidden'])
                           );
        }

        if ($tariff->local_calling && !Cast::str2bool($par['forbidden'])) {
            $params2 = Array($par['local_interval_1'],
                             $par['local_interval_n'],
                             $par['local_price_1'],
                             $par['local_price_n'],
                             get_area_name($par['prefix'], $par['area_name'])
                            );

            $params = array_merge($params, $params2);
        }

        $params = array_merge($params, Array($this->i_rate));

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Rate."));
        }

        $this->setFault(FALSE);
    }

    public function updateByPrefix($par) {
        global $db;

        $this->setFault(TRUE);

        $this->getEntryByPrefix($par['prefix']);

        $this->update($par, FALSE);
    }

    public function delete($par) {
        global $db;

        $this->setFault(TRUE);

        $sql = "DELETE FROM " . $this->tmp_table . "
                 WHERE i_rate = ?";
        $params = Array($par['i_rate']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Rate."));
        }

        $this->setFault(FALSE);
    }

    public function merge_rates() {
        global $db;

        $db->begin();

        try {
            $sql = "DELETE FROM rates
                     WHERE i_tariff = ?";
            $params = Array($this->i_tariff);
            if (!$db->prepNexec($sql, $params)) {
                throw new Exception(_("Cannot delete old rates."));
            };

            $sql = "INSERT INTO rates (SELECT * FROM " . $this->tmp_table . ")";
            if (!$db->prepNexec($sql)) {
                throw new Exception(_("Cannot insert new rates."));
            };
        } catch (Exception $e) {
            error_log($e);
            $db->rollback();
        }

        $db->commit();
    }

    public function save_report($basedir, $zip_filename, $error_msg = NULL) {
        global $db;

        if ($this->import_errors > 0) {                 /* there are errors */

            $basedir = rtrim($basedir, '/') . '/';
            $handle = opendir($basedir);

            $files = Array();
            for (; false !== ($file = readdir($handle)); ) {
                $fullpath = $basedir . $file;
                if ($file != "." && $file != ".." && is_file($fullpath)) {
                    $files[] = Array('name' => $file, 'path' => $fullpath);
                }
            }

            if (count($files) > 1) {
                /* zip files using send_report_by_email_zip_attaches() as it only makes an archive */
                send_report_by_email_zip_attaches($basedir, $zip_filename);
            }

            rewinddir($handle);

            for (; false !== ($file = readdir($handle)); ) {
                $fullpath = $basedir . $file;
                if ($file != "." && $file != ".." && is_file($fullpath)) {
                    $ext = explode('.', $file);
                    switch ($ext[1]) {
                        case 'xlsx': $content_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'; break;
                        case 'csv': $content_type = 'application/vnd.ms-excel'; break;
                        case 'zip': $content_type = 'application/zip'; break;
                        default: $content_type = 'application/octet-stream';
                    }

                    $data = file_get_contents($fullpath);
                    $data = chunk_split(base64_encode($data));

                    $sql = 'UPDATE upload_reports
                               SET errors_found = TRUE,
                                   finished_on = now(),
                                   progress = 1,
                                   content_name = ?,
                                   content_type = ?,
                                   data = ?
                             WHERE i_tariff = ?';
                    $params = Array($file, $content_type, $data, $this->i_tariff);
                    $db->prepNexec($sql, $params);
                }
            }

            closedir($handle);

            return;
        }

        if ($error_msg !== NULL) {
            $data = $error_msg;
            $errors_found = TRUE;
        } else {
            /* no errors have been found */
            $data = sprintf('Upload has completed successfully' . ":\n" .
                               ' - ' . '%0d rows processed' . ";\n" .
                               ' - ' . '%0d commands recognized' . ";\n" .
                               ' - ' . '%0d records added' . ";\n" .
                               ' - ' . '%0d records updated' . ";\n" .
                               ' - ' . '%0d records deleted' . '.' ,
                               $this->import_processed,
                               $this->import_recognized,
                               $this->import_added,
                               $this->import_updated,
                               $this->import_deleted);
            $errors_found = FALSE;
        }

        $sql = 'UPDATE upload_reports
                   SET errors_found = ?,
                       finished_on = now(),
                       progress = 1,
                       data = ?
                 WHERE i_tariff = ?';
        $params = Array($errors_found, chunk_split(base64_encode($data)), $this->i_tariff);
        $db->prepNexec($sql, $params);
    }

    static function init_web_job($i_tariff, $filename) {
        global $db, $par;

        $db->begin();

        if (!$db->prepNexec('LOCK web_jobs')) {
            $db->rollback();
            throw new Exception('Unable to acquire the lock, i_tariff = ' . $i_tariff);
        }

        $sql = "UPDATE tariffs
                   SET lock_for_upload = TRUE
                 WHERE i_tariff = ? AND NOT lock_for_upload";
        $params = Array($i_tariff);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception("Unable to acquire a lock for rates upload, i_tariff = " . $i_tariff);
        }

        $i_web_job = $db->nextID('web_jobs_seq');
        $wrapped_file_name = escapeshellarg(get_par('wrapped_file_name'));

        $command = '/usr/local/bin/php cli_wrapper.php -- ' . getenv('I_ENVIRONMENT') . ' ' . $i_web_job . ' ' . $wrapped_file_name . ' > /dev/null 2>&1 & echo $!';
        //$command = '/usr/local/bin/php cli_wrapper.php -- ' . getenv('I_ENVIRONMENT') . ' ' . $i_web_job . ' ' . $wrapped_file_name . ' > /var/tmp/err.log 2>&1 & echo $!';
        exec($command, $op);

        $procid = (int)$op[0]; 
        $ps = shell_exec("/bin/ps $procid");
        $ps = explode("\n", $ps);
        $ps = preg_split("/\s+/", trim($ps[1]));
        if ($procid == '' || $ps[4] != '/usr/local/bin/php') {
            $db->rollback();
            throw new Exception("Unable to initiate web job for rates upload, i_tariff = " . $i_tariff);
        }

        set_par('filename', $filename);
        $params = serialize($par);
        $session = serialize($_SESSION);

        $sql = "INSERT INTO web_jobs (i_web_job, i_type, procid, params, session) VALUES (?, ?, ?, ?, ?)";
        $params = Array($i_web_job, 'UPLOAD_ROUTES', $procid, $params, $session);
        $db->prepNexec($sql, $params);

        $sql = "DELETE FROM upload_reports WHERE i_tariff = ?";
        $params = Array($i_tariff);
        $db->prepNexec($sql, $params);

        $sql = "INSERT INTO upload_reports (i_tariff) VALUES (?)";
        $params = Array($i_tariff);
        $db->prepNexec($sql, $params);

        $db->commit();

        error_log('Launch ' . $wrapped_file_name . ' in CLI mode, i_environment = ' . getenv('I_ENVIRONMENT') . ', i_web_job = ' . $i_web_job);
    }

    public function clear_web_jobs() {
        global $db;
        global $i_web_job;

        $sql = 'DELETE FROM web_jobs WHERE i_web_job = ?';
        $params = Array($i_web_job);
        $db->prepNexec($sql, $params);

        $sql = "UPDATE tariffs
                   SET lock_for_upload = FALSE
                 WHERE i_tariff = ? AND lock_for_upload";
        $params = Array($this->i_tariff);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            error_log("Unable to release a lock for rates upload, i_tariff = " . $i_tariff);
        }

        if (@unlink(get_par('filename'))) {
            error_log('file ' . get_par('filename') . ' has been deleted');
        }
    }
}

class BinaryRateUploader extends RateUploader {

    public function save_report($basedir, $zip_filename, $error_msg = NULL, $upload = NULL) {
        global $db;

        if ($this->import_errors > 0) {                 /* there are errors */

            $status = 'FAIL';

            $basedir = rtrim($basedir, '/') . '/';
            $handle = opendir($basedir);

            $files = Array();
            for (; false !== ($file = readdir($handle)); ) {
                $fullpath = $basedir . $file;
                if ($file != "." && $file != ".." && is_file($fullpath)) {
                    $files[] = Array('name' => $file, 'path' => $fullpath);
                }
            }

            if (count($files) > 1) {
               /* zip files using send_report_by_email_zip_attaches() as it only makes an archive */
               send_report_by_email_zip_attaches($basedir, $zip_filename);
            }


            rewinddir($handle);

            for (; false !== ($file = readdir($handle)); ) {
                $fullpath = $basedir . $file;
                if ($file != "." && $file != ".." && is_file($fullpath)) {
                    $ext = explode('.', $file);
                    if (!@rename($fullpath, $upload['file_path'] . '_report.' . $ext[1])) {
                        @dbg($upload['i_upload'], sprintf("unable to rename %s to %s", $fullpath,
                                                          $upload['file_path'] . '_report' . $ext[1]));
                    }

                    break;
                }
            }

            closedir($handle);

        } elseif ($error_msg !== NULL) {

            $status = 'FAIL';

            $fh = fopen($upload['file_path'] . '_report.txt', "w+");
            fwrite($fh, $error_msg);
            fclose($fh);

        } else {            /* no errors have been found */

            $status = 'DONE';

            $data = sprintf('Upload has completed successfully' . ":\n" .
                               ' - ' . '%0d rows processed' . ";\n" .
                               ' - ' . '%0d commands recognized' . ";\n" .
                               ' - ' . '%0d records added' . ";\n" .
                               ' - ' . '%0d records updated' . ";\n" .
                               ' - ' . '%0d records deleted' . '.' ,
                               $this->import_processed,
                               $this->import_recognized,
                               $this->import_added,
                               $this->import_updated,
                               $this->import_deleted);

            $fh = fopen($upload['file_path'] . '_report.txt', "w+");
            fwrite($fh, $data);
            fclose($fh);
        }

        $sql = 'UPDATE uploads
                   SET status = ?,
                       procid = NULL,
                       status_changed_on = now()
                 WHERE i_upload = ?';
        $params = Array($status, $upload['i_upload']);
        $db->prepNexec($sql, $params);
    }

}
?>
