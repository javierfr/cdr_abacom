<?php

// *********************************************************************
// * ACHTUNG, ACHTUNG! THIS FILE IS TO BE OBSOLETED SOON, PLEASE DON'T *
// * ADD ANY NEW OPTIONS, USE DATABASE INSTEAD!!!!                     *
// * *******************************************************************

// Copyright (c) 2003-2005 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

    //
    define('DEBUG',false);

    //
    define('BASEPATH','/');

    // Database     
    define('PG_USER','sippy');
    define('PG_PASSWORD','');
    define('PG_DB','sippy'); 
    define('PG_HOST','localhost'); 

    define("SCRIPT_MAX_EXECUTE_TIME","1800"); 
    define('IS_REFUND_CHARGE',false);    
//    define('SHOW_FINANSICAL_TRANSACTION',true);
    /* 0=>"All", 1=>"Refund/Credit", 2=>"Charges/Debit", 3=>"Add Funds", 100=>"None" */    
    define('DEFAULT_FINANCIAL_TRANSACTION',0);    

    // Year for stat
    define('CONFIG_START_YEAR', "2002");
    define('CONFIG_END_YEAR', date("Y")); // set to current year 
    define("ROW_PER_PAGE",50);
    
    define('RULE_TRUNC', 15);

    /* On payment actions */
    define('ON_PAYMENT_ACTION_NONE', -1);
    define('ON_PAYMENT_ACTION_EXTEND_LIFETIME', 0);
    define('ON_PAYMENT_ACTION_CLEAR_FIRST_USE', 1);
    define('ON_PAYMENT_ACTION_RESTART_BILLING', 2);

    /* Callback agent */
    define('CB_AGENT', '/home/sobomax/cbagent/cbagent.py');

    /* Localization */
    define('L10N_DEFAULT_LANG', 'en');
    define('L10N_DOMAIN', 'sippy_web');
    define('L10N_LOCALE', '/home/ssp/locale');

    /* default character set */
    define('DEFAULT_CHARSET', 'UTF-8');

    /* Account web-interface customization */
    define('ACCOUNT_CDRS_SHOW_DURATION', true);		/* show 'Duration' column in account's CDRs */

    /* Path to payments transaction log */
    define('PATH_PAYMENTS_TX_LOG', '/var/log/payments.log');

    /* Payments results */
    define('PP_TX_OK', 1);
    define('PP_TX_FAIL', 2);
    define('PP_TX_REVERSE', 3);
    define('PP_TX_PENDING', 4);
    define('PP_TX_COMPLETED', 5);

    /* export types */
    define('FILE_FORMAT_CSV', 1);
    define('FILE_FORMAT_XLS', 2);

    /* openssl path */
    define('PATH_OPENSSL', '/usr/bin/openssl');

    /* path to keytool binary from Java distribution */
    define('PATH_KEYTOOL', '/usr/local/bin/keytool');

    /* path to java binary */
    define('PATH_JAVA', '/usr/local/bin/java');

    /* path to RRD-tool stuff */
    define('RRD_EXE', '/usr/local/bin/rrdtool');

    define('PATH_CLUSTER_CONF', '/mnt/envconf/env%s/cluster.conf');
    define('PATH_DISPATCHER_LIST', '/mnt/envconf/env%s/dispatcher.list');

    /* database bouncer */
    define('DB_BASE_PORT', 5480);
    define('DB_BASE_PORT_SHIFT', 20);

    /* XMLRPC server */
    define('XMLRPC_BASE_PORT', 38500);
    define('XMLRPC_BASE_PORT_SHIFT', 10);

    /* e-mail templates */
    define('PATH_EMAIL_TEMPLATES', '/home/ssp/templates/');

    /* batch size to send requests to balanced */
    define('BALANCED_BATCH_SIZE', 10000);       // 10k
?>
