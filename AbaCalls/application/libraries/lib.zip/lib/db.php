<?php

// Copyright (c) 2003-2005 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

require_once 'MDB2.php';

class DB_Wrapper {
    private $dsn;
    private $debug;

    public $mdb2;
    private $sth;
    private $res;
    private $cursor;
    public $affected_rows;

    function __construct($dsn) {
        $this->dsn = $dsn;
        $this->debug = false;

        $this->sth = NULL;
        $this->res = NULL;
        $this->cursor = NULL;
        $this->affected_rows = 0;

        $this->mdb2 = MDB2::connect($dsn);
        if (MDB2::isError($this->mdb2)) {
            error_log("Unable to connect to DB: " . $this->mdb2->getMessage());
            $this->mdb2 = NULL;
            return;
        }

        $this->mdb2->setOption('portability', MDB2_PORTABILITY_ALL ^ MDB2_PORTABILITY_EMPTY_TO_NULL);
        $this->mdb2->setOption('debug', 1);
        $this->mdb2->setOption('emulate_prepared', TRUE);
        $this->mdb2->setOption('seqname_format', '%s');
        $this->mdb2->setOption('log_line_break', '^^^___^^^');
    }

    function __destruct() {
        $this->affected_rows = 0;
        $this->free_res();
        $this->free_sth();
        $this->disconnect();
    }

    public function is_connected() {
        return MDB2::isConnection($this->mdb2);
    }

    private function disconnect() {
        if ($this->mdb2 !== NULL) {
            $this->mdb2->disconnect();
            $this->mdb2 = NULL;
        }
    }

    private function free_sth() {
        if ($this->sth !== NULL) {
            $this->sth->free();
            $this->sth = NULL;
        }
    }

    private function free_res() {
        if ($this->res !== NULL) {
            $this->res->free();
            $this->res = NULL;
        }
    }

    public function setDebug($debug = true) {
        $this->debug = $debug;
    }

    public function prepare($sql) {
        $this->free_sth();

        $flag = MDB2_PREPARE_MANIP;
        if (preg_match('/^[\s\(]*(SELECT|FETCH|WITH\s+RECURSIVE)\s+/i', $sql)) {
            $flag = MDB2_PREPARE_RESULT;
        };

        $sth = $this->mdb2->prepare($sql, NULL, $flag);
        if (MDB2::isError($sth)) {
            error_log('Unable to prepare query: ' . $sql);

            error_log(trim($sth->getMessage()));
            foreach (explode("\n", rtrim($sth->getUserinfo(), "\n")) as $m) {
                error_log($m);
            }
            error_log("Backtrace:");
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }

            return false;
        }

        $this->sth = $sth;
        return true;
    }

    public function exec($params) {
        $this->free_res();
        $this->affected_rows = 0;

        if ($this->sth === NULL) {
            error_log("There is no prepared SQL-statement.");
            error_log("Backtrace:");
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }

            return false;
        }

        $res = $this->sth->execute($params);

        if ($this->debug) {
            print "<pre>\n";
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                print $m . "\n";
            }
            print "</pre><hr/>\n";
        }

        if (MDB2::isError($res)) {
            error_log('SQL backtrace:');
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                error_log($m);
            }
            error_log(trim($res->getMessage()));
            foreach (explode("\n", rtrim($res->getUserinfo(), "\n")) as $m) {
                error_log($m);
            }
            error_log('Backtrace:');
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }
            $this->mdb2->debug_output = '';

            return false;
        }
        $this->mdb2->debug_output = '';

        if ($this->sth->is_manip) {
            $this->affected_rows = $res;
            $this->res = NULL;
        } else {
            $this->affected_rows = $res->numRows();
            $this->res = $res;
        }

        return true;
    }

    public function prepNexec($sql, $params = NULL) {
        if ($this->prepare($sql)) {
            return $this->exec($params);
        }

        return false;
    }

    public function getAll($sql, $params = NULL) {
        if ($this->prepNexec($sql, $params)) {
            $res = $this->res->fetchAll(MDB2_FETCHMODE_ASSOC);

            $this->free_res();
            $this->free_sth();

            return $res;
        }

        return false;
    }

    public function getAssociatedArray($sql, $params = NULL) {
        if ($this->prepNexec($sql, $params)) {
            $res = $this->res->fetchRow(MDB2_FETCHMODE_ASSOC, 0);

            $this->affected_rows = is_array($res) ? 1 : 0;

            $this->free_res();
            $this->free_sth();

            return $res;
        }

        return false;
    }

    public function getRow($sql, $params = NULL) {
        if ($this->prepNexec($sql, $params)) {
            $res = $this->res->fetchRow(MDB2_FETCHMODE_ORDERED, 0);

            $this->affected_rows = is_array($res) ? 1 : 0;

            $this->free_res();
            $this->free_sth();

            return $res;
        }

        return false;
    }

    public function getCol($sql, $params = NULL, $col_num = 0) {
        if ($this->prepNexec($sql, $params)) {
            $res = $this->res->fetchCol($col_num);

            $this->free_res();
            $this->free_sth();

            return $res;
        }

        return false;
    }

    public function getValue($sql, $params = NULL) {
        if ($this->prepNexec($sql, $params)) {
            $res = $this->res->fetchRow(MDB2_FETCHMODE_ORDERED, 0);

            $this->affected_rows = is_array($res) ? 1 : 0;

            $this->free_res();
            $this->free_sth();

            return $res[0];
        }

        return false;
    }

    public function cursor($cursor, $sql, $params = NULL) {
        $this->cursor = $cursor;

        $res = $this->prepNexec("DECLARE $cursor CURSOR FOR $sql", $params);
        if (!$res) {
            return false;
        }

        return true;
    }

    public function closeCursor() {
        if ($this->cursor !== NULL) {
            $this->prepNexec("CLOSE " . $this->cursor);
            $this->cursor = NULL;
        }
    }

    public function doFetch($direction = 'NEXT', $only_first_row = TRUE) {
        $this->free_res();
        $this->affected_rows = 0;

        if ($this->cursor === NULL) {
            return false;
        }

        $res = $this->mdb2->query("FETCH $direction FROM " . $this->cursor);

        if ($this->debug) {
            print "<pre>\n";
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                print $m . "\n";
            }
            print "</pre><hr/>\n";
        }

        if (MDB2::isError($res)) {
            error_log('SQL backtrace:');
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                error_log($m);
            }
            error_log(trim($res->getMessage()));
            foreach (explode("\n", rtrim($res->getUserinfo(), "\n")) as $m) {
                error_log($m);
            }
            error_log('Backtrace:');
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }
            $this->mdb2->debug_output = '';

            $this->closeCursor();

            return false;
        }
        $this->mdb2->debug_output = '';

        $this->res = $res;

        if ($only_first_row) {
            $res = $this->res->fetchRow(MDB2_FETCHMODE_ASSOC);
        } else {
            $res = $this->res->fetchAll(MDB2_FETCHMODE_ASSOC);
        }

        $this->affected_rows = $this->res->numRows();

        return $res;
    }

    public function nextID($seq) {
        $res = $this->mdb2->nextID($seq, false);

        if (MDB2::isError($res)) {
            error_log('SQL backtrace:');
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                error_log($m);
            }
            error_log(trim($res->getMessage()));
            foreach (explode("\n", rtrim($res->getUserinfo(), "\n")) as $m) {
                error_log($m);
            }
            error_log('Backtrace:');
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }
            $this->mdb2->debug_output = '';

            return false;
        }

        return $res;
    }

    public function currID($seq) {
        $res = $this->mdb2->currID($seq);

        if (MDB2::isError($res)) {
            error_log('SQL backtrace:');
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                error_log($m);
            }
            error_log(trim($res->getMessage()));
            foreach (explode("\n", rtrim($res->getUserinfo(), "\n")) as $m) {
                error_log($m);
            }
            error_log('Backtrace:');
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }
            $this->mdb2->debug_output = '';

            return false;
        }

        return $res;
    }

    public function begin() {
        $res = $this->mdb2->beginTransaction();

        if (MDB2::isError($res)) {
            error_log('SQL backtrace:');
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                error_log($m);
            }
            error_log(trim($res->getMessage()));
            foreach (explode("\n", rtrim($res->getUserinfo(), "\n")) as $m) {
                error_log($m);
            }
            error_log('Backtrace:');
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }
            $this->mdb2->debug_output = '';

            return false;
        }

        return true;
    }

    public function rollback() {
        $res = $this->mdb2->rollback();

        if (MDB2::isError($res)) {
            error_log('SQL backtrace:');
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                error_log($m);
            }
            error_log(trim($res->getMessage()));
            foreach (explode("\n", rtrim($res->getUserinfo(), "\n")) as $m) {
                error_log($m);
            }
            error_log('Backtrace:');
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }
            $this->mdb2->debug_output = '';

            return false;
        }

        return true;
    }

    public function commit() {
        $res = $this->mdb2->commit();

        if (MDB2::isError($res)) {
            error_log('SQL backtrace:');
            foreach (explode('^^^___^^^', rtrim($this->mdb2->getDebugOutput(), '^^^___^^^')) as $m) {
                error_log($m);
            }
            error_log(trim($res->getMessage()));
            foreach (explode("\n", rtrim($res->getUserinfo(), "\n")) as $m) {
                error_log($m);
            }
            error_log('Backtrace:');
            foreach (debug_backtrace() as $bt) {
                error_log('from ' . $bt['file'] . ':' . $bt['line'] . ' in function ' . $bt['function']);
            }
            $this->mdb2->debug_output = '';

            return false;
        }

        return true;
    }
}
?>
