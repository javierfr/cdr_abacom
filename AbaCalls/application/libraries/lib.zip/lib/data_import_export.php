<?php

// Copyright (c) 2018 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.

require_once 'lib/vendor/autoload.php';

require_once 'lib/bdb.php';

use League\Flysystem\Adapter\Local;
use League\Flysystem\Filesystem;
use Cache\Adapter\Filesystem\FilesystemCachePool;

use Cache\Bridge\SimpleCache\SimpleCacheBridge;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Settings;

use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

define('DATA_EXPORT_OUTPUT_USER', 1);           /* send output to user (default) */
define('DATA_EXPORT_OUTPUT_LOCAL', 2);          /* save output as local file */

define('CSV_LINE_SEPARATOR', "\r\n");

/*
 * limit number of rows as a big XLSX file consumes too much disk space
 * define('DATA_EXPORT_XLSX_MAX_ROWS_PER_FILE', 1048576);
 */
define('DATA_EXPORT_XLSX_MAX_ROWS_PER_FILE', 100001);

class data_import
{
    var $filename;      /* name of the imported file */
    var $callback;      /* callback function */
    var $format = NULL;
    var $col_types;

    var $error;         /* some error has been detected */
    var $error_msg;     /* the error description */

    /* constructor */
    function __construct($filename, $callback = NULL, $callback_args = NULL)
    {
        if (array_key_exists($filename, $_FILES)) {
            $this->setFilename($_FILES[$filename]['tmp_name']);
        } else {
            $this->setFilename($filename);
        }

        $this->col_types = Array();

        if ($callback !== NULL) {
            $this->setCallback($callback, $callback_args);
        }
    }

    function setFilename($filename)
    {
        $this->filename = str_replace(Array(':', ' '), Array('_', '_'), $filename);
    }

    function setCallback($callback, $callback_args = NULL)
    {
        if (!function_exists($callback)) {
            $msg = sprintf("Unable to set callback: function '%s' does not exist", $callback);
            throw new Exception($msg);
        }

        $this->callback = $callback;
        if ($callback_args !== NULL) {
            $this->callback_args = $callback_args;
        }
    }

    function detect_format()
    {
        try {
            $inputFileType = IOFactory::identify($this->filename);
            if ($inputFileType == 'Xlsx') {
                $this->reader = new excel_reader($this->filename);
                $this->format = FILE_FORMAT_XLS;
            } elseif ($inputFileType == 'Csv') {
                $this->reader = new csv_reader($this->filename);
                $this->format = FILE_FORMAT_CSV;
            } else {
                throw new Exception($inputFileType . ' format is not supported');
            }

            $this->reader->setParent($this);
        } catch (Exception $e) {
            $this->error = TRUE;
            $this->error_msg = _('Unable to recognize file format.');
            error_log('Unable to recognize file format: ' . $e->getMessage());
        }
    }

    function import_row()
    {
        if (!$this->error) {
            try {
                return $this->reader->read();
            } catch (Exception $e) {
                $this->error = TRUE;
                $this->error_msg = $e->getMessage();
                error_log($this->error_msg);

                return FALSE;
            }
        }
        /* do not process file when an error is detected */
        return FALSE;
    }

    /* import data */
    function import()
    {
        $failed_count = 0;
        $this->detect_format();

        if ($this->format == FILE_FORMAT_XLS) {
            /* cache is not used when read the XLSX file
             *
             * [> enable cache <]
             * $cache = \PhpOffice\PhpSpreadsheet\Settings::getCache();
             * $cacheType = get_class($cache);
             * if ($cacheType != 'Sippy\Cache\BDB') {
             *     $simpleCache = new \Sippy\Cache\BDB();
             *     \PhpOffice\PhpSpreadsheet\Settings::setCache($simpleCache);
             * }
             */
        }

        if (!$this->error) {
            while (($row = $this->import_row()) !== FALSE) {
                if (!call_user_func($this->callback, $row)) {
                    $failed_count++;
                }
            }
            $this->reader->close();
        }

        return $failed_count;
    }

    function getProgress()
    {
        return $this->reader->getProgress();
    }
}

class csv_reader
{
    function __construct($filename)
    {
        $this->input_fd = fopen($filename, 'r');

        $fstat = fstat($this->input_fd);
        $this->filesize = $fstat['size'];

        fgetcsv($this->input_fd, 8192); /* Skip first line */
    }

    function read()
    {
        if (($row = fgetcsv($this->input_fd, 8192)) === FALSE) {
            if ($this->getProgress() != 1) {
                throw new Exception("Unable to parse input file.");
            }
            return FALSE;
        }

        $c = count($row);
        for ($i = 0; $i < $c; $i++)
            $row[$i] = preg_replace('/^="(.*)"$/', '$1', $row[$i]);

        return $row;
    }

    function close()
    {
        fclose($this->input_fd);
    }

    function setParent(&$parent)
    {
        $this->parent = $parent;
    }

    function getProgress()
    {
        return ftell($this->input_fd) / $this->filesize;
    }

};

class excel_reader
{
    function __construct($filename)
    {
        $this->reader = IOFactory::createReader('Xlsx');
        $this->reader->setReadDataOnly(TRUE);

        $this->spreadsheet = $this->reader->load($filename);
        $this->worksheet = $this->spreadsheet->setActiveSheetIndex(0);

        $crd = $this->worksheet->getHighestRowAndColumn();
        $this->num_rows = $crd['row'];
        $this->num_cols = Coordinate::columnIndexFromString($crd['column']);

        $this->current_row = 2;
    }

    function read()
    {
        if ($this->current_row > $this->num_rows) {
            return FALSE;
        }

        $row = array();
        for ($j = 1; $j <= $this->num_cols; $j++) {
            $raw = (string) $this->worksheet->getCellByColumnAndRow($j, $this->current_row)
                                            ->getCalculatedValue();
            if (array_key_exists($j - 1, $this->parent->col_types)) {
                if ($this->parent->col_types[$j - 1] == 'date') {
                    $raw = $this->date_from_excel($raw);
                }
            }
            $row[] = $raw;
        }
        $this->current_row++;

        return $row;
    }

    function close()
    {
        $this->worksheet = NULL;
        unset($this->spreadsheet);
        $this->spreadsheet = NULL;
    }

    function setParent(&$parent)
    {
        $this->parent = $parent;
    }

    /* convert from Excel date */
    function date_from_excel($val) {
        if (!is_numeric($val)) {
            return $val;
        }
        return gmdate('Y-m-d H:i:s', round($val * 86400 - 86400 * 25569));
    }

    function getProgress()
    {
        return $this->current_row / $this->num_rows;
    }
};

class data_export
{
    var $format;        /* export format */

    var $output;        /* where to do output */
    var $split_data;    /* split the data to many files, applied only for DATA_EXPORT_OUTPUT_LOCAL output */
    var $filename;      /* name of the exported file */
    var $basedir;       /* path to directory for local file output */

    var $col_names;     /* array of columns names */
    var $col_types;     /* array of columns types */

    var $format_date;   /* date type format */

    var $callback;      /* callback function */
    var $callback_args; /* callback function arguments */

    var $finalize_callback;      /* finalize callback function */
    var $finalize_callback_args; /* finalize callback function arguments */

    var $user_data_path;        /* path to user supplied data */
    var $user_data_fh;          /* filehandler for user supplied data */

    var $max_rows_per_file;     /* only for XLSX format */

    /* constructor */
    function __construct($format = NULL)
    {
        $this->format = empty($format) ? FILE_FORMAT_XLS : $format;

        if ($this->format == FILE_FORMAT_XLS) {
            /* enable cache */
            $cache = \PhpOffice\PhpSpreadsheet\Settings::getCache();
            $cacheType = get_class($cache);
            if ($cacheType != 'Sippy\Cache\BDB') {
                $simpleCache = new \Sippy\Cache\BDB();
                \PhpOffice\PhpSpreadsheet\Settings::setCache($simpleCache);
            }

            $this->writer = new excel_writer();
        } else {
            $this->writer = new csv_writer();
        }

        $this->writer->setParent($this);

        $this->output = DATA_EXPORT_OUTPUT_USER;
        $this->split_data = FALSE;
        $this->basedir = create_temp_directory();
        $this->filename = 'report';

        $this->col_names = Array();
        $this->col_types = Array();

        $this->format_date = 'YYYY-MM-DD HH:MM:SS';

        $this->callback = NULL;
        $this->callback_args = Array();

        $this->finalize_callback = NULL;
        $this->finalize_callback_args = Array();

        $this->user_data_path = $this->basedir . '/' . 'user.data';
        $this->user_fh = NULL;

        $this->max_rows_per_file = DATA_EXPORT_XLSX_MAX_ROWS_PER_FILE;
    }

    function __destruct()
    {
        if ($this->user_fh !== NULL) {
            fclose($this->user_fh);
        }
        rmdir_recurse($this->basedir);
    }

    function setFilename($filename)
    {
        $this->filename = str_replace(Array(':', ' '), Array('_', '_'), $filename);
    }

    function setCallback($callback, $callback_args = NULL)
    {
        if (!function_exists($callback)) {
            $msg = sprintf("Unable to set callback: function '%s' does not exist", $callback);
            throw new Exception($msg);
        }

        $this->callback = $callback;
        if ($callback_args !== NULL) {
            $this->callback_args = $callback_args;
        }
    }

    function setFinalizeCallback($callback, $callback_args = NULL)
    {
        if (!function_exists($callback)) {
            $msg = sprintf("Unable to set finalize callback: function '%s' does not exist", $callback);
            throw new Exception($msg);
        }

        $this->finalize_callback = $callback;
        if ($callback_args !== NULL) {
            $this->finalize_callback_args = $callback_args;
        }
    }

    function setMeraMode($val)
    {
        try {
            $this->writer->setMeraMode($val);
        } catch (Exception $e) {
            // ignore any error
            error_log("unable to setMeraMode(): " . $e->getMessage());
        }
    }

    function start($filename = NULL)
    {
        $this->filename = empty($filename) ? $this->filename : $filename;
        $this->current_filename = $this->filename;
        $this->num_files = 1;

        $this->rows = 1;
        $this->writer->create_header($this->current_filename);
    }

    function end()
    {
        $this->writer->close();
    }

    function export($filename = NULL)
    {
        $this->start($filename);

        while ($row = call_user_func_array($this->callback, $this->callback_args)) {
            $this->export_row($row);
        }

        if (is_callable($this->finalize_callback)) {
            call_user_func_array($this->finalize_callback, $this->finalize_callback_args);
        }

        $this->end();
    }

    function export_row($row)
    {
        $this->rows++;
        $this->writer->write($row);

        if ($this->output == DATA_EXPORT_OUTPUT_LOCAL &&
            $this->split_data && $this->rows >= $this->max_rows_per_file)
        {
            $this->writer->close();
            $this->current_filename = $this->filename . '_(Part_' . ++$this->num_files . ')';

            /* reset rows counter */
            $this->rows = 1;
            $this->writer->create_header($this->current_filename);
        }
    }

    function createUserDataFile() {
        $this->user_fh = fopen($this->user_data_path, 'w+');
    }

    function writeUserData($data, $termination = "\n") {
        fwrite($this->user_fh, $data . $termination);
    }

    function rewindUserDataFile() {
        rewind($this->user_fh);
    }

    function readLineFromUserDataFile() {
        return fgets($this->user_fh);
    }

    function send_to_browser() {
        if (file_exists($this->user_data_path)) {
            unlink($this->user_data_path);
        }

        /* archive files if needed */
        $send_arch = FALSE;

        $basedir = rtrim($this->basedir, '/') . '/';
        $handle = opendir($basedir);

        $files = Array();
        for (; false !== ($file = readdir($handle)); ) {
            $fullpath = $basedir . $file;
            if ($file != "." && $file != ".." && is_file($fullpath)) {
                $files[] = Array('name' => $file, 'path' => $fullpath);
            }
        }

        closedir($handle);

        if (count($files) == 0) {

            /* nothing to send */
            return;

        } elseif (count($files) == 1) {

            $file_to_send = $files[0]['path'];

        } elseif (count($files) > 1) {

            $arch_name = $this->filename . '.zip';

            $arch = new ZipArchive();
            $arch->open($basedir . $arch_name, ZipArchive::CREATE | ZipArchive::OVERWRITE);

            foreach ($files as $file) {
                $arch->addFile($file['path'], $file['name']);
            }

            $arch->close();

            foreach ($files as $file) {
                @unlink($file['path']);
            }

            $send_arch = TRUE;
            $file_to_send = $basedir . $arch_name;
        }

        /* send the file */
        if ($send_arch) {
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $this->filename . '.zip"');
        } elseif ($this->format == FILE_FORMAT_XLS) {
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $this->filename . '.xlsx"');
        } elseif ($this->format == FILE_FORMAT_CSV) {
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment; filename="' . $this->filename . '.csv"');
        }

        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_to_send));

        readfile($file_to_send);
    }

    function setMaxRowsPerFile($value) {
        $this->max_rows_per_file = $value;
    }
}

class excel_writer
{
    function create_header($filename)
    {
        \PhpOffice\PhpSpreadsheet\Settings::getCache()
            ->clear();
        $this->spreadsheet = new Spreadsheet();
        $this->worksheet = $this->spreadsheet->setActiveSheetIndex(0);
        $this->worksheet->setTitle(substr($filename, 0, 31));

        $c = 1;

        /* Header row */
        foreach($this->parent->col_names as $col_name) {
            $this->worksheet->setCellValueExplicitByColumnAndRow($c++, $this->parent->rows, $col_name, DataType::TYPE_STRING);
        }

        if ($this->parent->output == DATA_EXPORT_OUTPUT_USER) {
            /* sending HTTP headers */
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Pragma: public');
        }
    }

    function write($row)
    {
        $c = 1;

        if (array_key_exists('custom_row', $row)) {
            array_shift($row);
            foreach($row as $col) {
                $this->worksheet->setCellValueExplicitByColumnAndRow($c++, $this->parent->rows, $col, DataType::TYPE_STRING);
            }
        } else {
            foreach($row as $col) {
                switch(strtoupper($this->parent->col_types[$c - 1])) {
                    case 'N':                               /* number */
                        $this->worksheet->setCellValueExplicitByColumnAndRow($c++, $this->parent->rows, $col, DataType::TYPE_NUMERIC);
                        break;

                    case 'DN':                              /* date or empty string */
                        if (strlen($col) == 0) {
                            $this->worksheet->setCellValueExplicitByColumnAndRow($c, $this->parent->rows, $col, DataType::TYPE_NULL);
                            $this->worksheet->getStyleByColumnAndRow($c++, $this->parent->rows)
                                            ->getNumberFormat()
                                            ->setFormatCode($this->parent->format_date);
                            break;
                        }
                        /* proceed as regular date */
                    case 'D':                               /* date */
                        # convert into Excel date
                        $tz = new DateTimeZone(date_default_timezone_get());
                        $now = new DateTime("now", $tz);
                        $col = strtotime($col);

                        $isNowDST = date('I');
                        $isDateDST = date('I', $col);
                        $dstOffset = 0;
                        if ($isNowDST && !$isDateDST) {
                            $dstOffset = -3600;
                        } elseif (!$isNowDST && $isDateDST) {
                            $dstOffset = 3600;
                        }

                        $col = $col + timezone_offset_get($tz, $now) + $dstOffset;
                        $col = ($col + 86400 * 25569) / 86400;
                        $this->worksheet->setCellValueExplicitByColumnAndRow($c, $this->parent->rows, $col, DataType::TYPE_NUMERIC);
                        $this->worksheet->getStyleByColumnAndRow($c++, $this->parent->rows)
                                        ->getNumberFormat()
                                        ->setFormatCode($this->parent->format_date);
                        break;

                    case 'S':                               /* string. use 'S' as default format */
                    default:
                        $this->worksheet->setCellValueExplicitByColumnAndRow($c++, $this->parent->rows, $col, DataType::TYPE_STRING);
                        break;
                }
            }
        }
    }

    function close()
    {
        $writer = IOFactory::createWriter($this->spreadsheet, "Xlsx");
        if ($this->parent->output == DATA_EXPORT_OUTPUT_USER) {
            $writer->save('php://output');
        } else {
            $writer->save($this->parent->basedir . '/' . $this->parent->current_filename . '.xlsx');
        }
    }

    function setParent(&$parent)
    {
        $this->parent = $parent;
    }
};

class csv_writer
{
    var $mera_mode;         /* mera compatible output */

    function __construct()
    {
        $this->mera_mode = FALSE;
    }

    function create_header($filename)
    {
        $this->fh = NULL;
        if ($this->parent->output == DATA_EXPORT_OUTPUT_LOCAL) {
            $this->fh = fopen($this->parent->basedir . '/' . $filename . '.csv', 'w');
        } else {
            /* sending HTTP headers */
            header("Content-type: text/csv");
            header("Content-Disposition: attachement; filename=\"" . $filename . ".csv\"");
            header("Expires: 0");
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header("Pragma: public");
        }

        if (!$this->mera_mode) {
            /* Header row */
            $r = array();
            foreach($this->parent->col_names as $col_name) {
                array_push($r, $this->quote_string($col_name));
            }

            $s = implode(",", $r) . CSV_LINE_SEPARATOR;
            if ($this->parent->output == DATA_EXPORT_OUTPUT_LOCAL) {
                fwrite($this->fh, $s);
            } else {
                print $s;
            }
        }
    }

    function write($row)
    {
        $c = 0;
        $r = array();

        if (array_key_exists('custom_row', $row)) {
            array_shift($row);
            foreach($row as $col) {
                array_push($r, $this->quote_string($col));
            }
        } else {
            foreach($row as $col) {
                switch(strtoupper($this->parent->col_types[$c++])) {
                    case 'N':                               /* number */
                        array_push($r, $col);
                        break;

                    case 'S':                               /* string. use 'S' as default format */
                    default:
                        array_push($r, $this->quote_string($col));
                        break;
                }
            }
        }

        $s = implode(",", $r) . CSV_LINE_SEPARATOR;

        if ($this->parent->output == DATA_EXPORT_OUTPUT_LOCAL) {
            fwrite($this->fh, $s);
        } else {
            print $s;
        }
    }

    function close()
    {
        if ($this->parent->output == DATA_EXPORT_OUTPUT_LOCAL) {
            fclose($this->fh);
        }
    }

    function quote_string($val = NULL)
    {
        if ($this->mera_mode) {
            return $val;
        }
        if (preg_match('/^0[0-9]+$/', $val))
            return '="' . $val . '"';

        $val = str_replace('"', '""', $val);
        return '"' . $val . '"';
    }

    function setMeraMode($val)
    {
        $this->mera_mode = $val;
    }

    function setParent(&$parent)
    {
        $this->parent = $parent;
    }
};

class data_import_export
{
    var $exporter = NULL;
    var $importer = NULL;
    var $import_callback = NULL;
    var $import_callback_args = Array();
    var $import_finalize_callback = NULL;
    var $import_finalize_callback_args = Array();
    var $import_progress_callback = NULL;
    var $import_progress_callback_args = Array();
    var $export_callback = NULL;
    var $export_callback_args = Array();
    var $export_format = NULL;
    var $export_filename = NULL;
    var $export_col_names = NULL;
    var $export_col_types = NULL;
    var $export_to_file = FALSE;
    var $exported_rows = 0;

    var $error;                     /* some error has been detected */
    var $error_msg;                 /* the error description */

    function __construct($filename = NULL)
    {
        $this->importer = new data_import($filename);

        /* share errors with data_import() instance */
        $this->error =& $this->importer->error;
        $this->error_msg =& $this->importer->error_msg;;
    }

    function __destruct()
    {
        /* do clean up here */
        // if (is_object($this->exporter) && $this->export_to_file) {
        //     rmdir_recurse($this->exporter->basedir);
        // }
    }

    function setExportToFile($val)
    {
        $this->export_to_file = $val;
    }

    function createExporter()
    {
        $this->exporter = new data_export($this->export_format);
        $this->exporter->setFilename($this->export_filename);
        $this->exporter->col_names = $this->export_col_names;
        $this->exporter->col_types = $this->export_col_types;

        if ($this->export_to_file) {
            // $basedir = create_temp_directory();
            $this->exporter->output = DATA_EXPORT_OUTPUT_LOCAL;
            // $this->exporter->basedir = $basedir;
            $this->exporter->split_data = TRUE;
        }
    }

    function stopExporter()
    {
        $this->exporter->end();
    }

    function setImportFilename($filename)
    {
        $this->importer->setFilename($filename);
    }

    function setExportFilename($filename)
    {
        $this->export_filename = $filename;
    }

    function setImportCallback($callback, $callback_args = NULL)
    {
        if (function_exists($callback)) {
            $this->import_callback = $callback;
        }
        if ($callback_args !== NULL) {
            $this->import_callback_args = $callback_args;
        }
    }

    function setImportFinalizeCallback($callback, $callback_args = NULL)
    {
        if (function_exists($callback)) {
            $this->import_finalize_callback = $callback;
        }
        if ($callback_args !== NULL) {
            $this->import_finalize_callback_args = $callback_args;
        }
    }

    function setImportProgressCallback($callback, $callback_args = NULL)
    {
        if (function_exists($callback)) {
            $this->import_progress_callback = $callback;
        }
        if ($callback_args !== NULL) {
            $this->import_progress_callback_args = $callback_args;
        }
    }

    function setExportCallback($callback, $callback_args = NULL)
    {
        if (function_exists($callback)) {
            $this->export_callback = $callback;
        }
        if ($callback_args !== NULL) {
            $this->export_callback_args = $callback_args;
        }
    }

    function setExportColNames($col_names)
    {
        $this->export_col_names = $col_names;
    }

    function setExportColTypes($col_types)
    {
        $this->export_col_types = $col_types;
    }

    function setImportColType($idx, $col_type)
    {
        $this->importer->col_types[$idx] = $col_type;
    }

    function run()
    {
        $imported_rows = 0;
        $this->exported_rows = 0;
        $exporter_started = FALSE;

        $this->importer->detect_format();

        if ($this->importer->format == FILE_FORMAT_XLS) {
            /* cache is not used when read the XLSX file
             *
             * [> enable cache <]
             * $cache = \PhpOffice\PhpSpreadsheet\Settings::getCache();
             * $cacheType = get_class($cache);
             * if ($cacheType != 'Sippy\Cache\BDB') {
             *     $simpleCache = new \Sippy\Cache\BDB();
             *     \PhpOffice\PhpSpreadsheet\Settings::setCache($simpleCache);
             * }
             */
        }

        if (!$this->error) {
            $this->export_format = $this->importer->format;
            $this->createExporter();

            while (($row = $this->importer->import_row()) !== FALSE) {
                $params = array_merge(Array($row), $this->import_callback_args);
                $ret = call_user_func_array($this->import_callback, $params);

                foreach ($ret as $row2) {
                    $params = array_merge(Array($row2), $this->export_callback_args);
                    $ret2 = call_user_func_array($this->export_callback, $params);
                    if ($ret2 !== NULL) {
                        if (!$exporter_started) {
                            $exporter_started = TRUE;
                            $this->exporter->start();
                        }
                        $this->exporter->export_row($ret2);
                        ++$this->exported_rows;
                    }
                }

                /* update progress every 1000 rows */
                if (++$imported_rows % 1000 == 0 && is_callable($this->import_progress_callback)) {
                    $params = array_merge(Array($this->getProgress()), $this->import_progress_callback_args);
                    call_user_func_array($this->import_progress_callback, $params);
                }
            }

            if ($this->import_finalize_callback !== NULL) {
                $params = $this->import_finalize_callback_args;
                $ret = call_user_func_array($this->import_finalize_callback, $params);

                foreach ($ret as $row2) {
                    $params = array_merge(Array($row2), $this->export_callback_args);
                    $ret2 = call_user_func_array($this->export_callback, $params);
                    if ($ret2 !== NULL) {
                        if (!$exporter_started) {
                            $exporter_started = TRUE;
                            $this->exporter->start();
                        }
                        $this->exporter->export_row($ret2);
                        ++$this->exported_rows;
                    }
                }
            }

            if ($exporter_started) {
                $this->stopExporter();
            }
        }

        return $this->exported_rows;
    }

    function getProgress()
    {
        return $this->importer->getProgress();
    }
};

?>
