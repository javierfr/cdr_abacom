<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id php,v 1.1 2010/01/29 20:10:02 geka Exp $

class Conference {

    public $i_conference;
    public $i_customer;
    public $i_account;
    public $confno;
    public $start_date;
    public $start_time;
    public $end_time;
    public $subject;
    public $participants;

    private $_start_time;
    private $_expire;
    private $_fault;

    function __construct($i_customer, $i_account, $i_conference = NULL) {
        
        $this->i_customer = $i_customer;
        $this->i_account = $i_account;
        $this->i_conference = $i_conference;
        $this->confno = '';
        $this->start_date = date('d-m-Y', strtotime('+1 hour'));
        $this->start_time = date('H:i', strtotime('+1 hour'));
        $this->end_time = date('H:i', strtotime('+3 hour'));
        $this->subject = '';
        $this->participants = Array();

	if ($this->i_conference !== NULL) {
            $this->getEntry($this->i_conference);
        }

        $this->_fault = FALSE;
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_conference) {
        global $db;

        $sql = "SELECT c.i_conference, c.confno,
                       to_char(c.start_time, 'DD-MM-YYYY') AS start_date, 
                       to_char(c.start_time, 'HH24:MI') AS start_time, 
                       to_char(c.expire, 'HH24:MI') AS end_time , 
                       c.expire, c.subject
                  FROM conferences c
                 WHERE c.i_account = ? AND c.i_conference = ? AND c.expire > NOW()
                 LIMIT 1";

        $entry = $db->getAssociatedArray($sql, Array($this->i_account, $i_conference));

	if ($db->affected_rows != 1) {
	    throw new Exception("No such Id.");
	}

        $this->i_conference = $entry['i_conference'];
        $this->confno = $entry['confno'];
        $this->start_date = $entry['start_date'];
        $this->start_time = $entry['start_time'];
        $this->end_time = $entry['end_time'];
        $this->subject = $entry['subject'];
    }

    public function initFromRequest($par) {
        $this->start_time = $par['start_time'];
        $this->expire = $par['expire'];
        $this->subject = $par['subject'];
        $this->start_date = $par['start_date'];
        $this->start_time = $par['start_time'];
        $this->end_time = $par['end_time'];

        $this->participants = Array();
        foreach (explode(',', $par['participants']) as $p) {
            $this->participants[] = trim($p);
        }
    }

    public function getTotal() {
	global $db;

	$sql = "SELECT COUNT(*)
                  FROM conferences c
                 WHERE c.i_account = ? AND c.expire > NOW()";
        $params = Array($this->i_account);

	return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
	global $db;

        $sql = "SELECT c.i_conference, c.confno,
                       extract(EPOCH FROM c.start_time) AS start_date,
                       extract(EPOCH FROM c.expire) AS expire_date,
                       c.subject
                  FROM conferences c
                 WHERE c.i_account = ? AND c.expire > NOW()
              ORDER BY c.start_time
		 LIMIT ${rpp}
		OFFSET ${off}";
        $params = Array($this->i_account);

	$ret = $db->getAll($sql, $params);

        foreach(array_keys($ret) as $key) {
            $ret[$key]['confno'] = rtrim(chunk_split($ret[$key]['confno'], 3, '-'), '-');
	}

	return $ret;
    }

    public function validate($par) {
        if ($par['subject'] == '') {
            throw new Exception(_('"Subject" field is mandatory.'));
        }

        if ($par['start_date'] == '') {
            throw new Exception(_('"Date" field is mandatory.'));
        }

        if ($par['start_time'] == '') {
            throw new Exception(_('"Start Time" field is mandatory.'));
        }

        if ($par['end_time'] == '') {
            throw new Exception(_('"End Time" field is mandatory.'));
        }

        if (!Validator::isEmailsList($par['participants'])) {
            throw new Exception(_('"Participants" field has incorrect format. Comma-separated list of E-mails in the format username@domain is expected.'));
        }
    }

    public function prepare_pars($par) {
        $f = 'H:i:s.000 \G\M\T D M d Y';
        $this->_start_time = gmdate($f, strtotime($par['start_date'] . ' ' . $par['start_time']));

        list($sh, $sm) = explode(':', $par['start_time']);
        list($eh, $em) = explode(':', $par['end_time']);
        if ($sh * 100 + $sm >= $eh * 100 + $em) {
            $this->_expire = gmdate($f, strtotime($par['start_date'] . ' ' . $par['end_time'] . ' +1 day'));
        } else {
            $this->_expire = gmdate($f, strtotime($par['start_date'] . ' ' . $par['end_time']));
        }
    }

    public function add($par) {
        $this->setFault(TRUE);

        $this->validate($par);
        $this->prepare_pars($par);

        $params = Array(
            "i_customer" => new xmlrpcval($this->i_customer, "int"),
            "i_account" => new xmlrpcval($this->i_account, "int"),
            "start_time" => new xmlrpcval($this->_start_time, "string"),
            "expire" => new xmlrpcval($this->_expire, "string"),
            "subject" => new xmlrpcval($par['subject'], "string")
        );
        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('addConference', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->getEntry($res->val['i_conference']);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        $this->setFault(TRUE);

        $params = Array(
            "i_customer" => new xmlrpcval($this->i_customer, "int"),
            "i_account" => new xmlrpcval($this->i_account, "int"),
            "i_conference" => new xmlrpcval($this->i_conference, "int")
        );
        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('deleteConference', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->setFault(FALSE);
    }
}

?>
