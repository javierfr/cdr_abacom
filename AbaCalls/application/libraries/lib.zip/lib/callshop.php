<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Callshop {
    public $prefs;

    function __construct($prefs) {
        $this->prefs = $prefs;
    }

    function __destruct() {
        /* nothing here */
    }

    public function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('name') != '') {
            if ($this->prefs->booth_name == Callshop_Prefs::BOOTH_NAME_DESC) {
                $ret['sql'] .= ' AND a.description ' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            } else {
                $ret['sql'] .= ' AND a.username ' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            }
            $ret['params'][] = get_par('name');
        }

        return $ret;
    }

    public function getTotalBoothes() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(a.*)
                   FROM accounts a
                  WHERE a.i_customer = ?
                        {$clause['sql']}";
        $params = array_merge(Array($this->prefs->i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getBoothesList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $db->begin();

        $sql = "CREATE TEMPORARY TABLE temp_callshop_sessions (
                    i_account   BIGINT,
                    i_cs_prev   BIGINT
                )  ON COMMIT DROP";
        $db->prepNexec($sql);

        $sql = "INSERT INTO temp_callshop_sessions
                       SELECT i_account, (SELECT i_callshop_session
                                            FROM callshop_sessions
                                           WHERE callshop_sessions.i_account = accounts.i_account
                                        ORDER BY i_callshop_session DESC
                                         LIMIT 1
                                        OFFSET 1)
                         FROM accounts
                        WHERE i_customer = ?";
        $db->prepNexec($sql, Array($this->prefs->i_customer));

        if ($this->prefs->booth_name == Callshop_Prefs::BOOTH_NAME_DESC) {
            $f = 'a.description';
        } else {
            $f = 'a.username';
        }

        $sql = "SELECT a.i_account AS i_account, ${f} AS username,
                       s.i_callshop_session, a.i_balance, x.rate AS x_rate,
                       0 AS available_credit, s.stop_date NOTNULL AS is_set_stop_date,
                       CASE WHEN s.stop_date ISNULL
                           THEN s.prepaid_amount + s.credit_limit
                           ELSE 0.0 END
                           AS session_cost,
                       to_char(s.start_date, 'YYYY-MM-DD HH24:MI:SS') AS start_date,
                       CASE WHEN s.stop_date NOTNULL THEN to_char(s.stop_date, 'YYYY-MM-DD HH24:MI:SS')
                          ELSE 'now' END AS stop_date,
                       (s.i_callshop_session ISNULL OR (s.i_callshop_session NOTNULL AND s.stop_date NOTNULL)) AS stopped,
                       CASE WHEN s.stop_date ISNULL
                           THEN sp.i_callshop_session
                           ELSE s.i_callshop_session
                           END
                       AS i_callshop_session_prev,
                       CASE WHEN s.stop_date ISNULL
                           THEN sp.total_charge
                           ELSE s.total_charge
                           END
                       AS session_cost_prev,
                       CASE WHEN s.stop_date ISNULL
                           THEN to_char(sp.start_date, 'YYYY-MM-DD HH24:MI:SS')
                           ELSE to_char(s.start_date, 'YYYY-MM-DD HH24:MI:SS')
                           END
                       AS start_date_prev,
                       CASE WHEN s.stop_date ISNULL
                           THEN to_char(sp.stop_date, 'YYYY-MM-DD HH24:MI:SS')
                           ELSE to_char(s.stop_date, 'YYYY-MM-DD HH24:MI:SS')
                           END
                       AS stop_date_prev
                  FROM accounts a
             LEFT JOIN callshop_sessions s ON (a.i_callshop_session = s.i_callshop_session)
                  JOIN temp_callshop_sessions t ON (t.i_account = a.i_account)
             LEFT JOIN callshop_sessions sp ON (sp.i_callshop_session = t.i_cs_prev)
                  JOIN x_rates x ON a.i_customer = x.i_customer AND a.base_currency = x.iso_4217
                 WHERE a.i_customer = ?
                       {$clause['sql']}
              ORDER BY username
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($this->prefs->i_customer), $clause['params']);
        $boothes = $db->getAll($sql, $params);

        $db->commit();

        $i_balances = Array();
        $bi_map = Array();

        foreach ($boothes as $r) {
            $i_balances[] = new xmlrpcval($r['i_balance'], "int");
        }

        /* fetch balance */
        $params = Array("i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
                        "i_balances" => new xmlrpcval($i_balances, 'array'),
                                       );
        $bal_clnt = new Balanced_Client('getBalances', $params);
        $bal_infos = $bal_clnt->get();

        if (!$bal_infos) {
            error_log('unable to fetch balances');
            $boothes2 = Array();
            while ($a = array_shift($boothes)) {
                $a['balance'] = 'NaN';
                $a['credit_limit'] = 'NaN';
                $boothes2[] = $a;
            }

            $boothes = $boothes2;
        } else {
            /* map balance infos */
            while ($b = array_pop($bal_infos['balance_infos'])) {
                $bi_map[$b['i_balance']] = Array(
                    'balance' => $b['balance'],
                    'credit_limit' => $b['credit_limit'],
                );
            }
        }

        foreach ($boothes as &$r) {
            if (array_key_exists($r['i_balance'], $bi_map)) {
                $balance = $bi_map[$r['i_balance']]['balance'] * $r['x_rate'];
                $credit_limit = $bi_map[$r['i_balance']]['credit_limit'] * $r['x_rate'];
            }

            $r['available_credit'] = $balance + $credit_limit;
            $r['session_cost'] = $r['session_cost'] - $r['available_credit'];

            if (!$r['is_set_stop_date']) {
                $r['session_cost'] = $r['session_cost'] - $r['available_credit'];
            }
        }

        /* update calls state */
        $params = Array(new xmlrpcval(
                                Array('i_customer' => new xmlrpcval($this->prefs->i_customer, 'int'),
                                      'recursive' =>  new xmlrpcval(FALSE, 'boolean')
                            ), 'struct'));
        $msg = new xmlrpcmsg('listActiveCalls', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception($res->faultString());
        }

        
        function merge_call_state($r, $s) {
            if ($r['stopped'] == 't') {
                $r['state'] = 'STOPPED';
                $r['state_desc'] = _('Stopped');
            } else {
                $r['state'] = 'IDLE';
                $r['state_desc'] = _('Idle');
            }
            if (count($s) > 0) {
                foreach ($s as $c) {
                    if ($c['I_ENVIRONMENT'] != getenv('I_ENVIRONMENT')) {
                        continue;
                    }
                    if ($r['i_account'] == $c['I_ACCOUNT']) {
                        if ($c['CC_STATE'] == 'Connected') {
                            $r['state'] = 'CONNECTED';
                            $r['state_desc'] = _('Talking to') . ' ' . $c['CLD'] . ', ' .
                                normalize_seconds($c['DURATION']);
                        } else {
                            $r['state'] = 'DIALING';
                            $r['state_desc'] = _('Dialing') . ' ' . $c['CLD'];
                        }
                        break;
                    }
                }
            }
            return $r;
        }

        foreach ($boothes as &$booth) {
            $booth = merge_call_state($booth, $res->val);
        }

        return $boothes;
    }

    public static function startTimer($i_customer, $i_account, $prepaid_amount, $credit_limit) {
        global $db;

        $db->begin();

        if (!$db->prepNexec('LOCK callshop_sessions')) {
            $db->rollback();
            throw new Exception(_('Unable to get lock.'));
        };

        $sql = 'SELECT i_callshop_session
                  FROM callshop_sessions s
                 WHERE i_account = ? AND s.stop_date ISNULL
                 LIMIT 1';
        $db->prepNexec($sql, Array($i_account));
        if ($db->affected_rows == 1) {
            $db->rollback();
            throw new Exception(_('Timer is already started.'));
        }

        $i_callshop_session = $db->nextID('callshop_sessions_seq');

        $sql = 'INSERT INTO callshop_sessions (i_callshop_session, i_account, prepaid_amount,
                                               credit_limit)
                     VALUES (?, ?, ?, ?)';
        $params = Array($i_callshop_session, $i_account, $prepaid_amount, $credit_limit);
        $db->prepNexec($sql, $params);
        if ($db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_('Unable to start the Timer.'));
        }

        $sql = 'UPDATE accounts
                   SET i_callshop_session = ?
                 WHERE i_customer = ? AND i_account = ?';
        $params = Array($i_callshop_session, $i_customer, $i_account);

        $db->prepNexec($sql, $params);
        if ($db->affected_rows != 1) {
            $db->rollback();
            throw new Exception('No such Id.');
        }

        //
        $sql = "SELECT a.i_balance, x.rate
                  FROM accounts a
                  JOIN x_rates x ON (a.i_customer = x.i_customer AND a.base_currency = x.iso_4217)
                 WHERE a.i_customer = ? AND a.i_account = ?
                 LIMIT 1";
        $params = Array($i_customer, $i_account);
        $row = $db->getAssociatedArray($sql, $params);

        $available_credit = ($credit_limit + $prepaid_amount) / $row['rate'];

        //
        $params = Array("i_customer" => new xmlrpcval($i_customer, "int"),
                        "i_balance" => new xmlrpcval($row['i_balance'], "int"),
                        "available_credit" => new xmlrpcval($available_credit, "double"),
                       );
        $bal_clnt = new Balanced_Client('setAvailableCredit', $params);
        $ret = $bal_clnt->get();
        if (!$ret) {
            $db->rollback();
            throw new Exception('unable to set available credit: i_account = ' .
                                $i_account . ', i_balance = ' . $row['i_balance']);
        }

        // all is done
        $db->commit();
    }

    public static function stopTimer($i_customer, $i_account, $i_callshop_session) {
        global $db;

        $sql = 'SELECT to_char(start_date,\'YYYY-MM-DD HH24:MI:SS\') AS start_date
                  FROM callshop_sessions s
                  JOIN accounts a USING (i_account)
                 WHERE a.i_customer = ? AND a.i_account = ? AND
                       s.stop_date ISNULL AND s.i_callshop_session = ?
                 LIMIT 1';
        $start_date = $db->getValue($sql, Array($i_customer, $i_account, $i_callshop_session));
        if ($db->affected_rows != 1) {
            throw new Exception(_('No such Id.'));
        }

        /* drop active calls */
        $params = Array(new xmlrpcval(Array(
                            "audit_info" => new xmlrpcval(Audit_Info::get(), "struct"),

                            'i_customer' => new xmlrpcval($i_customer, 'int'),
                            'i_account' => new xmlrpcval($i_account, 'int'),
                       ), 'struct'));
        $msg = new xmlrpcmsg('disconnectAccount', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception($res->faultString());
        }

        if ($res->val['result'] != 'OK') {
            throw new Exception('Unexpected XMLRPC result: "' . $res->val['result'] . '"');
        }

        if ($res->val['count'] > 0) {
            sleep(2);
        }

        $stop_date = parse_date('now');

        CDRs_View::create('calls', $start_date, $stop_date);
        CDRs_View::create('cdrs', $start_date, $stop_date);

        $sql = 'SELECT CASE WHEN SUM(cost) ISNULL THEN 0 ELSE SUM(cost * x.rate) END
                  FROM cdrs
                  JOIN accounts a USING (i_account)
                  JOIN calls USING (i_call)
                  JOIN x_rates x ON a.i_customer = x.i_customer AND a.base_currency = x.iso_4217
                 WHERE cdrs.i_account = ? AND calls.setup_time >= ? AND calls.setup_time < ?';
        $params = Array($i_account, $start_date, $stop_date);
        $total_charge = $db->getValue($sql, $params);

        $db->begin();

        $sql = 'UPDATE callshop_sessions
                   SET total_charge = ?, stop_date = ?
                 WHERE i_callshop_session = ?';
        $params = Array($total_charge, $stop_date, $i_callshop_session);
        $db->prepNexec($sql, $params);
        if ($db->affected_rows != 1) {
            $db->rollback();
            throw new Exception('Unable to stop the Timer.');
        }

        //
        $sql = "SELECT a.i_balance
                  FROM accounts a
                 WHERE a.i_customer = ? AND a.i_account = ?
                 LIMIT 1";
        $params = Array($i_customer, $i_account);
        $row = $db->getAssociatedArray($sql, $params);

        //
        $params = Array("i_customer" => new xmlrpcval($i_customer, "int"),
                        "i_balance" => new xmlrpcval($row['i_balance'], "int"),
                       );
        $bal_clnt = new Balanced_Client('setAvailableCredit', $params);
        $ret = $bal_clnt->get();
        if (!$ret) {
            $db->rollback();
            throw new Exception('unable to set available credit: i_account = ' .
                                $i_account . ', i_balance = ' . $row['i_balance']);
        }

        // all is done
        $db->commit();
    }

    public function viewReceipt($i_account, $i_callshop_session) {
        require_once 'lib/vendor/autoload.php';

        global $db;
        global $web_session;
        global $base_c;

        if ($this->prefs->booth_name == Callshop_Prefs::BOOTH_NAME_DESC) {
            $f = 'a.description';
        } else {
            $f = 'a.username';
        }

        $sql = "SELECT to_char(s.start_date,'YYYY-MM-DD HH24:MI:SS') AS start_date,
                       to_char(s.stop_date,'YYYY-MM-DD HH24:MI:SS') AS stop_date,
                       s.total_charge,
                       to_char(now(), 'YYYY-MM-DD') AS date_now,
                       to_char(now(), 'HH24:MI') AS time_now,
                       ${f} AS booth_name, s.prepaid_amount
                  FROM callshop_sessions s
                  JOIN accounts a USING (i_account)
                 WHERE s.i_callshop_session = ? AND a.i_account = ? AND a.i_customer = ? AND
                       s.stop_date NOTNULL 
                 LIMIT 1";
        $params = Array($i_callshop_session, $i_account, $this->prefs->i_customer);
        $row = $db->getAssociatedArray($sql, $params);
        if ($db->affected_rows != 1) {
            $db->rollback();
            throw new Exception('No such Id.');
        }

        $cs_snum = $i_callshop_session;
        if ($web_session->subtype === NULL) {
            if ($_SESSION['first_name'] == '' && $_SESSION['last_name'] == '') {
                $operator_name = $_SESSION['customer_name'];
            } else {
                $operator_name = $_SESSION['first_name'] . ' ' . $_SESSION['last_name'];
            }
        } else {
            $operator_name = $_SESSION['first_name'];
        }
        $start_date = $row['start_date'];
        $stop_date = $row['stop_date'];
        $total_charge = $row['total_charge'];
        $date_now = $row['date_now'];
        $time_now = $row['time_now'];
        $booth_name = $row['booth_name'] != '' ? $row['booth_name'] : 'Account #' . $i_account ;
        $prepaid_amount = $row['prepaid_amount'];

        $decimal_digits = $db->getValue('SELECT decimal_digits
                                           FROM currencies
                                          WHERE iso_4217 = ?
                                          LIMIT 1',
                                         Array($base_c));

        $total_charge = sprintf('%0.' . $decimal_digits . 'f', $total_charge);
        $prepaid_amount = sprintf('%0.' . $decimal_digits . 'f', $prepaid_amount);
        $payment_due = sprintf('%0.' . $decimal_digits . 'f', $total_charge - $prepaid_amount);

        CDRs_View::create('calls', $start_date, $stop_date);
        CDRs_View::create('cdrs', $start_date, $stop_date);

        $sql = 'SELECT to_char(calls.setup_time, \'YYYY-MM-DD HH24:MI:SS\') AS setup_time,
                       calls.cld, cdrs.billed_duration, cdrs.cost * x.rate AS cost
                  FROM cdrs
                  JOIN accounts a USING (i_account)
                  JOIN calls USING (i_call)
                  JOIN x_rates x ON a.i_customer = x.i_customer AND a.base_currency = x.iso_4217
                 WHERE cdrs.i_account = ? AND calls.setup_time >= ? AND calls.setup_time < ?';
        $cdrs = $db->getAll($sql, Array($i_account, $start_date, $stop_date));

        if ($db->affected_rows > 0) {
            load_prefixes();

            foreach(array_keys($cdrs) as $key) {
                list($cdrs[$key]['country'], $cdrs[$key]['desc']) = get_description($cdrs[$key]['cld']);
                if ($cdrs[$key]['desc'] != '') {
                    $cdrs[$key]['country'] = $cdrs[$key]['country'] . ', ' . $cdrs[$key]['desc'];
                }
                $cdrs[$key]["billed_duration"] = normalize_seconds(round($cdrs[$key]['billed_duration']));
                $cdrs[$key]["cost"] = sprintf(get_dpf(), $cdrs[$key]['cost']);
            }
        }

        $booth_ncalls = count($cdrs);

        // create new PDF document
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

        // set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        //set margins
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

        //set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        // set font
        $pdf->SetFont('helvetica', '', 9);

        // add a page
        $pdf->AddPage();

        $html = <<<EOF
<h2 align="center"><strong>Callshop Receipt #${cs_snum}</strong></h2>
<br>
<table width="100%" border="0">
<tr>
<td align="left">Date: ${date_now} ${time_now}</td>
<td align="right">Cashier: ${operator_name}</td>
</tr>
<tr>
<td align="left">Cabin: {$booth_name}</td>
<td align="right">Number of Calls: {$booth_ncalls}</td>
</tr>
</table>
<br>
<br>
EOF;

        // output the HTML content
        $pdf->writeHTML($html, true, 0, true, 0);

        $html = <<<EOF
<table width="100%" border="1">
 <tr bgcolor="#dddddd">
  <th align="center">Date</th>
  <th align="center">Country</th>
  <th align="center">Destination Number</th>
  <th align="center">Call Duration, mm:ss</th>
  <th align="center">Call Cost, {$base_c}</th>
 </tr>
EOF;
        if (count($cdrs) == 0) {
            $html .= <<<EOF
 <tr>
  <td align="center" colspan="5">List is empty.</td>
 </tr>
EOF;
        } else {
            foreach ($cdrs as $cdr) {
            $html .= <<<EOF
 <tr>
  <td align="center">{$cdr['setup_time']}</td>
  <td>{$cdr['country']}</td>
  <td>{$cdr['cld']}</td>
  <td align="center">{$cdr['billed_duration']}</td>
  <td align="right">{$cdr['cost']}</td>
 </tr>
EOF;
            }
        }

        $html .= <<<EOF
</table>
EOF;

        $pdf->SetFont('helvetica', '', 7);
        $pdf->writeHTML($html, true, 0, true, 0);

        $html = <<<EOF
<br>
<table width="100%" border="0">

<tr>
<td></td>
<td>
  <table width="100%" border="0">
  <tr><td align="left">Initial Deposit, {$base_c}:</td><td align="right">{$prepaid_amount}</td></tr>
  </table>
</td>
</tr>

<tr>
<td></td>
<td>
  <table width="100%" border="0">
  <tr><td align="left">Total Cost, {$base_c}:</td><td align="right">{$total_charge}</td></tr>
  </table>
  <hr />
</td>
</tr>

<tr>
<td></td>
<td>
  <table width="100%" border="0">
  <tr><td align="left">Payment Due, {$base_c}:</td><td align="right">{$payment_due}</td></tr>
  </table>
</td>
</tr>

</table>
EOF;

        $pdf->SetFont('helvetica', '', 9);
        $pdf->writeHTML($html, true, 0, true, 0);

        // reset pointer to the last page
        $pdf->lastPage();

        //Close and output PDF document
        $pdf->Output('receipt_' . $cs_snum . '.pdf', 'I');

        exit();
    }
}

class Callshop_Prefs {

    const ON_START_ENTER_DEPOSIT = 0;           /* default */
    const ON_START_USE_DEFAULT_DEPOSIT = 1;

    const ON_STOP_OPEN_RECEIPT = 0;             /* default */
    const ON_STOP_DO_NOTHING = 1;

    const BOOTH_NAME_ACCOUNT = 0;               /* default */
    const BOOTH_NAME_DESC = 1;

    public $i_customer;
    public $default_credit_limit;
    public $default_prepaid_amount;
    public $on_start;
    public $on_stop;
    public $start_on_stop;
    public $booth_name;
    public $refresh_interval;

    function __construct($i_customer) {
        $this->i_customer = $i_customer;

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;

        $sql = 'SELECT c.*
                  FROM callshops c
                 WHERE c.i_customer = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($this->i_customer));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->default_credit_limit = $entry['default_credit_limit'];
        $this->default_prepaid_amount = $entry['default_prepaid_amount'];
        $this->on_start = $entry['on_start'];
        $this->on_stop = $entry['on_stop'];
        $this->start_on_stop = $entry['start_on_stop'] == 't';
        $this->booth_name = $entry['booth_name'];
        $this->refresh_interval = $entry['refresh_interval'];
    }

    public function initFromRequest($par) {
        $this->default_credit_limit = $par['default_credit_limit'];
        $this->default_prepaid_amount = $par['default_prepaid_amount'];
        $this->on_start = $par['on_start'];
        $this->on_stop = $par['on_stop'];
        $this->start_on_stop = $par['start_on_stop'] == 1 ? TRUE : FALSE;;
        $this->booth_name = $par['booth_name'];
        $this->refresh_interval = $par['refresh_interval'];
    }

    public function validate($par) {
        if ($par['default_prepaid_amount'] == '' || $par['default_prepaid_amount'] < 0) {
            throw new Exception(_('Prepaid Amount has incorrect number format. Number greater than or equal 0 is expected.'));
        }

        if ($par['default_credit_limit'] == '' || $par['default_credit_limit'] < 0) {
            throw new Exception(_('Credit Limit has incorrect number format. Number greater than or equal 0 is expected.'));
        }

        if ($par['refresh_interval'] < 10 || $par['refresh_interval'] > 300) {
            throw new Exception(_('Refresh Interval has incorrect number format. Decimal number in the range from 10 to 300 is expected.'));
        }
    }

    public function update($par) {
        global $db;

        $this->validate($par);

        $sql = 'UPDATE callshops
                   SET default_credit_limit = ?, default_prepaid_amount = ?,
                       on_start = ?, on_stop = ?, start_on_stop = ?,
                       booth_name = ?, refresh_interval = ?
                 WHERE i_customer = ?';
        $params = Array($par['default_credit_limit'], $par['default_prepaid_amount'],
                        $par['on_start'], $par['on_stop'], $par['start_on_stop'] == 1,
                        $par['booth_name'], $par['refresh_interval'], $this->i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Callshop Preferences."));
        }
    }

    public static function add($i_customer) {
        global $db;

        $sql = "INSERT INTO callshops (i_customer)
                     VALUES (?)";
        $params = Array($i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot add Callshop Preferences."));
        }
    }

}
?>
