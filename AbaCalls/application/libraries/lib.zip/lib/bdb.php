<?php

namespace Sippy\Cache;

use Psr\SimpleCache\CacheInterface;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Collection\Cells;

class DummyCells extends Cells
{
    public function __construct() {
    }

    public function __destruct() {
    }

    public function update(Cell $cell) {
    }
}

/**
 * The BDB cache to store everything in one BDB file. This cache is gone
 * once the process ends.
 *
 */
class BDB implements CacheInterface
{
    private $db_path;
    private $db;
    private $cell;
    private $cells;
    private $row_key;
    private $row_data;
    private $row_data_changed;

    function __construct($dir = '/var/tmp')
    {
        $this->db_path = tempnam($dir, "BDB_cache.");
        $this->db = dba_open($this->db_path, "n", "db4");
        $this->cell = NULL;
        $this->cells = new DummyCells();
        $this->row_key = NULL;
        $this->row_data = NULL;
        $this->row_data_changed = FALSE;
    }

    function __destruct()
    {
        $this->flush_cache();
        dba_close($this->db);
        unlink($this->db_path);
    }

    private function reduce_key($key)
    {
        return preg_split('#(?<=[a-z])(?=\d)#i', array_pop(explode('.', $key)));
    }

    private function flush_cache()
    {
        if ($this->row_key !== NULL && $this->row_data_changed) {
            // error_log(microtime(true) . ": flush_cache: " . $this->row_key . "\n", 3, "/tmp/web.log");
            if ($this->row_data !== NULL) {
                dba_replace($this->row_key, serialize($this->row_data), $this->db);
            } else {
                dba_delete($this->row_key, $this->db);
            }
            $this->row_data_changed = FALSE;
        }
    }

    function get($key, $default = NULL)
    {
        list($cell_key, $row_key) = $this->reduce_key($key);

        if ($this->row_key !== NULL && $this->row_key != $row_key) {
            $this->flush_cache();
        }

        if ($this->row_key === NULL || ($this->row_key !== NULL && $this->row_key != $row_key)) {
            $this->row_key = $row_key;
            $data = dba_fetch($row_key, $this->db);
            $this->row_data = ($data === FALSE) ? NULL : @unserialize($data);
        }

        if (!@array_key_exists($cell_key, $this->row_data)) {
                if ($default === NULL) {
                    return NULL;
                }

                $this->row_data[$cell_key] = @$default->getDataType() . ':' .
                                            @$default->getXfIndex() . ':' .
                                            serialize(@$default->getValue());
                $this->row_data_changed = TRUE;
        }

        list($type, $xfIndex, $value) = explode(':', $this->row_data[$cell_key], 3);
        $this->cell->attach($this->cells);
        $this->cell->setValueExplicit(unserialize($value), $type);
        $this->cell->setXfIndex($xfIndex);
        $this->cell->detach();

        // error_log(microtime(true) . ": get: " . $cell_key . $row_key . "\n", 3, "/tmp/web.log");
        // error_log(microtime(true) . ": " . serialize($this->cell) . "\n", 3, "/tmp/web.log");

        return $this->cell;
    }

    function set($key, $value, $ttl = NULL)
    {
        if ($this->cell === NULL) {
            $this->cell = clone $value;
        }

        list($cell_key, $row_key) = $this->reduce_key($key);

        // error_log(microtime(true) . ": set: " . $cell_key . $row_key . "\n", 3, "/tmp/web.log");
        // error_log(microtime(true) . ": set: cached row: " . $this->row_key . "\n", 3, "/tmp/web.log");

        if ($this->row_key !== NULL && $this->row_key != $row_key) {
            $this->flush_cache();
        }

        if ($this->row_key === NULL || ($this->row_key !== NULL && $this->row_key != $row_key)) {
            $this->row_key = $row_key;
            $data = dba_fetch($row_key, $this->db);
            $this->row_data = ($data === FALSE) ? NULL : @unserialize($data);
        }

        $old_value = @$this->row_data[$cell_key];

        $this->row_data[$cell_key] = $value->getDataType() . ':' .
                                     $value->getXfIndex() . ':' .
                                     serialize($value->getValue());

        // error_log(microtime(true) . ": " . serialize($this->row_data[$cell_key]) . "\n", 3, "/tmp/web.log");

        if ($this->row_data[$cell_key] !== $old_value) {
            $this->row_data_changed = TRUE;
        }

        return TRUE;
    }

    function delete($key)
    {
        list($cell_key, $row_key) = $this->reduce_key($key);

        if ($this->row_key !== NULL && $this->row_key != $row_key) {
            $this->flush_cache();
            $this->row_key = $row_key;
            $data = dba_fetch($row_key, $this->db);
            $this->row_data = ($data === FALSE) ? NULL : @unserialize($data);
        }

        unset($this->row_data[$cell_key]);

        // error_log(microtime(true) . ": delete: " . $cell_key . $row_key . "\n", 3, "/tmp/web.log");

        $this->row_data_changed = TRUE;

        return TRUE;
    }

    function clear()
    {
        dba_close($this->db);
        $this->db = dba_open($this->db_path, "n", "db4");

        $this->cell = NULL;
        $this->row_key = NULL;
        $this->row_data = NULL;
        $this->row_data_changed = FALSE;

        return TRUE;
    }

    function has($key)
    {
        list($cell_key, $row_key) = $this->reduce_key($key);

        // error_log(microtime(true) . ": has: " . $cell_key . $row_key . "\n", 3, "/tmp/web.log");

        if ($this->row_key !== NULL && $this->row_key != $row_key) {
            $data = dba_fetch($row_key, $this->db);
            if ($data === FALSE) {
                return FALSE;
            }

            $this->row_key = $row_key;
            $this->row_data = @unserialize($data);
        }

        return @array_key_exists($cell_key, $this->row_data);
    }

    function getMultiple($keys, $default = null)
    {
        return FALSE;
    }

    function setMultiple($values, $ttl = null)
    {
        return FALSE;
    }

    function deleteMultiple($keys)
    {
        return FALSE;
    }
}
