<?php

// Copyright (c) 2006-2010 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

define('PP_TURKISH_DENIZBANK_3D_TEST_URL', 'https://testsanalpos.est.com.tr/servlet/est3Dgate');
define('PP_TURKISH_DENIZBANK_3D_TEST_API_URL', 'https://testsanalpos.est.com.tr/servlet/cc5ApiServer');
define('PP_TURKISH_DENIZBANK_3D_PROD_URL', 'https://sanalpos.denizbank.com.tr/servlet/est3Dgate');
define('PP_TURKISH_DENIZBANK_3D_PROD_API_URL', 'https://sanalpos.denizbank.com.tr/servlet/cc5ApiServer');

function pp_redirect($tx) {

    $suported_currencies = array('TRY', 'JPY', 'RUB', 'GBP', 'USD', 'EUR');

    $tx_id = $tx['tx_id'];

    $url = PP_TURKISH_DENIZBANK_3D_PROD_URL;
    $api_url = PP_TURKISH_DENIZBANK_3D_PROD_API_URL;
    if ($tx['env'] == 1) {      /* test environment */
        $api_url = PP_TURKISH_DENIZBANK_3D_TEST_API_URL;
        $url = PP_TURKISH_DENIZBANK_3D_TEST_URL;
    }

    if (!in_array($tx['pp_currency'], $suported_currencies)) {
        tx_log($tx_id, "error: Turkish DenizBank 3D does not support ${tx['pp_currency']} at this time");
        return array('FAIL', "error: Turkish DenizBank 3D does not support ${tx['pp_currency']} at this time");
    }

    list($clientid, $api_user) = explode(':', $tx['login']);
    list($storekey, $api_password) = explode(':', $tx['password']);

    $redirect_params = Array();

    $redirect_params['oid'] = $tx_id;
    $redirect_params['storetype'] = '3d';
    $redirect_params['clientid'] = $clientid;

    $redirect_params['pan'] = $tx['card_number'];
    $redirect_params['Ecom_Payment_Card_ExpDate_Month'] = $tx['exp_date_mm'];
    $redirect_params['Ecom_Payment_Card_ExpDate_Year'] = $tx['exp_date_yy'];
    $redirect_params['cv2'] = $tx['cvv_cvc'];

    $redirect_params['amount'] = sprintf('%0.2f', $tx['amount']);
    $redirect_params['currency'] = $tx['pp_currency_num'];

    list($serverName, $serverPort) = explode(':', $_SERVER['HTTP_HOST']);
    $serverPort = empty($serverPort) ? $_SERVER['SERVER_PORT'] : $serverPort;
    $path_parts = pathinfo($_SERVER['REQUEST_URI']);
    $path_info = $path_parts['dirname'];
    $server_url = 'https://' . $serverName . ':' . $serverPort . $path_info;
    $okUrl = $server_url . '/make_payment_return_ok.php';

    $redirect_params['okUrl'] = $okUrl;
    $redirect_params['failUrl'] = $okUrl;

    $rnd = microtime();
    $redirect_params['rnd'] = $rnd;

    $hashstr = $redirect_params['clientid'] . $redirect_params['oid'] . $redirect_params['amount'] .
               $redirect_params['okUrl'] . $redirect_params['failUrl'] . $redirect_params['rnd'] .
               $storekey;
    $hash = base64_encode(pack('H*', sha1($hashstr)));

    $redirect_params['hash'] = $hash;

    $_SESSION['PP_TDB_3D_api_url'] = $api_url;
    $_SESSION['PP_TDB_3D_clientid'] = $clientid;
    $_SESSION['PP_TDB_3D_storekey'] = $storekey;
    $_SESSION['PP_TDB_3D_api_user'] = $api_user;
    $_SESSION['PP_TDB_3D_api_password'] = $api_password;
    $_SESSION['PP_TDB_3D_amount'] = $tx['amount'];
    $_SESSION['PP_TDB_3D_pp_currency_num'] = $tx['pp_currency_num'];
    $_SESSION['PP_TDB_3D_customer_ip'] = $tx['customer_ip'];

    return array('OK', '', $url, $redirect_params);
}

function pp_return_ok(&$tx) {

    $tx_id = $tx['tx_id'];

    $storekey = $_SESSION['PP_TDB_3D_storekey'];

    foreach (array_keys($_SESSION) as $k) {
        if (substr($k, 0, strlen('PAYMENT_TX_RETURN_OK_')) == 'PAYMENT_TX_RETURN_OK_') {
            $new_k = strtolower(substr($k, strlen('PAYMENT_TX_RETURN_OK_')));
            $v = $_SESSION[$k];
            unset($_SESSION[$k]);
            $_SESSION['PAYMENT_TX_RETURN_OK_' . $new_k] = $v;
        }
    }

    $hashparamsval = $_SESSION['PAYMENT_TX_RETURN_OK_hashparamsval'];
    $hashparamsval .= $storekey;
    $hash = base64_encode(pack('H*', sha1($hashparamsval)));

    if ($hash != $_SESSION['PAYMENT_TX_RETURN_OK_hash']) {
        $err_msg = "Received invalid hash: " . $_SESSION['PAYMENT_TX_RETURN_OK_hash'];
        tx_log($tx_id, "error: $err_msg");

        pp_clear_session();
        return array('FAIL', $err_msg);
    }

    if ($_SESSION['PAYMENT_TX_RETURN_OK_mdstatus'] != 1) {
        $err_msg = "Received invalid mdstatus: '" . $_SESSION['PAYMENT_TX_RETURN_OK_mdstatus'] . "'";
        tx_log($tx_id, "error: $err_msg");

        pp_clear_session();
        return array('FAIL', $err_msg);
    }

    $xid = $_SESSION['PAYMENT_TX_RETURN_OK_xid'];
    $_SESSION['PP_TDB_3D_xid'] = $xid;
    tx_log($tx_id, "xid = $xid");

    tx_log($tx_id, "3D Auth is Successful");

    return array('OK', '');
}

function pp_process($tx) {

    $tx_id = $tx['tx_id'];

    if (!array_key_exists('PP_TDB_3D_xid', $_SESSION)) {
        tx_log($tx_id, 'error: data integrity violation: transaction xid is not defined');
        return array('FAIL', 'data integrity violation: transaction xid is not defined');
    }

    $xid = $_SESSION['PP_TDB_3D_xid'];

    $api_url = $_SESSION['PP_TDB_3D_api_url'];
    $clientid = $_SESSION['PP_TDB_3D_clientid'];
    $api_user = $_SESSION['PP_TDB_3D_api_user'];
    $api_password = $_SESSION['PP_TDB_3D_api_password'];
    $amount = $_SESSION['PP_TDB_3D_amount'];
    $pp_currency_num = $_SESSION['PP_TDB_3D_pp_currency_num'];
    $customer_ip = $_SESSION['PP_TDB_3D_customer_ip'];

    /* * * * */
    $request = "DATA=<?xml version=\"1.0\" encoding=\"ISO-8859-9\"?>".
            "<CC5Request>".
            "<Name>$api_user</Name>".
            "<Password>$api_password</Password>".
            "<ClientId>$clientid</ClientId>".
            "<IPAddress>$customer_ip</IPAddress>".
            "<Email></Email>".
            "<Mode>P</Mode>".
            "<OrderId>{$_SESSION['PAYMENT_TX_RETURN_OK_oid']}</OrderId>".
            "<GroupId></GroupId>".
            "<TransId></TransId>".
            "<UserId></UserId>".
            "<Type>Auth</Type>".
            "<Number>{$_SESSION['PAYMENT_TX_RETURN_OK_md']}</Number>".
            "<Expires></Expires>".
            "<Cvv2Val></Cvv2Val>".
            "<Total>$amount</Total>".
            "<Currency>$pp_currency_num</Currency>".
            "<Taksit></Taksit>".
            "<PayerTxnId>$xid</PayerTxnId>".
            "<PayerSecurityLevel>{$_SESSION['PAYMENT_TX_RETURN_OK_eci']}</PayerSecurityLevel>".
            "<PayerAuthenticationCode>{$_SESSION['PAYMENT_TX_RETURN_OK_cavv']}</PayerAuthenticationCode>".
            "<CardholderPresentCode>13</CardholderPresentCode>".
            "<BillTo>".
            "<Name></Name>".
            "<Street1></Street1>".
            "<Street2></Street2>".
            "<Street3></Street3>".
            "<City></City>".
            "<StateProv></StateProv>".
            "<PostalCode></PostalCode>".
            "<Country></Country>".
            "<Company></Company>".
            "<TelVoice></TelVoice>".
            "</BillTo>".
            "<ShipTo>".
            "<Name></Name>".
            "<Street1></Street1>".
            "<Street2></Street2>".
            "<Street3></Street3>".
            "<City></City>".
            "<StateProv></StateProv>".
            "<PostalCode></PostalCode>".
            "<Country></Country>".
            "</ShipTo>".
            "<Extra></Extra>".
            "</CC5Request>";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
    curl_setopt($ch, CURLOPT_SSLVERSION, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 90);
    curl_setopt($ch, CURLOPT_POSTFIELDS, urlencode($request));

    tx_log($tx_id, "sending Sale request...");

    $res = curl_exec($ch);

    if (curl_errno($ch)) {
        $err = curl_error($ch);
        curl_close($ch);
        tx_log($tx_id, "error: curl: $err");
        return array('FAIL', "curl: $err");
    }

    curl_close($ch);

    $xml = new xmlToArrayParser($res);
    $res = $xml->array;


    $response = $res['CC5Response']['Response'];
    $orderid = $res['CC5Response']['OrderId'];
    $authcode = $res['CC5Response']['AuthCode'];
    $procreturncode = $res['CC5Response']['ProcReturnCode'];
    $err = $res['CC5Response']['ErrMsg'];
    $hostrefnum = $res['CC5Response']['HostRefNum'];
    $transid = $res['CC5Response']['TransId'];

    if ($response != 'Approved') {
        $err_msg = "Received invalid response: '" . $response . "'";
        tx_log($tx_id, "error: $err_msg");

        pp_clear_session();
        return array('FAIL', $err_msg);
    }

    if ($procreturncode != '00') {
        $err_msg = "Received invalid procreturncode: '" . $procreturncode . "'";
        tx_log($tx_id, "error: $err_msg");

        pp_clear_session();
        return array('FAIL', $err_msg);
    }

    pp_clear_session();

    tx_log($tx_id, "response = $response");
    tx_log($tx_id, "orderid = $orderid");
    tx_log($tx_id, "authcode = $authcode");
    tx_log($tx_id, "procreturncode = $procreturncode");
    tx_log($tx_id, "hostrefnum = $hostrefnum");
    tx_log($tx_id, "transid = $transid");


    /* success */
    return array('OK', $transid);
}

function pp_clear_session() {
    foreach (array_keys($_SESSION) as $k) {
        if (substr($k, 0, strlen('PAYMENT_TX_RETURN_OK_')) == 'PAYMENT_TX_RETURN_OK_') {
            unset($_SESSION[$k]);
        }
    }
    unset($_SESSION['PP_TDB_3D_xid']);
    unset($_SESSION['PP_TDB_3D_api_url']);
    unset($_SESSION['PP_TDB_3D_clientid']);
    unset($_SESSION['PP_TDB_3D_storekey']);
    unset($_SESSION['PP_TDB_3D_api_user']);
    unset($_SESSION['PP_TDB_3D_api_password']);
    unset($_SESSION['PP_TDB_3D_amount']);
    unset($_SESSION['PP_TDB_3D_pp_currency_num']);
    unset($_SESSION['PP_TDB_3D_customer_ip']);
}

?>
