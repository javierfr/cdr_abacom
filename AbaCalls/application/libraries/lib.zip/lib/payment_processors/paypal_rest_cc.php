<?php

// Copyright (c) 2016 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

require_once 'lib/vendor/autoload.php';

use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;
use PayPal\Api\CreditCard;
use PayPal\Api\FundingInstrument;
use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Address;
use PayPal\Api\Payment;
use PayPal\Api\Transaction;


function pp_process($tx) {

    $cards_mapping   = array( 1 => 'visa',              /* Visa */
                              2 => 'amex',              /* American Express */
                              3 => 'mastercard',        /* MasterCard */
                              4 => 'discover'           /* Discover */
                           );

    $suported_currencies = array('AUD', 'BRL', 'CAD', 'CZK', 'DKK', 'EUR', 'HKD', 'HUF',
                                 'ILS', 'JPY', 'MYR', 'MXN', 'TWD', 'NZD', 'NOK', 'PHP',
                                 'PLN', 'GBP', 'RUB', 'SGD', 'SEK', 'CHF', 'THB', 'TRY',
                                 'USD');
    $tx_id = $tx['tx_id'];

    if ($tx['test']) {
        tx_log($tx_id, 'error: PayPal REST API does not support Test Mode');
        return array('FAIL', 'PayPal REST API does not support Test Mode');
    }

    if (!in_array($tx['pp_currency'], $suported_currencies)) {
        tx_log($tx_id, "error: PayPal REST API does not support ${tx['pp_currency']} at this time");
        return array('FAIL', "error: PayPal REST API does not support ${tx['pp_currency']} at this time");
    }

    $clientId = $tx['login'];
    $clientSecret = $tx['password'];

    $apiContext = new ApiContext(new OAuthTokenCredential($clientId, $clientSecret));
    $apiContext->setConfig(Array('mode' => ($tx['env'] == 1) ?
                                           'sandbox' :
                                           'live'));

    /* * */
    $address = new Address();
    $address->setLine1($tx['address1'])
        ->setLine2($tx['address2'])
        ->setCity($tx['city'])
        ->setState($tx['state'])
        ->setPostalCode($tx['postal_code'])
        ->setCountryCode($tx['country'])
        ->setPhone($tx['phone']);

    /* * */
    $creditCardType = $cards_mapping[$tx['payment_method']];

    list($firstName, $lastName) = preg_split('/[ \t]+/', $tx['card_holder'], 2);
    $creditCardNumber = $tx['card_number'];
    $expDateMonth = $tx['exp_date_mm'];
    $expDateYear = '20' . $tx['exp_date_yy'];
    $cvv2Number = $tx['cvv_cvc'];

    $card = new CreditCard();
    $card->setType($creditCardType)
        ->setNumber($creditCardNumber)
        ->setExpireMonth($expDateMonth)
        ->setExpireYear($expDateYear)
        ->setCvv2($cvv2Number)
        ->setFirstName($firstName)
        ->setLastName($lastName)
        ->setBillingAddress($address);

    /* * */
    $fi = new FundingInstrument();
    $fi->setCreditCard($card);

    /* * */
    $payer = new Payer();
    $payer->setPaymentMethod("credit_card")
        ->setFundingInstruments(Array($fi));

    /* * */
    $pp_amount = $tx['amount'];
    $item_price = (array_key_exists('pp_transaction_fee', $tx) && $tx['pp_transaction_fee'] > 0) ?
                  $pp_amount - $tx['pp_transaction_fee'] :
                  $pp_amount;

    $item = new Item();
    $item->setName('VoIP services')
        ->setCurrency($tx['pp_currency'])
        ->setQuantity(1)
        ->setPrice($item_price);

    $itemList = new ItemList();
    $itemList->setItems(Array($item));

    $amount = new Amount();
    $amount->setCurrency($tx['pp_currency'])
        ->setTotal($pp_amount);

    if (array_key_exists('pp_transaction_fee', $tx) && $tx['pp_transaction_fee'] > 0) {
        $details = new Details();
        $details->setHandlingFee($tx['pp_transaction_fee'])
            ->setSubtotal($pp_amount - $tx['pp_transaction_fee']);

        $amount->setDetails($details);
    }

    $transaction = new Transaction();
    $transaction->setAmount($amount)
        ->setItemList($itemList)
        ->setDescription("VoIP services")
        ->setInvoiceNumber(sprintf("%010s", $tx_id));

    /* * */
    $payment = new Payment();
    $payment->setIntent("sale")
        ->setPayer($payer)
        ->setTransactions(Array($transaction));

    /* * */
    tx_log($tx_id, "sending sale request...");

    try {
        $payment->create($apiContext);
    } catch (Exception $e) {
        // tx_log($tx_id, print_r($e, TRUE));
        $data = json_decode($e->getData());
        if ($data !== NULL) {
            tx_log($tx_id, 'error: ' . $data->error . ': ' . $data->error_description);
            return Array('FAIL', $data->error . ': ' . $data->error_description);
        } else {
            tx_log($tx_id, 'error: ' . $e->getMessage());
            return Array('FAIL', $e->getMessage());
        }
    }

    /* success */
    $payment_id = $payment->getId();
    tx_log($tx_id, 'Transaction-ID: ' . $payment_id);

    $payment_state = $payment->getState();
    tx_log($tx_id, 'payment state: '. $payment_state);

    if ($payment_state != 'approved') {
        $error = $payment->getFailureReason();
        if (empty($error)) {
            $error = 'Unexpected payment state';
        }
        return Array('FAIL', $error);
    }

    $transactions = $payment->getTransactions();
    $relatedResources = $transactions[0]->getRelatedResources();
    $sale = $relatedResources[0]->getSale();

    $transaction_state = $sale->getState();
    tx_log($tx_id, 'transaction state: '. $transaction_state);

    if ($transaction_state == 'completed') {
        return array('OK', $payment_id);
    } elseif ($transaction_state != 'pending') {
        return array('FAIL', 'Wrong transaction state: ' . $transaction_state);
    }

    return array('PENDING', $payment_id);
}

function pp_complete_pending_transaction($pp, $p) {
    $tx_id = $p['i_payment'];

    tx_log($tx_id, "getting state of sale payment...");

    $clientId = $pp['login'];
    $clientSecret = $pp['password'];

    try {
        $apiContext = new ApiContext(new OAuthTokenCredential($clientId, $clientSecret));
        $apiContext->setConfig(Array('mode' => ($pp['env'] == 1) ?
                                               'sandbox' :
                                               'live'));

        $payment = Payment::get($p['tx_id'], $apiContext);
        $transactions = $payment->getTransactions();
        $relatedResources = $transactions[0]->getRelatedResources();
        $sale = $relatedResources[0]->getSale();

        $transaction_state = $sale->getState();
        tx_log($tx_id, 'transaction state: '. $transaction_state);

        if ($transaction_state == 'completed') {
            return array('COMPLETED', '');
        } elseif ($transaction_state != 'pending') {
            return array('FAIL', 'Wrong transaction state: ' . $transaction_state);
        }
    } catch (Exception $e) {
        $data = json_decode($e->getData());

        if ($data !== NULL) {
            tx_log($tx_id, 'error: ' . $data->error . ': ' . $data->error_description);
            return Array('FAIL', $data->error . ': ' . $data->error_description);
        } else {
            tx_log($tx_id, 'error: ' . $e->getMessage());
            return Array('FAIL', $e->getMessage());
        }
    }

    return Array('NOCHANGE', PP_PAYPAL_REST_PAYPAL_CHECK_INTERVAL);
}

?>
