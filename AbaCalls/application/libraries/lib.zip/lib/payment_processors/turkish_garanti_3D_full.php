<?php

// Copyright (c) 2006-2010 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

define('PP_TURKISH_GARANTI_3D_FULL_URL', 'https://sanalposprov.garanti.com.tr/servlet/gt3dengine');

function pp_redirect($tx) {

    $suported_currencies = array('TRY', 'USD');

    $tx_id = $tx['tx_id'];

    $mode = 'PROD';
    if ($tx['test']) {  /* test mode */
        $mode = 'TEST';
    }

    if (!in_array($tx['pp_currency'], $suported_currencies)) {
        tx_log($tx_id, "error: Turkish Garanti Bank 3D FULL does not support ${tx['pp_currency']} at this time");
        return array('FAIL', "error: Turkish Garanti Bank 3D FULL does not support ${tx['pp_currency']} at this time");
    }

    list($merchant_id, $terminal_id) = explode(':', $tx['login']);
    list($passowrd, $secure_key) = explode(':', $tx['password']);

    $redirect_params = Array();

    $redirect_params['orderid'] = $tx_id;
    $redirect_params['secure3dsecuritylevel'] = '3D_FULL';
    $redirect_params['apiversion'] = 'v0.01';
    $redirect_params['mode'] = $mode;
    $redirect_params['txntype'] = 'sales';

    $redirect_params['terminalprovuserid'] = 'PROVAUT';
    $redirect_params['terminaluserid'] = $terminal_id;
    $redirect_params['terminalmerchantid'] = $merchant_id;
    $redirect_params['terminalid'] = $terminal_id;

    $redirect_params['cardnumber'] = $tx['card_number'];
    $redirect_params['cardexpiredatemonth'] = $tx['exp_date_mm'];
    $redirect_params['cardexpiredateyear'] = $tx['exp_date_yy'];
    $redirect_params['cardcvv2'] = $tx['cvv_cvc'];

    $redirect_params['customeripaddress'] = $tx['customer_ip'];

    $redirect_params['txnamount'] = sprintf('%0d', $tx['amount'] * 100);
    $redirect_params['txncurrencycode'] = $tx['pp_currency_num'];
    $redirect_params['txninstallmentcount'] = '';

    list($serverName, $serverPort) = explode(':', $_SERVER['HTTP_HOST']);
    $serverPort = empty($serverPort) ? $_SERVER['SERVER_PORT'] : $serverPort;
    $path_parts = pathinfo($_SERVER['REQUEST_URI']);
    $path_info = $path_parts['dirname'];
    $url = 'https://' . $serverName . ':' . $serverPort . $path_info;
    $returnURL = $url . '/make_payment_return_ok.php';

    $redirect_params['successurl'] = $returnURL;
    $redirect_params['errorurl'] = $returnURL;

    $security_data = strtoupper(sha1($passowrd . sprintf('%09d', $terminal_id)));
    $hash_data = strtoupper(sha1($terminal_id . $tx_id . sprintf('%0d', $tx['amount'] * 100) . $returnURL .
                                 $returnURL . 'sales' . '' . $secure_key . $security_data));

    $redirect_params['secure3dhash'] = $hash_data;
    $_SESSION['PP_TGB_3D_FULL_secure3dhash'] = $hash_data;
    tx_log($tx_id, "secure3dhash: $hash_data");

    $url_params = Array();
    foreach ($redirect_params as $k => $v) {
        $url_params[] = "$k=" . urlencode($v); 
    }
    $url_params = implode('&', $url_params);

    $url = PP_TURKISH_GARANTI_3D_FULL_URL . '?' . $url_params;

    return array('OK', '', $url);
}

function pp_return_ok(&$tx) {

    $tx_id = $tx['tx_id'];

    foreach (array_keys($_SESSION) as $k) {
        if (substr($k, 0, strlen('PAYMENT_TX_RETURN_OK_')) == 'PAYMENT_TX_RETURN_OK_') {
            $new_k = strtolower(substr($k, strlen('PAYMENT_TX_RETURN_OK_')));
            $v = $_SESSION[$k];
            unset($_SESSION[$k]);
            $_SESSION['PAYMENT_TX_RETURN_OK_' . $new_k] = $v;
        }
    }

    if ($_SESSION['PP_TGB_3D_FULL_secure3dhash'] != $_SESSION['PAYMENT_TX_RETURN_OK_secure3dhash']) {
        $err_msg = "Received invalid secure3dhash: " . $_SESSION['PAYMENT_TX_RETURN_OK_secure3dhash'];
        tx_log($tx_id, "error: $err_msg");

        pp_clear_session();
        return array('FAIL', $err_msg);
    }

    if ($_SESSION['PAYMENT_TX_RETURN_OK_mdstatus'] != 1) {
        $err_msg = "Received invalid mdstatus: '" . $_SESSION['PAYMENT_TX_RETURN_OK_mdstatus'] . "'";
        tx_log($tx_id, "error: $err_msg");

        pp_clear_session();
        return array('FAIL', $err_msg);
    }

    if ($_SESSION['PAYMENT_TX_RETURN_OK_response'] != 'Approved') {
        $err_msg = "Received invalid response: '" . $_SESSION['PAYMENT_TX_RETURN_OK_response'] . "'";
        tx_log($tx_id, "error: $err_msg");

        pp_clear_session();
        return array('FAIL', $err_msg);
    }

    if ($_SESSION['PAYMENT_TX_RETURN_OK_procreturncode'] != '00') {
        $err_msg = "Received invalid procreturncode: '" . $_SESSION['PAYMENT_TX_RETURN_OK_procreturncode'] . "'";
        tx_log($tx_id, "error: $err_msg");

        pp_clear_session();
        return array('FAIL', $err_msg);
    }

    $xid = $_SESSION['PAYMENT_TX_RETURN_OK_xid'];
    tx_log($tx_id, "xid = $xid");

    pp_clear_session();

    $_SESSION['PP_TGB_3D_FULL_xid'] = $xid;
    tx_log($tx_id, "received valid response");

    return array('OK', '');
}

function pp_clear_session() {
    foreach (array_keys($_SESSION) as $k) {
        if (substr($k, 0, strlen('PAYMENT_TX_RETURN_OK_')) == 'PAYMENT_TX_RETURN_OK_') {
            unset($_SESSION[$k]);
        }
    }
    unset($_SESSION['PP_TGB_3D_FULL_secure3dhash']);
    unset($_SESSION['PP_TGB_3D_FULL_xid']);
}

function pp_process($tx) {
    if (!array_key_exists('PP_TGB_3D_FULL_xid', $_SESSION)) {
        tx_log($tx['tx_id'], 'error: data integrity violation: transaction xid is not defined');
        return array('FAIL', 'data integrity violation: transaction xid is not defined');
    }

    $xid = $_SESSION['PP_TGB_3D_FULL_xid'];
    pp_clear_session();

    /* success */
    return array('OK', $xid);
}

?>
