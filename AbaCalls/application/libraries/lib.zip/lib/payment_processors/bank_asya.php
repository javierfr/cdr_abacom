<?php

// Copyright (c) 2006-2008 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

define('PP_BANK_ASYA_TEST_URL', 'https://vpstest.bankasya.com.tr/iposnet/sposnet.aspx');
define('PP_BANK_ASYA_PROD_URL', 'https://web.bankasya.com.tr/spos/iposnet/sposnet.aspx');

global $pp_bank_asya_codes;
$pp_bank_asya_codes = array(
				'0000' => 'Accepted',
				'0001' => 'Call Your Bank',
				'0002' => 'Call Your Bank',
				'0004' => 'Declined - Keep the Card',
				'0005' => 'Declined - Unauthorised',
				'0008' => 'ID Check - Acception Code',
				'0011' => 'Approval Code',
				'0012' => 'Declined - Invalid Transaction',
				'0013' => 'Declined - Invalid Ampunt',
				'0014' => 'Declined - Improper Card',
				'0015' => 'Declined - Invalid Card',
				'0030' => 'Call Your Bank',
				'0033' => 'Declined - Keep the Card',
				'0034' => 'Declined - Keep the Card',
				'0038' => 'Declined - Keep the Card',
				'0041' => 'Declined - Keep the Card',
				'0043' => 'Declined - Keep the Card',
				'0051' => 'Declined - Insufficient Balance',
				'0054' => 'Declined - Not Approved',
				'0055' => 'Declined - Retry Code',
				'0057' => 'Declined - Not Approved',
				'0058' => 'Declined - Not Approved',
				'0062' => 'Declined - Not Approved',
				'0065' => 'Declined - Not Approved',
				'0075' => 'Declined - Not Approved',
				'0091' => 'Declined - No Connection',
				'0092' => 'Declined - Invalid Card',
				'0096' => 'Declined - No Connection',
				'1010' => 'Internal Error',
				'1020' => 'Internal Error',
				'1030' => 'Internal Error',
				'5000' => 'ISRS No error',
				'5001' => 'Client required field empty error',
				'5002' => 'Communication Error',
				'5003' => 'POS Interface Error',
				'5101' => 'Merchant Authorizer Configuration File property is not set',
				'5102' => 'Merchant Authorizer VerifyNumericValues returned false',
				'5103' => 'Merchant Authorizer SendAndReceive fails',
				'5201' => 'Merchant Factory Configuration File property is not set',
				'5301' => 'Configuration File property is not set',
				'5302' => 'Modifier VerifyNumericValues returned false',
				'5303' => 'Modifier SendAndReceive fails',
				'5401' => 'Merchant Query Configuration File property is not set',
				'5402' => 'Merchant Query Action Type is invalid',
				'5403' => 'Merchant Query SendAndReceive fails',
				'5501' => 'Batch Operation Configuration File property is not set',
				'5502' => 'Batch Operation VerifyNumericValues returned false',
				'5503' => 'Batch Operation Action Type is invalid',
				'5504' => 'Batch Operation SendAndReceive fails',
				'5601' => 'Refund Configuration File property is not set',
				'5602' => 'Refund VerifyNumericValues returned false',
				'5603' => 'Refund Operation SendAndReceive fails',
				'6000' => 'XML hatasi',
				'6010' => 'Amount is not numeric',
				'6011' => 'Currency is not numeric',
				'6012' => 'PAN is not numeric',
				'6013' => 'CVV2 is not numeric',
				'6014' => 'Invalid expiry Date',
				'6015' => 'Amount is greater than 20 billion',
				'6020' => 'Currency code is not defined in the system',
				'6021' => 'BrandId is not defined in the system',
				'6030' => 'Card Expiry Date is expired',
				'6040' => 'Merchant is not valid',
				'6041' => 'Merchant Password is incorrect',
				'6042' => 'Merchant is busy',
				'6050' => 'Terminal is not valid',
				'6051' => 'Terminal is busy',
				'6060' => 'Merchant is not authorized to process this transaction',
				'6061' => 'Terminal is not authorized to process this transaction',
				'6062' => 'User is not authorized to process this transaction',
				'6070' => 'No opened batch found',
				'6071' => 'Stan number could not be generated',
				'6072' => 'Auth req could not be inserted into the database',
				'6073' => 'Original Transaction info is empty',
				'6074' => 'Original Transaction can not be modified',
				'6075' => 'Modifier Amount is bigger than original amount',
				'6076' => 'Reauth period has been expired',
				'6077' => 'Original Transaction is busy',
				'6078' => 'Original transaction is not found',
				'6079' => 'Original request and modifier request are not in the same batch',
				'6080' => 'Original request and modifier request are not in the same types',
				'6081' => 'Modifier period has been expired',
				'6082' => 'Transaction with this transaction id has been processed before',
				'6083' => 'Transaction with the same transaction id has been processed before for the batch request',
				'6084' => 'No opened currency found for the batch',
				'6085' => 'Opened batch found for the terminals',
				'6086' => 'Terminal Pool could not be created',
				'6087' => 'Db Error in Merchant Transaction Authorization Module',
				'6088' => 'Transaction req could not be inserted into the database',
				'6089' => 'Db Error while fetching original transaction',
				'6090' => 'Purchase Order Info could not be inserted into database',
				'6091' => 'LI returned false',
				'6092' => 'Fraud engine cannot validate transaction',
				'6093' => 'Query Control returned false',
				'6094' => 'Insert Query Transaction returned false',
				'6095' => 'Query processing is unsuccessful',
				'6096' => 'Db Error In Merchant Validation',
				'6097' => 'Terminal Control returned false',
				'6098' => 'Original Transaction Info is empty',
				'6099' => 'Transaction fields are not same with the original Transaction',
				'6100' => 'Amount contains more than one decimal point. Ambigous amount.',
				'6101' => 'Amount cannot contain thousands separator.',
				'6102' => 'An internal error occurred while modifying the transaction. Original transaction appears to be incorrect due to 0 amount.',
				'6103' => 'Invalid amount format. Please check your acquirer\'s amount format policy again, and send the amount in the correct form.',
				'6104' => 'There is no available terminal belonging this merchant.',
				'6105' => 'Amount should contain cents separator.',
				'6106' => 'This currency is obsolote and will not be used anymore',
				'6107' => 'Authorization batch should be closed before credit request.',
				'6108' => 'Original and modifier amounts are not equal.',
				'6111' => 'Modifier Loyalty Amount is bigger than original loyalty amount.',
				'7000' => 'Missing required data',
				'7001' => 'Internal Error',
				'7011' => 'Original Pan Number is different with the modifier Pan Number',
				'7012' => 'Original Expiry is different with modifier expiry',
				'7013' => 'Original CVV2 is different with the modifier expiry',
				'7014' => 'Original Auth Code is different with the modifier AuthCode',
				'7015' => 'Original currency code is different with the modifier currency code',
				'7019' => 'Modifier Amount must be equal to original amount.',
				'9000' => 'Your transaction is already in progress. Please try again, if transaction fails or expires.',
				'9996' => 'Mutabakat isleminde "hostdate" alani gonderilmemis',
				'9997' => 'XML Reply hazirlanamadi',
				'9998' => 'XML Request inde gerekli parametreler bulunamadi.',
				'9999' => 'Hatali XML Mesaji'
                                );

function pp_process($tx) {

    global $pp_bank_asya_codes;

    $cards_mapping = array( 1 => 'VISA',
			    3 => 'MASTERCARD'
			  );

    $suported_currencies = array('TRY');

    $tx_id = $tx['tx_id'];

    $bank_asya_url = PP_BANK_ASYA_PROD_URL;
    if ($tx['env'] == 1) {	/* test environment */
        $bank_asya_url = PP_BANK_ASYA_TEST_URL;
    }

    if ($tx['test']) {
	tx_log($tx_id, 'error: Asya Bank does not support Test Mode');
	return array('FAIL', 'Asya Bank does not support Test Mode');
    }

    if (!in_array($tx['pp_currency'], $suported_currencies)) {
	tx_log($tx_id, "error: Asya Bank does not support ${tx['pp_currency']} at this time");
	return array('FAIL', "error: Asya Bank does not support ${tx['pp_currency']} at this time");
    }

    $trnxid = sprintf("%010s", $tx_id);

    $msg = "<?xml version=\"1.0\" encoding=\"ISO-8859-9\" ?>
<ePaymentMsg VersionInfo=\"2.0\" TT=\"Request\" RM=\"Direct\" CT=\"Money\">
  <Operation ActionType=\"Sale\">
    <OpData>
      <MerchantInfo MerchantId=\"{$tx['login']}\" MerchantPassword=\"{$tx['password']}\"/>
      <ActionInfo>
        <TrnxCommon TrnxID=\"{$trnxid}\" Protocol=\"156\">
          <AmountInfo Amount=\"{$tx['amount']}\" Currency=\"{$tx['pp_currency_num']}\" />
        </TrnxCommon>
        <PaymentTypeInfo>
          <InstallmentInfo NumberOfInstallments=\"0\" />
        </PaymentTypeInfo>
      </ActionInfo>
      <PANInfo PAN=\"{$tx['card_number']}\" ExpiryDate=\"20{$tx['exp_date_yy']}{$tx['exp_date_mm']}\"
          CVV2=\"{$tx['cvv_cvc']}\" BrandID=\"{$cards_mapping[$tx['payment_method']]}\" />
      <OrderInfo>
        <OrderLine>1</OrderLine>
        <OrderText>Customer's payment.</OrderText>
      </OrderInfo>
      <OrgTrnxInfo />
    </OpData>
  </Operation>
</ePaymentMsg>
";

    $ch =       curl_init();
    curl_setopt($ch, CURLOPT_URL, $bank_asya_url . '?prmstr=' . urlencode($msg));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    tx_log($tx_id, "sending request...");

    $res = curl_exec($ch);

    if (curl_errno($ch)) {
	$err = curl_error($ch);
	curl_close($ch);
	tx_log($tx_id, "error: curl: $err");
	return array('FAIL', "curl: $err");
    }


    curl_close($ch);

    $xml = new XmlToArray($res);
    $res = $xml->createArray();

    $LIDM = $res['ePaymentMsg']['Operation'][0]['OpData'][0]['ActionInfo'][0]['POSTrnxID']['LIDM'];
    tx_log($tx_id, "LIDM: $LIDM");

    $RRPID = $res['ePaymentMsg']['Operation'][0]['OpData'][0]['ActionInfo'][0]['POSTrnxID']['RRPID'];
    tx_log($tx_id, "RRPID: $RRPID");

    if (is_array($res['ePaymentMsg']['Operation'][0]['OpData'][0]['ActionInfo'][0]['HostResponse']) &&
	array_key_exists('__attributes', $res['ePaymentMsg']['Operation'][0]['OpData'][0]['ActionInfo'][0]['HostResponse'])) {
	$ResultCode = $res['ePaymentMsg']['Operation'][0]['OpData'][0]['ActionInfo'][0]['HostResponse']['__attributes']['ResultCode'];
    } else {
	$ResultCode = $res['ePaymentMsg']['Operation'][0]['OpData'][0]['ActionInfo'][0]['HostResponse']['ResultCode'];
    }
    tx_log($tx_id, "ResultCode: $ResultCode");

    if ($ResultCode != '0000') {
	if(array_key_exists($ResultCode, $pp_bank_asya_codes)) {
            $error = $ResultCode . ': ' . $pp_bank_asya_codes[$ResultCode];
        } else {
	    $error = "Unknown error. Error code = $ResultCode";
	}

	tx_log($tx_id, "error: $error");
	return array('FAIL', $error);
    }

    /* success */
    return array('OK', "LIDM=$LIDM;RRPID=$RRPID");
}


class XmlToArray 
{ 
    
    var $xml=''; 
    
    /** 
    * Default Constructor 
    * @param $xml = xml data 
    * @return none 
    */ 
    
    function __construct($xml) 
    { 
       $this->xml = $xml;    
    } 
    
    /** 
    * _struct_to_array($values, &$i) 
    * 
    * This is adds the contents of the return xml into the array for easier processing. 
    * Recursive, Static 
    * 
    * @access    private 
    * @param    array  $values this is the xml data in an array 
    * @param    int    $i  this is the current location in the array 
    * @return    Array 
    */ 
    
    function _struct_to_array($values, &$i) 
    { 
        $child = array(); 
        if (isset($values[$i]['value'])) array_push($child, $values[$i]['value']); 
        
        while ($i++ < count($values)) { 
            switch ($values[$i]['type']) { 
                case 'cdata': 
                array_push($child, $values[$i]['value']); 
                break; 
                
                case 'complete': 
                    $name = $values[$i]['tag']; 
                    if(!empty($name)){ 
                    $child[$name]= (@$values[$i]['value'])?(@$values[$i]['value']):''; 
                    if(isset($values[$i]['attributes'])) {                    
                        $child[$name] = $values[$i]['attributes']; 
                    } 
                }    
              break; 
                
                case 'open': 
                    $name = $values[$i]['tag']; 
                    $size = isset($child[$name]) ? sizeof($child[$name]) : 0; 
                    if(isset($values[$i]['attributes'])) {                    
                        $child[$name]['__attributes'] = $values[$i]['attributes']; 
                    } 
                    $child[$name][$size] = $this->_struct_to_array($values, $i); 
                break; 
                
                case 'close': 
                return $child; 
                break; 
            } 
        } 
        return $child; 
    }//_struct_to_array 
    
    /** 
    * createArray($data) 
    * 
    * This is adds the contents of the return xml into the array for easier processing. 
    * 
    * @access    public 
    * @param    string    $data this is the string of the xml data 
    * @return    Array 
    */ 
    function createArray() 
    { 
        $xml    = $this->xml; 
        $values = array(); 
        $index  = array(); 
        $array  = array(); 
        $parser = xml_parser_create(); 
        xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1); 
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0); 
        xml_parse_into_struct($parser, $xml, $values, $index); 
        xml_parser_free($parser); 
        $i = 0; 
        $name = $values[$i]['tag']; 
        $array[$name] = isset($values[$i]['attributes']) ? $values[$i]['attributes'] : ''; 
        $array[$name] = $this->_struct_to_array($values, $i); 
        return $array; 
    }//createArray 
    
    
}//XmlToArray 
?>
