<?php

// Copyright (c) 2006-2008 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

define('PP_AUTHORIZE_NET_PROD_URL', 'https://secure.authorize.net/gateway/transact.dll');
define('PP_AUTHORIZE_NET_TEST_URL', 'https://test.authorize.net/gateway/transact.dll');

function pp_process($tx) {

    $suported_currencies = Array('USD', 'CAD', 'CHF', 'DKK', 'EUR', 'GBP', 'NOK', 'PLN',
                                 'SEK', 'AUD', 'NZD');

    $tx_id = $tx['tx_id'];

    $url = PP_AUTHORIZE_NET_PROD_URL;
    if ($tx['env'] == 1) {	/* test environment */
        $url = PP_AUTHORIZE_NET_TEST_URL;
    }

    if ($tx['test']) {
	tx_log($tx_id, 'error: Authorize.Net does not support Test Mode');
	return array('FAIL', 'Authorize.Net does not support Test Mode');
    }

    if (!in_array($tx['pp_currency'], $suported_currencies)) {
	tx_log($tx_id, "error: Authorize.Net does not support ${tx['pp_currency']} at this time");
	return array('FAIL', "error: Authorize.Net does not support ${tx['pp_currency']} at this time");
    }

    $trnxid = sprintf("%010s", $tx_id);
    $card_holder = explode(' ', $tx['card_holder'], 2);

    $post_values = array(
	"x_login"		=> $tx['login'],
	"x_tran_key"		=> $tx['password'],

	"x_version"		=> "3.1",
	"x_delim_data"		=> "TRUE",
	"x_delim_char"		=> "|",
	"x_relay_response"	=> "FALSE",

	"x_type"		=> "AUTH_CAPTURE",
	"x_method"		=> "CC",
	"x_card_num"		=> "{$tx['card_number']}",
	"x_card_code"		=> "{$tx['cvv_cvc']}",
	"x_exp_date"		=> "{$tx['exp_date_mm']}{$tx['exp_date_yy']}",

	"x_amount"		=> "{$tx['amount']}",

	"x_first_name"		=> $card_holder[0],
	"x_last_name"		=> $card_holder[1],
	"x_address"		=> "{$tx['address1']} {$tx['address2']}",
	"x_city"		=> $tx['city'],
	"x_state"		=> $tx['state'],
	"x_country"		=> $tx['country'],
	"x_zip"			=> $tx['postal_code'],
	"x_phone"		=> $tx['phone'],

	"x_customer_ip"		=> $tx['customer_ip']
    );

    $msg = "";
    foreach ($post_values as $key => $value) {
	$msg .= "$key=" . urlencode( $value ) . "&";
    }
    $msg = rtrim($msg, "& ");

    $ch =       curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $msg);

    tx_log($tx_id, "sending request...");

    $res = curl_exec($ch);

    if (curl_errno($ch)) {
	$err = curl_error($ch);
	curl_close($ch);
	tx_log($tx_id, "error: curl: $err");
	return array('FAIL', "curl: $err");
    }


    curl_close($ch);

    $res = explode($post_values["x_delim_char"], $res);

    tx_log($tx_id, "Response Code: " . $res[0]);
    tx_log($tx_id, "Response Subcode: " . $res[1]);
    tx_log($tx_id, "Response Reason Code: " . $res[2]);
    tx_log($tx_id, "Response Reason Text: " . $res[3]);
    tx_log($tx_id, "Authorization Code: " . $res[4]);
    tx_log($tx_id, "Transaction ID: " . $res[6]);

    if ($res[0] != 1) {
	$error = $res[0] . ':' . $res[1] . ':' . $res[2] . ':' . $res[3];

	tx_log($tx_id, "error: $error");
	return array('FAIL', $error);
    }

    /* success */
    return array('OK', $res[6]);
}

?>
