<?php

// Copyright (c) 2016 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

define('PP_PAYPAL_REST_PAYPAL_CHECK_INTERVAL', '6 hours');

require_once 'lib/vendor/autoload.php';

use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;
use PayPal\Api\Payer;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Details;
use PayPal\Api\Amount;
use PayPal\Api\Transaction;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Payment;
use PayPal\Api\ExecutePayment;
use PayPal\Api\PaymentExecution;

function pp_redirect($tx) {

    $suported_currencies = array('AUD', 'BRL', 'CAD', 'CZK', 'DKK', 'EUR', 'HKD', 'HUF',
                                 'ILS', 'JPY', 'MYR', 'MXN', 'TWD', 'NZD', 'NOK', 'PHP',
                                 'PLN', 'GBP', 'RUB', 'SGD', 'SEK', 'CHF', 'THB', 'TRY',
                                 'USD');

    $tx_id = $tx['tx_id'];

    if ($tx['test']) {
        tx_log($tx_id, 'error: PayPal REST API does not support Test Mode');
        return array('FAIL', 'PayPal REST API does not support Test Mode');
    }

    if (!in_array($tx['pp_currency'], $suported_currencies)) {
        tx_log($tx_id, "error: PayPal REST API does not support ${tx['pp_currency']} at this time");
        return array('FAIL', "error: PayPal REST API does not support ${tx['pp_currency']} at this time");
    }

    $clientId = $tx['login'];
    $clientSecret = $tx['password'];

    $apiContext = new ApiContext(new OAuthTokenCredential($clientId, $clientSecret));
    $apiContext->setConfig(Array('mode' => ($tx['env'] == 1) ?
                                           'sandbox' :
                                           'live'));

    /* * */
    $payer = new Payer();
    $payer->setPaymentMethod("paypal");

    /* * */
    $pp_amount = $tx['amount'];
    $item_price = (array_key_exists('pp_transaction_fee', $tx) && $tx['pp_transaction_fee'] > 0) ?
                  $pp_amount - $tx['pp_transaction_fee'] :
                  $pp_amount;

    $item = new Item();
    $item->setName('VoIP services')
        ->setCurrency($tx['pp_currency'])
        ->setQuantity(1)
        ->setPrice($item_price);

    $itemList = new ItemList();
    $itemList->setItems(Array($item));

    $amount = new Amount();
    $amount->setCurrency($tx['pp_currency'])
        ->setTotal($pp_amount);

    if (array_key_exists('pp_transaction_fee', $tx) && $tx['pp_transaction_fee'] > 0) {
        $details = new Details();
        $details->setHandlingFee($tx['pp_transaction_fee'])
            ->setSubtotal($pp_amount - $tx['pp_transaction_fee']);

        $amount->setDetails($details);
    }

    $transaction = new Transaction();
    $transaction->setAmount($amount)
        ->setItemList($itemList)
        ->setDescription("VoIP services")
        ->setInvoiceNumber(sprintf("%010s", $tx_id));

    /* * */
    list($serverName, $serverPort) = explode(':', $_SERVER['HTTP_HOST']);
    $serverPort = empty($serverPort) ? $_SERVER['SERVER_PORT'] : $serverPort;

    $path_parts = pathinfo($_SERVER['REQUEST_URI']);
    $path_info = $path_parts['dirname'];
    $url = 'https://' . $serverName . ':' . $serverPort . $path_info;

    $returnURL = $url . '/make_payment_return_ok.php';
    $cancelURL = $url . '/make_payment_return_cancel.php';

    $redirectUrls = new RedirectUrls();
    $redirectUrls->setReturnUrl($returnURL)
        ->setCancelUrl($cancelURL);

    /* * */
    $payment = new Payment();
    $payment->setIntent("sale")
        ->setPayer($payer)
        ->setRedirectUrls($redirectUrls)
        ->setTransactions(Array($transaction));

    /* * */
    tx_log($tx_id, "sending sale request...");

    try {
        $payment->create($apiContext);
    } catch (Exception $e) {
        // tx_log($tx_id, print_r($e, TRUE));
        $data = json_decode($e->getData());
        if ($data !== NULL) {
            pp_clear_session();
            tx_log($tx_id, 'error: ' . $data->error . ': ' . $data->error_description);
            return Array('FAIL', $data->error . ': ' . $data->error_description);
        } else {
            pp_clear_session();
            tx_log($tx_id, 'error: ' . $e->getMessage());
            return Array('FAIL', $e->getMessage());
        }
    }

    /* * */
    $approvalUrl = $payment->getApprovalLink();

    /* save context */
    $_SESSION['PP_PAYPAL_REST_PAYPAL_CONTEXT'] = serialize($apiContext);

    /* * */
    return Array('OK', '', $approvalUrl);
}


function pp_return_ok(&$tx) {

    $tx_id = $tx['tx_id'];

    tx_log($tx_id, 'getting billing address details...');

    /* * */
    $apiContext = unserialize($_SESSION['PP_PAYPAL_REST_PAYPAL_CONTEXT']);
    $apiContext->setConfig(Array('mode' => ($tx['env'] == 1) ?
                                           'sandbox' :
                                           'live'));

    /* * */
    if (!isset($_SESSION['PAYMENT_TX_RETURN_OK_paymentId']) ||
        !isset($_SESSION['PAYMENT_TX_RETURN_OK_PayerID'])) {
        pp_clear_session();

        tx_log($tx_id, 'error: no paymentId or PayerID found');
        return array('FAIL', 'no paymentId or PayerID found');
    }

    /* * */
    $paymentId = $_SESSION['PAYMENT_TX_RETURN_OK_paymentId'];
    $payment = Payment::get($paymentId, $apiContext);

    /* * */
    $address = $payment->getPayer()->getPayerInfo()->getBillingAddress();
    if ($address === NULL) {
        tx_log($tx_id, 'getBillingAddress() returned nothing, use getShippingAddress() instead');
        $address = $payment->getPayer()->getPayerInfo()->getShippingAddress();
    }

    try {
        $tx['address1'] = $address->getLine1();
        $tx['address2'] = $address->getLine2();
        $tx['city'] = $address->getCity();
        $tx['state'] = $address->getState();
        $tx['postal_code'] = $address->getPostalCode();
        $tx['country'] = $address->getCountryCode();
        $tx['phone'] = $address->getPhone();
    } catch (Exception $e) {
        tx_log($tx_id, 'unable to get billing address details: ' . $e->getMessage());
    }

    /* save context */
    $_SESSION['PP_PAYPAL_REST_PAYPAL_CONTEXT'] = serialize($apiContext);

    /* * */
    return array('OK', '');
}


function pp_return_cancel($tx) {
    $tx_id = $tx['tx_id'];

    tx_log($tx_id, 'canceling transaction...');
    pp_clear_session();

    return array('OK', '');
}


function pp_process($tx) {

    $tx_id = $tx['tx_id'];

    tx_log($tx_id, "executing the payment...");

    /* * */
    $apiContext = unserialize($_SESSION['PP_PAYPAL_REST_PAYPAL_CONTEXT']);
    $apiContext->setConfig(Array('mode' => ($tx['env'] == 1) ?
                                           'sandbox' :
                                           'live'));

    /* * */
    $paymentId = $_SESSION['PAYMENT_TX_RETURN_OK_paymentId'];
    $payment = Payment::get($paymentId, $apiContext);

    $payerId = $_SESSION['PAYMENT_TX_RETURN_OK_PayerID'];
    $execution = new PaymentExecution();
    $execution->setPayerId($payerId);

    try {
        $payment->execute($execution, $apiContext);
    } catch (Exception $e) {
        // tx_log($tx_id, print_r($e, TRUE));
        $data = json_decode($e->getData());
        if ($data !== NULL) {
            pp_clear_session();
            tx_log($tx_id, 'error: ' . $data->error . ': ' . $data->error_description);
            return Array('FAIL', $data->error . ': ' . $data->error_description);
        } else {
            pp_clear_session();
            tx_log($tx_id, 'error: ' . $e->getMessage());
            return Array('FAIL', $e->getMessage());
        }
    }

    $payment_state = $payment->getState();
    tx_log($tx_id, 'payment state: '. $payment_state);

    if ($payment_state != 'approved') {
        pp_clear_session();
        $error = $payment->getFailureReason();
        if (empty($error)) {
            $error = 'Unexpected payment state';
        }
        tx_log($tx_id, 'error: ' . $error);
        return Array('FAIL', $error);
    }

    /* success */
    $payment_id = $payment->getId();
    tx_log($tx_id, 'Transaction-ID: ' . $payment_id);

    $transactions = $payment->getTransactions();
    $relatedResources = $transactions[0]->getRelatedResources();
    $sale = $relatedResources[0]->getSale();

    $transaction_state = $sale->getState();
    tx_log($tx_id, 'transaction state: '. $transaction_state);

    if ($transaction_state == 'completed') {
        pp_clear_session();
        return array('OK', $payment_id);
    } elseif ($transaction_state != 'pending') {
        pp_clear_session();
        return array('FAIL', 'Wrong transaction state: ' . $transaction_state);
    }

    pp_clear_session();
    return array('PENDING', $payment_id);
}


function pp_complete_pending_transaction($pp, $p) {
    $tx_id = $p['i_payment'];

    tx_log($tx_id, "getting state of sale payment...");

    $clientId = $pp['login'];
    $clientSecret = $pp['password'];

    try {
        $apiContext = new ApiContext(new OAuthTokenCredential($clientId, $clientSecret));
        $apiContext->setConfig(Array('mode' => ($pp['env'] == 1) ?
                                               'sandbox' :
                                               'live'));

        $payment = Payment::get($p['tx_id'], $apiContext);
        $transactions = $payment->getTransactions();
        $relatedResources = $transactions[0]->getRelatedResources();
        $sale = $relatedResources[0]->getSale();

        $transaction_state = $sale->getState();
        tx_log($tx_id, 'transaction state: '. $transaction_state);

        if ($transaction_state == 'completed') {
            return array('COMPLETED', '');
        } elseif ($transaction_state != 'pending') {
            return array('FAIL', 'Wrong transaction state: ' . $transaction_state);
        }
    } catch (Exception $e) {
        $data = json_decode($e->getData());

        if ($data !== NULL) {
            tx_log($tx_id, 'error: ' . $data->error . ': ' . $data->error_description);
            return Array('FAIL', $data->error . ': ' . $data->error_description);
        } else {
            tx_log($tx_id, 'error: ' . $e->getMessage());
            return Array('FAIL', $e->getMessage());
        }
    }

    return Array('NOCHANGE', PP_PAYPAL_REST_PAYPAL_CHECK_INTERVAL);
}


function pp_clear_session() {
    unset($_SESSION['PP_PAYPAL_REST_PAYPAL_CONTEXT']);
    unset($_SESSION['PAYMENT_TX_RETURN_OK_paymentId']);
    unset($_SESSION['PAYMENT_TX_RETURN_OK_PayerID']);
}

?>
