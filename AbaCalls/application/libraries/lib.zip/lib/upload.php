<?php

// Copyright (c) 2017 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class UploadedStreamMethodNotAllowed extends Exception { };

class UploadedStream {
    const TYPE_ROUTES = 1;
    const TYPE_RATES = 2;

    private $i_upload;
    private $i_environment;
    private $i_upload_type;
    private $token;
    private $prefix;
    private $file_path;
    private $fh;

    public function __construct($i_environment, $i_upload_type, $token, $prefix = 'UploadedStream') {
        $this->i_upload = NULL;
        $this->i_environment = $i_environment;
        $this->i_upload_type = $i_upload_type;
        $this->token = $token;
        $this->prefix = $prefix;
        $this->file_path = '';
        $this->fh = FALSE;
    }

    public function __destruct() {
        if ($this->fh !== FALSE) {
            fclose($this->fh);
        }
    }

    public function copyToFile() {
        global $db;

        /* consistency checks */
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            throw new UploadedStreamMethodNotAllowed();
        };

        $node = trim(file_get_contents('/SSP_ID'));

        $db->begin();

        $sql = "SELECT i_upload
                  FROM uploads
                 WHERE i_upload_type = ? AND token = ?
                       AND status = ? AND expires_on > now()
                       LIMIT 1
                   FOR UPDATE SKIP LOCKED";
        $params = Array($this->i_upload_type, $this->token, 'INIT_TOKEN');

        $this->i_upload = $db->getValue($sql, $params);

        if ($db->affected_rows != 1) {
            $db->rollback();
            throw new Exception('Token has not found');
        }

        /* copy streamed data */
        $in = fopen('php://input', 'r');
        $this->file_path = tempnam(sys_get_temp_dir(), $this->prefix . '.');
        chgrp($this->file_path, 'www');
        $this->fh = fopen($this->file_path, "w+");

        if (!stream_copy_to_stream($in, $this->fh)) {
            $db->rollback();
            throw new Exception('Unable to copy stream');
        };

        fclose($this->fh);
        $this->fh = FALSE;
        fclose($in);

        $new_file_path = sprintf('/var/env%d/upload/%s', $this->i_environment, basename($this->file_path));
        if (!rename($this->file_path, $new_file_path)) {
            $db->rollback();
            throw new Exception('Unable to rename file');
        }

        $this->file_path = $new_file_path;

        $sql = "UPDATE uploads
                   SET status = ?, file_path = ?, file_node = ?,
                       status_changed_on = now()
                 WHERE i_upload = ?";
        $params = Array('FILE_UPLOADED', $this->file_path, $node, $this->i_upload);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception("Cannot update uploads");
        }

        $db->commit();
    }

    public function cleanUp() {
        if ($this->file_path != '') {
            @unlink($this->file_path);
        }
    }

    /*
    public function getPath() {
        return $this->file_path;
    }
    */
}
?>
