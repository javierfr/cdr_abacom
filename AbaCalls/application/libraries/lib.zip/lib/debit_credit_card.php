<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Debit_Credit_Card {

    const TYPE_VISA = 1;
    const TYPE_AMERICAN_EXPRESS = 2;
    const TYPE_MASTER_CARD = 3;
    const TYPE_DISCOVER = 4;
    const TYPE_JCB = 5;
    const TYPE_DINERS_CLUB = 6;

    public $i_debit_credit_card;
    public $i_account;
    public $i_customer;
    public $alias;
    public $primary;
    public $i_card_type;
    public $holder;
    public $number;
    public $exp_mm;
    public $exp_yy;
    public $cvv;
    public $street_addr1;
    public $street_addr2;
    public $state;
    public $postal_code;
    public $city;
    public $country;
    public $phone;

    private $_fault;

    function __construct($i_account, $i_customer, $i_debit_credit_card = NULL) {

        $this->i_debit_credit_card = $i_debit_credit_card;
        $this->i_account = $i_account;
        $this->i_customer = $i_customer;
        $this->alias = '';
        $this->primary = FALSE;
        $this->i_card_type = self::TYPE_VISA;
        $this->holder = '';
        $this->number = '';
        $this->exp_mm = NULL;
        $this->exp_yy = NULL;
        $this->cvv = NULL;
        $this->street_addr1 = '';
        $this->street_addr2 = '';
        $this->state = '';
        $this->postal_code = '';
        $this->city = '';
        $this->country = NULL;
        $this->phone = '';

        if ($this->i_debit_credit_card !== NULL) {
            $this->getEntry($this->i_debit_credit_card);
        }

        $this->_fault = FALSE;
    }

    function __destruct() {
        /* nothing here */
    }

    private static function isOwnAccount($i_customer, $i_account) {
        global $db;

        $sql = 'SELECT i_account
                  FROM accounts
                 WHERE i_customer = ? AND i_account = ?
                 LIMIT 1';
        $params = Array($i_customer, $i_account);

        $c = $db->getValue($sql, $params);
        if ($c <= 0) {
            throw new Exception("No such Id.");
        }
    } 

    private static function isOwnSubcustomer($i_wholesaler, $i_customer) {
        global $db;

        $sql = 'SELECT i_customer
                  FROM customers
                 WHERE i_wholesaler = ? AND i_customer = ?
                 LIMIT 1';
        $params = Array($i_wholesaler, $i_customer);

        $c = $db->getValue($sql, $params);
        if ($c <= 0) {
            throw new Exception("No such Id.");
        }
    } 

    public static function getInstanceSafe($i_wholesaler, $type, $i_owner, $i_debit_credit_card = NULL) {
        switch ($type) {
            case 'account':
                self::isOwnAccount($i_wholesaler, $i_owner);
                break;

            case 'customer':
                self::isOwnSubcustomer($i_wholesaler, $i_owner);
                break;

            default:
                throw new Exception("Unable to getInstance(), wrong type ('" . $type . "')");
                break;

        }

        return self::getInstance($type, $i_owner, $i_debit_credit_card);
    }

    public static function getInstance($type, $i_owner, $i_debit_credit_card = NULL) {
        global $db;

        switch ($type) {
            case 'account':
                return new self($i_owner, 0, $i_debit_credit_card);
                break;

            case 'customer':
                return new self(0, $i_owner, $i_debit_credit_card);
                break;

            default:
                throw new Exception("Unable to getInstance(), wrong type ('" . $type . "')");
                break;
        }
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_debit_credit_card) {
        $params = Array();

        $params['l10n_lang'] = new xmlrpcval(getenv('LC_MESSAGES'), 'string');

        if ($this->i_account > 0) {
            $params['i_account'] = new xmlrpcval($this->i_account, 'i4');
        } else {
            $params['i_customer'] = new xmlrpcval($this->i_customer, 'i4');
        }

        $params['i_debit_credit_card'] = new xmlrpcval($i_debit_credit_card, 'i4');

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('getDebitCreditCardInfo', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->return_type = 'phpvals';
        $cli->setSSLVerifyPeer(false);

        $res = $cli->send($msg, 20);       /* 20 seconds timeout */

        if ($res->faultCode()) {
            throw new Exception($res->faultString());
        } elseif ($res->val['result'] != 'OK') {
            throw new Exception(_('Wrong responce from XMLRPC server.'));
        }

        $entry = $res->val;

        $this->i_debit_credit_card = $entry['i_debit_credit_card'];
        $this->alias = $entry['alias'];
        $this->primary = Cast::str2bool($entry['primary']);
        $this->i_card_type = $entry['i_card_type'];
        $this->holder = $entry['holder'];
        $this->number = $entry['number'];
        $this->exp_mm = $entry['exp_mm'];
        $this->exp_yy = $entry['exp_yy'] - 2000;
        $this->cvv = '';
        $this->street_addr1 = $entry['street_addr1'];
        $this->street_addr2 = $entry['street_addr2'];
        $this->state = $entry['state'];
        $this->postal_code = $entry['postal_code'];
        $this->city = $entry['city'];
        $this->country = $entry['country'];
        $this->phone = $entry['phone'];
    }

    public function initFromRequest($par) {
        if ($par['action'] == 'change') {
            $this->getEntry($par['i_debit_credit_card']);
        } else {
            $this->primary = Cast::str2bool($par['primary']);
            $this->i_card_type = $par['i_card_type'];
            $this->number = $par['card_number'];
            $this->cvv = $par['cvv'];
        }
        $this->i_debit_credit_card = $par['i_debit_credit_card'];
        $this->alias = $par['alias'];
        $this->holder = $par['holder'];
        $this->exp_mm = $par['exp_mm'];
        $this->exp_yy = $par['exp_yy'];
        $this->street_addr1 = $par['street_addr1'];
        $this->street_addr2 = $par['street_addr2'];
        $this->state = $par['state'];
        $this->postal_code = $par['postal_code'];
        $this->city = $par['city'];
        $this->country = $par['country'];
        $this->phone = $par['phone'];
    }

    public function getTotal() {
        global $db;

        $sql = "SELECT COUNT(*)
                  FROM debit_credit_cards dcc
                 WHERE dcc.i_account = ? OR dcc.i_customer = ?";
        $params = Array($this->i_account, $this->i_customer);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        $params = Array();

        if (!$_SESSION["debit_credit_cards_enabled"]) {
            return Array();
        }

        $params['l10n_lang'] = new xmlrpcval(getenv('LC_MESSAGES'), 'string');
        $params['offset'] = new xmlrpcval($off, 'i4');
        $params['limit'] = new xmlrpcval($rpp, 'i4');

        if ($this->i_account > 0) {
            $params['i_account'] = new xmlrpcval($this->i_account, 'i4');
        } else {
            $params['i_customer'] = new xmlrpcval($this->i_customer, 'i4');
        }

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('listDebitCreditCards', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->return_type = 'phpvals';
        $cli->setSSLVerifyPeer(false);

        $res = $cli->send($msg, 20);       /* 20 seconds timeout */

        if ($res->faultCode()) {
            throw new Exception($res->faultString());
        } elseif ($res->val['result'] != 'OK') {
            throw new Exception(_('Wrong responce from XMLRPC server.'));
        }

        $ret = $res->val['debit_credit_cards'];

        foreach(array_keys($ret) as $key) {
            $ret[$key]['exp_yy'] = $ret[$key]['exp_yy'] - 2000;
            $ret[$key]['primary'] = Cast::str2bool($ret[$key]['primary']);
        }

        return $ret;
    }

    public function add($par) {
        $this->setFault(TRUE);

        $params = Array();

        $params['l10n_lang'] = new xmlrpcval(getenv('LC_MESSAGES'), 'string');

        if ($this->i_account > 0) {
            $params['i_account'] = new xmlrpcval($this->i_account, 'i4');
        } else {
            $params['i_customer'] = new xmlrpcval($this->i_customer, 'i4');
        }

        $params['alias'] = new xmlrpcval($par['alias'], 'string');
        $params['primary'] = new xmlrpcval(Cast::str2bool($par['primary']), 'boolean');
        $params['i_card_type'] = new xmlrpcval($par['i_card_type'], 'i4');
        $params['holder'] = new xmlrpcval($par['holder'], 'string');
        $params['number'] = new xmlrpcval($par['card_number'], 'string');
        $params['exp_mm'] = new xmlrpcval($par['exp_mm'], 'int');
        $params['exp_yy'] = new xmlrpcval(2000 + $par['exp_yy'], 'int');
        $params['cvv'] = new xmlrpcval($par['cvv'], 'string');
        $params['street_addr1'] = new xmlrpcval($par['street_addr1'], 'string');
        $params['street_addr2'] = new xmlrpcval($par['street_addr2'], 'string');
        $params['state'] = new xmlrpcval($par['state'], 'string');
        $params['postal_code'] = new xmlrpcval($par['postal_code'], 'string');
        $params['city'] = new xmlrpcval($par['city'], 'string');
        $params['country'] = new xmlrpcval($par['country'], 'string');
        $params['phone'] = new xmlrpcval($par['phone'], 'string');

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('addDebitCreditCard', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->return_type = 'phpvals';
        $cli->setSSLVerifyPeer(false);

        $res = $cli->send($msg, 20);       /* 20 seconds timeout */

        if ($res->faultCode()) {
            throw new Exception($res->faultString());
        } elseif ($res->val['result'] != 'OK') {
            throw new Exception(_('Wrong responce from XMLRPC server.'));
        }

        $this->getEntry($res->val['i_debit_credit_card']);

        $this->setFault(FALSE);
    }

    public function update($par) {
        $this->setFault(TRUE);

        $params = Array();

        $params['l10n_lang'] = new xmlrpcval(getenv('LC_MESSAGES'), 'string');

        if ($this->i_account > 0) {
            $params['i_account'] = new xmlrpcval($this->i_account, 'i4');
        } else {
            $params['i_customer'] = new xmlrpcval($this->i_customer, 'i4');
        }

        $params['i_debit_credit_card'] = new xmlrpcval($par['i_debit_credit_card'], 'i4');
        $params['alias'] = new xmlrpcval($par['alias'], 'string');
        if (Cast::str2bool($par['primary'])) {
            $params['primary'] = new xmlrpcval(Cast::str2bool($par['primary']), 'boolean');
        }
        $params['holder'] = new xmlrpcval($par['holder'], 'string');
        $params['exp_mm'] = new xmlrpcval($par['exp_mm'], 'int');
        $params['exp_yy'] = new xmlrpcval(2000 + $par['exp_yy'], 'int');
        if ($par['cvv'] != '') {
            $params['cvv'] = new xmlrpcval($par['cvv'], 'string');
        }
        $params['street_addr1'] = new xmlrpcval($par['street_addr1'], 'string');
        $params['street_addr2'] = new xmlrpcval($par['street_addr2'], 'string');
        $params['state'] = new xmlrpcval($par['state'], 'string');
        $params['postal_code'] = new xmlrpcval($par['postal_code'], 'string');
        $params['city'] = new xmlrpcval($par['city'], 'string');
        $params['country'] = new xmlrpcval($par['country'], 'string');
        $params['phone'] = new xmlrpcval($par['phone'], 'string');

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('updateDebitCreditCard', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->return_type = 'phpvals';
        $cli->setSSLVerifyPeer(false);

        $res = $cli->send($msg, 20);       /* 20 seconds timeout */

        if ($res->faultCode()) {
            throw new Exception($res->faultString());
        } elseif ($res->val['result'] != 'OK') {
            throw new Exception(_('Wrong responce from XMLRPC server.'));
        }

        $this->getEntry($par['i_debit_credit_card']);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        $params = Array();

        $params['l10n_lang'] = new xmlrpcval(getenv('LC_MESSAGES'), 'string');

        if ($this->i_account > 0) {
            $params['i_account'] = new xmlrpcval($this->i_account, 'i4');
        } else {
            $params['i_customer'] = new xmlrpcval($this->i_customer, 'i4');
        }

        $params['i_debit_credit_card'] = new xmlrpcval($par['i_debit_credit_card'], 'i4');

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('deleteDebitCreditCard', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->return_type = 'phpvals';
        $cli->setSSLVerifyPeer(false);

        $res = $cli->send($msg, 20);       /* 20 seconds timeout */

        if ($res->faultCode()) {
            throw new Exception($res->faultString());
        } elseif ($res->val['result'] != 'OK') {
            throw new Exception(_('Wrong responce from XMLRPC server.'));
        }
    }

    public function getCardTypes() {
        global $db;

        $sql = "SELECT ct.i_card_type, ct.name
                  FROM card_types ct
                 WHERE debit_credit
              ORDER BY ct.name";

        return $db->getAll($sql);
    }

    public function initBillingAddress() {
        global $db;

        if ($this->i_account > 0) {
            $sql = "SELECT cn.street_addr, cn.state, cn.postal_code, cn.city, cn.country, cn.phone
                      FROM accounts a
                      JOIN contacts cn USING (i_contact)
                     WHERE a.i_account = ?
                     LIMIT 1";
            $params = Array($this->i_account);
        } else {        // customer
            $sql = "SELECT cn.street_addr, cn.state, cn.postal_code, cn.city, cn.country, cn.phone
                      FROM customers c
                      JOIN contacts cn USING (i_contact)
                     WHERE c.i_customer = ?
                     LIMIT 1";
            $params = Array($this->i_customer);
        }

        $res = $db->getAll($sql, $params);

        if ($db->affected_rows != 1) {
            return;
        }

        $this->street_addr1 = $res[0]['street_addr'];
        $this->state = $res[0]['state'];
        $this->postal_code = $res[0]['postal_code'];
        $this->city = $res[0]['city'];
        $this->phone = $res[0]['phone'];

        $res = $db->getValue('SELECT iso3166 FROM countries WHERE name ILIKE ? LIMIT 1', Array($res[0]['country']));
        if ($db->affected_rows == 1) {
            $this->country = $res;
        }
    }

}

?>
