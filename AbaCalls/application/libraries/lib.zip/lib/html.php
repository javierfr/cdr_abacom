<?php

// Copyright (c) 2003-2005 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

$cook = $_COOKIE;

$par = Array();
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $par = $_GET;
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $par = $_POST;
};

array_walk_recursive($cook, 'html_clean_up_recursive');
array_walk_recursive($par, 'html_clean_up_recursive');

/*
 *  Clean up the supplied values
 */

function html_clean_up_recursive(&$item, $key, $decode = TRUE) {
    $item = get_magic_quotes_gpc() ? stripslashes($item) : $item;
    if ($decode) {
        $item = html_entity_decode($item, ENT_COMPAT, 'UTF-8');
    }
}

/*
 * Return $par with html entities preserved
 */
function get_raw_par() {
    $res = Array();
    if ($_SERVER['REQUEST_METHOD'] == 'GET') {
        $res = $_GET;
    } elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $res = $_POST;
    };

    array_walk_recursive($res, 'html_clean_up_recursive', FALSE);

    return $res;
}

/*
 * get cookie from $cook array
 */
function get_cook($key) {

    global $cook;

    return array_key_exists($key, $cook) ? $cook[$key] : '';

};

/*
 * get parameter from $par array
 */
function get_par($key) {

    global $par;

    return array_key_exists($key, $par) ? $par[$key] : '';

};

/*
 * set parameter in $par array
 */
function set_par($key, $val) {

    global $par;

    $par[$key] = $val;

};

/*
 * check if parameter is set
 */
function isset_par($key) {

    global $par;

    return array_key_exists($key, $par);

};

?>
