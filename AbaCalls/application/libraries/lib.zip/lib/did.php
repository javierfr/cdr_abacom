<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class DID {

    public $i_did;
    public $i_customer;
    public $did;
    public $incoming_did;
    public $cli_translation_rule;
    public $translation_rule;
    public $country;
    public $dest_description;
    public $i_ivr_application;
    public $i_account;
    public $description;
    public $i_dids_charging_group;
    public $i_vendor;
    public $i_connection;
    public $buying_i_dids_charging_group;
    public $dd_description;
    public $dd_i_did_delegation;
    public $i_did_delegation;
    public $parent_i_did_delegation;
    public $dd_i_dids_charging_group;
    public $assigned_i_customer;
    public $customer_name;
    public $i_wholesaler;
    public $is_delegated;
    public $weak_auth;

    private $_fault;

    function __construct($i_customer, $i_did = NULL, $did = NULL) {
        $this->i_customer = $i_customer;
        $this->i_did = $i_did;
        $this->did = '';
        $this->incoming_did = '';
        $this->cli_translation_rule = '';
        $this->translation_rule = '';
        $this->country = '';
        $this->dest_description = '';
        $this->i_ivr_application = 0;
        $this->ivr_name = '';
        $this->i_account = 0;
        $this->account_name = '';
        $this->description = '';
        $this->i_dids_charging_group = 0;
        $this->i_vendor = 0;
        $this->i_connection = 0;
        $this->buying_i_dids_charging_group = 0;
        $this->dd_description = '';
        $this->dd_i_did_delegation = 0;
        $this->i_did_delegation = 0;
        $this->parent_i_did_delegation = 0;
        $this->dd_i_dids_charging_group = 0;
        $this->assigned_i_customer = 0;
        $this->customer_name = '';
        $this->i_wholesaler = 0;
        $this->is_delegated = FALSE;
        $this->weak_auth = FALSE;

        $this->_fault = FALSE;

        if ($this->i_did !== NULL) {
            $this->getEntry($this->i_did);
        } elseif ($did !== NULL) {
            $this->getEntry(NULL, $did);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_did, $did = NULL) {
        global $db;

        $get_by_field = ($did === NULL) ? 'i_did' : 'did';

        $sql = "SELECT DISTINCT ON (d.did) d.i_did, d.did, da.incoming_did,
                       da.cli_translation_rule, d.translation_rule,
                       dest.description AS dest_description,
                       cn.name AS country, d.i_ivr_application,
                       ia.name AS ivr_name, ir.i_account,
                       a.username || ' (' || a.base_currency || ')' AS account_name,
                       d.description, d.i_dids_charging_group, da.i_vendor, da.i_connection,
                       da.i_dids_charging_group AS buying_i_dids_charging_group,
                       dd.description AS dd_description,
                       dd.i_did_delegation AS dd_i_did_delegation,
                       dd2.i_did_delegation AS i_did_delegation,
                       dd2.parent_i_did_delegation AS parent_i_did_delegation,
                       dd2.i_dids_charging_group AS dd_i_dids_charging_group,
                       dd2.delegated_to AS assigned_i_customer,
                       c.name || ' (' || c.base_currency || ')' AS customer_name,
                       c_dd.i_wholesaler AS i_wholesaler,
                       dd.i_did_delegation IS NOT NULL AS is_delegated,
                       da2.i_did_authorization IS NOT NULL AS weak_auth
                  FROM dids d
                  JOIN did_authorizations da ON (da.i_did = d.i_did)
             LEFT JOIN did_authorizations da2 ON (da2.i_did = d.i_did AND da2.i_vendor IS NULL)
             LEFT JOIN incoming_routes ir ON (ir.i_did = d.i_did) 
             LEFT JOIN destinations dest ON (dest.prefix = ANY(prefixes(d.did)))
             LEFT JOIN countries cn ON (cn.iso = dest.country_iso)
             LEFT JOIN accounts a ON (ir.i_account = a.i_account)
             LEFT JOIN ivr_applications ia ON (d.i_ivr_application = ia.i_ivr_application)
             LEFT JOIN did_delegations dd ON (d.i_did = dd.i_did AND d.i_customer <> ?)
             LEFT JOIN did_delegations dd2 ON (d.i_did = dd2.i_did AND (
                                                  dd.i_did_delegation = dd2.parent_i_did_delegation
                                               OR dd2.delegated_to IN (SELECT i_customer
                                                                         FROM customers
                                                                        WHERE i_wholesaler = ?)))
             LEFT JOIN customers c_dd ON (dd.delegated_to = c_dd.i_customer)
             LEFT JOIN customers c ON (dd2.delegated_to = c.i_customer)
                 WHERE (d.i_customer = ? OR dd.delegated_to = ?) AND d." . $get_by_field . " = ?
              ORDER BY d.did, da.i_did_authorization, length(dest.prefix) DESC
                 LIMIT 1";
        $params = Array($this->i_customer, $this->i_customer, $this->i_customer,
                        $this->i_customer, ($did === NULL) ? $i_did : $did);
        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception(($did === NULL) ? _("No such Id.") : _("No such DID."));
        }

        $this->i_did = $entry['i_did'];
        $this->did = $entry['did'];
        $this->incoming_did = $entry['incoming_did'];
        $this->cli_translation_rule = $entry['cli_translation_rule'];
        $this->translation_rule = $entry['translation_rule'];
        $this->country = $entry['country'];
        $this->dest_description = $entry['dest_description'];
        $this->i_ivr_application = $entry['i_ivr_application'] > 0 ? $entry['i_ivr_application'] : 0;
        $this->ivr_name = $entry['ivr_name'];
        $this->i_account = $entry['i_account'] > 0 ? $entry['i_account'] : 0;
        $this->account_name = $entry['account_name'];
        $this->description = $entry['description'];
        $this->i_dids_charging_group = $entry['i_dids_charging_group'] > 0 ? $entry['i_dids_charging_group'] : 0;
        $this->i_vendor = $entry['i_vendor'] > 0 ? $entry['i_vendor'] : 0;
        $this->i_connection = $entry['i_connection'] > 0 ? $entry['i_connection'] : 0;
        $this->buying_i_dids_charging_group = $entry['buying_i_dids_charging_group'] > 0 ?
                                              $entry['buying_i_dids_charging_group'] : 0;
        $this->dd_description = $entry['dd_description'];
        $this->dd_i_did_delegation = $entry['dd_i_did_delegation'];
        $this->i_did_delegation = $entry['i_did_delegation'];
        $this->parent_i_did_delegation = $entry['parent_i_did_delegation'];
        $this->dd_i_dids_charging_group = $entry['dd_i_dids_charging_group'];
        $this->assigned_i_customer = $entry['assigned_i_customer'];
        $this->customer_name = $entry['customer_name'];
        $this->i_wholesaler = $entry['i_wholesaler'];
        $this->is_delegated = Cast::str2bool($entry['is_delegated']);
        $this->weak_auth = Cast::str2bool($entry['weak_auth']);

        if ($this->assigned_i_customer > 0) {
            $this->i_dids_charging_group = $this->dd_i_dids_charging_group;
        }
    }

    public function prepare_par(&$par) {
        global $db;

        list($type, $id) = explode('_', $par['assigned_to']);
        switch ($type) {
            case '1':
                $par['i_ivr_application'] = $id;
                $par['ivr_name'] = $db->getValue('SELECT name FROM ivr_applications WHERE i_ivr_application = ?',
                                                Array($id));
                $par['i_account'] = 0;
                $par['assigned_i_customer'] = 0;
                break;
            case '2':
                $par['i_ivr_application'] = 0;
                $par['i_account'] = $id;
                $par['account_name'] = $db->getValue("SELECT username || ' (' || base_currency || ')'
                                                        FROM accounts
                                                       WHERE i_account = ?", Array($id));
                $par['assigned_i_customer'] = 0;
                break;
            case '3':
                $par['i_ivr_application'] = 0;
                $par['i_account'] = 0;
                $par['assigned_i_customer'] = $id;
                $par['customer_name'] = $db->getValue("SELECT name || ' (' || base_currency || ')'
                                                         FROM customers
                                                        WHERE i_customer = ?", Array($id));
                break;
            default:
                $par['i_ivr_application'] = 0;
                $par['i_account'] = 0;
                $par['assigned_i_customer'] = 0;
                break;
        }
    }

    public function initFromRequest($par) {
        $this->i_did = $par['i_did'];
        if (!$this->is_delegated) { 
            $this->did = $par['did'];
            $this->description = $par['description'];
        }
        $this->incoming_did = $par['incoming_did'];
        $this->cli_translation_rule = $par['cli_translation_rule'];
        $this->translation_rule = $par['translation_rule'];
        $this->i_ivr_application = $par['i_ivr_application'];
        $this->ivr_name = $par['ivr_name'];
        $this->i_account = $par['i_account'];
        $this->account_name = $par['account_name'];
        $this->i_dids_charging_group = $par['i_dids_charging_group'];
        $this->i_vendor = $par['i_vendor'];
        $this->i_connection = $par['i_connection'];
        $this->buying_i_dids_charging_group = $par['buying_i_dids_charging_group'];
        $this->dd_description = $par['description'];
        $this->assigned_i_customer =  $par['assigned_i_customer'];
        $this->customer_name = $par['customer_name'];
    }

    public function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('did_pattern') != '') {
            $ret['sql'] .= " AND d.did" . (get_par('did_clause') == 1 ? ' NOT' : '') . " LIKE ?";
            $ret['params'][] = get_par('did_pattern');
        }

        if (get_par('incoming_did_pattern') != '') {
            $ret['sql'] .= " AND da.incoming_did" . (get_par('incoming_did_clause') == 1 ? ' NOT' : '') . " LIKE ?";
            $ret['params'][] = get_par('incoming_did_pattern');
        }

        if (get_par('country_pattern') != '') {
            $ret['sql'] .= ' AND cn.name ' . (get_par('country_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('country_pattern');
        }

        if (get_par('dest_description_pattern') != '') {
            $ret['sql'] .= ' AND dest.description ' . (get_par('dest_description_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('dest_description_pattern');
        }

        if (get_par('assigned_to_filter') != '') {
            list($type, $id) = explode('_', get_par('assigned_to_filter'));
            switch ($type) {
                case '1':
                    $ret['sql'] .= ' AND d.i_ivr_application = ?';
                    $ret['params'][] = $id;
                    break;

                case '2':
                    $ret['sql'] .= ' AND ir.i_account = ?';
                    $ret['params'][] = $id;
                    break;

                case '3':
                    $ret['sql'] .= ' AND c.i_customer = ?';
                    $ret['params'][] = $id;
                    break;

                case '0':
                    $ret['sql'] .= ' AND d.i_ivr_application ISNULL AND ir.i_account ISNULL AND dd2.delegated_to ISNULL';
                    $ret['params'][] = $id;
                    break;
            }
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(*) FROM (
                SELECT DISTINCT ON (d.i_did) COUNT(d.*)
                  FROM dids d
                  JOIN did_authorizations da ON (da.i_did = d.i_did)
             LEFT JOIN incoming_routes ir ON (ir.i_did = d.i_did)
             LEFT JOIN destinations dest ON (dest.prefix = ANY(prefixes(d.did)))
             LEFT JOIN countries cn ON (cn.iso = dest.country_iso)
             LEFT JOIN did_delegations dd ON (d.i_did = dd.i_did AND d.i_customer <> ?)
             LEFT JOIN did_delegations dd2 ON (d.i_did = dd2.i_did AND (
                                                  dd.i_did_delegation = dd2.parent_i_did_delegation
                                               OR dd2.delegated_to IN (SELECT i_customer
                                                                         FROM customers
                                                                        WHERE i_wholesaler = ?)))
             LEFT JOIN customers c ON (dd2.delegated_to = c.i_customer)
                 WHERE (d.i_customer = ? OR dd.delegated_to = ?)
                       {$clause['sql']}
              GROUP BY d.i_did, dest.prefix
              ORDER BY d.i_did, length(dest.prefix) DESC) AS foo";

        $params = Array($this->i_customer, $this->i_customer, $this->i_customer, $this->i_customer);
        $params = array_merge($params, $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT DISTINCT ON (d.did) d.i_did, d.did, d.translation_rule,
                       dest.description AS dest_description, cn.name AS country,
                       a.i_account AS i_account, a.username AS username,
                       ia.name AS ivr_name, d.i_ivr_application AS assigned_i_ivr_application,
                       ir.i_account AS assigned_i_account, a2.username AS account_name,
                       a.i_customer = ? AS own_account, c_hd.name AS c_name,
                       get_ivr_app_exclusive_mode(d.i_ivr_application) AS sd_em,
                       d.description, dd.description AS dd_description,
                       dd2.delegated_to AS assigned_i_customer, c.name AS customer_name,
                       dd.i_did_delegation IS NOT NULL AS is_delegated,
                       da2.i_did_authorization IS NOT NULL AS weak_auth
                  FROM dids d
                  JOIN did_authorizations da ON (da.i_did = d.i_did)
             LEFT JOIN did_authorizations da2 ON (da2.i_did = d.i_did AND da2.i_vendor IS NULL)
             LEFT JOIN incoming_routes ir ON (ir.i_did = d.i_did) 
             LEFT JOIN hot_dial_keys hd ON (hd.i_did = d.i_did)
             LEFT JOIN accounts a ON (hd.i_account = a.i_account)
             LEFT JOIN accounts a2 ON (ir.i_account = a2.i_account)
             LEFT JOIN destinations dest ON (dest.prefix = ANY(prefixes(d.did)))
             LEFT JOIN countries cn ON (cn.iso = dest.country_iso)
             LEFT JOIN ivr_applications ia ON (d.i_ivr_application = ia.i_ivr_application)
             LEFT JOIN customers c_hd ON (get_nearest_i_customer(?, a.i_customer) = c_hd.i_customer)
             LEFT JOIN did_delegations dd ON (d.i_did = dd.i_did AND d.i_customer <> ?)
             LEFT JOIN did_delegations dd2 ON (d.i_did = dd2.i_did AND (
                                                  dd.i_did_delegation = dd2.parent_i_did_delegation
                                               OR dd2.delegated_to IN (SELECT i_customer
                                                                         FROM customers
                                                                        WHERE i_wholesaler = ?)))
             LEFT JOIN customers c ON (dd2.delegated_to = c.i_customer)
                 WHERE (d.i_customer = ? OR dd.delegated_to = ?)
                       {$clause['sql']}
              ORDER BY d.did, length(dest.prefix) DESC
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = Array($this->i_customer, $this->i_customer, $this->i_customer,
                        $this->i_customer, $this->i_customer, $this->i_customer);
        $params = array_merge($params, $clause['params']);

        $ret = $db->getAll($sql, $params);

        foreach(array_keys($ret) as $key) {
            $ret[$key]['sd_em'] = Cast::str2bool($ret[$key]['sd_em']);
            $ret[$key]['own_account'] = Cast::str2bool($ret[$key]['own_account']);
            $ret[$key]['is_delegated'] = Cast::str2bool($ret[$key]['is_delegated']);
            $ret[$key]['weak_auth'] = Cast::str2bool($ret[$key]['weak_auth']);
        }

        return $ret;
    }

    public function getExportQuery() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT DISTINCT ON (d.did) d.i_did, d.did, da.incoming_did,
                       da.cli_translation_rule, d.translation_rule,
                       dest.description AS dest_description,
                       cn.name AS country, a.username AS username,
                       a.i_account AS i_account,
                       d.i_ivr_application AS assigned_i_ivr_application,
                       ir.i_account AS assigned_i_account,
                       a.i_customer = ? AS own_account, c_hd.name AS c_name,
                       get_ivr_app_exclusive_mode(d.i_ivr_application) AS sd_em,
                       d.description, d.i_dids_charging_group,
                       da.i_vendor, da.i_connection,
                       da.i_dids_charging_group AS buying_i_dids_charging_group,
                       dd.description AS dd_description,
                       dd2.delegated_to AS assigned_i_customer,
                       dd2.i_dids_charging_group AS dd_i_dids_charging_group,
                       dd.i_did_delegation IS NOT NULL AS is_delegated
                  FROM dids d
                  JOIN did_authorizations da ON (da.i_did = d.i_did)
             LEFT JOIN incoming_routes ir ON (ir.i_did = d.i_did) 
             LEFT JOIN hot_dial_keys hd ON (hd.i_did = d.i_did)
             LEFT JOIN accounts a ON (hd.i_account = a.i_account)
             LEFT JOIN accounts a2 ON (ir.i_account = a2.i_account)
             LEFT JOIN destinations dest ON (dest.prefix = ANY(prefixes(d.did)))
             LEFT JOIN countries cn ON (cn.iso = dest.country_iso)
             LEFT JOIN customers c_hd ON (get_nearest_i_customer(?, a.i_customer) = c_hd.i_customer)
             LEFT JOIN did_delegations dd ON (d.i_did = dd.i_did AND d.i_customer <> ?)
             LEFT JOIN did_delegations dd2 ON (d.i_did = dd2.i_did AND (
                                                  dd.i_did_delegation = dd2.parent_i_did_delegation
                                               OR dd2.delegated_to IN (SELECT i_customer
                                                                         FROM customers
                                                                        WHERE i_wholesaler = ?)))
             LEFT JOIN customers c ON (dd2.delegated_to = c.i_customer)
                 WHERE (d.i_customer = ? OR dd.delegated_to = ?)
                       {$clause['sql']}
              ORDER BY d.did, da.i_did_authorization, length(dest.prefix) DESC";

        $params = Array($this->i_customer, $this->i_customer, $this->i_customer,
                        $this->i_customer, $this->i_customer, $this->i_customer);
        $params = array_merge($params, $clause['params']);

        return Array($sql, $params);
    }

    public function add($par) {
        $this->setFault(TRUE);

        $params = Array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'did' => new xmlrpcval($par['did'], "string"),
            'incoming_did' => new xmlrpcval($par['incoming_did'], "string"),
            'cli_translation_rule' => new xmlrpcval($par['cli_translation_rule'], "string"),
            'translation_rule' => new xmlrpcval($par['translation_rule'], "string"),
            'i_ivr_application' => new xmlrpcval($par['i_ivr_application'],
                                                 $par['i_ivr_application'] > 0 ? 'int' : 'null'),
            'i_account' => new xmlrpcval($par['i_account'], $par['i_account'] > 0 ? 'int' : 'null'),
            'i_vendor' => new xmlrpcval($par['i_vendor'], $par['i_vendor'] > 0 ? 'int' : 'null'),
            'i_connection' => new xmlrpcval($par['i_connection'], $par['i_connection'] > 0 ? 'int' : 'null'),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
        );

        if (!$par['assigned_i_customer'] > 0) {
            $params = array_merge(
                $params,
                Array(
                    'description' => new xmlrpcval($par['description'], "string"),
                    'i_dids_charging_group' => new xmlrpcval($par['i_dids_charging_group'],
                                                             $par['i_dids_charging_group'] > 0 ? 'int' : 'null'),
                )
            );
        }

        if ($par['i_vendor'] > 0 && $par['i_connection'] > 0) {
            $params = array_merge(
                $params,
                Array(
                    'buying_i_dids_charging_group' =>
                        new xmlrpcval($par['buying_i_dids_charging_group'],
                                      $par['buying_i_dids_charging_group'] > 0 ? 'int' : 'null')
                )
            );
        }

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('addDID', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $i_did = $res->val['i_did'];

        if ($par['assigned_i_customer'] > 0) {
            $params = Array(
                'i_customer' => new xmlrpcval($this->i_customer, "int"),
                'i_did' => new xmlrpcval($i_did, "int"),
                'delegated_to' => new xmlrpcval($par['assigned_i_customer'], "int"),
                'description' => new xmlrpcval($par['description'], "string"),
                'parent_i_did_delegation' => new xmlrpcval('', 'null'),
                'i_dids_charging_group' => new xmlrpcval($par['i_dids_charging_group'],
                                                         $par['i_dids_charging_group'] > 0 ? 'int' : 'null'),
                'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
            );
            $params = array(new xmlrpcval($params, 'struct'));
            $msg = new xmlrpcmsg('addDIDDelegation', $params);

            $master_addr = get_master_XMLRPC_server();
            $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
            $cli->setSSLVerifyPeer(false);
            $cli->return_type = 'phpvals';

            $res = $cli->send($msg);
            if ($res->faultCode()) {
                /* do rolback */
                try {
                    $this->delete(Array('i_did' => $i_did));
                } catch(Exception $e) { /* ignore any error */ };

                throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            }
        }

        $this->getEntry($i_did);

        $this->setFault(FALSE);
    }

    public function update($par, $by_did = FALSE, $update_did_auth = FALSE) {
        $this->setFault(TRUE);

        if ($par['i_ivr_application'] > 0 && $par['assigned_i_customer'] > 0) {
            throw new Exception(_('Assign either to Customer or IVR Application.'));
        }

        if ($par['i_account'] > 0 && $par['assigned_i_customer'] > 0) {
            throw new Exception(_('Assign either to Customer or Account.'));
        }

        /* i_ivr_application and i_account are checked in XMLAPI */

        $params = array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct"),
            'translation_rule' => new xmlrpcval($par['translation_rule'], "string")
        );

        if ($par['i_ivr_application'] > 0) {
            /* assigned to IVR */
            $params['i_ivr_application'] = new xmlrpcval($par['i_ivr_application'], 'int');
        } elseif ($par['i_account'] > 0) {
            /* assigned to Account */
            $params['i_account'] = new xmlrpcval($par['i_account'], 'int');
        } elseif ($par['i_account'] == 0 && $par['i_ivr_application'] == 0 &&  $par['assigned_i_customer'] == 0) {
            /* Not Assigned */
            $params['i_ivr_application'] = new xmlrpcval($par['i_ivr_application'], 'null');
            $params['i_account'] = new xmlrpcval($par['i_account'], 'null');
        }

        if ($par['i_ivr_application'] > 0 || $par['i_account'] > 0 || $par['assigned_i_customer'] == 0) {
            $params['i_dids_charging_group'] = new xmlrpcval($par['i_dids_charging_group'],
                                                             $par['i_dids_charging_group'] > 0 ? 'int' : 'null');
        }

        if (!$this->is_delegated) {
            $params['did'] = new xmlrpcval($par['did'], "string");
            $params['description'] = new xmlrpcval($par['description'], "string");

            if ($update_did_auth) {
                $params['incoming_did'] = new xmlrpcval($par['incoming_did'], "string");
                $params['cli_translation_rule'] = new xmlrpcval($par['cli_translation_rule'], "string");
                $params['i_vendor'] = new xmlrpcval($par['i_vendor'], $par['i_vendor'] > 0 ? 'int' : 'null');
                $params['i_connection'] = new xmlrpcval($par['i_connection'], $par['i_connection'] > 0 ? 'int' : 'null');
                if ($par['i_vendor'] > 0 && $par['i_connection'] > 0) {
                    $params['buying_i_dids_charging_group'] =
                                new xmlrpcval($par['buying_i_dids_charging_group'],
                                              $par['buying_i_dids_charging_group'] > 0 ? 'int' : 'null');
                }
            }
        } else {
            $params['did'] = new xmlrpcval($this->did, "string");
            /* update the description to avoid 'nothing to update' error */
            $params['description'] = new xmlrpcval($this->description, "string");
        }

        if (!$by_did) {
            $params['i_did'] =  new xmlrpcval($par['i_did'], "int");
        }

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('updateDID', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $i_did = $res->val['i_did'];

        if ($this->assigned_i_customer > 0 && $par['assigned_i_customer'] == 0 && 
            $par['i_ivr_application'] == 0 && $par['i_account'] == 0) {
            /* delete entry from did_delegations */
            /* need to delete only if it was not assigned to an account neither IVR */
            $params = Array(
                'i_customer' => new xmlrpcval($this->i_customer, "int"),
                'i_did_delegation' => new xmlrpcval($this->i_did_delegation, "int"),
                'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
            );
            $params = array(new xmlrpcval($params, 'struct'));
            $msg = new xmlrpcmsg('deleteDIDDelegation', $params);

            $master_addr = get_master_XMLRPC_server();
            $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
            $cli->setSSLVerifyPeer(false);
            $cli->return_type = 'phpvals';

            $res = $cli->send($msg);
            if ($res->faultCode()) {
                throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            }

        } elseif (!$this->assigned_i_customer > 0 && $par['assigned_i_customer'] > 0) {
            /* add new entry to did_delegations */
            $params = Array(
                'i_customer' => new xmlrpcval($this->i_customer, "int"),
                'i_did' => new xmlrpcval($i_did, "int"),
                'delegated_to' => new xmlrpcval($par['assigned_i_customer'], "int"),
                'parent_i_did_delegation' => new xmlrpcval($this->dd_i_did_delegation,
                                                           $this->is_delegated ? 'int' : 'null'),
                'i_dids_charging_group' => new xmlrpcval($par['i_dids_charging_group'],
                                                         $par['i_dids_charging_group'] > 0 ? 'int' : 'null'),
                'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
            );
            $params = array(new xmlrpcval($params, 'struct'));
            $msg = new xmlrpcmsg('addDIDDelegation', $params);

            $master_addr = get_master_XMLRPC_server();
            $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
            $cli->setSSLVerifyPeer(false);
            $cli->return_type = 'phpvals';

            $res = $cli->send($msg);
            if ($res->faultCode()) {
                throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            }

        } elseif ($this->assigned_i_customer > 0 && $par['assigned_i_customer'] > 0) {
            /* update an existing entry in did_delegations */
            $params = Array(
                'i_did_delegation' => new xmlrpcval($this->i_did_delegation, "int"),
                'i_customer' => new xmlrpcval($this->i_customer, "int"),
                'delegated_to' => new xmlrpcval($par['assigned_i_customer'], "int"),
                'i_dids_charging_group' => new xmlrpcval($par['i_dids_charging_group'],
                                                         $par['i_dids_charging_group'] > 0 ? 'int' : 'null'),
                'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
            );
            $params = array(new xmlrpcval($params, 'struct'));
            $msg = new xmlrpcmsg('updateDIDDelegation', $params);

            $master_addr = get_master_XMLRPC_server();
            $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
            $cli->setSSLVerifyPeer(false);
            $cli->return_type = 'phpvals';

            $res = $cli->send($msg);
            if ($res->faultCode()) {
                throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            }

        }

        /* update description of delegated DID */
        if ($this->is_delegated) {
            $params = Array(
                'i_did_delegation' => new xmlrpcval($this->dd_i_did_delegation, "int"),
                'i_customer' => new xmlrpcval($this->i_wholesaler, "int"),
                'description' => new xmlrpcval($par['description'], "string"),
                'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
            );
            $params = array(new xmlrpcval($params, 'struct'));
            $msg = new xmlrpcmsg('updateDIDDelegation', $params);

            $master_addr = get_master_XMLRPC_server();
            $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
            $cli->setSSLVerifyPeer(false);
            $cli->return_type = 'phpvals';

            $res = $cli->send($msg);
            if ($res->faultCode()) {
                throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            }
        }

        $this->getEntry($i_did);

        $this->setFault(FALSE);
    }

    public function updateByDID($par, $update_did_auth = FALSE) {
        $this->update($par, TRUE, $update_did_auth);
    }


    public function delete($par) {
        $params = array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'i_did' =>  new xmlrpcval($par['i_did'], "int"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct")
        );

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('deleteDID', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }
    }

}

?>
