<?php

// Copyright (c) 2016 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Vendor {

    public $i_customer;

    public $i_vendor;
    public $name;
    public $web_login;
    public $i_time_zone;
    public $balance;
    public $base_currency;
    public $i_lang;
    public $web_password;
    public $i_export_type;
    public $i_password_policy;
    public $round_up;
    public $decimal_precision;
    public $cost_round_up;

    public $company_name;
    public $salutation;
    public $first_name;
    public $mid_init;
    public $last_name;
    public $street_addr;
    public $state;
    public $postal_code;
    public $city;
    public $country;
    public $contact;
    public $phone;
    public $fax;
    public $alt_phone;
    public $alt_contact;
    public $email;
    public $cc;
    public $bcc;

    private $_fault;

    function __construct($i_customer, $i_vendor = NULL) {
        $this->i_customer = $i_customer;

        $this->i_vendor = $i_vendor;
        $this->name = '';
        $this->web_login = '';
        $this->i_time_zone = $_SESSION['i_time_zone'];
        $this->balance = 0;
        $this->base_currency = NULL;
        $this->i_lang = 'en';
        $this->web_password = '';
        $this->i_export_type = 2;
        $this->i_password_policy = 1;
        $this->round_up = FALSE;
        $this->decimal_precision = 20;
        $this->cost_round_up = FALSE;

        $this->company_name = '';
        $this->salutation = '';
        $this->first_name = '';
        $this->mid_init = '';
        $this->last_name = '';
        $this->street_addr = '';
        $this->state = '';
        $this->postal_code = '';
        $this->city = '';
        $this->country = '';
        $this->contact = '';
        $this->phone = '';
        $this->fax = '';
        $this->alt_phone = '';
        $this->alt_contact = '';
        $this->email = '';
        $this->cc = '';
        $this->bcc = '';

        $this->_fault = FALSE;

        if ($this->i_vendor !== NULL) {
            $this->getEntry($this->i_vendor);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_vendor) {
        $params = Array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),
            "i_vendor" => new xmlrpcval($i_vendor, "int"),
        );
        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('getVendorInfo', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $entry = $res->val['vendor'];

        $this->i_vendor = $entry['i_vendor'];
        $this->name = $entry['name'];
        $this->web_login = $entry['web_login'];
        $this->i_time_zone = $entry['i_time_zone'];
        $this->base_currency = $entry['base_currency'];
        $this->balance = $entry['balance'];
        $this->i_lang = $entry['i_lang'];
        $this->i_export_type = $entry['i_export_type'];
        $this->i_password_policy = $entry['i_password_policy'];
        $this->round_up = Cast::str2bool($entry['round_up']);
        $this->decimal_precision = $entry['decimal_precision'];
        $this->cost_round_up = Cast::str2bool($entry['cost_round_up']);

        $this->company_name = $entry['company_name'];
        $this->salutation = $entry['salutation'];
        $this->first_name = $entry['first_name'];
        $this->mid_init = $entry['mid_init'];
        $this->last_name = $entry['last_name'];
        $this->street_addr = $entry['street_addr'];
        $this->state = $entry['state'];
        $this->postal_code = $entry['postal_code'];
        $this->city = $entry['city'];
        $this->country = $entry['country'];
        $this->contact = $entry['contact'];
        $this->phone = $entry['phone'];
        $this->fax = $entry['fax'];
        $this->alt_phone = $entry['alt_phone'];
        $this->alt_contact = $entry['alt_contact'];
        $this->email = $entry['email'];
        $this->cc = $entry['cc'];
        $this->bcc = $entry['bcc'];
    }

    public function initFromRequest($par) {
        $this->name = $par['name'];
        $this->web_login = $par['web_login'];
        $this->i_time_zone = $par['i_time_zone'];
        $this->base_currency = $par['base_currency'];
        $this->balance = $par['balance'];
        $this->i_lang = $par['i_lang'];
        $this->i_export_type = $par['i_export_type'];
        $this->i_password_policy = $par['i_password_policy'];
        $this->round_up = Cast::str2bool($par['round_up']);
        $this->decimal_precision = $par['decimal_precision'];
        $this->cost_round_up = Cast::str2bool($par['cost_round_up']);

        $this->company_name = $par['company_name'];
        $this->salutation = $par['salutation'];
        $this->first_name = $par['first_name'];
        $this->mid_init = $par['mid_init'];
        $this->last_name = $par['last_name'];
        $this->street_addr = $par['street_addr'];
        $this->state = $par['state'];
        $this->postal_code = $par['postal_code'];
        $this->city = $par['city'];
        $this->country = $par['country'];
        $this->contact = $par['contact'];
        $this->phone = $par['phone'];
        $this->fax = $par['fax'];
        $this->alt_phone = $par['alt_phone'];
        $this->alt_contact = $par['alt_contact'];
        $this->email = $par['email'];
        $this->cc = $par['cc'];
        $this->bcc = $par['bcc'];
    }

    public function buildClause() {
        $ret = Array('sql' => '',
                     'params' => Array(),
                     'xml_params' => Array());

        if (get_par('vendor_name_filter') != '') {
            $ret['sql'] = " AND v.name ILIKE ?";
            $ret['params'] = '%' . get_par('vendor_name_filter') . '%';
            $ret['xml_params'] = Array(
                "name_pattern" => new xmlrpcval('%' . get_par('vendor_name_filter') . '%', "string"),
            );
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(v.*)
                  FROM vendors v
                 WHERE NOT v.system
                       {$clause['sql']}";

        $params = $clause['params'];

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        $clause = $this->buildClause();

        $params = Array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),
            "limit" => new xmlrpcval($rpp, "int"),
            "offset" => new xmlrpcval($off, "int"),
        );
        $params = array_merge($params, $clause['xml_params']);
        $params = array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('listVendors', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $ret = $res->val['vendors'];

        foreach ($ret as &$entry) {
            $entry['balance'] = X_Rates::convert2base_c($this->i_customer, $entry['base_currency'], $entry['balance']);
        }

        return $ret;
    }

    public function add($par) {
        $this->setFault(TRUE);

        $params = Array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),

            'name' => new xmlrpcval($par['name'], "string"),
            'web_login' => new xmlrpcval($par['web_login'], "string"),
            'web_password' => new xmlrpcval($par['web_password'], "string"),
            'i_time_zone' => new xmlrpcval($par['i_time_zone'], "int"),
            'base_currency' => new xmlrpcval($par['base_currency'], "string"),
            'i_lang' => new xmlrpcval($par['i_lang'], "string"),
            'i_export_type' => new xmlrpcval($par['i_export_type'], "int"),
            'i_password_policy' => new xmlrpcval($par['i_password_policy'], "int"),
            'round_up' => new xmlrpcval(Cast::str2bool($par['round_up']), "boolean"),
            'decimal_precision' => new xmlrpcval($par['decimal_precision'], "int"),
            'cost_round_up' => new xmlrpcval(Cast::str2bool($par['cost_round_up']), "boolean"),

            "company_name" => new xmlrpcval($par['company_name'], "string"),
            "salutation" => new xmlrpcval($par['salutation'], "string"),
            "first_name" => new xmlrpcval($par['first_name'], "string"),
            "last_name" => new xmlrpcval($par['last_name'], "string"),
            "mid_init" => new xmlrpcval($par['mid_init'], "string"),
            "street_addr" => new xmlrpcval($par['street_addr'], "string"),
            "state" => new xmlrpcval($par['state'], "string"),
            "postal_code" => new xmlrpcval($par['postal_code'], "string"),
            "country" => new xmlrpcval($par['country'], "string"),
            "contact" => new xmlrpcval($par['contact'], "string"),
            "phone" => new xmlrpcval($par['phone'], "string"),
            "fax" => new xmlrpcval($par['fax'], "string"),
            "alt_phone" => new xmlrpcval($par['alt_phone'], "string"),
            "alt_contact" => new xmlrpcval($par['alt_contact'], "string"),
            "city" => new xmlrpcval($par['city'], "string"),
            "email" => new xmlrpcval($par['email'], "string"),
            "cc" => new xmlrpcval($par['cc'], "string"),
            "bcc" => new xmlrpcval($par['bcc'], "string"),
        );

        if ($par['balance'] > 0) {
            $params["balance"] = new xmlrpcval($par['balance'], "double");
        }

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('createVendor', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $i_vendor = $res->val['i_vendor'];

        $this->getEntry($i_vendor);

        $this->setFault(FALSE);
    }

    public function update($par) {
        $this->setFault(TRUE);

        $params = array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),

            'i_vendor' => new xmlrpcval($par['i_vendor'], "int"),
            'name' => new xmlrpcval($par['name'], "string"),
            'web_login' => new xmlrpcval($par['web_login'], "string"),
            'i_time_zone' => new xmlrpcval($par['i_time_zone'], "int"),
            'i_lang' => new xmlrpcval($par['i_lang'], "string"),
            'i_export_type' => new xmlrpcval($par['i_export_type'], "int"),
            'i_password_policy' => new xmlrpcval($par['i_password_policy'], "int"),
            'round_up' => new xmlrpcval(Cast::str2bool($par['round_up']), "boolean"),
            'decimal_precision' => new xmlrpcval($par['decimal_precision'], "int"),
            'cost_round_up' => new xmlrpcval(Cast::str2bool($par['cost_round_up']), "boolean"),

            "company_name" => new xmlrpcval($par['company_name'], "string"),
            "salutation" => new xmlrpcval($par['salutation'], "string"),
            "first_name" => new xmlrpcval($par['first_name'], "string"),
            "last_name" => new xmlrpcval($par['last_name'], "string"),
            "mid_init" => new xmlrpcval($par['mid_init'], "string"),
            "street_addr" => new xmlrpcval($par['street_addr'], "string"),
            "state" => new xmlrpcval($par['state'], "string"),
            "postal_code" => new xmlrpcval($par['postal_code'], "string"),
            "country" => new xmlrpcval($par['country'], "string"),
            "contact" => new xmlrpcval($par['contact'], "string"),
            "phone" => new xmlrpcval($par['phone'], "string"),
            "fax" => new xmlrpcval($par['fax'], "string"),
            "alt_phone" => new xmlrpcval($par['alt_phone'], "string"),
            "alt_contact" => new xmlrpcval($par['alt_contact'], "string"),
            "city" => new xmlrpcval($par['city'], "string"),
            "email" => new xmlrpcval($par['email'], "string"),
            "cc" => new xmlrpcval($par['cc'], "string"),
            "bcc" => new xmlrpcval($par['bcc'], "string"),
        );

        if ($par['web_password'] != '') {
            $params["web_password"] = new xmlrpcval($par['web_password'], "string");
        }

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('updateVendor', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->getEntry($par['i_vendor']);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        $params = array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),

            'i_vendor' => new xmlrpcval($par['i_vendor'], "int"),
        );

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('deleteVendor', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }
    }

    public function update_balance($par) {
        $do = $par['do'];
        if ($do == '1') {           /* manual charge */
            $method = 'vendorDebit';
        } elseif ($do == '2') {     /* manual refund */
            $method = 'vendorCredit';
        } elseif ($do == '3') {     /* add funds */
            $method = 'vendorAddFunds';
        } else {
            /* silently do nothing */
            return;
        }

        $params = array(
            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),

            'i_vendor' => new xmlrpcval($par['i_vendor'], "int"),
            'amount' => new xmlrpcval($par['amount'], "double"),
            'currency' => new xmlrpcval($par['mnt_currency'], "string"),
            'payment_notes' => new xmlrpcval($par['payment_notes'], "string"),
        );

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg($method, $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }
    }

    public function generate_new() {
        global $db;

        $sql = "SELECT c.base_currency, wu.i_lang
                  FROM customers c
                  JOIN web_users wu ON (wu.i_customer = c.i_customer AND wu.default_user)
                 WHERE c.i_customer = 1
                 LIMIT 1";

        $root = $db->getAssociatedArray($sql);

        $this->web_password = Password::gen();
        $this->base_currency = $root['base_currency'];
        $this->i_lang = $root['i_lang'];
    }
}

?>
