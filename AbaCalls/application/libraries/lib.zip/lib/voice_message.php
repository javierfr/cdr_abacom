<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Voice_Message {
    public $i_vm_message;
    public $i_account;
    public $i_vm_folder_name;
    public $deleted;
    public $arrived;
    public $folder_name;
    public $sender;
    public $duration;
    public $data;

    private $_fault;

    function __construct($i_account, $i_vm_message = NULL) {
        $this->i_account = $i_account;
        $this->i_vm_folder_name = 0; /* default to inbox */
        $this->deleted = false;
        $this->arrived = '';
        $this->data ='';
        $this->vm_folder_name = 'INBOX';
        $this->i_vm_message = $i_vm_message;
        
        $this->_fault = FALSE;
        
        if ($this->i_vm_message !== NULL) {
           $this->getEntry($this->i_vm_message);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    private function build_clause() {
        $ret = Array('sql' => '', 'params' => Array());
        
        $from_date = isset_par('startDate') ? parse_date(get_par('startDate')) : parse_date('today');
        $to_date = isset_par('endDate') ? parse_date(get_par('endDate')) : parse_date('now');

        $ret['sql'] .= " AND (vm.arrived >= ?) AND (vm.arrived <= ?)";
        $ret['params'][] = $from_date;
        $ret['params'][] = $to_date;

        $sender = get_par('sender');
        if ($sender != '') {
            $sender_clause = get_par('sender_clause');
            $ret['sql'] .= " AND (vm.sender " . ($sender_clause ? "NOT " : "") . "LIKE ?)";
            $ret['params'][] = $sender;
        }

        return $ret;
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;
    
        $clause = $this->build_clause();       

        $sql = "SELECT vm.i_vm_message, n.name as vm_folder_name, 
                       vm.deleted, extract(epoch from vm.arrived) AS arrived, 
                       vm.sender, vm.duration, vm.i_vm_folder_name
                  FROM vm_messages vm, vm_folder_names n
                 WHERE vm.i_account = ? 
                       AND vm.i_vm_folder_name = n.i_vm_folder_name
                       {$clause['sql']}
              ORDER BY vm.arrived DESC
                 LIMIT ${rpp}
                OFFSET ${off}";
        $params = array_merge(array($this->i_account), $clause['params']);

        $result = $db->getAll($sql, $params);
        
        foreach ($result as $key => $value) {
            $result[$key]['duration_norm']   = normalize_seconds($result[$key]['duration']);  
        }

        return $result;
    }

    public function getEntry($i_vm_message) {
        global $db;
        
        $sql = 'SELECT vm.i_vm_message, n.name as vm_folder_name,
                       vm.deleted, extract(epoch from vm.arrived) AS arrived, 
                       vm.i_vm_folder_name, vm.sender, vm.duration, d.data
                  FROM vm_messages vm, vm_folder_names n, vm_message_data d
                 WHERE vm.i_account = ?
                   AND vm.i_vm_folder_name = n.i_vm_folder_name
                   AND vm.i_vm_message = ? 
                   AND d.i_vm_message = vm.i_vm_message
                   AND d.i_audio_format = 0';
        $params = Array($this->i_account, $i_vm_message);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }
        
        $this->i_vm_message     = $entry['i_vm_message'];
        $this->vm_folder_name   = $entry['vm_folder_name'];
        $this->deleted          = $entry['deleted'];
        $this->arrived          = $entry['arrived'];
        $this->i_vm_folder_name = $entry['i_vm_folder_name'];
        $this->sender           = $entry['sender'];
        $this->duration         = $entry['duration'];
        $this->data             = gzuncompress(base64_decode($entry['data']));
    }

    public function getTotal() {
        global $db;

        $clause = $this->build_clause();

        $sql = "SELECT COUNT(*)
                  FROM vm_messages vm
                 WHERE vm.i_account = ? 
                       {$clause['sql']}";
        $params = array_merge(Array($this->i_account), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public function delete() {
        global $db;
            
        $sql = 'DELETE FROM vm_messages
                 WHERE i_account = ? AND i_vm_message = ?';
        $params = array($this->i_account, $this->i_vm_message);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();    
            throw new Exception(_('Cannot delete "Voice Message".'));
        }
    }
}

?>
