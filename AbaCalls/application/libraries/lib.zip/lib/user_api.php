<?

// Copyright (c) 2003-2006 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

include('auth_api.php');

function user_get_info($p_username, $p_user_atributes) {
    global $db;

    $query = sprintf("SELECT *, (CAST(now() AS DATE) - CAST(last_login AS DATE)) AS ll, 
			     (CAST(now() AS DATE) - CAST(last_password_change AS DATE)) AS lp,
			     (CAST(now() AS DATE) - CAST(tmp_web_password_gen_date AS DATE)) AS tlp
			FROM %s 
		       WHERE %s = ?",
		     $p_user_atributes['table'], $p_user_atributes['username']);
	    
    return $db->getAssociatedArray($query, Array($p_username));
}

function user_get_uid($p_username, $p_user_atributes) {

    $t_user_info = user_get_info( $p_username, $p_user_atributes);

    if (!$t_user_info) {
	return 0;
    }	

    return $t_user_info[$p_user_atributes['uid']];
}

function user_get_atributes($type) {

    switch($type) {
    
	case 'account' :
	    return array(
	    'type'		=> 'account',
	    'table'		=> 'accounts',
	    'username'		=> 'username',
	    'password' 		=> 'web_password',
	    'uid'		=> 'i_account',
	    'prefix'		=> 'a',
	    'redirect_page'	=> 'cdrs.php'
	    );
	    break;
	    
	case 'customer' :
	    return array(
	    'type'		=> 'customer',
	    'table'    		=> 'customers',
	    'username'  	=> 'web_login',
	    'password'  	=> 'web_password',
	    'uid'       	=> 'i_customer',
	    'prefix'    	=> 'c',
	    'redirect_page'	=> 'cdrs_customer_self.php',
	    'mntn_rdr_page'	=> 'show_graphs.php'		/* where to redirect when system in maintenance mode */
	    );
	    break;

	case 'vendor':
	    return array(
	    'type'		=> 'vendor',
	    'table'     	=> 'vendors',
	    'username'  	=> 'web_login',
	    'password'  	=> 'web_password',
	    'uid'       	=> 'i_vendor',
	    'prefix'    	=> 'v',
	    'redirect_page'	=> 'cdrs_vendor.php'
	    );
	    break;
	    
	default:
	    return false;
    }

}

function user_update_password($p_user_uid, $p_user_atributes, $new_password) {
    global $db;

    $t_salt = auth_key_gen();

    $query = sprintf("UPDATE %s
			 SET web_password = ?, last_password_change = now(), 
			     tmp_web_password = NULL, tmp_web_password_gen_date = NULL
		       WHERE %s = ?",
			$p_user_atributes['table'], $p_user_atributes['uid']);

    $params = Array(auth_crypt_password($new_password, CRYPTO_TYPE_SHA256, $t_salt) . $t_salt, $p_user_uid);

    return $db->prepNexec($query, $params);
}

function user_update_tmp_web_password($p_user_uid, $p_user_atributes, $new_password) {
    global $db;

    $t_salt 		= auth_key_gen();

    $query = sprintf("UPDATE %s
			 SET tmp_web_password = ?, tmp_web_password_gen_date = now()
		       WHERE %s = ?",
			$p_user_atributes['table'], $p_user_atributes['uid']);

    $params = Array(auth_crypt_password($new_password, CRYPTO_TYPE_SHA256, $t_salt) . $t_salt, $p_user_uid);

    return $db->prepNexec($query, $params);
}

function user_check_old_password($p_user_uid, $p_user_atributes, $p_new_password) {
    global $db;

    $query = sprintf("SELECT web_password_history, web_password FROM %s WHERE %s = ?",
			$p_user_atributes['table'], $p_user_atributes['uid']);
    
    list($t_old_password_history, $t_old_password) = $db->getRow($query, Array($p_user_uid));
    
    if (empty($t_old_password_history)) {
	return true;
    }
    
    $t_old_password_history = $t_old_password_history . ':' . $t_old_password;

    foreach (explode(':', $t_old_password_history) as $t_old_password) {
	$t_old_password_hash = substr($t_old_password,0,64);
	$t_old_password_salt = substr($t_old_password,64,8);

	$t_new_password_crypted = auth_crypt_password($p_new_password, CRYPTO_TYPE_SHA256, $t_old_password_salt);
    
	if ($t_old_password_hash == $t_new_password_crypted) {
	    return false;
	}
    }
    
    return true;
}

function user_rotate_password_history($p_user_uid, $p_user_atributes) {
    global $db;

    $query = sprintf("SELECT web_password_history, web_password FROM %s WHERE %s = ?",
			$p_user_atributes['table'], $p_user_atributes['uid']);
    
    list($t_old_password_history, $t_old_password) = $db->getRow($query, Array($p_user_uid));

    if (empty($t_old_password)) {
	return false;
    }
    
    $t_old_password_history_array = array();
    if (!empty($t_old_password_history)) {
	$t_old_password_history_array = explode(':', $t_old_password_history);
    }
    
    if (count($t_old_password_history_array) == 3) {
	array_shift($t_old_password_history_array);
    }
    
    array_push($t_old_password_history_array, $t_old_password);

    $query = sprintf("UPDATE %s SET web_password_history = ? WHERE %s = ?",
			$p_user_atributes['table'], $p_user_atributes['uid']);
    
    return $db->prepNexec($query, Array(implode(':', $t_old_password_history_array), $p_user_uid));
}

//===================================================================================================

function account_vm_password($p_i_account, $vm_password = null){
    global $db;

    $vm_password = ($vm_password == null) ? get_par('vm_password') : $vm_password;

    if ($vm_password != '@@@@@@') {
	$t_salt = auth_key_gen();
	$t_vm_password = auth_crypt_password($vm_password, CRYPTO_TYPE_SHA256, $t_salt) . $t_salt;

	$query = sprintf("UPDATE accounts SET vm_password = ? WHERE i_account = ?");

	return $db->prepNexec($query, Array(($vm_password == '' ? '' : $t_vm_password), $p_i_account));
    }

    return false;
}

?>
