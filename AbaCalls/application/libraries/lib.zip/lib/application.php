<?php

// Copyright (c) 2003-2005 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

if (php_sapi_name() == 'cli') {
    define('CLI_MODE', TRUE);
    if (!defined('DB_GET_MASTER_CON')) {
        define('DB_GET_MASTER_CON', TRUE);
    }
}

include("config.php");
include("lib.php");
include("common.php");
include('html.php');            /* propagate into global scope $par and $cook arrays */
require("db.php");
require("system_config.php");
require('Smarty.class.php');
require("xmlrpc/xmlrpc.inc");

ini_set('display_errors', 0);    
ini_set('log_errors', 1);

$i_env = get_my_i_env();

$db_master_port = DB_BASE_PORT + $i_env * DB_BASE_PORT_SHIFT;
$db_slave_port = $db_master_port + 1;

$env_db_name = get_my_db_name();

$db_master_dsn = 'pgsql://' . PG_USER . ':' . PG_PASSWORD . '@' . 'db_primary' . ':' . $db_master_port . '/' . $env_db_name;
if (defined('DB_USE_SLAVE')) {
    $db_dsn = 'pgsql://' . PG_USER . ':' . PG_PASSWORD . '@' . 'db_primary' . ':' . $db_slave_port . '/' . $env_db_name;
} else {
    $db_dsn = $db_master_dsn;
}

$db = new DB_Wrapper($db_dsn);
if (!$db->is_connected()) {
    print "Unable to connect to DB.";
    exit();
}

if (defined('DB_GET_MASTER_CON')) {
    if ($db_dsn == $db_master_dsn) {
        $db_master = $db;
    } else {
        $db_master = new DB_Wrapper($db_master_dsn);
        if (!$db_master->is_connected()) {
            print "Unable to connect to master DB.";
            exit();
        }
    }
}

session_start();

/* prepare script environment to run in CLI mode */
if (defined('CLI_MODE') && defined('WEB_JOB')) {
    $db_master->begin();

    if (!$db_master->prepNexec('LOCK web_jobs')) {
        print "Unable to acquire the lock, i_web_job = $i_web_job.\n";
        $db_master->rollback();
        exit();
    };

    $sql = 'SELECT params, session
              FROM web_jobs
             WHERE i_web_job = ?';
    $row = $db_master->getRow($sql, Array($i_web_job));
    if (!$row) {
        print "Unable to restore the job environment, i_web_job = $i_web_job.\n";
        $db_master->rollback();
        exit();
    };

    $db_master->commit();

    unset($par);
    session_unset();
    $par = unserialize($row[0]);
    $_SESSION = unserialize($row[1]);
}

/* localization */
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : L10N_DEFAULT_LANG; 
putenv('LC_MESSAGES=' . $lang);
bindtextdomain(L10N_DOMAIN, L10N_LOCALE);
bind_textdomain_codeset(L10N_DOMAIN, DEFAULT_CHARSET);
textdomain(L10N_DOMAIN);

/* set HTTP headers */
header('Content-Type: text/html; charset=' . DEFAULT_CHARSET);

class Smarty_Engine extends Smarty {

    function __construct() {
        parent::__construct();

        $this->setTemplateDir('./templates/');
        $this->setCompileDir('/var/env' . get_my_i_env() . '/templates_c/');
        $this->addPluginsDir('./lib/smarty_plugins');
        $this->setCaching(Smarty::CACHING_OFF);
    }
}

$smarty = new Smarty_Engine();
$smarty->assign("dec_format", get_dpf());
$smarty->assign("basepath", BASEPATH);
    
?>
