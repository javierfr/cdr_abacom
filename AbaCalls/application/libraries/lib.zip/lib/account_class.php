<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id php,v 1.1 2010/01/29 20:10:02 geka Exp $

class Account_Class {

    public $i_account_class;
    public $i_customer;
    public $name;
    public $description;
    public $system;
    public $ivr_enabled;
    public $vm_enabled;
    public $onnet_enabled;
    public $registration_enabled;
    public $provisioning_enabled;
    public $followme_enabled;
    public $selfcare_enabled;
    public $cc_payments_enabled;
    public $voucher_payments_enabled;
    public $webphone_enabled;
    public $cb_enabled;
    public $modify_own_address_info;
    public $translation_rule;
    public $cli_translation_rule;
    public $max_credit_time;
    public $conferencing_enabled;
    public $generate_ringbacktone;
    public $allow_free_onnet_calls;
    public $sc_1;
    public $sc_2;
    public $sc_3;
    public $sc_4;
    public $sc_5;
    public $sc_6;
    public $sc_7;
    public $sc_8;

    private $_fault;

    function __construct($i_customer, $i_account_class = NULL) {
        
        $this->i_customer = $i_customer;
        $this->i_account_class = $i_account_class;
        $this->name = '';
        $this->description = '';
        $this->system = FALSE;
        $this->ivr_enabled = TRUE;
        $this->vm_enabled = TRUE;
        $this->onnet_enabled = TRUE;
        $this->registration_enabled = TRUE;
        $this->provisioning_enabled = TRUE;
        $this->followme_enabled = TRUE;
        $this->selfcare_enabled = TRUE;
        $this->cc_payments_enabled = TRUE;
        $this->voucher_payments_enabled = TRUE;
        $this->webphone_enabled = TRUE;
        $this->cb_enabled = TRUE;
        $this->modify_own_address_info = TRUE;
        $this->max_credit_time = 3600;
        $this->conferencing_enabled = TRUE;
        $this->generate_ringbacktone = TRUE;
        $this->allow_free_onnet_calls = FALSE;
        $this->sc_1 = new Account_Class_Service_Code(Service_Code::CALL_FORWADING_ENABLE, $this->i_account_class);
        $this->sc_2 = new Account_Class_Service_Code(Service_Code::CALL_FORWADING_DISABLE, $this->i_account_class);
        $this->sc_3 = new Account_Class_Service_Code(Service_Code::DND_ENABLE, $this->i_account_class);
        $this->sc_4 = new Account_Class_Service_Code(Service_Code::DND_DISABLE, $this->i_account_class);
        $this->sc_5 = new Account_Class_Service_Code(Service_Code::BLOCK_INCOMING_ANONYMOUS_CALLS, $this->i_account_class);
        $this->sc_6 = new Account_Class_Service_Code(Service_Code::UNBLOCK_INCOMING_ANONYMOUS_CALLS, $this->i_account_class);
        $this->sc_7 = new Account_Class_Service_Code(Service_Code::CALL_BLOCK_ADD_LAST_CALLERI, $this->i_account_class);
        $this->sc_8 = new Account_Class_Service_Code(Service_Code::CALL_BLOCK_REMOVE_LAST_CALLER, $this->i_account_class);

        if ($this->i_account_class !== NULL) {
            $this->getEntry($this->i_account_class);
        }

        $this->_fault = FALSE;
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_account_class) {
        global $db;

        $sql = 'SELECT  ac.i_account_class, ac.name, ac.description, ac.system,
                        ac.ivr_enabled, ac.vm_enabled, ac.onnet_enabled,
                        ac.registration_enabled, ac.provisioning_enabled, ac.followme_enabled,
                        ac.selfcare_enabled, ac.cc_payments_enabled, ac.voucher_payments_enabled,
                        ac.webphone_enabled, ac.translation_rule, ac.cli_translation_rule,
                        ac.max_credit_time, ac.cb_enabled, ac.modify_own_address_info, ac.conferencing_enabled,
                        ac.generate_ringbacktone, ac.allow_free_onnet_calls
                   FROM account_classes ac
                  WHERE (ac.i_customer = ? OR ac.system) 
                    AND ac.i_account_class = ?
                    LIMIT 1';

        $entry = $db->getAssociatedArray($sql, Array($this->i_customer, $i_account_class));
        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_account_class          = $entry['i_account_class'];
        $this->name                     = $entry['name'];
        $this->description              = $entry['description'];
        $this->system                   = Cast::str2bool($entry['system']);
        $this->ivr_enabled              = Cast::str2bool($entry['ivr_enabled']);
        $this->vm_enabled               = Cast::str2bool($entry['vm_enabled']);
        $this->onnet_enabled            = Cast::str2bool($entry['onnet_enabled']);
        $this->registration_enabled     = Cast::str2bool($entry['registration_enabled']);
        $this->provisioning_enabled     = Cast::str2bool($entry['provisioning_enabled']);
        $this->followme_enabled         = Cast::str2bool($entry['followme_enabled']);
        $this->selfcare_enabled         = Cast::str2bool($entry['selfcare_enabled']);
        $this->cc_payments_enabled      = Cast::str2bool($entry['cc_payments_enabled']);
        $this->voucher_payments_enabled = Cast::str2bool($entry['voucher_payments_enabled']);
        $this->webphone_enabled         = Cast::str2bool($entry['webphone_enabled']);
        $this->cb_enabled               = Cast::str2bool($entry['cb_enabled']);
        $this->modify_own_address_info  = Cast::str2bool($entry['modify_own_address_info']);
        $this->translation_rule         = $entry['translation_rule'];
        $this->cli_translation_rule     = $entry['cli_translation_rule'];
        $this->max_credit_time          = $entry['max_credit_time'];
        $this->conferencing_enabled     = Cast::str2bool($entry['conferencing_enabled']);
        $this->generate_ringbacktone    = Cast::str2bool($entry['generate_ringbacktone']);
        $this->allow_free_onnet_calls   = Cast::str2bool($entry['allow_free_onnet_calls']);

        $this->sc_1->getEntry();
        $this->sc_2->getEntry();
        $this->sc_3->getEntry();
        $this->sc_4->getEntry();
        $this->sc_5->getEntry();
        $this->sc_6->getEntry();
        $this->sc_7->getEntry();
        $this->sc_8->getEntry();
    }

    public function initFromRequest($par) {

        $this->i_account_class = $par['i_account_class'];

        if (!$this->system) {
            $this->name                     = $par['ac_name'];
            $this->description              = $par['description'];
            $this->ivr_enabled              = Cast::str2bool($par['ivr_enabled']);
            $this->vm_enabled               = Cast::str2bool($par['vm_enabled']);
            $this->onnet_enabled            = Cast::str2bool($par['onnet_enabled']);
            $this->registration_enabled     = Cast::str2bool($par['registration_enabled']);
            $this->provisioning_enabled     = Cast::str2bool($par['provisioning_enabled']);
            $this->followme_enabled         = Cast::str2bool($par['followme_enabled']);
            $this->selfcare_enabled         = Cast::str2bool($par['selfcare_enabled']);
            $this->cc_payments_enabled      = Cast::str2bool($par['cc_payments_enabled']);
            $this->voucher_payments_enabled = Cast::str2bool($par['voucher_payments_enabled']);
            $this->webphone_enabled         = Cast::str2bool($par['webphone_enabled']);
            $this->cb_enabled               = Cast::str2bool($par['cb_enabled']);
            $this->modify_own_address_info  = Cast::str2bool($par['modify_own_address_info']);
            $this->translation_rule         = $par['translation_rule'];
            $this->cli_translation_rule     = $par['cli_translation_rule'];
            $this->max_credit_time          = $par['max_credit_time'];
            $this->conferencing_enabled     = Cast::str2bool($par['conferencing_enabled']);
            $this->generate_ringbacktone    = Cast::str2bool($par['generate_ringbacktone']);
            $this->allow_free_onnet_calls   = Cast::str2bool($par['allow_free_onnet_calls']);

            $this->sc_1->initFromRequest($par);
            $this->sc_2->initFromRequest($par);
            $this->sc_3->initFromRequest($par);
            $this->sc_4->initFromRequest($par);
            $this->sc_5->initFromRequest($par);
            $this->sc_6->initFromRequest($par);
            $this->sc_7->initFromRequest($par);
            $this->sc_8->initFromRequest($par);
        }
    }

    public function genID() {
        global $db;

        return $db->nextID('account_classes_seq');
    }

    public static function buildClause() {

        $ret = Array('sql' => '', 'params' => Array());
        if (get_par('name') != '') {
            $ret['sql'] .= ' AND ac.name ' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('name');
        }
        return $ret;
    }

    public static function getTotal($i_customer) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT COUNT(*)
                FROM account_classes ac
                WHERE (ac.i_customer = ? OR ac.system)
                {$clause['sql']}";
        $params = array_merge(Array($i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public static function getList($i_customer, $off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT ac.i_account_class, ac.name, ac.description, ac.system,
                         (SELECT COUNT(*)
                            FROM accounts a
                           WHERE a.i_account_class = ac.i_account_class) AS links
                  FROM account_classes ac
                 WHERE (ac.i_customer = ? 
                    OR ac.system)
                         {$clause['sql']}
              ORDER BY ac.system DESC, ac.name
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($i_customer), $clause['params']);

        $rows = $db->getAll($sql, $params);

        foreach ($rows as &$row) {
           $row['system'] = Cast::str2bool($row['system']);
        }

        return $rows;
    }

    private function doesNameExist($name, $i_account_class = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM account_classes ac
                 WHERE ac.name = ? AND (ac.i_customer = ? OR ac.system) 
                       AND ac.i_account_class <> ?';

        $params = Array($name, $this->i_customer, $i_account_class);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $i_account_class = 0) {

        if (!$this->system) {
            if ($par['ac_name'] == '') {
                throw new Exception(_('"Name" field is mandatory.'));
            }
            if (!(Validator::isNumber($par['max_credit_time'])) || $par['max_credit_time'] <= 0) {
                throw new Exception(_('"Max Session Time" field has incorrect number format. Positive number is expected.'));
            }
            if (!(Validator::isTransRule($par['cli_translation_rule']))) {
                throw new Exception(_('"CLI Tr. rule" has wrong format.'));
            }
            if (!(Validator::isTransRule($par['translation_rule']))) {
                throw new Exception(_('"CLD Tr. rule" has wrong format.'));
            }
            if ($this->doesNameExist($par['ac_name'], $i_account_class)) {
                throw new Exception(_('Another Account Class with conflicting "Name" already exists.'));
            }
         }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $i_account_class = $this->genID();

        $sql = 'INSERT INTO account_classes (i_account_class, i_customer, name, 
                    description, ivr_enabled, vm_enabled, onnet_enabled,
                    registration_enabled, provisioning_enabled, followme_enabled,
                    selfcare_enabled, cc_payments_enabled, voucher_payments_enabled,
                    webphone_enabled, cb_enabled, modify_own_address_info, translation_rule,
                    cli_translation_rule, max_credit_time, conferencing_enabled,
                    generate_ringbacktone, allow_free_onnet_calls)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $params = Array($i_account_class, $this->i_customer, 
                        $par['ac_name'], 
                        $par['description'],
                        Cast::str2bool($par['ivr_enabled']),
                        Cast::str2bool($par['vm_enabled']),
                        Cast::str2bool($par['onnet_enabled']),
                        Cast::str2bool($par['registration_enabled']),
                        Cast::str2bool($par['provisioning_enabled']),
                        Cast::str2bool($par['followme_enabled']),
                        Cast::str2bool($par['selfcare_enabled']),
                        Cast::str2bool($par['cc_payments_enabled']),
                        Cast::str2bool($par['voucher_payments_enabled']),
                        Cast::str2bool($par['webphone_enabled']),
                        Cast::str2bool($par['cb_enabled']),
                        Cast::str2bool($par['modify_own_address_info']),
                        $par['translation_rule'],
                        $par['cli_translation_rule'],
                        $par['max_credit_time'],
                        Cast::str2bool($par['conferencing_enabled']),
                        Cast::str2bool($par['generate_ringbacktone']),
                        Cast::str2bool($par['allow_free_onnet_calls'])
                       );
        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Account Class."));
        }
        $this->i_account_class = $i_account_class;

        $this->sc_1->update($par, $this->i_account_class);
        $this->sc_2->update($par, $this->i_account_class);
        $this->sc_3->update($par, $this->i_account_class);
        $this->sc_4->update($par, $this->i_account_class);
        $this->sc_5->update($par, $this->i_account_class);
        $this->sc_6->update($par, $this->i_account_class);
        $this->sc_7->update($par, $this->i_account_class);
        $this->sc_8->update($par, $this->i_account_class);

        $this->getEntry($this->i_account_class);
        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $par['i_account_class']);

        $sql = 'UPDATE account_classes
                   SET name = ?, 
                       description = ?,
                       ivr_enabled = ?,
                       vm_enabled = ?,
                       onnet_enabled = ?,
                       registration_enabled = ?,
                       provisioning_enabled = ?,
                       followme_enabled = ?,
                       selfcare_enabled = ?,
                       cc_payments_enabled = ?,
                       voucher_payments_enabled = ?,
                       webphone_enabled = ?,
                       cb_enabled = ?,
                       modify_own_address_info = ?,
                       translation_rule = ?,
                       cli_translation_rule = ?,
                       max_credit_time = ?,
                       conferencing_enabled = ?,
                       generate_ringbacktone = ?,
                       allow_free_onnet_calls = ?
                 WHERE i_account_class = ? AND i_customer = ? AND NOT system';

        $params = Array($par['ac_name'], 
            $par['description'],
            Cast::str2bool($par['ivr_enabled']),
            Cast::str2bool($par['vm_enabled']),
            Cast::str2bool($par['onnet_enabled']),
            Cast::str2bool($par['registration_enabled']),
            Cast::str2bool($par['provisioning_enabled']),
            Cast::str2bool($par['followme_enabled']),
            Cast::str2bool($par['selfcare_enabled']),
            Cast::str2bool($par['cc_payments_enabled']),
            Cast::str2bool($par['voucher_payments_enabled']),
            Cast::str2bool($par['webphone_enabled']),
            Cast::str2bool($par['cb_enabled']),
            Cast::str2bool($par['modify_own_address_info']),
            $par['translation_rule'],
            $par['cli_translation_rule'],
            $par['max_credit_time'],
            Cast::str2bool($par['conferencing_enabled']),
            Cast::str2bool($par['generate_ringbacktone']),
            Cast::str2bool($par['allow_free_onnet_calls']),
            $par['i_account_class'], 
            $this->i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Account Class."));
        }
        $this->i_account_class = $par['i_account_class'];

        Account_Class_Service_Code::delete($this->i_account_class);
        $this->sc_1->update($par);
        $this->sc_2->update($par);
        $this->sc_3->update($par);
        $this->sc_4->update($par);
        $this->sc_5->update($par);
        $this->sc_6->update($par);
        $this->sc_7->update($par);
        $this->sc_8->update($par);

        $this->getEntry($this->i_account_class);
        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        $this->setFault(TRUE);

        $sql = 'DELETE FROM account_classes
                      WHERE i_account_class = ? AND i_customer = ? AND NOT system';
        $params = Array($par['i_account_class'], $this->i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Account Class."));
        }

        $this->setFault(FALSE);
    }
}

?>
