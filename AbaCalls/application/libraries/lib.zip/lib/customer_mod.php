<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Customer_Mod {
    public $i_customer_mod;
    public $i_wholesaler;
    public $i_customer;
    public $dns_alias;
    public $css;

    private $_fault;

    function __construct($i_wholesaler, $i_customer) {
        $this->i_customer_mod = NULL;
        $this->i_wholesaler = $i_wholesaler;
        $this->i_customer = $i_customer;

        $this->getEntry($this->i_customer);

        $this->_fault = FALSE;
    }

    function __destruct() {
	/* nothing here */
    }

    protected function setFault($fault) {
	$this->_fault = $fault;
    }

    public function isFault() {
	return $this->_fault;
    }

    public function getEntry($i_customer) {
	global $db;

	$sql = 'SELECT cm.i_customer_mod, cm.css, cm.dns_alias
		  FROM customer_mods cm
                  JOIN customers c USING (i_customer)
		 WHERE c.i_wholesaler = ? AND c.i_customer = ?
		 LIMIT 1';
	$entry = $db->getAssociatedArray($sql, Array($this->i_wholesaler, $i_customer));

        if ($db->affected_rows != 1) {
	    throw new Exception("No such Id.");
	}

	$this->i_customer_mod = $entry['i_customer_mod'];
	$this->css = $entry['css'];
	$this->dns_alias = $entry['dns_alias'];
    }

    public function initFromRequest($par) {
        $this->dns_alias = $par['dns_alias'];
        $this->css = $par['css'];
    }

    public function validate($par) {
	global $db;
        
        $dns_alias = trim($par['dns_alias']);
        if (strlen($dns_alias) > 0) {
            $sql = 'SELECT COUNT(*)
                      FROM customer_mods
                     WHERE dns_alias = ? AND i_customer_mod <> ?';
            $c = $db->getValue($sql, array($dns_alias, $this->i_customer_mod));
	    if ($c > 0) {
                throw new Exception(_('"DNS Alias" is used by another customer.'));
	    }
	}
    }

    public function update($par) {
	global $db;

        $this->setFault(TRUE);
        $this->validate($par);

        $params = Array(
                    "i_customer"    => new xmlrpcval($this->i_customer, "int"),
                    "i_wholesaler"  => new xmlrpcval($this->i_wholesaler, "int"),
                    "css"           => new xmlrpcval($par['css'], "string"),
                    "dns_alias"     => new xmlrpcval(trim($par['dns_alias']), "string")
                    );
        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('updateCustomer', $params);

        $master_addr = get_master_XMLRPC_server();       

        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->getEntry($this->i_customer);
        $this->setFault(FALSE);
    }
}
?>
