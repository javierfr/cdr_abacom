<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Web_User {

    public $i_web_user;
    public $i_customer;
    public $default_user;
    public $name;
    public $description;
    public $web_login;
    public $web_password;
    public $last_login;
    public $last_password_change;
    public $i_time_zone;
    public $start_page;
    public $i_lang;
    public $i_export_type;
    public $email;
    public $i_access_level;
    public $allowed_hosts;

    function __construct($i_customer, $i_web_user = NULL) {
        $this->i_web_user = $i_web_user;
        $this->i_customer = $i_customer;
        $this->default_user = FALSE;
        $this->name = '';
        $this->description = '';
        $this->web_login = '';
        $this->web_password = '';
        $this->last_login = '';
        $this->last_password_change = '';
        $this->i_time_zone = NULL;
        $this->start_page = 4;
        $this->i_lang = 'en';
        $this->i_export_type = FILE_FORMAT_XLS;
        $this->email = '';
        $this->i_access_level = NULL;
        $this->allowed_hosts = 'Any';
        $this->sippy_support_user = FALSE;

        if ($this->i_web_user !== NULL) {
            $this->getEntry($this->i_web_user);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_web_user) {
        global $db;

        $sql = 'SELECT wu.*, extract(epoch from last_login) AS last_login,
                       extract(epoch from last_password_change) AS last_password_change
                  FROM web_users wu
                 WHERE wu.i_customer = ? AND wu.i_web_user = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($this->i_customer, $i_web_user));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_web_user = $entry['i_web_user'];
        $this->i_customer = $entry['i_customer'];
        $this->default_user = Cast::str2bool($entry['default_user']);
        $this->name = $entry['name'];
        $this->description = $entry['description'];
        $this->web_login = $entry['web_login'];
        $this->web_password = $entry['web_password'];
        $this->last_login = $entry['last_login'];
        $this->last_password_change = $entry['last_password_change'];
        $this->i_time_zone = $entry['i_time_zone'];
        $this->start_page = $entry['start_page'];
        $this->i_lang = $entry['i_lang'];
        $this->i_export_type = $entry['i_export_type'];
        $this->email = $entry['email'];
        $this->i_access_level = $entry['i_access_level'];
        $this->sippy_support_user = Cast::str2bool($entry['sippy_support_user']);

        $sql = 'SELECT ip
                  FROM web_allowed_hosts
                 WHERE i_web_user = ?
              ORDER BY i_web_allowed_host';
        $params = Array($this->i_web_user);

        $rows = $db->getCol($sql, $params);
        if ($db->affected_rows == 0) {
            $this->allowed_hosts = 'Any';
        } else {
            $this->allowed_hosts = implode(', ', $rows);
        }
    }

    public function initFromRequest($par) {
        global $db;

        $this->i_web_user = $par['i_web_user'];
        $this->name = $par['wu_name'];
        $this->description = $par['description'];
        $this->web_login = $par['web_login'];
        $this->web_password = $par['web_password'];
        $this->i_time_zone = $par['i_time_zone'];
        $this->start_page = $par['start_page'];
        $this->i_lang = $par['i_lang'];
        $this->i_export_type = $par['i_export_type'];
        $this->email = $par['email'];
        $this->i_access_level = $par['i_access_level'];
        $this->allowed_hosts = $par['allowed_hosts'];
    }

    public function genID() {
        global $db;

        $this->i_web_user = $db->nextID('web_users_seq');
    }

    public static function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('name') != '') {
            $ret['sql'] .= ' AND wu.name ' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('name');
        }

        return $ret;
    }

    public static function getTotal($i_customer) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT COUNT(wu.*)
                   FROM web_users wu
                  WHERE wu.i_customer = ?
                        {$clause['sql']}";
        $params = array_merge(Array($i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public static function getList($i_customer, $off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT wu.i_web_user AS i_web_user, wu.name AS name,
                       wu.description AS description, wu.web_login AS web_login,
                       wu.default_user AS default_user, al.name AS al_name,
                       wu.sippy_support_user AS sippy_support_user
                  FROM web_users wu
                  JOIN access_levels al USING(i_access_level)
                 WHERE wu.i_customer = ?
                       {$clause['sql']}
              ORDER BY wu.default_user DESC, wu.name
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($i_customer), $clause['params']);

        return $db->getAll($sql, $params);
    }

    private static function doesNameExist($i_customer, $name, $i_web_user = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM web_users wu
                 WHERE wu.i_customer = ? AND wu.name ILIKE ? AND wu.i_web_user <> ?';

        $params = Array($i_customer, $name, $i_web_user);

        return $db->getValue($sql, $params) > 0;
    }

    protected static function doesWebLoginExist($name, $i_web_user = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM web_users wu
                 WHERE wu.web_login ILIKE ? AND wu.i_web_user <> ?';

        $params = Array($name, $i_web_user);

        return $db->getValue($sql, $params) > 0;
    }

    public static function validate($i_customer, $par, $form_as_add = FALSE) {
        if (empty($par['default_user'])) {
            if ($par['wu_name'] == '') {
                throw new Exception(_('"Name" field is mandatory.'));
            }

            if ($form_as_add) {
                if (self::doesNameExist($i_customer, $par['wu_name'])) {
                    throw new Exception(_('Cannot add User. Another User with conflicting "Name" already exists.'));
                }
            } else {
                if (self::doesNameExist($i_customer, $par['wu_name'], $par['i_web_user'])) {
                    throw new Exception(_('Cannot update User. Another User with conflicting "Name" already exists.'));
                }
            }
        }

        if (empty($par['default_user']) || (!empty($par['default_user']) && $_SESSION['is_root_customer'])) {
            if ($par['web_login'] == '') {
                throw new Exception(_('"Web Login" field is mandatory.'));
            }

            if ($form_as_add) {
                if (self::doesWebLoginExist($par['web_login'])) {
                    throw new Exception(_('Cannot add User. Another User with conflicting "Web Login" already exists.'));
                }
            } else {
                if (self::doesWebLoginExist($par['web_login'], $par['i_web_user'])) {
                    throw new Exception(_('Cannot update User. Another User with conflicting "Web Login" already exists.'));
                }
            }
        }

        if ($form_as_add && $par['web_password'] == '') {
            throw new Exception(_('"Web Password" field is mandatory.'));
        }

        if ($par['web_password'] != '') {
            $i_password_policy = Password_Policy::get($i_customer);
            $pp = new Password_Policy($i_password_policy, _('Web Password'));
            $pp->validate($par['web_password']);
        }

        if (empty($par['default_user'])) {
            if (!Validator::isEmail($par['email'])) {
                throw new Exception(_('"E-Mail" field has incorrect format. E-mail in the format username@domain is expected.'));
            }
        }

        if ($par['allowed_hosts'] != '' && $par['allowed_hosts'] != 'Any') {
            foreach (preg_split('/[,\s\n\r;]+/', $par['allowed_hosts'], NULL, PREG_SPLIT_NO_EMPTY) as $ip) {
                if (!Validator::isIPAddress($ip, TRUE)) {
                    throw new Exception(_('"Allowed Hosts" field has incorrect format. Comma separated list of IPs is expected.'));
                }
            }
        }
    }

    public static function add($i_customer, $par) {
        global $db;

        self::validate($i_customer, $par, TRUE);

        try {
            $db->begin();

            $salt = Password::gen_salt();
            $password = Password::crypt($par['web_password'], Password::SHA256, $salt) . $salt;

            $sql = 'INSERT INTO web_users (i_web_user, i_customer, name, description, web_login,
                                           web_password, i_time_zone, start_page,
                                           i_lang, i_export_type, email, i_access_level)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
            $params = Array($par['i_web_user'], $i_customer, $par['wu_name'], $par['description'],
                            $par['web_login'], $password, $par['i_time_zone'],
                            $par['start_page'], $par['i_lang'],
                            $par['i_export_type'], $par['email'], $par['i_access_level']);

            if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
                throw new Exception(_("Cannot insert User."));
            }

            if ($par['allowed_hosts'] != '' && $par['allowed_hosts'] != 'Any') {
                $ips = preg_split('/[,\s\n\r;]+/', $par['allowed_hosts'], NULL, PREG_SPLIT_NO_EMPTY);
                $ips = array_unique((array) $ips);
                foreach ($ips as $ip) {
                    $sql = 'INSERT INTO web_allowed_hosts (i_web_user, ip)
                                 VALUES (?, ?)';
                    $params = Array($par['i_web_user'], $ip);
                    if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
                        throw new Exception(_("Cannot insert Allowed Host."));
                    }
                }
            }
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
        $db->commit();

        return new self($i_customer, $par['i_web_user']);
    }

    private static function update_any_user($i_customer, $par) {
        global $db;

        $sql = 'UPDATE web_users
                   SET start_page = ?, i_lang = ?, i_export_type = ?, i_time_zone = ?,
                       description = ?
                 WHERE i_customer = ? AND i_web_user = ?';
        $params = Array($par['start_page'], $par['i_lang'], $par['i_export_type'], $par['i_time_zone'],
                        $par['description'],
                        $i_customer, $par['i_web_user']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update User."));
        }

        /* web_allowed_hosts*/
        $sql = 'DELETE FROM web_allowed_hosts
                      WHERE i_web_user = ?';
        $params = Array($par['i_web_user']);
        $db->prepNexec($sql, $params);

        if ($par['allowed_hosts'] != '' && $par['allowed_hosts'] != 'Any') {
            $ips = preg_split('/[,\s\n\r;]+/', $par['allowed_hosts'], NULL, PREG_SPLIT_NO_EMPTY);
            $ips = array_unique((array) $ips);
            foreach ($ips as $ip) {
                $sql = 'INSERT INTO web_allowed_hosts (i_web_user, ip)
                             VALUES (?, ?)';
                $params = Array($par['i_web_user'], $ip);
                if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
                    throw new Exception(_("Cannot update Allowed Host."));
                }
            }
        }
    }

    private static function update_regular_user($i_customer, $par) {
        global $db;

        $sql = 'UPDATE web_users
                   SET name = ?, web_login = ?, email = ?
                 WHERE i_customer = ? AND i_web_user = ? AND NOT default_user';
        $params = Array($par['wu_name'], $par['web_login'], $par['email'],
                        $i_customer, $par['i_web_user']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update User."));
        }
    }

    private static function update_access_level($i_customer, $par) {
        global $db;

        $sql = 'UPDATE web_users
                   SET i_access_level = ?
                 WHERE i_customer = ? AND i_web_user = ? AND NOT default_user';
        $params = Array($par['i_access_level'],
                        $i_customer, $par['i_web_user']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update User."));
        }
    }

    private static function update_root_user($i_customer, $par) {
        global $db;

        $sql = 'UPDATE web_users
                   SET web_login = ?
                 WHERE i_customer = ? AND i_web_user = ? AND default_user';
        $params = Array($par['web_login'],
                        $i_customer, $par['i_web_user']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update User."));
        }
    }

    public static function update($i_customer, $par) {
        global $db;

        self::validate($i_customer, $par);

        $wu = new self($i_customer, $par['i_web_user']);
        if ($wu->sippy_support_user) {
            throw new Exception(_("Cannot update User."));
        };

        try {
            $db->begin();

            /* simple security check if customer can update this web-user */
            $sql = 'SELECT COUNT(*)
                      FROM web_users
                     WHERE i_customer = ? AND i_web_user = ?';
            $params = Array($i_customer, $par['i_web_user']);
            if ($db->getValue($sql, $params) != 1) {
                throw new Exception(_("Cannot update User."));
            };

            if ($par['web_password'] != '') {
                $ph = new Password_History(Web_Password::WEB_USER, $par['i_web_user'], _('Web Password'));
                $ph->chk_rot_upd($par['web_password']);
            }

            self::update_any_user($i_customer, $par);

            if (empty($par['default_user'])) {
                self::update_regular_user($i_customer, $par);
                if ($_SESSION['sub_uid'] != $par['i_web_user']) {
                    self::update_access_level($i_customer, $par);
                }
            }

            if ($_SESSION['is_root_customer'] && $par['default_user']) {
                self::update_root_user($i_customer, $par);
            }
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
        $db->commit();

        return new self($i_customer, $par['i_web_user']);
    }

    public static function delete($i_customer, $par) {
        global $db;

        $sql = 'DELETE FROM web_users
                 WHERE i_customer = ? AND i_web_user = ? AND NOT default_user
                       AND NOT sippy_support_user';
        $params = Array($i_customer, $par['i_web_user']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete User."));
        }
    }

}

class Web_User_Self {

    public $i_web_user;
    public $i_customer;
    public $i_time_zone;
    public $start_page;
    public $i_lang;
    public $i_export_type;
    public $email;
    public $web_password;
    public $allowed_hosts;

    function __construct($i_customer, $i_web_user) {
        $this->i_web_user = $i_web_user;
        $this->i_customer = $i_customer;

        $this->getEntry();
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry() {
        global $db;

        $sql = 'SELECT wu.*
                  FROM web_users wu
                 WHERE wu.i_customer = ? AND wu.i_web_user = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($this->i_customer, $this->i_web_user));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_time_zone = $entry['i_time_zone'];
        $this->start_page = $entry['start_page'];
        $this->i_lang = $entry['i_lang'];
        $this->i_export_type = $entry['i_export_type'];
        $this->email = $entry['email'];
        $this->web_password = $entry['web_password'];

        $sql = 'SELECT ip
                  FROM web_allowed_hosts
                 WHERE i_web_user = ?
              ORDER BY i_web_allowed_host';
        $params = Array($this->i_web_user);

        $rows = $db->getCol($sql, $params);
        if ($db->affected_rows == 0) {
            $this->allowed_hosts = 'Any';
        } else {
            $this->allowed_hosts = implode(', ', $rows);
        }
    }

    public function initFromRequest($par) {
        $this->i_time_zone = $par['i_time_zone'];
        $this->start_page = $par['start_page'];
        $this->i_lang = $par['i_lang'];
        $this->i_export_type = $par['i_export_type'];
        $this->email = $par['email'];
        $this->allowed_hosts = $par['allowed_hosts'];
    }

    public function validate($par) {
        if (($par['web_password'] != '' || $par['confirm_web_password'] != '') &&
            strcmp($par['web_password'], $par['confirm_web_password'])) {

            throw new Exception(_('Password mismatch.'));
        }

        if ($par['web_password'] != '') {
            $i_password_policy = Password_Policy::get($this->i_customer);
            $pp = new Password_Policy($i_password_policy, _('Web Password'));
            $pp->validate($par['web_password']);
        }

        if (!Validator::isEmail($par['email'])) {
            throw new Exception(_('"E-Mail" field has incorrect format. E-mail in the format username@domain is expected.'));
        }

        if ($par['allowed_hosts'] != '' && $par['allowed_hosts'] != 'Any') {
            foreach (preg_split('/[,\s\n\r;]+/', $par['allowed_hosts'], NULL, PREG_SPLIT_NO_EMPTY) as $ip) {
                if (!Validator::isIPAddress($ip, TRUE)) {
                    throw new Exception(_('"Allowed Hosts" field has incorrect format. Comma separated list of IPs is expected.'));
                }
            }
        }
    }

    public function update($par) {
        global $db;

        $this->validate($par);

        if ($par['web_password'] != '') {
            $ph = new Password_History(Web_Password::WEB_USER, $this->i_web_user, _('Web Password'));
            $ph->chk_rot_upd($par['web_password']);

            $this->getEntry();
            $_SESSION['password'] = $this->web_password;
        }

        $db->begin();

        $sql = 'UPDATE web_users
                   SET i_time_zone = ?, start_page = ?, i_lang = ?, i_export_type = ?, email = ?
                 WHERE i_customer = ? AND i_web_user = ?';
        $params = Array($par['i_time_zone'], $par['start_page'], $par['i_lang'],
                        $par['i_export_type'], $par['email'],
                        $this->i_customer, $this->i_web_user);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_("Cannot update User."));
        }

        /* web_allowed_hosts*/
        $sql = 'DELETE FROM web_allowed_hosts
                      WHERE i_web_user = ?';
        $params = Array($this->i_web_user);
        $db->prepNexec($sql, $params);

        if ($par['allowed_hosts'] != '' && $par['allowed_hosts'] != 'Any') {
            $ips = preg_split('/[,\s\n\r;]+/', $par['allowed_hosts'], NULL, PREG_SPLIT_NO_EMPTY);
            $ips = array_unique((array) $ips);
            foreach ($ips as $ip) {
                $sql = 'INSERT INTO web_allowed_hosts (i_web_user, ip)
                             VALUES (?, ?)';
                $params = Array($this->i_web_user, $ip);
                if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
                    $db->rollback();
                    throw new Exception(_("Cannot update Allowed Host."));
                }
            }
        }

        Audit_Logger::write('U', sprintf('web_users:i_web_user=%d', $this->i_web_user));

        $db->commit();

        $this->getEntry();
    }
}

class Web_User_Default_User extends Web_User {

    function __construct($i_customer, $i_web_user = NULL) {
       parent::__construct($i_customer, $i_web_user);
    }

    private function validate_default_user($par, $form_as_add = FALSE) {
        if ($par['web_login'] == '') {
            throw new Exception(_('"Web Login" field is mandatory.'));
        }

        if ($form_as_add) {
            if (self::doesWebLoginExist($par['web_login'])) {
                throw new Exception(_('Cannot add User. Another User with conflicting "Web Login" already exists.'));
            }
        } else {
            if (self::doesWebLoginExist($par['web_login'], $this->i_web_user)) {
                throw new Exception(_('Cannot update User. Another User with conflicting "Web Login" already exists.'));
            }
        }

        if ($form_as_add && $par['web_password'] == '') {
            throw new Exception(_('"Web Password" field is mandatory.'));
        }

        if ($par['web_password'] != '') {
            $i_password_policy = Password_Policy::get($this->i_customer);
            $pp = new Password_Policy($i_password_policy, _('Web Password'));
            $pp->validate($par['web_password']);
        }
    }

    public function add_default_user($par) {
        global $db;

        $this->genID();

        $this->validate_default_user($par, TRUE);

        $salt = Password::gen_salt();
        $password = Password::crypt($par['web_password'], Password::SHA256, $salt) . $salt;

        $sql = 'INSERT INTO web_users (default_user, i_web_user, i_customer, name, description,
                                       web_login, web_password, i_time_zone, start_page,
                                       i_lang, i_export_type, i_access_level)
                     VALUES (TRUE, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $params = Array($this->i_web_user, $this->i_customer, 'Default User', $par['description'],
                        $par['web_login'], $password, $par['i_time_zone'],
                        $par['start_page'], $par['i_lang'],
                        $par['i_export_type'], 'ADMINISTRATOR');

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert User."));
        }
    }

    protected function get_i_web_user() {
        global $db;

        $this->i_web_user = $db->getValue('SELECT i_web_user
                                             FROM web_users
                                            WHERE i_customer = ? AND default_user',
                                          Array($this->i_customer));
    }

    public function update_default_user($par) {
        global $db;

        $this->get_i_web_user();

        $this->validate_default_user($par);

        if ($par['web_password'] != '') {
            $ph = new Password_History(Web_Password::WEB_USER, $this->i_web_user, _('Web Password'));
            $ph->chk_rot_upd($par['web_password']);
        }

        $sql = 'UPDATE web_users
                   SET web_login = ?, i_time_zone = ?, start_page = ?,
                       i_lang = ?, i_export_type = ?
                 WHERE i_customer = ? AND i_web_user = ?';
        $params = Array($par['web_login'], $par['i_time_zone'], $par['start_page'],
                        $par['i_lang'], $par['i_export_type'],
                        $this->i_customer, $this->i_web_user);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update User."));
        }
    }

}

class Web_User_Default_User_Self extends Web_User_Default_User {

    function __construct($i_customer, $i_web_user = NULL) {
       parent::__construct($i_customer, $i_web_user);
    }

    private function validate_default_user($par) {
        if ($par['web_password'] != '') {
            $i_password_policy = Password_Policy::get($this->i_customer);
            $pp = new Password_Policy($i_password_policy, _('Web Password'));
            $pp->validate_by_owner($par['web_password']);
        }

        if ($par['allowed_hosts'] != '' && $par['allowed_hosts'] != 'Any') {
            foreach (preg_split('/[,\s\n\r;]+/', $par['allowed_hosts'], NULL, PREG_SPLIT_NO_EMPTY) as $ip) {
                if (!Validator::isIPAddress($ip, TRUE)) {
                    throw new Exception(_('"Allowed Hosts" field has incorrect format. Comma separated list of IPs is expected.'));
                }
            }
        }
    }

    public function update_self_default_user($par, $update_session = TRUE) {
        global $db;

        $this->get_i_web_user();

        $this->validate_default_user($par);

        if ($par['web_password'] != '') {
            $ph = new Password_History(Web_Password::WEB_USER, $this->i_web_user, _('Web Password'));
            $ph->chk_rot_upd($par['web_password']);

            if ($update_session) {
                $this->getEntry($this->i_web_user);
                $_SESSION['password'] = $this->web_password;
            }
        }

        $sql = 'UPDATE web_users
                   SET i_time_zone = ?, start_page = ?,
                       i_lang = ?, i_export_type = ?
                 WHERE i_customer = ? AND i_web_user = ?';
        $params = Array($par['i_time_zone'], $par['start_page'],
                        $par['i_lang'], $par['i_export_type'],
                        $this->i_customer, $this->i_web_user);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update User."));
        }

        /* web_allowed_hosts*/
        $sql = 'DELETE FROM web_allowed_hosts
                      WHERE i_web_user = ?';
        $params = Array($this->i_web_user);
        $db->prepNexec($sql, $params);

        if ($par['allowed_hosts'] != '' && $par['allowed_hosts'] != 'Any') {
            $ips = preg_split('/[,\s\n\r;]+/', $par['allowed_hosts'], NULL, PREG_SPLIT_NO_EMPTY);
            $ips = array_unique((array) $ips);
            foreach ($ips as $ip) {
                $sql = 'INSERT INTO web_allowed_hosts (i_web_user, ip)
                             VALUES (?, ?)';
                $params = Array($this->i_web_user, $ip);
                if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
                    throw new Exception(_("Cannot update Allowed Host."));
                }
            }
        }
    }

}
?>
