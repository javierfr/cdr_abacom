<?php

// Copyright (c) 2006-2014 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class File_Upload {
    private $do_nothing;        /* do nothing as it is not a file uploading case */
    private $completed;         /* TRUE if upload is completed */
    private $check_mode;        /* TRUE if client checks if chunk exists on server */
    private $path;
    private $size;

    function __construct() {
        $this->do_nothing = !isset_par('file_uploader');
        $this->completed = FALSE;
        $this->check_mode = ($_SERVER['REQUEST_METHOD'] === 'GET');
        $this->path = NULL;
        $this->size = 0;
    }

    function __destruct() {
        if ($this->path !== NULL) {
            if (@unlink($this->path)) {
                error_log('file ' . $this->path . ' has been deleted');
            }
        }
    }

    public function completed() {
        return $this->completed;
    }

    public function getPath() {
        return $this->path;
    }

    public function getSize() {
        return $this->size;
    }

    public function proceed() {
        if ($this->do_nothing) {
            return;
        }

        //check if the requested chunk exists or not. this makes testChunks work
        if ($this->check_mode) {
            $temp_dir = '/var/tmp/' . get_par('resumableIdentifier');
            $chunk_file = $temp_dir . '/' . get_par('resumableFilename') . '.part'.
                          get_par('resumableChunkNumber');
            if (file_exists($chunk_file)) {
                header("HTTP/1.0 200 Ok");
            } else {
                header("HTTP/1.0 404 Not Found");
            }
            exit();
        }

        // loop through files and move the chunks to a temporarily created directory
        if (!empty($_FILES)) foreach ($_FILES as $file) {

            // check the error status
            if ($file['error'] != 0) {
                error_log(sprintf('file %s: processing chunk #%d: error = %s',
                                  get_par('resumableFilename'), get_par('resumableChunkNumber'),
                                  $file['error']));
                header("HTTP/1.0 503 Error in chunk #" . get_par('resumableChunkNumber'));
                break;
            }

            // init the destination file (format <filename.ext>.part<#chunk>
            // the file is stored in a temporary directory
            $temp_dir = '/var/tmp/' . get_par('resumableIdentifier');
            $dest_file = $temp_dir . '/' . get_par('resumableFilename') . '.part' .
                         get_par('resumableChunkNumber');

            // create the temporary directory
            if (!is_dir($temp_dir)) {
                mkdir($temp_dir, 0777, true);
            }

            // move the temporary file
            if (!move_uploaded_file($file['tmp_name'], $dest_file)) {
                error_log('error saving (move_uploaded_file) chunk #' .
                          get_par('resumableChunkNumber') . ' for file ' .
                          get_par('resumableFilename'));
                header("HTTP/1.0 503 Error in chunk #" . get_par('resumableChunkNumber'));
                break;
            } else {
                // check if all the parts present, and create the final destination file
                $ret = $this->createFileFromChunks($temp_dir, get_par('resumableFilename'), 
                                                   get_par('resumableChunkSize'),
                                                   get_par('resumableTotalSize'));
                if ($ret === FALSE) {
                    /* delete this chunk and the target file to allow to resume the upload */
                    @unlink($dest_file);
                    @unlink('/var/tmp/' . get_par('resumableFilename'));
                }
            }
        }
    }

    /**
     *
     * Check if all the parts exist, and 
     * gather all the parts of the file together
     * @param string $dir - the temporary directory holding all the parts of the file
     * @param string $fileName - the original file name
     * @param string $chunkSize - each chunk size (in bytes)
     * @param string $totalSize - original file size (in bytes)
     */
    public function createFileFromChunks($temp_dir, $fileName, $chunkSize, $totalSize) {
        // count all the parts of this file
        $total_files = 0;
        foreach(scandir($temp_dir) as $file) {
            if (stripos($file, $fileName) !== false) {
                $total_files++;
            }
        }

        // check that all the parts are present
        // the size of the last part is between chunkSize and 2*$chunkSize
        if ($total_files * $chunkSize >=  ($totalSize - $chunkSize + 1)) {

            // create the final destination file 
            if (($fp = fopen('/var/tmp/' . $fileName, 'w')) !== false) {
                for ($i = 1; $i <= $total_files; $i++) {
                    //error_log('writing chunk ' . $i);
                    $chunk_path = $temp_dir . '/' . $fileName. '.part' . $i;
                    $chunk_length = filesize($chunk_path);
                    $ret = fwrite($fp, file_get_contents($chunk_path));
                    if ($ret === FALSE) {
                        fclose($fp);
                        error_log('writing chunk #' . $i . ': fwrite() error');
                        header("HTTP/1.0 503 Error in chunk #" . $i);
                        return FALSE;
                    } elseif ($ret != $chunk_length) {
                        fclose($fp);
                        error_log(sprintf('writing chunk #%d: error: size = %d, has been written %d',
                                          $i, $chunk_length, $ret));
                        header("HTTP/1.0 503 Error in chunk #" . $i);
                        return FALSE;
                    }
                }
                fclose($fp);
                $this->completed = TRUE;
                error_log('file /var/tmp/' . $fileName . ' has been uploaded, size = ' . $totalSize . ' bytes');
                $this->path = '/var/tmp/' . $fileName;
                $this->size = $totalSize;
            } else {
                error_log('cannot create the destination file ' . '/var/tmp/' . $fileName);
                header("HTTP/1.0 503 Error");
                return FALSE;
            }

            // rename the temporary directory (to avoid access from other 
            // concurrent chunks uploads) and than delete it
            if (rename($temp_dir, $temp_dir . '_UNUSED')) {
                rmdir_recurse($temp_dir . '_UNUSED');
                error_log('temporary directory ' . $temp_dir . '_UNUSED' . ' has been deleted');
            } else {
                rmdir_recurse($temp_dir);
                error_log('temporary directory ' . $temp_dir . ' has been deleted');
            }
        }
    }
}
?>
