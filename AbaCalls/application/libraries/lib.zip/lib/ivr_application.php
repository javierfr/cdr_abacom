<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class IVR_Application {

    const TYPE_CALLING_CARD = 1;
    const TYPE_ANI_CALLBACK = 2;
    const TYPE_TOPUP        = 3;
    const TYPE_PLAY_BALANCE = 4;
    const TYPE_CONFERENCE   = 5;

    public $i_ivr_application;
    public $i_customer;
    public $name;
    public $type;
    public $description;

    private $_fault;

    function __construct($i_customer, $i_ivr_application = NULL) {

        $this->i_customer = $i_customer;
        $this->i_ivr_application = $i_ivr_application;
        $this->name = '';
        $this->type = self::TYPE_PLAY_BALANCE;
        $this->description = '';

        $this->_fault = FALSE;
    }

    function __destruct() {
        /* nothing here */
    }

    public static function getInstance($i_customer, $i_ivr_application = NULL, $type = NULL) {
        global $db;

        if ($i_ivr_application !== NULL) {
            $sql = 'SELECT type
                      FROM ivr_applications
                     WHERE i_customer = ? AND i_ivr_application = ?';
            $type = $db->getValue($sql, Array($i_customer, $i_ivr_application));
            if ($db->affected_rows != 1) {
                throw new Exception("No such Id.");
            }
        }

        switch ($type) {
            case self::TYPE_ANI_CALLBACK:
                return new IVR_Application_ANI_Callback($i_customer, $i_ivr_application);
                break;

            case self::TYPE_TOPUP:
                return new IVR_Application_Topup($i_customer, $i_ivr_application);
                break;

            case self::TYPE_PLAY_BALANCE:
                return new IVR_Application_Play_Balance($i_customer, $i_ivr_application);
                break;

            case self::TYPE_CALLING_CARD:
            default:
                return new IVR_Application_Calling_Card($i_customer, $i_ivr_application);
                break;
        }
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_ivr_application) {
        global $db;

        $sql = 'SELECT ia.i_ivr_application, ia.name, ia.type, ia.description
                  FROM ivr_applications ia
                 WHERE ia.i_customer = ? AND ia.i_ivr_application = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($this->i_customer, $i_ivr_application));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_ivr_application = $entry['i_ivr_application'];
        $this->name = $entry['name'];
        $this->type = $entry['type'];
        $this->description = $entry['description'];
    }

    public function initFromRequest($par) {
        $this->i_ivr_application = $par['i_ivr_application'];
        $this->name = $par['ia_name'];
        $this->type = $par['type'];
        $this->description = $par['description'];
    }

    public function genID() {
        global $db;

        return $db->nextID('ivr_applications_seq');
    }

    public static function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('name') != '') {
            $ret['sql'] .= ' AND ia.name ' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('name');
        }

        return $ret;
    }

    public static function getTotal($i_customer) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT COUNT(*)
                  FROM ivr_applications ia
                 WHERE ia.i_customer = ?
                       {$clause['sql']}";
        $params = array_merge(Array($i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public static function getList($i_customer, $off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT ia.i_ivr_application, ia.name, ia.type, ia.description,
                       iat.description AS type_desc,
                       (SELECT COUNT(*) FROM ivr_config ic
                         WHERE ic.section = 'callback' AND ic.option = 'ivrapplication'
                               AND CAST(ic.value AS BIGINT) = ia.i_ivr_application) AS links
                  FROM ivr_applications ia
                  JOIN ivr_application_types iat ON (ia.type = iat.i_ivr_application_type)
                 WHERE ia.i_customer = ?
                       {$clause['sql']}
              ORDER BY ia.name
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($i_customer), $clause['params']);

        return $db->getAll($sql, $params);
    }

    private function doesNameExist($name, $i_ivr_application = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM ivr_applications ia
                 WHERE ia.name = ? AND ia.i_customer = ? AND ia.i_ivr_application <> ?';

        $params = Array($name, $this->i_customer, $i_ivr_application);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $i_ivr_application = 0) {
        if ($par['ia_name'] == '') {
            throw new Exception(_('"Name" field is mandatory.'));
        }

        if ($this->doesNameExist($par['ia_name'], $i_ivr_application)) {
            throw new Exception(_('Another IVR Application with conflicting "Name" already exists.'));
        }
    }

    public function add($par) {
        global $db;

        $i_ivr_application = $this->genID();

        $sql = 'INSERT INTO ivr_applications (i_ivr_application, i_customer, name, type, description)
                     VALUES (?, ?, ?, ?, ?)';
        $params = Array($i_ivr_application, $this->i_customer, $par['ia_name'], $par['type'], $par['description']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert IVR Application."));
        }

        $this->i_ivr_application = $i_ivr_application;
    }

    public function update($par) {
        global $db;

        $sql = 'UPDATE ivr_applications
                   SET name = ?, description = ?
                 WHERE i_ivr_application = ? AND i_customer = ?';
        $params = Array($par['ia_name'], $par['description'],
                        $par['i_ivr_application'], $this->i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update IVR Application."));
        }

        $this->i_ivr_application = $par['i_ivr_application'];
    }

    public function delete($par) {
        global $db;

        $sql = 'DELETE FROM ivr_applications
                 WHERE i_ivr_application = ? AND i_customer = ?';
        $params = Array($par['i_ivr_application'], $this->i_customer);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete IVR Application."));
        }
    }

    public static function getTypes() {
        global $db;

        $sql = "SELECT t.i_ivr_application_type AS type, t.description AS desc,
                       t.depends_on
                  FROM ivr_application_types t
              ORDER BY t.description";

        $types = $db->getAll($sql);

        $ret = Array();
        foreach ($types as $type) {
            if ($type['depends_on'] == '') {
                $ret[] = $type;
            }

            $skip = FALSE;
            $modules = explode(",", $type['depends_on']);
            foreach ($modules as $module) {
                if (!is_module_installed($module)) {
                    $skip = TRUE;
                }
                if ($type['type'] == self::TYPE_CONFERENCE && !$_SESSION["conferencing_enabled"]) {
                    $skip = TRUE;
                }
            }

            if (!$skip) {
                $ret[] = $type;
            }
        }

        return $ret;
    }

    public function getAvailableAdvancedParams() {
        global $db;

        $sql = 'SELECT icd.section, icd.option, icd.value, icd.name, icd.description
                  FROM ivr_config_defaults icd
                 WHERE (i_ivr_application_type = ? OR i_ivr_application_type IS NULL)
                       AND icd.section || icd.option NOT IN (
                        SELECT ic.section || ic.option
                          FROM ivr_config ic
                         WHERE ic.i_ivr_application = ?
                       )
              ORDER BY icd.name';
        return $db->getAll($sql, Array($this->type, $this->i_ivr_application));
    }

    public function getAdvancedParam($i_ivr_config) {
        global $db;

        $sql = 'SELECT ic.i_ivr_config, ic.section, ic.option, ic.value
                  FROM ivr_config ic
                 WHERE ic.i_ivr_application = ? AND ic.i_ivr_config = ?';
        $params = Array($this->i_ivr_application, $i_ivr_config);

        return $db->getAssociatedArray($sql, $params);
    }

    public function genAdvancedParamID() {
        global $db;

        return $db->nextID('ivr_config_seq');
    }

    public function addAdvancedParam($par) {
        global $db;

        $i_ivr_config = $this->genAdvancedParamID();

        list($section, $option) = explode('_', $par['adv_param_name']);

        $sql = 'INSERT INTO ivr_config (i_ivr_config, section, option, value, i_ivr_application)
                     VALUES (?, ?, ?, ?, ?)';
        $params = Array($i_ivr_config, $section, $option, $par['adv_param_val'], $this->i_ivr_application);
        $db->prepNexec($sql, $params);

        return $i_ivr_config;
    }

    public function updateAdvancedParam($par) {
        global $db;

        $sql = 'UPDATE ivr_config
                   SET value = ?
                 WHERE i_ivr_application = ? AND i_ivr_config = ?';
        $params = Array($par['adv_param_val'], $this->i_ivr_application, $par['i_ivr_config']);
        $db->prepNexec($sql, $params);

        return $par['i_ivr_config'];
    }

    public function deleteAdvancedParam($i_ivr_config) {
        global $db;

        $sql = 'DELETE FROM ivr_config
                 WHERE i_ivr_application = ? AND i_ivr_config = ?';
        $params = Array($this->i_ivr_application, $i_ivr_config);
        $db->prepNexec($sql, $params);
    }
}

class IVR_Application_Calling_Card extends IVR_Application {

    public $lang1;
    public $lang2;
    public $lang3;
    public $lang4;
    public $lang5;
    public $lang6;
    public $lang7;
    public $lang8;
    public $lang9;
    public $lang10;
    public $sd_links;           /* smart dial links */

    function __construct($i_customer, $i_ivr_application = NULL) {
        global $db;

        $this->lang1 = 'en';
        $this->lang2 = NULL;
        $this->lang3 = NULL;
        $this->lang4 = NULL;
        $this->lang5 = NULL;
        $this->lang6 = NULL;
        $this->lang7 = NULL;
        $this->lang8 = NULL;
        $this->lang9 = NULL;
        $this->lang10 = NULL;
        $this->sd_links = 0;

        parent::__construct($i_customer, $i_ivr_application);

        if ($this->i_ivr_application === NULL) {
            $lang = $db->getValue('SELECT wu.i_lang
                                     FROM web_users wu
                                     JOIN languages l USING (i_lang)
                                    WHERE wu.i_customer = ? AND wu.default_user AND l.ivr',
                                  Array($i_customer));
            if ($db->affected_rows == 1) {
                $this->lang1 = $lang;
            }
        } else {
            $this->getEntry($this->i_ivr_application);
        }
    }

    function __destruct() {
        parent::__destruct();
    }

    public function getEntry($i_ivr_application) {
        global $db;

        parent::getEntry($i_ivr_application);

        $sql = 'SELECT ic.value
                  FROM ivr_config ic
                 WHERE ic.i_ivr_application = ? AND ic.section = ? AND ic.option = ?';
        $params = Array($this->i_ivr_application, 'callingcard', 'languages');
        $langs = $db->getValue($sql, $params);
        $a = explode(' ', $langs);
        $this->lang1 = $a[0];
        $this->lang2 = array_key_exists(1, $a) ? $a[1] : NULL;
        $this->lang3 = array_key_exists(2, $a) ? $a[2] : NULL;
        $this->lang4 = array_key_exists(3, $a) ? $a[3] : NULL;
        $this->lang5 = array_key_exists(4, $a) ? $a[4] : NULL;
        $this->lang6 = array_key_exists(5, $a) ? $a[5] : NULL;
        $this->lang7 = array_key_exists(6, $a) ? $a[6] : NULL;
        $this->lang8 = array_key_exists(7, $a) ? $a[7] : NULL;
        $this->lang9 = array_key_exists(8, $a) ? $a[8] : NULL;
        $this->lang10 = array_key_exists(9, $a) ? $a[9] : NULL;

        $this->sd_links = $this->getSDLinks();
    }

    public function initFromRequest($par) {
        parent::initFromRequest($par);

        $this->lang1 = $par['lang1'];
        $this->lang2 = $par['lang2'];
        $this->lang3 = $par['lang3'];
        $this->lang4 = $par['lang4'];
        $this->lang5 = $par['lang5'];
        $this->lang6 = $par['lang6'];
        $this->lang7 = $par['lang7'];
        $this->lang8 = $par['lang8'];
        $this->lang9 = $par['lang9'];
        $this->lang10 = $par['lang10'];
    }

    public function validate($par, $i_ivr_application = 0) {
        parent::validate($par, $i_ivr_application);
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        parent::add($par);

        $lang = trim(join(Array($par['lang1'], $par['lang2'], $par['lang3'], $par['lang4'],
                                $par['lang5'], $par['lang6'], $par['lang7'], $par['lang8'],
                                $par['lang9'], $par['lang10']), ' '));

        $sql = 'INSERT INTO ivr_config (section, option, value, i_ivr_application)
                     VALUES (?, ?, ?, ?)';
        $params = Array('callingcard', 'languages', $lang, $this->i_ivr_application);
        $db->prepNexec($sql, $params);

        $this->getEntry($this->i_ivr_application);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $par['i_ivr_application']);

        parent::update($par);

        $lang = trim(join(Array($par['lang1'], $par['lang2'], $par['lang3'], $par['lang4'],
                                $par['lang5'], $par['lang6'], $par['lang7'], $par['lang8'],
                                $par['lang9'], $par['lang10']), ' '));


        $sql = 'UPDATE ivr_config
                   SET value = ?
                 WHERE i_ivr_application = ? AND section = ? AND option = ?';
        $params = Array($lang, $this->i_ivr_application, 'callingcard', 'languages');

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update IVR Application."));
        }

        $this->getEntry($this->i_ivr_application);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        parent::delete($par);
    }

    public function getAdvancedParams() {
        global $db;

        $sql = 'SELECT ic.i_ivr_config, ic.section, ic.option, ic.value, icd.name, icd.description
                  FROM ivr_config ic
                  JOIN ivr_config_defaults icd ON (icd.section = ic.section AND icd.option = ic.option)
                 WHERE ic.i_ivr_application = ? AND icd.i_ivr_config_defaults <> 27
              ORDER BY icd.name';
        return $db->getAll($sql, Array($this->i_ivr_application));
    }

    public function addAdvancedParam($par) {
        list($section, $option) = explode('_', $par['adv_param_name']);

        if ($section == 'callingcard' && $option == 'smartdialexclusive') {
            if (Cast::str2bool($par['adv_param_val']) && $this->sd_links > 1) {
                throw new Exception(_("Cannot set Smart Dial Exclusive Mode option. The IVR Application is used by more than one Smart Dial."));
            }
        }

        parent::addAdvancedParam($par);
    }

    public function updateAdvancedParam($par) {
        $ap = $this->getAdvancedParam($par['i_ivr_config']);

        if ($ap['section'] == 'callingcard' && $option == 'smartdialexclusive') {
            if (Cast::str2bool($par['adv_param_val']) && $this->sd_links > 1) {
                throw new Exception(_("Cannot set Smart Dial Exclusive Mode option. The IVR Application is used by more than one Smart Dial."));
            }
        }

        parent::updateAdvancedParam($par);
    }

    public static function getLangs() {
        global $db;

        $sql = "SELECT l.i_lang AS i_lang, l.name AS name
                  FROM languages l
                 WHERE l.ivr
              ORDER BY l.name";

        return $db->getAll($sql);
    }

    public function getSDLinks() {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM hot_dial_keys h
                  JOIN dids d USING (i_did)
                  JOIN ivr_applications ia USING (i_ivr_application)
                 WHERE ia.i_ivr_application = ?';
        $params = Array($this->i_ivr_application);

        return $db->getValue($sql, $params);
    }

}

class IVR_Application_ANI_Callback extends IVR_Application {

    public $start_ivr;

    function __construct($i_customer, $i_ivr_application = NULL) {
        global $db;

        $this->start_ivr = NULL;

        parent::__construct($i_customer, $i_ivr_application);

        if ($this->i_ivr_application !== NULL) {
            $this->getEntry($this->i_ivr_application);
        }
    }

    function __destruct() {
        parent::__destruct();
    }

    public function getEntry($i_ivr_application) {
        global $db;

        parent::getEntry($i_ivr_application);

        $sql = 'SELECT CAST(ic.value AS BIGINT)
                  FROM ivr_config ic
                 WHERE ic.i_ivr_application = ? AND ic.section = ? AND ic.option = ?';
        $params = Array($this->i_ivr_application, 'callback', 'ivrapplication');
        $this->start_ivr = $db->getValue($sql, $params);
    }

    public function initFromRequest($par) {
        parent::initFromRequest($par);

        $this->start_ivr = $par['start_ivr'];
    }

    public function validate($par, $i_ivr_application = 0) {
        parent::validate($par, $i_ivr_application);

        if ($par['start_ivr'] <= 0) {
            throw new Exception(_('"IVR Application" field is mandatory.'));
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        parent::add($par);

        $sql = 'INSERT INTO ivr_config (section, option, value, i_ivr_application)
                     VALUES (?, ?, ?, ?)';
        $params = Array('callback', 'ivrapplication', $par['start_ivr'], $this->i_ivr_application);
        $db->prepNexec($sql, $params);

        $this->getEntry($this->i_ivr_application);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $par['i_ivr_application']);

        parent::update($par);

        $sql = 'UPDATE ivr_config
                   SET value = ?
                 WHERE i_ivr_application = ? AND section = ? AND option = ?';
        $params = Array($par['start_ivr'], $this->i_ivr_application, 'callback', 'ivrapplication');

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update IVR Application."));
        }

        $this->getEntry($this->i_ivr_application);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        parent::delete($par);
    }

    public function getAdvancedParams() {
        global $db;

        $sql = 'SELECT ic.i_ivr_config, ic.section, ic.option, ic.value, icd.name, icd.description
                  FROM ivr_config ic
                  JOIN ivr_config_defaults icd ON (icd.section = ic.section AND icd.option = ic.option)
                 WHERE ic.i_ivr_application = ? AND icd.i_ivr_config_defaults <> 71
              ORDER BY icd.name';
        return $db->getAll($sql, Array($this->i_ivr_application));
    }

    public static function getIVRApps($i_customer) {
        global $db;

        $sql = "SELECT ia.i_ivr_application AS i_ivr_application, ia.name AS name
                  FROM ivr_applications ia
                 WHERE ia.type <> ? AND ia.i_customer = ?
              ORDER BY ia.name";

        return $db->getAll($sql, Array(parent::TYPE_ANI_CALLBACK, $i_customer));
    }

}

class IVR_Application_Topup extends IVR_Application {

    public $lang1;
    public $lang2;
    public $lang3;
    public $lang4;
    public $lang5;
    public $lang6;
    public $lang7;
    public $lang8;
    public $lang9;
    public $lang10;

    function __construct($i_customer, $i_ivr_application = NULL) {
        global $db;

        $this->lang1 = 'en';
        $this->lang2 = NULL;
        $this->lang3 = NULL;
        $this->lang4 = NULL;
        $this->lang5 = NULL;
        $this->lang6 = NULL;
        $this->lang7 = NULL;
        $this->lang8 = NULL;
        $this->lang9 = NULL;
        $this->lang10 = NULL;
        $this->sd_links = 0;

        parent::__construct($i_customer, $i_ivr_application);

        if ($this->i_ivr_application === NULL) {
            $lang = $db->getValue('SELECT wu.i_lang
                                     FROM web_users wu
                                     JOIN languages l USING (i_lang)
                                    WHERE wu.i_customer = ? AND wu.default_user AND l.ivr',
                                  Array($i_customer));
            if ($db->affected_rows == 1) {
                $this->lang1 = $lang;
            }
        } else {
            $this->getEntry($this->i_ivr_application);
        }
    }

    function __destruct() {
        parent::__destruct();
    }

    public function getEntry($i_ivr_application) {
        global $db;

        parent::getEntry($i_ivr_application);

        $sql = 'SELECT ic.value
                  FROM ivr_config ic
                 WHERE ic.i_ivr_application = ? AND ic.section = ? AND ic.option = ?';
        $params = Array($this->i_ivr_application, 'callingcard', 'languages');
        $langs = $db->getValue($sql, $params);
        $a = explode(' ', $langs);
        $this->lang1 = $a[0];
        $this->lang2 = array_key_exists(1, $a) ? $a[1] : NULL;
        $this->lang3 = array_key_exists(2, $a) ? $a[2] : NULL;
        $this->lang4 = array_key_exists(3, $a) ? $a[3] : NULL;
        $this->lang5 = array_key_exists(4, $a) ? $a[4] : NULL;
        $this->lang6 = array_key_exists(5, $a) ? $a[5] : NULL;
        $this->lang7 = array_key_exists(6, $a) ? $a[6] : NULL;
        $this->lang8 = array_key_exists(7, $a) ? $a[7] : NULL;
        $this->lang9 = array_key_exists(8, $a) ? $a[8] : NULL;
        $this->lang10 = array_key_exists(9, $a) ? $a[9] : NULL;
    }

    public function initFromRequest($par) {
        parent::initFromRequest($par);

        $this->lang1 = $par['lang1'];
        $this->lang2 = $par['lang2'];
        $this->lang3 = $par['lang3'];
        $this->lang4 = $par['lang4'];
        $this->lang5 = $par['lang5'];
        $this->lang6 = $par['lang6'];
        $this->lang7 = $par['lang7'];
        $this->lang8 = $par['lang8'];
        $this->lang9 = $par['lang9'];
        $this->lang10 = $par['lang10'];
    }

    public function validate($par, $i_ivr_application = 0) {
        parent::validate($par, $i_ivr_application);
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        parent::add($par);

        $lang = trim(join(Array($par['lang1'], $par['lang2'], $par['lang3'], $par['lang4'],
                                $par['lang5'], $par['lang6'], $par['lang7'], $par['lang8'],
                                $par['lang9'], $par['lang10']), ' '));

        $sql = 'INSERT INTO ivr_config (section, option, value, i_ivr_application)
                     VALUES (?, ?, ?, ?)';
        $params = Array('callingcard', 'languages', $lang, $this->i_ivr_application);
        $db->prepNexec($sql, $params);

        $this->getEntry($this->i_ivr_application);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $par['i_ivr_application']);

        parent::update($par);

        $lang = trim(join(Array($par['lang1'], $par['lang2'], $par['lang3'], $par['lang4'],
                                $par['lang5'], $par['lang6'], $par['lang7'], $par['lang8'],
                                $par['lang9'], $par['lang10']), ' '));

        $sql = 'UPDATE ivr_config
                   SET value = ?
                 WHERE i_ivr_application = ? AND section = ? AND option = ?';
        $params = Array($lang, $this->i_ivr_application, 'callingcard', 'languages');

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update IVR Application."));
        }

        $this->getEntry($this->i_ivr_application);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        parent::delete($par);
    }

    public function getAdvancedParams() {
        global $db;

        $sql = 'SELECT ic.i_ivr_config, ic.section, ic.option, ic.value, icd.name, icd.description
                  FROM ivr_config ic
                  JOIN ivr_config_defaults icd ON (icd.section = ic.section AND icd.option = ic.option)
                 WHERE ic.i_ivr_application = ? AND icd.i_ivr_config_defaults <> 27
              ORDER BY icd.name';
        return $db->getAll($sql, Array($this->i_ivr_application));
    }

    public function addAdvancedParam($par) {
        parent::addAdvancedParam($par);
    }

    public function updateAdvancedParam($par) {
        parent::updateAdvancedParam($par);
    }

    public static function getLangs() {
        global $db;

        $sql = "SELECT l.i_lang AS i_lang, l.name AS name
                  FROM languages l
                 WHERE l.ivr
              ORDER BY l.name";

        return $db->getAll($sql);
    }

    public function getAvailableAdvancedParams() {
        global $db;

        $sql = 'SELECT icd.section, icd.option, icd.value, icd.name, icd.description
                  FROM ivr_config_defaults icd
                 WHERE (i_ivr_config_defaults IN (7, 73, 9, 11, 15, 16, 20, 28, 30, 31, 33, 40, 41, 43, 45, 46, 48, 14, 50, 80, 88) OR i_ivr_application_type IS NULL)
                       AND icd.section || icd.option NOT IN (
                        SELECT ic.section || ic.option
                          FROM ivr_config ic
                         WHERE ic.i_ivr_application = ?
                       )
              ORDER BY icd.name';
        return $db->getAll($sql, Array($this->i_ivr_application));
    }

}

class IVR_Application_Play_Balance extends IVR_Application_Calling_Card {

    public function getAvailableAdvancedParams() {
        global $db;

        $sql = 'SELECT icd.section, icd.option, icd.value, icd.name, icd.description
                  FROM ivr_config_defaults icd
                 WHERE (i_ivr_application_type = ? OR i_ivr_application_type IS NULL OR i_ivr_config_defaults IN (81, 36, 37))
                       AND icd.section || icd.option NOT IN (
                        SELECT ic.section || ic.option
                          FROM ivr_config ic
                         WHERE ic.i_ivr_application = ?
                       )
              ORDER BY icd.name';
        return $db->getAll($sql, Array($this->type, $this->i_ivr_application));
    }
}

?>
