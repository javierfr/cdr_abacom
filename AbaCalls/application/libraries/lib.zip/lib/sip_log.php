<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class SIP_Log {

    const STATUS_EXTRACTING = 0;
    const STATUS_COMPLETED  = 1;
    const STATUS_NOT_FOUND  = 2;

    public $i_sip_log;
    public $call_id;
    public $description;
    public $status;
    public $log;

    private $_fault;

    function __construct($i_sip_log = NULL) {
        $this->i_sip_log = $i_sip_log;
        $this->call_id = NULL;
        $this->description = '';
        $this->status = SIP_Log::STATUS_EXTRACTING;
        $this->log = NULL;

        $this->_fault = FALSE;

        if ($this->i_sip_log !== NULL) {
            $this->getEntry($this->i_sip_log);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_sip_log) {
        global $db;

        $sql = "SELECT sl.*
                  FROM sip_logs sl
                 WHERE sl.i_sip_log = ?
                 LIMIT 1";
        $params = Array($i_sip_log);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_sip_log = $i_sip_log;

        $this->call_id = $entry['call_id'];
        $this->description = $entry['description'];
        $this->status = $entry['status'];
        $this->log = base64_decode($entry['log']);
    }

    public function getTotal() {
        global $db;

        $sql = "SELECT COUNT(sl.*)
                  FROM sip_logs sl";

        return $db->getValue($sql);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $sql = "SELECT sl.*
                  FROM sip_logs sl
              ORDER BY sl.i_sip_log DESC
                 LIMIT ${rpp}
                OFFSET ${off}";

        $ret = $db->getAll($sql);

        return $ret;
    }

    public function validate($par) {
        if ($par['call_id'] == '') {
            throw new Exception(_('"Call-Id" field is mandatory.'));
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $sql = "INSERT INTO sip_logs (call_id, description)
                     VALUES (?, ?)";

        $params = Array($par['call_id'],
                        $par['description']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Extracting Task."));
        }

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        $sql = 'DELETE FROM sip_logs
                      WHERE i_sip_log = ?';
        $params = Array($this->i_sip_log);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete SIP Log."));
        }
    }

    public function get($par) {
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename=sip-log-' . $this->call_id . '.txt');
        print $this->log;
        exit();
    }
}

class SIP_Log_Viewer {

    function __construct($sip_log = NULL) {
        $this->sip_log = $sip_log;
    }

    function __destruct() {
        /* nothing here */
    }

    public function find_ip($line, $str, $n = 0){
        $find = strpos($line, $str); 
        if( $find > 0 ){
            return substr($line, $find + strlen($str), $n);
        }
        return '';
    }

    public function get_sender($line){
        if (strpos($line, 'b2bua')){
            return 'B2BUA';
        } elseif (strpos($line, 'opensips') || strpos($line, 'ser')) {
            return 'FRONTEND';
        } elseif (strpos($line, 'rtpproxy[')) {
            return 'RTPPROXY';
        } else{
            return '';
        }
    }

    public function get_sip_message($str, $key){
        $arr = explode(' ', $str);
        if ($arr[0] == 'SIP/2.0'){
            if (substr($arr[1],0,1) >= '3') {
                $sipmsg = '<a style="text-decoration: none; color: red; cursor: pointer;">'.str_pad($arr[1].'-'.substr($arr[2],0,-1), 28, '-', STR_PAD_BOTH).'</a>';
            } elseif (substr($arr[1],0,3) == '200') {
                $sipmsg = '<a style="text-decoration: none; color: green; cursor: pointer;">'.str_pad($arr[1].'-'.substr($arr[2],0,-1), 28, '-', STR_PAD_BOTH).'</a>';
            } elseif (substr($arr[1],0,1) == '1') {
                $sipmsg = '<a style="text-decoration: none; color: gray; cursor: pointer;">'.str_pad($arr[1].'-'.substr($arr[2],0,-1), 28, '-', STR_PAD_BOTH).'</a>';
            } else {
                $sipmsg = '<a style="text-decoration: none; cursor: pointer;">'.str_pad($arr[1].'-'.substr($arr[2],0,-1), 28, '-', STR_PAD_BOTH).'</a>';
            }
        } else {
            $sipmsg = '<a style="text-decoration: none; cursor: pointer;">'.str_pad($arr[0], 28, '-',STR_PAD_BOTH).'</a>'; 
        }

        return $sipmsg;
    }

    public function sort_log($str) {
        $strAr = explode("\n", $str);
        $i = -1;
        $j = 0;
        $ret['time'] = substr($strAr[0], 0,strpos($strAr[0], '/'));
        foreach($strAr as $key => $line){
            if ((strpos($line, 'RECEIVED message from ') > 0 || strpos($line, 'SENDING message to ') > 0) ||
                 strpos($line, 'rtpproxy[') > 0) {
                $i++;
                $j = 0;
                $newAr[$i]['time_str'] = substr($line, 0,strpos($line, '/'));
                $newAr[$i]['time'] = $this->time_from_setup(substr($line, 0,strpos($line, '/')), $ret['time']);
                $newAr[$i]['sender'] = $this->get_sender($line);
                $newAr[$i]['order_number'] = $i;
            }
            $newAr[$i]['message'][$j] = $line;
            if ($j == 1) {
                $newAr[$i]['sipmsg'] = $this->get_sip_message($line, $key);
            }
            $j++;
        }

        function cmp($a, $b) {
            if ($a['time'] == $b['time']) {
                return ($a['order_number'] > $b['order_number']) ? 1 : -1;
            } else {
                return ($a['time'] > $b['time']) ? 1 : -1;
            }
        };

        usort($newAr, "cmp");

        $ret['time'] = $newAr[0]['time_str'];
        $delta = $newAr[0]['time'];
        foreach($newAr as &$val) {
            $val['time'] = sprintf('%0.3f', $val['time'] - $delta);
            unset($val['time_str']);
        }

        $ret['sip_log'] = $newAr;

        return $ret;
    }

    public function time_from_setup($t1, $t2){
        $t1 = substr($t1, 0, 6) . ' ' . date("Y") . substr($t1, -13);
        $t2 = substr($t2, 0, 6) . ' ' . date("Y") . substr($t2, -13);

        $startTime = new DateTime($t2);
        $endTime  = new DateTime($t1);

        $diff = $endTime->format('U') + $endTime->format('u') / (1000.0 * 1000.0) -
                ($startTime->format('U') + $startTime->format('u') / (1000.0 * 1000.0));
        $diff = sprintf('%0.3f', $diff);

        return $diff; 

    }

    public function parse() {
        $siplog = htmlspecialchars($this->sip_log);
        $logAr = $this->sort_log($siplog);
        $logAr['uas']['0'] = $this->find_ip($logAr['sip_log'][0]['message'][0], 'RECEIVED message from ', -1);
        foreach($logAr['sip_log'] as $key => $line){
            if (is_array($logAr['sip_log'][$key]['message'])) {
                foreach($logAr['sip_log'][$key]['message'] as $jkey => $jline){
                    $ip_received = $this->find_ip($jline, 'RECEIVED message from ', -1);
                    $ip_send = $this->find_ip($jline, 'SENDING message to ', -1);
                    if ($ip_send !='' && !in_array($ip_send, $logAr['uas'])) {
                        array_push($logAr['uas'], $ip_send);
                    }
                    if ($ip_received !='' && !in_array($ip_received, $logAr['uas'])) {
                        array_push($logAr['uas'], $ip_received);
                    }
                }
            }
        }
        $tmp = $logAr['uas'][1];
        $logAr['uas'][1] = $logAr['uas'][2];
        $logAr['uas'][2] = $tmp;
        $ip_fe = $logAr['uas'][1];
        $i_fe = array_search($ip_fe, $logAr['uas']);
        $ip_b2b = $logAr['uas'][2];
        $i_b2b = array_search($ip_b2b, $logAr['uas']);
        $logAr['web']['head'] = str_pad(substr($logAr['time'], 0, -4), 16, ' ', STR_PAD_LEFT) . ' ';
        foreach ($logAr['uas'] as $i_ua => $ua) {
            $logAr['web']['head'] .= '|'.str_pad($ua, 30, ' ');
        }
        foreach($logAr['sip_log'] as $key => $line){
            if (is_array($logAr['sip_log'][$key]['message'])) {
                foreach($logAr['sip_log'][$key]['message'] as $jkey => $jline){
                    if (strpos($jline, 'rtpproxy[')) {
                        $rtp_msg = substr($jline, strpos($jline, ']: ') + 3);
                        $logAr['web'][$key] .= "\n".str_pad($logAr['sip_log'][$key]['time'], 16, ' ', STR_PAD_LEFT).' | ' .
                                               'rtpproxy: ' . $rtp_msg;
                        continue;
                    }
                    $ip_received = $this->find_ip($jline, 'RECEIVED message from ', -1);
                    $ip_send = $this->find_ip($jline, 'SENDING message to ', -1);
                    if ($ip_received != '' || $ip_send != '') {
                        $sipmsg = $this->get_sip_message($logAr['sip_log'][$key]['message'][$jkey+1], $key);
                        $sender = $this->get_sender($jline);
                        $logAr['web'][$key] = str_pad($logAr['sip_log'][$key]['time'], 16, ' ', STR_PAD_LEFT).' |';
                        $k = 0;
                        foreach ($logAr['uas'] as $i_ua => $ua) {
                            if ($ip_received == $ua) {
                                if ($sender == 'FRONTEND') {
                                    $logAr['web'][$key] .= ($i_fe >$i_ua) ? '&#64;'.$sipmsg : '&#64;|';
                                    $k = ($i_fe >$i_ua) ? 1:0;
                                } elseif ($sender == 'B2BUA') {
                                    $logAr['web'][$key] .= ($i_b2b >$i_ua) ? '&#64;'.$sipmsg : '&#64;|';
                                    $k= ($i_b2b >$i_ua) ? 1:0;
                                }
                            } elseif ($ip_send == $ua) {
                                if ($sender == 'FRONTEND') {
                                    $logAr['web'][$key] .= ($i_fe>$i_ua) ? '&#60;'.$sipmsg : '&#62;|';
                                    $k = ($i_fe >$i_ua) ? 1:0;
                                } elseif ($sender == 'B2BUA') {
                                    $logAr['web'][$key] .= ($i_b2b>$i_ua) ? '&#60;'.$sipmsg : '&#62;|';
                                    $k= ($i_b2b >$i_ua) ? 1:0;
                                }
                            } elseif ($ua == $ip_fe && $ip_received !='' && $sender == 'FRONTEND') {
                                $logAr['web'][$key] .= ($i_fe>array_search($ip_received, $logAr['uas'])) ? '&#62;|' : '&#60;'.$sipmsg;
                                $k = ($i_fe>array_search($ip_received, $logAr['uas'])) ? 0:1;
                            } elseif ($ua == $ip_fe && $ip_send !='' && $sender == 'FRONTEND') {
                                $logAr['web'][$key] .= ($i_fe>array_search($ip_send, $logAr['uas'])) ? '&#64;|' : '&#64;'.$sipmsg;
                                $k = ($i_fe>array_search($ip_send, $logAr['uas'])) ? 0:1;
                            } elseif ($ua == $ip_b2b && $ip_received !='' && $sender == 'B2BUA') {
                                $logAr['web'][$key] .= ($i_b2b>array_search($ip_received, $logAr['uas'])) ? '&#62;|' : '&#60;'.$sipmsg;
                                $k = ($i_b2b>array_search($ip_received, $logAr['uas'])) ? 0:1;
                            } elseif ($ua == $ip_b2b && $ip_send !='' && $sender == 'B2BUA') {
                                $logAr['web'][$key] .= ($i_b2b>array_search($ip_send, $logAr['uas'])) ? '&#64;|' : '&#64;'.$sipmsg;
                                $k = ($i_b2b>array_search($ip_send, $logAr['uas'])) ? 0 : 1;
                            } elseif ($k == 1){
                                $logAr['web'][$key] .='-------------------------------';
                            } else {
                                $logAr['web'][$key] .='                              |';
                            }
                        }
                    }
                }
            }
        } 

        return $logAr;
    }
}
?>
