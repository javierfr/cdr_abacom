<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Password_Policy {

    const LETTERS_DIGITS = 1;   /* Letters and Digits */
    const LETTERS = 2;          /* Letters (digits are optional) */
    const DIGITS = 3;           /* Digits (letters are optional) */
    const ANY = 4;              /* Any characters */

    const MAX_LENGTH = 32;      /* Max password length */

    public $web_label;          /* label name on the web */

    public $min_length;
    public $change_first_login;
    public $expires;
    public $block_idle_in;
    public $use_as_default;
    public $i_password_policy;
    public $i_password_content;
    public $i_customer;
    public $immutable;
    public $system;

    function __construct($i_password_policy = NULL, $web_label = NULL) {
        $this->web_label = $web_label;

        $this->min_length = NULL;
        $this->change_first_login = NULL;
        $this->expires = NULL;
        $this->block_idle_in = NULL;
        $this->use_as_default = NULL;
        $this->i_password_policy = $i_password_policy;
        $this->i_password_content = NULL;
        $this->i_customer = NULL;
        $this->immutable = NULL;
        $this->system = NULL;

        if ($this->i_password_policy !== NULL) {
            $this->getEntry($this->i_password_policy);
        }

        if ($this->web_label === NULL) {
            $this->web_label = _('Password');
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_password_policy) {
        global $db;

        $sql = 'SELECT *
                  FROM password_policies
                 WHERE i_password_policy = ?';
        $entry = $db->getAssociatedArray($sql, Array($i_password_policy));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->min_length = $entry['min_length'];
        $this->change_first_login = $entry['change_first_login'] == 't' ? TRUE : FALSE;
        $this->expires = $entry['expires'];
        $this->block_idle_in = $entry['block_idle_in'];
        $this->use_as_default = $entry['use_as_default'] == 't' ? TRUE : FALSE;
        $this->i_password_policy = $entry['i_password_policy'];
        $this->i_password_content = $entry['i_password_content'];
        $this->i_customer = $entry['i_customer'];
        $this->immutable = $entry['immutable'] == 't' ? TRUE : FALSE;
        $this->system = $entry['system'] == 't' ? TRUE : FALSE;
    }

    public function validate_by_owner($val) {
        if ($this->immutable) {
            throw new Exception(sprintf(_('You cannot change "%s" field.'), $this->web_label));
        }

        $this->validate($val);
    }

    public function validate($val) {
        if (strlen((string)$val) < $this->min_length) {
            throw new Exception(sprintf(_('"%s" field should contain at least %0d symbols.'), $this->web_label,
                                        $this->min_length));
        }

        if (strlen((string)$val) > self::MAX_LENGTH) {
            throw new Exception(sprintf(_('"%s" field is too long. Not more than %0d symbols is allowed.'), $this->web_label,
                                        self::MAX_LENGTH));
        }

        switch ($this->i_password_content) {
        case self::LETTERS:
            if (!preg_match('/[[:alpha:]]/', (string)$val)) {
                throw new Exception(sprintf(_('"%s" field should contain letters.'), $this->web_label));
            }

            break;

        case self::DIGITS:
            if (!preg_match('/\d/', (string)$val)) {
                throw new Exception(sprintf(_('"%s" field should contain digits.'), $this->web_label));
            }

            break;

        case self::ANY:

            break;

        case self::LETTERS_DIGITS:
        default:
            if (!(preg_match('/[[:alpha:]]/', (string)$val) && preg_match('/\d/', (string)$val))) {
                throw new Exception(sprintf(_('"%s" field should contain letters and digits.'), $this->web_label));
            }

            break;
        }
    }

    public static function getList($i_customer) {
        global $db;

        $sql = '(SELECT i_password_policy, name
                   FROM password_policies
                  WHERE (i_customer = ? OR i_customer ISNULL) AND use_as_default
               ORDER BY i_customer, name)
                UNION ALL
                (SELECT i_password_policy, name
                   FROM password_policies
                  WHERE i_customer ISNULL AND NOT use_as_default
               ORDER BY name)
                UNION ALL
                (SELECT i_password_policy, name
                   FROM password_policies
                  WHERE i_customer = ? AND NOT use_as_default
               ORDER BY name)';

        return $db->getAll($sql, Array($i_customer, $i_customer));
    }

    public static function get($i_customer) {
        global $db;

        $sql = 'SELECT i_password_policy
                  FROM customers
                 WHERE i_customer = ?';

        return $db->getValue($sql, Array($i_customer));
    }

    public static function getMaxPasswordLength($i_customer) {
        global $db;

        $sql = 'SELECT MAX(min_length)
                  FROM password_policies
                 WHERE i_customer = ? OR i_customer ISNULL';

        return $db->getValue($sql, Array($i_customer));
    }

    public static function isAllowed($i_customer, $i_password_policy) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM password_policies
                 WHERE (i_customer = ? OR i_customer ISNULL)
                       AND i_password_policy = ?';

        return $db->getValue($sql, Array($i_customer, $i_password_policy)) == 1;
    }
}
?>
