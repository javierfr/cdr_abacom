<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Followme {
    public $i_followme_mode;
    public $i_account;
    public $enabled;

    /* these are for runtime entry: */
    public $i_followme_entry;
    public $description;
    public $timeout;
    public $preference;
    public $cld;

    private $_fault;

    function __construct($i_account, $i_followme_entry = NULL) {
        $this->i_account = $i_account;
        $this->i_followme_entry = $i_followme_entry;
        $this->enabled = $this->isEnabled();

        $this->description = '';
        $this->timeout = 15;
        $this->preference = 1;
        $this->cld = '';

        $this->_fault = FALSE;

        if ($this->i_followme_entry !== NULL) {
           $this->getEntry($this->i_followme_entry);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function isEnabled() {
        global $db;

        $sql = 'SELECT followme_enabled 
                  FROM accounts 
                 WHERE i_account = ?';
        $followme_enabled = $db->getValue($sql, Array($this->i_account));
        
        return Cast::str2bool($followme_enabled);
    }

    public function getModes() {
        global $db;

        $sql = 'SELECT i_followme_mode, name 
                  FROM followme_modes
              ORDER BY name';

        return $db->getAll($sql);
    }

    public function getMode() {
        global $db;

        $sql = 'SELECT i_followme_mode 
                  FROM accounts 
                 WHERE i_account = ?';
        $params = Array($this->i_account);
        $i_followme_mode = $db->getValue($sql, $params);

        return  $i_followme_mode;
    }

    public function setMode($i_followme_mode) {
        global $db;

        $this->setFault(TRUE);    

        $sql = 'UPDATE accounts 
                   SET i_followme_mode = ? 
                 WHERE i_account = ?';
        $params = array($i_followme_mode,
                        $this->i_account);
        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_('Cannot update "Follow Me Mode".'));
        }

        $this->setFault(FALSE);
    }


    public function getEntries() {
        global $db;
        
        $sql = 'SELECT i_followme_entry, cld, description,
                       timeout, preference 
                  FROM followme_entries 
                 WHERE i_account = ? 
              ORDER BY preference';

        return $db->getAll($sql, Array($this->i_account));
    }

    public function getEntry($i_followme_entry) {
        global $db;

        $sql = 'SELECT i_followme_entry, cld, description,
                       timeout, preference 
                  FROM followme_entries 
                 WHERE i_account = ? 
                   AND i_followme_entry = ?';
        $params = Array($this->i_account, 
                        $i_followme_entry);

        $entry = $db->getAssociatedArray($sql, $params);

	    if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
	    }

        $this->i_followme_entry = $entry['i_followme_entry'];
        $this->preference = $entry['preference'];
        $this->cld = $entry['cld'];
        $this->timeout = $entry['timeout'];
        $this->description = $entry['description'];
    }

    public function initFromRequest($par) {
        $this->preference = $par['preference'];
        $this->cld = $par['cld'];
        $this->timeout = $par['timeout'];
        $this->description = $par['description'];
    }
        
    public function updateEntry($par) {
        global $db;
        
        $this->setFault(TRUE);

        $this->validate($par, $this->i_followme_entry);

        $sql = 'UPDATE followme_entries 
                   SET cld = ?, description = ?, timeout = ?
                 WHERE i_account = ? AND i_followme_entry = ?';
        $params = array($par['cld'], 
                        $par['description'],
                        $par['timeout'],
                        $this->i_account,
                        $this->i_followme_entry);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_('Cannot update "Follow Me Entry".'));
        }

        $this->setFault(FALSE);
    }


    public function genID() {
        global $db;

        return $db->nextID('followme_entries_seq');
    }
    
    public function getMaxPreference()  {
        global $db;

        $sql = 'SELECT max(preference) 
                  FROM followme_entries 
                 WHERE i_account = ?';

        return $db->getValue($sql, array($this->i_account));
    } 

    public function validate($par, $i_followme_entry = 0) {
        global $db;

        if ($i_followme_entry > 0 &&
            (!Validator::isNumber($par['preference']) || $par['preference'] < 1 || $par['preference'] > 20)) {
            throw new Exception(_('"Order Preference" field has incorrect number format. Number in the range from 1 to 20 is expected.'));
        }
        if (trim($par['cld']) == '') {
            throw new Exception(_('"Phone Number/CLD" field is mandatory..'));
        }

        if (!Validator::isNumber($par['timeout']) || $par['timeout'] < 5 || $par['timeout'] > 60) {
            throw new Exception(_('"Timeout" field has incorrect number format. Number in the range from 5 to 60 is expected.'));
        }
    }


    public function addEntry($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $db->begin();

        $i_followme_entry = $this->genID();

        $sql = 'UPDATE followme_entries
                   SET preference = preference + 1
                 WHERE i_account = ? AND preference >= ?';
        $params = array($this->i_account, 
                        $par['preference']);
        $db->prepNexec($sql, $params);

        $sql = 'INSERT INTO followme_entries(i_followme_entry,
                            description,
                            i_account,
                            timeout,
                            preference,
                            cld)
                            VALUES(?, ?, ?, ?, ?, ?)';

        $params = array($i_followme_entry,
                        $par['description'],
                        $this->i_account,
                        $par['timeout'],
                        $par['preference'],
                        $par['cld']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_('Cannot add "Follow Me Entry".'));
        }
        
        $this->i_followme_entry = $i_followme_entry;

        $db->commit();

        $this->setFault(FALSE);
    }
   
    public function upEntry() {
        global $db;

        $this->setFault(TRUE);

        $db->begin();

        $sql = 'UPDATE followme_entries 
                   SET preference = preference + 1 
                 WHERE preference = ? - 1 AND i_account = ?';
        $params = array($this->preference, 
                        $this->i_account);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_('Cannot move up "Follow Me Entry".'));
        }

        $sql = 'UPDATE followme_entries 
                   SET preference = preference - 1 
                 WHERE i_followme_entry = ? AND i_account = ?';
        $params = array($this->i_followme_entry, 
                        $this->i_account);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_('Cannot move up "Follow Me Entry".'));
        }

        $db->commit();

        $this->setFault(FALSE);
    }
    
    public function downEntry() {
        global $db;
        
        $this->setFault(TRUE);

        $db->begin();

        $sql = 'UPDATE followme_entries 
                   SET preference = preference - 1 
                 WHERE preference= ? + 1 AND i_account = ?';
        $params = array($this->preference, 
                        $this->i_account);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();
            throw new Exception(_('Cannot move down "Follow Me Entry".'));
        }

        $sql = 'UPDATE followme_entries 
                   SET preference = preference + 1 
                 WHERE i_followme_entry = ? AND i_account = ?';
        $params = array($this->i_followme_entry,
                        $this->i_account);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();    
            throw new Exception(_('Cannot move down "Follow Me Entry".'));
        }
        
        $db->commit();

        $this->setFault(FALSE);
    }

    public function deleteEntry() {
        global $db;
            
        $this->setFault(TRUE);

        $db->begin();

        $sql = 'DELETE FROM followme_entries 
                 WHERE i_account = ? AND i_followme_entry = ?';
        $params = array($this->i_account,
                        $this->i_followme_entry);
        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            $db->rollback();    
            throw new Exception(_('Cannot delete "Follow Me Entry".'));
        }
    
        $sql = 'UPDATE followme_entries 
                   SET preference = preference - 1 
                 WHERE preference > ? 
                   AND i_account = ?';

        $params = array($this->preference,
                        $this->i_account);
        if (!$db->prepNexec($sql, $params)) {
            $db->rollback();
            throw new Exception(_('Cannot delete "Follow Me Entry".'));
        }

        $db->commit();

        $this->setFault(FALSE);
    }

    public function setFollowme_Timeout($followme_timeout) {
        global $db;

        $this->setFault(TRUE);    

        if (!Validator::isNumber($followme_timeout) || $followme_timeout < 5 || $followme_timeout > 60) {
            throw new Exception(_('"Timeout" field has incorrect number format. Number in the range from 5 to 60 is expected.'));
        }

        $sql = 'UPDATE accounts 
                   SET followme_timeout = ? 
                 WHERE i_account = ?';
        $params = array($followme_timeout,
                        $this->i_account);
        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_('Cannot update "Timeout".'));
        }

        $this->setFault(FALSE);
    }

}

?>
