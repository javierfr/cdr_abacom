<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Incoming_Route {

    const FORWARD_DID_MODE_OFF = 1;
    const FORWARD_DID_MODE_IN_URI = 2;
    const FORWARD_DID_MODE_DIVERSION_HEADER = 3;

    public $i_incoming_route;
    public $i_customer;
    public $i_account;
    public $i_trunk;
    public $i_did;
    public $did_translation_rule;
    public $i_forward_did_mode;
    public $self_managed;

    private $_fault;

    function __construct($i_customer, $i_account, $i_incoming_route = NULL) {
        global $db;

        $this->i_customer = $i_customer;
        $this->i_account = $i_account;
        $this->i_incoming_route = $i_incoming_route;
        $this->i_trunk = NULL;
        $this->i_did = NULL;
        $this->did_translation_rule = '';
        $this->i_forward_did_mode = self::FORWARD_DID_MODE_DIVERSION_HEADER;
        $this->self_managed = FALSE;

        $this->_fault = FALSE;

        if ($this->i_incoming_route !== NULL) {
            $this->getEntry($this->i_incoming_route);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_incoming_route) {
        global $db;

        $sql = 'SELECT ir.*,
                       dids.translation_rule AS did_translation_rule
                  FROM incoming_routes ir
                  JOIN accounts a ON (a.i_account = ir.i_account)
             LEFT JOIN dids ON (dids.i_did = ir.i_did)
                 WHERE a.i_customer = ? AND ir.i_account = ? AND ir.i_incoming_route = ?
                 LIMIT 1';
        $params = Array($this->i_customer, $this->i_account, $i_incoming_route);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_incoming_route = $i_incoming_route;
        $this->i_trunk = $entry['i_trunk'];
        $this->i_did = $entry['i_did'];
        $this->did_translation_rule = $entry['did_translation_rule'];
        $this->i_forward_did_mode = $entry['i_forward_did_mode'];
        $this->self_managed = Cast::str2bool($entry['self_managed']);
    }

    public function initFromRequest($par) {
        $this->i_incoming_route = $par['i_incoming_route'];
        $this->i_trunk = $par['i_trunk'];
        $this->i_did = $par['i_did'];
        $this->i_forward_did_mode = $par['i_forward_did_mode'];
        $this->self_managed = Cast::str2bool($par['self_managed']);
    }

    public function getTotal() {
        global $db;

        $sql = "SELECT COUNT(ir.*)
                  FROM incoming_routes ir
                  JOIN accounts a ON (a.i_account = ir.i_account)
                 WHERE a.i_customer = ? AND ir.i_account = ?";
        $params = Array($this->i_customer, $this->i_account);

        return $db->getValue($sql, $params);
    }

    public function reset_n($id) {
        global $db;

        $n = 0;

        $sql = "SELECT ir.i_incoming_route AS id
                  FROM incoming_routes ir
                  JOIN accounts a ON (a.i_account = ir.i_account)
                 WHERE a.i_customer = ? AND ir.i_account = ?
              ORDER BY ir.i_incoming_route";
        $params = Array($this->i_customer, $this->i_account);

        $rows = $db->getAll($sql, $params);

        $i = 0;
        foreach ($rows as $row) {
            if ($i++ == ROW_PER_PAGE) {
                $n++;
                $i = 0;
            }
            if ($row['id'] == $id) {
                break;
            }
        }

        return $n;
    }
    
    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $sql = "SELECT ir.i_incoming_route, ir.i_account, ir.i_trunk,
                       ir.i_did, ir.self_managed, dids.did,
                       dids.translation_rule AS did_translation_rule,
                       t.name AS trunk_name, ir.i_forward_did_mode,
                       fdm.description AS forward_did_mode
                  FROM incoming_routes ir
                  JOIN accounts a ON (a.i_account = ir.i_account)
             LEFT JOIN dids ON (dids.i_did = ir.i_did)
             LEFT JOIN forward_did_modes fdm ON (ir.i_forward_did_mode = fdm.i_forward_did_mode)
             LEFT JOIN trunks t ON (t.i_trunk = ir.i_trunk)
                 WHERE a.i_customer = ? AND ir.i_account = ?
              ORDER BY ir.i_incoming_route
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = Array($this->i_customer, $this->i_account);

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$r) {
            $r['self_managed'] = Cast::str2bool($r['self_managed']);
        }

        return $ret;
    }

    public function validate($par) {
        /* do nothing */
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        $params = array(
            'updated_by' => new xmlrpcval(Operator::get(), "string"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct"),

            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'i_incoming_route' => new xmlrpcval($par['i_incoming_route'], "int"),
            'self_managed' => new xmlrpcval(Cast::str2bool($par['self_managed']), "boolean"),
            'i_trunk' => new xmlrpcval($par['i_trunk'], $par['i_trunk'] > 0 ? 'int' : 'null')
        );

        if ($this->i_did > 0) {
            $params['i_forward_did_mode'] = new xmlrpcval($par['i_forward_did_mode'], "int");
        }

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('updateIncomingRoute', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->getEntry($this->i_incoming_route);

        $this->setFault(FALSE);
    }
}

class Incoming_Route_Self extends Incoming_Route {

    public function initFromRequest($par) {
        $this->i_trunk = $par['i_trunk'];
        $this->i_forward_did_mode = $par['i_forward_did_mode'];
        $this->did_translation_rule = $par['did_translation_rule'];
    }

    public function validate($par) {
        if (!$this->self_managed) {
            throw new Exception(_('You are not allowed to change this Incoming Route.'));
        }

        parent::validate($par);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par);

        /***/
        $params = array(
            'updated_by' => new xmlrpcval(Operator::get(), "string"),
            'audit_info' => new xmlrpcval(Audit_Info::get(), "struct"),

            'i_customer' => new xmlrpcval($this->i_customer, "int"),
            'i_incoming_route' => new xmlrpcval($par['i_incoming_route'], "int"),
            'i_trunk' => new xmlrpcval($par['i_trunk'], $par['i_trunk'] > 0 ? 'int' : 'null')
        );

        $params = array(new xmlrpcval($params, 'struct'));
        $msg = new xmlrpcmsg('updateIncomingRoute', $params);

        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        /***/
        if ($this->i_did > 0) {
            $params = array(
                'updated_by' => new xmlrpcval(Operator::get(), "string"),
                'audit_info' => new xmlrpcval(Audit_Info::get(), "struct"),

                'i_customer' => new xmlrpcval($this->i_customer, "int"),
                'i_did' => new xmlrpcval($this->i_did, "int"),
                'translation_rule' => new xmlrpcval($par['did_translation_rule'], "string")
            );

            $params = array(new xmlrpcval($params, 'struct'));
            $msg = new xmlrpcmsg('updateDID', $params);

            $master_addr = get_master_XMLRPC_server();
            $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
            $cli->setSSLVerifyPeer(false);
            $cli->return_type = 'phpvals';

            $res = $cli->send($msg);
            if ($res->faultCode()) {
                throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            }
        }

        /***/
        $this->getEntry($this->i_incoming_route);

        $this->setFault(FALSE);
    }
}

?>
