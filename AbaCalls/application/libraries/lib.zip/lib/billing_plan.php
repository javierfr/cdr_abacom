<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Billing_Plan {

    const BILLING_CYCLE_WEEKLY      = 1;
    const BILLING_CYCLE_BI_WEEKLY   = 2;
    const BILLING_CYCLE_MONTHLY     = 3;

    const BILLING_INTERVALS = Array(
        self::BILLING_CYCLE_WEEKLY      => '1 week',
        self::BILLING_CYCLE_BI_WEEKLY   => '2 weeks',
        self::BILLING_CYCLE_MONTHLY     => '1 month',
    );

    public $i_billing_plan;
    public $i_tariff;
    public $i_customer;
    public $name;
    public $description;
    public $i_billing_plan_suspend_mode;
    public $iso_4217;
    public $prepaid;

    public $sc;
    public $as;
    public $sp;

    function __construct($i_customer, $i_billing_plan = NULL) {
        $this->i_billing_plan = $i_billing_plan;
        $this->i_tariff = NULL;
        $this->i_customer = $i_customer;
        $this->name = NULL;
        $this->description = '';
        $this->i_billing_plan_suspend_mode = 1;
        $this->iso_4217 = NULL;
        $this->billing_cycle = self::BILLING_CYCLE_MONTHLY;
        $this->links = 0;
        $this->prepaid = TRUE;
        $this->i_billing_day = -1;
        $this->round_up = FALSE;

        $this->sc = NULL;
        $this->as = NULL;
        $this->sp = NULL;

        if ($this->i_billing_plan !== NULL) {
            $this->getEntry($this->i_billing_plan);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_billing_plan) {
        global $db;

        $sql = 'SELECT bp.i_billing_plan, bp.i_tariff, bp.name, bp.description,
                       bp.i_billing_plan_suspend_mode, bp.iso_4217, bp.billing_cycle, bp.prepaid,
                       bp.i_billing_day, bp.round_up
                  FROM billing_plans bp
                 WHERE bp.i_billing_plan = ? AND bp.i_customer = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($i_billing_plan, $this->i_customer));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_billing_plan = $entry['i_billing_plan'];
        $this->i_tariff = $entry['i_tariff'];
        $this->name = $entry['name'];
        $this->description = $entry['description'];
        $this->i_billing_plan_suspend_mode = $entry['i_billing_plan_suspend_mode'];
        $this->iso_4217 = $entry['iso_4217'];
        $this->billing_cycle = $entry['billing_cycle'];
        $this->prepaid = $entry['prepaid'] == 't' ? TRUE : FALSE;
        $this->i_billing_day = $entry['i_billing_day'];
        $this->round_up = Cast::str2bool($entry['round_up']);

        $sql = 'SELECT 1
                  FROM accounts
                 WHERE i_billing_plan = ?
                 LIMIT 1';
        $params = Array($this->i_billing_plan);
        $links = $db->getValue($sql, $params);

        $this->links = $db->affected_rows == 1 ? 1 : 0;
    }

    public function initFromRequest($par, $getBaseCurrency = TRUE) {
        global $db;

        $this->i_billing_plan = $par['i_billing_plan'];
        $this->i_tariff = $par['i_tariff'];
        $this->name = $par['bp_name'];
        $this->description = $par['description'];
        $this->i_billing_plan_suspend_mode = $par['i_billing_plan_suspend_mode'];
        $this->billing_cycle = $par['billing_cycle'];
        $this->links = $par['links'];
        $this->prepaid = $par['prepaid'] == 1 ? TRUE : FALSE;
        $this->i_billing_day = $par['i_billing_day'];
        $this->round_up = Cast::str2bool($par['round_up']);

        if ($getBaseCurrency) {
            $sql = 'SELECT t.iso_4217
                      FROM tariffs t
                    WHERE t.i_tariff = ?';
            $params = Array($this->i_tariff);
            $this->iso_4217 = $db->getValue($sql, $params);
        }
    }

    public function genID() {
        global $db;

        $this->i_billing_plan = $db->nextID('billing_plans_seq');
    }

    public static function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('name') != '') {
            $ret['sql'] .= ' AND bp.name ' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('name');
        }

        return $ret;
    }

    public static function getTotal($i_customer) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT COUNT(bp.*)
                   FROM billing_plans bp
                  WHERE bp.i_customer = ?
                        {$clause['sql']}";
        $params = array_merge(Array($i_customer), $clause['params']);

        return $db->getValue($sql, $params);
    }

    public static function getList($i_customer, $off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT bp.i_billing_plan AS i_billing_plan, bp.name AS name,
                       bp.description AS description, t.name AS t_name, t.i_tariff AS i_tariff,
                       (SELECT CASE WHEN SUM(sc.price) ISNULL THEN 0 ELSE SUM(sc.price) END
                          FROM service_charges sc
                         WHERE sc.i_billing_plan = bp.i_billing_plan) +
                       (SELECT CASE WHEN SUM(sp.price) ISNULL THEN 0 ELSE SUM(sp.price) END
                          FROM service_plans sp
                         WHERE sp.i_billing_plan = bp.i_billing_plan) AS price,
                       bp.billing_cycle AS billing_cycle, bp.iso_4217 AS iso_4217
                  FROM billing_plans bp
             LEFT JOIN tariffs t ON bp.i_tariff = t.i_tariff
                 WHERE bp.i_customer = ?
                       {$clause['sql']}
              ORDER BY bp.name
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = array_merge(Array($i_customer), $clause['params']);

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$r) {
            $sql = 'SELECT 1
                      FROM accounts
                     WHERE i_billing_plan = ?
                     LIMIT 1';
            $params = Array($r['i_billing_plan']);
            $db->getAll($sql, $params);

            $r['links'] = $db->affected_rows == 1 ? 1 : 0;
        }

        return $ret;
    }

    public function getBillingCycles() {
        return Array(Array('billing_cycle' => self::BILLING_CYCLE_WEEKLY,
                           'name'          => _('Weekly')),
                     Array('billing_cycle' => self::BILLING_CYCLE_BI_WEEKLY,
                           'name'          => _('Bi-Weekly')),
                     Array('billing_cycle' => self::BILLING_CYCLE_MONTHLY,
                           'name'          => _('Monthly'))
                    );
    }

    public static function getBCMap() {
        return Array(Array('billing_cycle' => self::BILLING_CYCLE_WEEKLY,
                           'name'          => _('week')),
                     Array('billing_cycle' => self::BILLING_CYCLE_BI_WEEKLY,
                           'name'          => _('2 weeks')),
                     Array('billing_cycle' => self::BILLING_CYCLE_MONTHLY,
                           'name'          => _('month'))
                    );
    }

    public function getBillingDays() {
        global $db;

        $special_days = $db->getAll('SELECT i_billing_day, name FROM billing_days ORDER BY name');

        $month_days = Array();
        for ($i = 1; $i <= 31; $i++) {
            array_push($month_days, Array('i_billing_day' => $i,
                                          'name' => date('jS', strtotime('1 January + ' . ($i - 1) . ' days'))));
        }

        $week_days = Array();
        for ($i = 1; $i <= 7; $i++) {
            array_push($week_days, Array('i_billing_day' => $i,
                                         'name' => date('l', strtotime('Monday + ' . ($i - 1) . ' days'))));
        }

        $month_days = array_merge($special_days, $month_days);
        $week_days = array_merge($special_days, $week_days);

        $month_days2 = Array();
        foreach ($month_days as $v) {
            array_push($month_days2, json_encode(Array($v['i_billing_day'], _($v['name']))));
        }

        $week_days2 = Array();
        foreach ($week_days as $v) {
            array_push($week_days2, json_encode(Array($v['i_billing_day'], _($v['name']))));
        }

        return Array(
            'month_days' => implode(', ', $month_days2),
            'week_days' => implode(', ', $week_days2)
        );
    }
    public function getTariffs() {
        global $db;

        $my_tariff = Array();

        if (!$_SESSION['is_root_customer'] && $_SESSION['use_own_tariff']) {
            $base_currency = $db->getValue("SELECT base_currency FROM customers WHERE i_customer = ?",
                                           Array($_SESSION['uid']));
            if ($this->iso_4217 == NULL || $this->iso_4217 == $base_currency) {
                $my_tariff[] = Array('i_tariff' => -1, 'name' => '- MY TARIFF - (' . $base_currency . ')');
            }
        }

        $clause = Array('sql' => '', 'params' => Array());
        if ($this->iso_4217 != NULL) {
            $clause['sql'] .= ' AND t.iso_4217 = ?';
            $clause['params'][] = $this->iso_4217;
        }

        $sql = "SELECT t.i_tariff, t.name || ' (' || t.iso_4217 || ')' AS name
                  FROM tariffs t
                  JOIN customers c ON (c.i_customer = t.i_owner)
                 WHERE get_customer_i_tariff(c.i_customer) != t.i_tariff
                       AND t.i_owner = ?
                       {$clause['sql']}
              ORDER BY name";

        $params = array_merge(Array($_SESSION['uid']), $clause['params']);
        $tariffs = $db->getAll($sql, $params);

        return array_merge($my_tariff, $tariffs);
    }

    public function getASDIDs() {
        global $db;

        $sql = 'SELECT d.did
                  FROM dids d
                 WHERE d.i_customer = ?
                       AND d.did NOT IN (SELECT asrch.cld
                                       FROM temp_accessibility_surcharges asrch
                                      WHERE asrch.i_billing_plan = ?)
              ORDER BY d.did';
        $params = Array($this->i_customer, $this->i_billing_plan);

        return $db->getCol($sql, $params);
    }

    public function getBillingFailureActions() {
        global $db;

        $sql = 'SELECT i_billing_plan_suspend_mode, description
                  FROM billing_plan_suspend_modes
              ORDER BY i_billing_plan_suspend_mode';

        return $db->getAll($sql);
    }

    public function getSPMinutes() {
        global $db;

        $ret = Array('Unlimited');

        $sql = 'SELECT DISTINCT sp.seconds_total / 60 AS sp_mins
                  FROM service_plans sp
                 WHERE sp.i_billing_plan = ? AND sp.seconds_total > 0
              ORDER BY sp_mins';
        $params = Array($this->i_billing_plan);

        $ret = array_merge($ret, $db->getCol($sql, $params));
        
        return $ret;
    }

    public function getServiceCharges($virt = TRUE) {
        return Service_Charge::getList($this->i_billing_plan, $virt);
    }

    public function getServicePlans($virt = TRUE) {
        return Service_Plan::getList($this->i_billing_plan, $virt);
    }

    public function getServicePlansByAccount($i_account) {
        return Service_Plan::getListByAccount($this->i_billing_plan, $i_account);
    }

    public function getAccessibility_Surcharges($virt = TRUE) {
        return Accessibility_Surcharge::getList($this->i_billing_plan, $virt);
    }

    private static function doesNameExist($i_customer, $name, $i_billing_plan = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM billing_plans bp
                 WHERE bp.i_customer = ? AND bp.name ILIKE ? AND i_billing_plan <> ?';
        $params = Array($i_customer, $name, $i_billing_plan);

        return $db->getValue($sql, $params) > 0;
    }

    public static function validate($par) {
        if ($par['bp_name'] == '') {
            throw new Exception(_('"Plan Name" field is mandatory.'));
        }
    }

    public static function add($i_customer, $par) {
        global $db;

        if (self::doesNameExist($i_customer, $par['bp_name'])) {
            throw new Exception(_('Cannot add Service Plan. Another Service Plan with conflicting "Plan Name" already exists.'));
        }

        self::validate($par);

        if ($par['i_tariff'] == -1) {
            $base_currency = $db->getValue("SELECT base_currency FROM customers WHERE i_customer = ?",
                                           Array($i_customer));
        } else {
            $base_currency = $db->getValue("SELECT iso_4217 FROM tariffs WHERE i_tariff = ?",
                                           Array($par['i_tariff']));
        }

        $sql = 'INSERT INTO billing_plans (i_billing_plan, i_tariff, i_customer, name, description,
                                           i_billing_plan_suspend_mode, iso_4217, billing_cycle, prepaid,
                                           i_billing_day, round_up)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $params = Array($par['i_billing_plan'],
                        $par['i_tariff'] == -1 ? NULL : $par['i_tariff'],
                        $i_customer, $par['bp_name'], $par['description'],
                        $par['i_billing_plan_suspend_mode'],
                        $base_currency,
                        $par['billing_cycle'],
                        Cast::str2bool($par['prepaid']),
                        $par['i_billing_day'],
                        Cast::str2bool($par['round_up'])
                       );

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Service Plan."));
        }

        return new self($i_customer, $par['i_billing_plan']);
    }

    public static function update($i_customer, $par) {
        global $db;

        if (self::doesNameExist($i_customer, $par['bp_name'], $par['i_billing_plan'])) {
            throw new Exception(_('Cannot update Service Plan. Another Service Plan with conflicting "Plan Name" already exists.'));
        }

        self::validate($par);

        $sql = 'UPDATE billing_plans
                   SET i_tariff = ?, name = ?, description =?, i_billing_plan_suspend_mode = ?,
                       billing_cycle = ?, prepaid = ?, i_billing_day = ?,
                       round_up = ?
                 WHERE i_customer = ? AND i_billing_plan = ?';
        $params = Array($par['i_tariff'] == -1 ? NULL : $par['i_tariff'],
                        $par['bp_name'], $par['description'],
                        $par['i_billing_plan_suspend_mode'],
                        $par['billing_cycle'],
                        Cast::str2bool($par['prepaid']),
                        $par['i_billing_day'],
                        Cast::str2bool($par['round_up']),
                        $i_customer,
                        $par['i_billing_plan']
                       );

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Service Plan."));
        }

        return new self($i_customer, $par['i_billing_plan']);
    }

    public static function delete($i_customer, $par) {
        global $db;

        $sql = 'DELETE FROM billing_plans
                 WHERE i_customer = ? AND i_billing_plan = ?';
        $params = Array($i_customer, $par['i_billing_plan']);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Service Plan."));
        }
    }

    public static function apply_db_history($i_billing_plan, &$db_history, $virt = true) {
        global $db;

        if ($virt) {
            $db->begin();
        }

        Service_Charge::apply_db_history($i_billing_plan, $db_history, $virt);
        Service_Plan::apply_db_history($i_billing_plan, $db_history, $virt);
        Accessibility_Surcharge::apply_db_history($i_billing_plan, $db_history, $virt);

        if (!$virt) {
            self::clear_db_history($db_history);
            unset($_SESSION['db_history']);
        }
    }

    public static function save_db_history($db_history, $do_commit = TRUE) {
        global $db;

        $_SESSION['db_history'] = serialize($db_history);

        if ($do_commit) {
            $db->commit();
        }
    }

    public static function clear_db_history(&$db_history) {
        $db_history = Array('sc' => Array(), 'sp' => Array(), 'as' => Array());
    }
}

class Service_Charge {

    public $i_service_charge;
    public $i_billing_plan;
    public $description;
    public $price;

    function __construct($i_billing_plan, $i_service_charge = NULL) {
        $this->i_billing_plan = $i_billing_plan;
        $this->i_service_charge = $i_service_charge;
        $this->description = '';
        $this->price = 0.0;

        if ($this->i_service_charge !== NULL) {
            $this->getEntry($this->i_service_charge);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_service_charge) {
        global $db;

        $sql = 'SELECT *
                  FROM temp_service_charges
                 WHERE i_billing_plan = ? AND i_service_charge = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($this->i_billing_plan, $i_service_charge));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_billing_plan = $entry['i_billing_plan'];
        $this->i_service_charge = $entry['i_service_charge'];
        $this->description = $entry['description'];
        $this->price = $entry['price'];
    }

    public function initFromRequest($par) {
        $this->i_service_charge = $par['i_service_charge'];
        $this->i_billing_plan = $par['i_billing_plan'];
        $this->description = $par['sc_description'];
        $this->price = $par['sc_price'];
    }

    public static function getList($i_billing_plan, $virt = TRUE) {
        global $db;

        $service_charges_table = $virt ? 'temp_service_charges' : 'service_charges';

        $sql = "SELECT sc.i_service_charge AS i_service_charge,
                       sc.description AS sc_description, sc.price AS sc_price
                  FROM $service_charges_table sc
                 WHERE sc.i_billing_plan = ?
              ORDER BY sc.description";

        $params = Array($i_billing_plan);

        return $db->getAll($sql, $params);
    }

    public static function validate($par) {
        if ($par['sc_description'] == '') {
            throw new Exception(_('"Service Charge Name" field is mandatory.'));
        }

        if ($par['sc_price'] == '') {
            throw new Exception(_('"Service Charge Price" field is mandatory.'));
        }

        if ((string) (float) $par['sc_price'] != $par['sc_price']) {
            throw new Exception(_('"Service Charge Price" field has incorrect number format. Fractional number is expected.'));
        }
    }

    public static function add($i_billing_plan, $par, &$db_history) {
        global $db;

        self::validate($par);

        $i_service_charge = $db->nextID('service_charges_seq');

        $sql = 'INSERT INTO %s (i_service_charge, i_billing_plan, description, price)
                     VALUES (?, ?, ?, ?)';
        $params = Array($i_service_charge, $i_billing_plan, $par['sc_description'], $par['sc_price']);

        $sql2 = sprintf($sql, 'temp_service_charges');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Service Charge."));
        }

        $db_history['sc'][] = Array('sql' => $sql, 'params' => $params);

        return new self($i_billing_plan, $i_service_charge);
    }

    public static function update($i_billing_plan, $par, &$db_history) {
        global $db;

        self::validate($par);

        $sql = 'UPDATE %s
                   SET description = ?, price = ?
                 WHERE i_service_charge = ? AND i_billing_plan = ?';
        $params = Array($par['sc_description'], $par['sc_price'], $par['i_service_charge'],
                        $i_billing_plan);

        $sql2 = sprintf($sql, 'temp_service_charges');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Service Charge."));
        }

        $db_history['sc'][] = Array('sql' => $sql, 'params' => $params);

        return new self($i_billing_plan, $par['i_service_charge']);
    }

    public static function delete($i_billing_plan, $par, &$db_history) {
        global $db;

        $sql = 'DELETE FROM %s
                 WHERE i_billing_plan = ? AND i_service_charge = ?';
        $params = Array($i_billing_plan, $par['i_service_charge']);

        $sql2 = sprintf($sql, 'temp_service_charges');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Service Charge."));
        }

        $db_history['sc'][] = Array('sql' => $sql, 'params' => $params);
    }

    public static function apply_db_history($i_billing_plan, $db_history, $virt = true) {
        global $db;

        $table = $virt ? 'temp_service_charges' : 'service_charges';

        if ($virt) {
            $db->prepNexec("CREATE TEMPORARY TABLE temp_service_charges (
                                i_service_charge BIGINT NOT NULL,
                                i_billing_plan BIGINT NOT NULL,
                                description TEXT DEFAULT '' NOT NULL,
                                price DOUBLE PRECISION NOT NULL
                            ) ON COMMIT DROP");
            $db->prepNexec("INSERT INTO temp_service_charges (SELECT * FROM service_charges
                                                               WHERE i_billing_plan = ?)",
                           Array($i_billing_plan));
        }

        foreach ($db_history['sc'] as $tmpl) {
            $sql = sprintf($tmpl['sql'], $table);
            $db->prepNexec($sql, $tmpl['params']);
        };
    }
}

class Accessibility_Surcharge {

    public $i_accessibility_surcharge;
    public $i_billing_plan;
    public $cld;
    public $connect_fee;
    public $free_seconds;
    public $grace_period;
    public $price_1;
    public $price_n;
    public $interval_1;
    public $interval_n;

    function __construct($i_billing_plan, $i_accessibility_surcharge = NULL) {
        $this->i_billing_plan = $i_billing_plan;
        $this->i_accessibility_surcharge = $i_accessibility_surcharge;
        $this->cld = '';
        $this->connect_fee = 0.0;
        $this->free_seconds = 0;
        $this->grace_period = 0;
        $this->price_1 = 0.0;
        $this->price_n = 0.0;
        $this->interval_1 = 1;
        $this->interval_n = 1;

        if ($this->i_accessibility_surcharge !== NULL) {
            $this->getEntry($this->i_accessibility_surcharge);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_accessibility_surcharge) {
        global $db;

        $sql = 'SELECT *
                  FROM temp_accessibility_surcharges
                 WHERE i_billing_plan = ? AND i_accessibility_surcharge = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($this->i_billing_plan, $i_accessibility_surcharge));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_billing_plan = $entry['i_billing_plan'];
        $this->i_accessibility_surcharge = $entry['i_accessibility_surcharge'];
        $this->cld = $entry['cld'];
        $this->connect_fee = $entry['connect_fee'];
        $this->free_seconds = $entry['free_seconds'];
        $this->grace_period = $entry['grace_period'];
        $this->price_1 = $entry['price_1'];
        $this->price_n = $entry['price_n'];
        $this->interval_1 = $entry['interval_1'];
        $this->interval_n = $entry['interval_n'];
    }

    public function initFromRequest($par) {
        $this->i_accessibility_surcharge = $par['i_accessibility_surcharge'];
        $this->i_billing_plan = $par['i_billing_plan'];
        $this->cld = $par['as_cld'];
        $this->connect_fee = $par['as_connect_fee'];
        $this->free_seconds = $par['as_free_seconds'];
        $this->grace_period = $par['as_grace_period'];
        $this->price_1 = $par['as_price_1'];
        $this->price_n = $par['as_price_n'];
        $this->interval_1 = $par['as_interval_1'];
        $this->interval_n = $par['as_interval_n'];
    }

    public static function getList($i_billing_plan, $virt = TRUE) {
        global $db;

        $table = $virt ? 'temp_accessibility_surcharges' : 'accessibility_surcharges';

        $sql = "SELECT asrch.i_accessibility_surcharge AS i_accessibility_surcharge,
                       asrch.cld AS as_cld, asrch.connect_fee AS as_connect_fee,
                       asrch.free_seconds AS as_free_seconds,
                       asrch.grace_period AS as_grace_period,
                       asrch.price_1 AS as_price_1, asrch.price_n AS as_price_n,
                       asrch.interval_1 AS as_interval_1, asrch.interval_n AS as_interval_n
                  FROM $table asrch
                 WHERE asrch.i_billing_plan = ?
              ORDER BY asrch.cld";

        $params = Array($i_billing_plan);

        return $db->getAll($sql, $params);
    }

    private static function doesCLDExist($i_billing_plan, $cld, $i_accessibility_surcharge = 0) {
        global $db;

        $sql = 'SELECT COUNT(*)
                  FROM temp_accessibility_surcharges asrch
                 WHERE asrch.i_billing_plan = ? AND asrch.cld = ? AND asrch.i_accessibility_surcharge <> ?';
        $params = Array($i_billing_plan, $cld, $i_accessibility_surcharge);

        return $db->getValue($sql, $params) > 0;
    }

    public static function validate($i_billing_plan, $par, $i_accessibility_surcharge = 0) {
        if ($par['as_cld'] == '') {
            throw new Exception(_('"Incoming DID/CLD" field is mandatory.'));
        }

        if (self::doesCLDExist($i_billing_plan, $par['as_cld'], $i_accessibility_surcharge)) {
            throw new Exception(_('Another Accessibility Surcharge with conflicting "Incoming DID/CLD" already exists.'));
        }

        if (!preg_match('/^\d+\*?$/', $par['as_cld'])) {
            throw new Exception(_('"Incoming DID/CLD" field has incorrect format. Number with optional * at the end is expected.'));
        }

        if (!(Validator::isFloat($par['as_connect_fee'], TRUE) && $par['as_connect_fee'] >= 0)) {
            throw new Exception(_('"Connect Fee" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isNumber($par['as_free_seconds'], TRUE) && $par['as_free_seconds'] >= 0)) {
            throw new Exception(_('"Free Seconds" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isNumber($par['as_grace_period'], TRUE) && $par['as_grace_period'] >= 0)) {
            throw new Exception(_('"Grace Period" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isFloat($par['as_price_1'], TRUE) && $par['as_price_1'] >= 0)) {
            throw new Exception(_('"Price 1" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isFloat($par['as_price_n'], TRUE) && $par['as_price_n'] >= 0)) {
            throw new Exception(_('"Price N" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isNumber($par['as_interval_1'], TRUE) && $par['as_interval_1'] >= 0)) {
            throw new Exception(_('"Interval 1" field has incorrect number format. Non-negative number is expected.'));
        }

        if (!(Validator::isNumber($par['as_interval_n'], TRUE) && $par['as_interval_n'] > 0)) {
            throw new Exception(_('"Interval N" field has incorrect number format. Integer number greater than zero is expected.'));
        }
    }

    public static function add($i_billing_plan, $par, &$db_history) {
        global $db;

        self::validate($i_billing_plan, $par);

        $i_accessibility_surcharge = $db->nextID('accessibility_surcharges_seq');

        $sql = 'INSERT INTO %s (i_accessibility_surcharge, i_billing_plan, cld, connect_fee, free_seconds,
                                grace_period, price_1, price_n, interval_1, interval_n)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $params = Array($i_accessibility_surcharge, $i_billing_plan, $par['as_cld'], $par['as_connect_fee'],
                        $par['as_free_seconds'], $par['as_grace_period'], $par['as_price_1'], $par['as_price_n'],
                        $par['as_interval_1'], $par['as_interval_n']);

        $sql2 = sprintf($sql, 'temp_accessibility_surcharges');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Accessibility Surcharge."));
        }

        $db_history['as'][] = Array('sql' => $sql, 'params' => $params);

        return new self($i_billing_plan, $i_accessibility_surcharge);
    }

    public static function update($i_billing_plan, $par, &$db_history) {
        global $db;

        self::validate($i_billing_plan, $par, $par['i_accessibility_surcharge']);

        $sql = 'UPDATE %s
                   SET cld = ?, connect_fee = ?, free_seconds = ?, grace_period = ?,
                       price_1 = ?, price_n = ?, interval_1 = ?, interval_n = ?
                 WHERE i_accessibility_surcharge = ? AND i_billing_plan = ?';
        $params = Array($par['as_cld'], $par['as_connect_fee'], $par['as_free_seconds'],
                        $par['as_grace_period'], $par['as_price_1'], $par['as_price_n'],
                        $par['as_interval_1'], $par['as_interval_n'],
                        $par['i_accessibility_surcharge'], $i_billing_plan);

        $sql2 = sprintf($sql, 'temp_accessibility_surcharges');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Accessibility Surcharge."));
        }

        $db_history['as'][] = Array('sql' => $sql, 'params' => $params);

        return new self($i_billing_plan, $par['i_accessibility_surcharge']);
    }

    public static function delete($i_billing_plan, $par, &$db_history) {
        global $db;

        $sql = 'DELETE FROM %s
                 WHERE i_billing_plan = ? AND i_accessibility_surcharge = ?';
        $params = Array($i_billing_plan, $par['i_accessibility_surcharge']);

        $sql2 = sprintf($sql, 'temp_accessibility_surcharges');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Accessibility Surcharge."));
        }

        $db_history['as'][] = Array('sql' => $sql, 'params' => $params);
    }

    public static function apply_db_history($i_billing_plan, $db_history, $virt = true) {
        global $db;

        $table = $virt ? 'temp_accessibility_surcharges' : 'accessibility_surcharges';

        if ($virt) {
            $db->prepNexec("CREATE TEMPORARY TABLE temp_accessibility_surcharges (
                                i_accessibility_surcharge BIGINT NOT NULL,
                                i_billing_plan      BIGINT NOT NULL,
                                cld                 CHARACTER VARYING(128) NOT NULL,
                                connect_fee         DOUBLE PRECISION NOT NULL,
                                free_seconds        INTEGER NOT NULL,
                                grace_period        INTEGER NOT NULL,
                                price_1             DOUBLE PRECISION NOT NULL,
                                price_n             DOUBLE PRECISION NOT NULL,
                                interval_1          INTEGER NOT NULL,
                                interval_n          INTEGER NOT NULL
                            ) ON COMMIT DROP");
            $db->prepNexec("INSERT INTO temp_accessibility_surcharges (SELECT * FROM accessibility_surcharges
                                                               WHERE i_billing_plan = ?)",
                           Array($i_billing_plan));
        }

        foreach ($db_history['as'] as $tmpl) {
            $sql = sprintf($tmpl['sql'], $table);
            $db->prepNexec($sql, $tmpl['params']);
        };
    }
}

class Service_Plan {

    public $i_service_plan;
    public $i_billing_plan;
    public $description;
    public $destinations;
    public $price;
    public $seconds_total;
    public $interval_1;
    public $interval_n;
    public $grace_period_enable;

    private $dest_inc;
    private $dest_exc;

    function __construct($i_billing_plan, $i_service_plan = NULL) {
        $this->i_billing_plan = $i_billing_plan;
        $this->i_service_plan = $i_service_plan;
        $this->description = '';
        $this->destinations = '';
        $this->price = 0.0;
        $this->seconds_total = 0;
        $this->interval_1 = 0;
        $this->interval_n = 1;
        $this->grace_period_enable = TRUE;

        $this->dest_inc = Array();
        $this->dest_exc = Array();

        if ($this->i_service_plan !== NULL) {
            $this->getEntry($this->i_service_plan);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    public function getEntry($i_service_plan) {
        global $db;

        $sql = 'SELECT sp.*
                  FROM temp_service_plans sp
                 WHERE sp.i_billing_plan = ? AND sp.i_service_plan = ?
                 LIMIT 1';
        $entry = $db->getAssociatedArray($sql, Array($this->i_billing_plan, $i_service_plan));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_billing_plan = $entry['i_billing_plan'];
        $this->i_service_plan = $entry['i_service_plan'];
        $this->description = $entry['description'];
        $this->destinations = $entry['destinations'];
        $this->price = $entry['price'];
        $this->seconds_total = $entry['seconds_total'];
        $this->interval_1 = $entry['interval_1'];
        $this->interval_n = $entry['interval_n'];
        $this->grace_period_enable = Cast::str2bool($entry['grace_period_enable']);

        $this->dest2arrays();
    }

    public function initFromRequest($par) {
        $this->i_service_plan = $par['i_service_plan'];
        $this->i_billing_plan = $par['i_billing_plan'];
        $this->description = $par['sp_description'];
        $this->destinations = $par['sp_destinations'];
        $this->price = $par['sp_price'];
        $this->seconds_total = strtoupper($par['sp_seconds_total']) == 'UNLIMITED' ? -1
                                                                                   : $par['sp_seconds_total'];
        $this->interval_1 = $par['sp_interval_1'];
        $this->interval_n = $par['sp_interval_n'];
        $this->grace_period_enable = Cast::str2bool($par['sp_grace_period_enable'], TRUE, FALSE);
    }

    public static function getList($i_billing_plan, $virt = TRUE) {
        global $db;

        $service_plans_table = $virt ? 'temp_service_plans' : 'service_plans';

        $sql = "SELECT sp.i_service_plan AS i_service_plan,
                       sp.description AS sp_description,
                       sp.destinations AS sp_destinations,
                       sp.price AS sp_price,
                       sp.seconds_total AS sp_seconds_total,
                       sp.interval_1 AS sp_interval_1,
                       sp.interval_n AS sp_interval_n,
                       sp.grace_period_enable AS sp_grace_period_enable
                  FROM $service_plans_table sp
                 WHERE sp.i_billing_plan = ?
              ORDER BY sp.description";

        $params = Array($i_billing_plan);

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$row) {
            $row['sp_dest_inc'] = 0;
            $row['sp_dest_exc'] = 0;
            $prefixes = preg_split('/[\s]+/', $row['sp_destinations'], -1, PREG_SPLIT_NO_EMPTY);
            foreach ($prefixes as $prefix) {
                $p = str_split($prefix);
                if ($p[0] == '^') {
                    $row['sp_dest_exc']++;
                } else {
                    $row['sp_dest_inc']++;
                }
            }

           $row['sp_grace_period_enable'] =  Cast::str2bool($row['sp_grace_period_enable']);
        }

        return $ret;
    }

    public static function getListByAccount($i_billing_plan, $i_account) {
        global $db;

        $sql = "SELECT sp.i_service_plan AS i_service_plan,
                       sp.description AS sp_description,
                       sp.destinations AS sp_destinations,
                       sp.price AS sp_price,
                       sp.seconds_total AS sp_seconds_total,
                       CASE WHEN am.seconds_left ISNULL THEN -1 ELSE am.seconds_left END AS sp_seconds_left,
                       CASE WHEN am.chargeable_seconds ISNULL THEN 0 ELSE am.chargeable_seconds END AS sp_chargeable_seconds
                  FROM service_plans sp
             LEFT JOIN accounts_minutes am USING (i_service_plan)
                 WHERE sp.i_billing_plan = ? AND am.i_account = ?
              ORDER BY sp.description";

        $params = Array($i_billing_plan, $i_account);

        return $db->getAll($sql, $params);
    }

    public static function validate($par, $i_service_plan = 0) {
        if ($par['sp_description'] == '') {
            throw new Exception(_('"Minute Plan Name" field is mandatory.'));
        }

        if ($par['sp_seconds_total'] == '') {
            throw new Exception(_('"Included Minutes" field is mandatory.'));
        }

        if (((string) (int) $par['sp_seconds_total'] != $par['sp_seconds_total'] &&
             strtoupper($par['sp_seconds_total']) != 'UNLIMITED') ||
            ((string) (int) $par['sp_seconds_total'] == $par['sp_seconds_total'] &&
             $par['sp_seconds_total'] <= 0)) {
            throw new Exception(_('"Included Minutes" field has incorrect number format. Non-negative integer number is expected.'));
        }

        if ($par['sp_price'] == '') {
            throw new Exception(_('"Minute Plan Price" field is mandatory.'));
        }

        if ((string) (float) $par['sp_price'] != $par['sp_price']) {
            throw new Exception(_('"Minute Plan Price" field has incorrect number format. Fractional number is expected.'));
        }

        if ($i_service_plan == 0 && $par['sp_destinations'] == '') {
            throw new Exception(_('"Destination Patterns" field is mandatory.'));
        }

        if (!Validator::isNumber($par['sp_interval_1']) || $par['sp_interval_1'] < 0) {
            throw new Exception(_('"Minute Plan Interval 1" field has incorrect number format. Zero or non-negative integer number is expected.'));
        }

        if (!Validator::isNumber($par['sp_interval_n']) || $par['sp_interval_n'] <= 0) {
            throw new Exception(_('"Minute Plan Interval N" field has incorrect number format. Non-negative integer number is expected.'));
        }
    }

    public static function add($i_billing_plan, $par, &$db_history) {
        global $db;

        self::validate($par);

        $i_service_plan = $db->nextID('service_plans_seq');

        $sql = 'INSERT INTO %s (i_service_plan, i_billing_plan, description, destinations, price, seconds_total,
                                interval_1, interval_n, grace_period_enable)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $params = Array($i_service_plan, $i_billing_plan, $par['sp_description'],
                        $par['sp_destinations'], $par['sp_price'],
                        strtoupper($par['sp_seconds_total']) == 'UNLIMITED' ? -1 : (int) ($par['sp_seconds_total'] * 60),
                        $par['sp_interval_1'], $par['sp_interval_n'],
                        Cast::str2bool($par['sp_grace_period_enable'])
                       );

        $sql2 = sprintf($sql, 'temp_service_plans');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Minute Plan."));
        }

        $db_history['sp'][] = Array('sql' => $sql, 'params' => $params);

        return new self($i_billing_plan, $i_service_plan);
    }

    public static function update($i_billing_plan, $par, &$db_history) {
        global $db;

        self::validate($par, $par['i_service_plan']);

        $add_sql = '';
        $add_params = Array();
        if ($par['sp_destinations'] != '') {
            $add_sql = ', destinations = ?';
            $add_params[] = $par['sp_destinations'];
        }

        $sql = "UPDATE %s
                   SET description = ?, price = ?, seconds_total = ?,
                       interval_1 = ?, interval_n = ?, grace_period_enable = ?
                       $add_sql
                 WHERE i_service_plan = ? AND i_billing_plan = ?";
        $params = array_merge(Array($par['sp_description'], $par['sp_price'],
                        strtoupper($par['sp_seconds_total']) == 'UNLIMITED' ? -1 : (int) ($par['sp_seconds_total'] * 60),
                        $par['sp_interval_1'], $par['sp_interval_n'],
                        Cast::str2bool($par['sp_grace_period_enable'])),
                        $add_params, Array($par['i_service_plan'], $i_billing_plan));

        $sql2 = sprintf($sql, 'temp_service_plans');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Minute Plan."));
        }

        $db_history['sp'][] = Array('sql' => $sql, 'params' => $params);

        return new self($i_billing_plan, $par['i_service_plan']);
    }

    public static function delete($i_billing_plan, $par, &$db_history) {
        global $db;

        $sql = 'DELETE FROM %s
                 WHERE i_billing_plan = ? AND i_service_plan = ?';
        $params = Array($i_billing_plan, $par['i_service_plan']);

        $sql2 = sprintf($sql, 'temp_service_plans');
        if (!$db->prepNexec($sql2, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Minute Plan."));
        }

        $db_history['sp'][] = Array('sql' => $sql, 'params' => $params);
    }

    public static function apply_db_history($i_billing_plan, $db_history, $virt = true) {
        global $db;

        $table = $virt ? 'temp_service_plans' : 'service_plans';

        if ($virt) {
            $db->prepNexec("CREATE TEMPORARY TABLE temp_service_plans (
                                i_service_plan BIGINT NOT NULL,
                                i_billing_plan BIGINT NOT NULL,
                                description TEXT DEFAULT '' NOT NULL,
                                destinations TEXT NOT NULL,
                                price DOUBLE PRECISION NOT NULL,
                                seconds_total INTEGER NOT NULL,
                                interval_1 INTEGER NOT NULL DEFAULT 0,
                                interval_n INTEGER NOT NULL DEFAULT 1,
                                grace_period_enable BOOLEAN NOT NULL DEFAULT TRUE
                            ) ON COMMIT DROP");
            $db->prepNexec("INSERT INTO temp_service_plans (SELECT * FROM service_plans
                                                             WHERE i_billing_plan = ?)",
                           Array($i_billing_plan));
        }

        foreach ($db_history['sp'] as $tmpl) {
            $sql = sprintf($tmpl['sql'], $table);
            $db->prepNexec($sql, $tmpl['params']);
        };
    }

    private function dest2arrays() {
        $this->dest_inc = Array();
        $this->dest_exc = Array();

        $prefixes = preg_split('/[\s]+/', $this->destinations, -1, PREG_SPLIT_NO_EMPTY);

        foreach ($prefixes as $prefix) {
            $p = str_split($prefix);
            if ($p[0] == '^') {
                array_shift($p);
                $this->dest_exc[] = implode('', $p);
            } else {
                $this->dest_inc[] = implode('', $p);
            }
        }
    }

    public function getIncDests() {
        return $this->dest_inc;
    }

    public function getExcDests() {
        return $this->dest_exc;
    }
}

class Account_Billing_Plan {

    public $i_account;

    public $bp;
    public $scs;
    public $sps;
    public $price_period;
    public $next_billing_time;
    public $billing_plan_suspended;
    public $price;

    function __construct($i_account) {
        global $db;

        $this->i_account = $i_account;

        $sql = 'SELECT i_customer, i_billing_plan,
                       extract(epoch from next_billing_time) AS next_billing_time,
                       billing_plan_suspended
                  FROM accounts
                 WHERE i_account = ?';
        list($i_customer, $i_billing_plan, $next_billing_time, $billing_plan_suspended) =
            $db->getRow($sql, Array($this->i_account));

        $this->next_billing_time = $next_billing_time;

        $this->bp = new Billing_Plan($i_customer, $i_billing_plan);
        $this->scs = $this->bp->getServiceCharges(FALSE);
        $this->sps = $this->bp->getServicePlansByAccount($this->i_account);
        $this->billing_plan_suspended = Cast::str2bool($billing_plan_suspended);

        $this->price = 0;
        foreach ($this->scs as $sc) {
            $this->price += $sc['sc_price'];
        }
        foreach ($this->sps as $sp) {
            $this->price += $sp['sp_price'];
        }

        foreach (Billing_Plan::getBCMap() as $p) {
            if ($this->bp->billing_cycle == $p['billing_cycle']) {
                $this->price_period = $p['name'];
            }
        }
    }

    function __destruct() {
        /* nothing here */
    }
}

?>
