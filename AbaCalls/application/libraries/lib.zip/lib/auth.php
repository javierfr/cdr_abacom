<?

// Copyright (c) 2003-2005 Maxim Sobolev. All rights reserved.
// Copyright (c) 2006 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

include('web_session.php');

session_start();

$web_login = isset($_SESSION['account_subtype']) ? $_SESSION['sub_web_login'] : $_SESSION['username'];
$web_session = new Web_Session($_SESSION['account_type'], $web_login);
if (isset($_SESSION['account_subtype'])) {
    $web_session->subtype = $_SESSION['account_subtype'];
}

try {
    $web_session->check($_SESSION['password'], $_SESSION['session_expiration_time']);
    $web_session->get_user_info();

    $access_level = new Access_Level($web_session->user_info['i_access_level'],
				     defined('I_PAGE') ? I_PAGE : NULL);
    $access_level->set_menu_template();
    /* propagate acl into temlates */
    $smarty->assign('acl', $access_level);

    $web_session->update_user_info();
} catch (Exception $e) {
    error_log($e->getMessage());
    show_login();
}

Maintenance_Mode::set($_SESSION['is_root_customer'] && !isset($_SESSION['account_subtype']) ||
                      $web_session->is_sippy_support_user);
get_access_rights();
get_balance();
set_timezone();
set_is_accounts_menu_available();
set_is_customers_menu_available();
set_is_commissions_menu_available();
set_is_vouchers_menu_available();
set_is_tariffs_menu_available();
set_is_web_phone_available();
set_is_callshop_available();
set_is_cb_available();
set_is_vpn_available();
set_hosted_max();
set_is_sysinfo_available();
set_is_calling_cards_menu_available();
set_is_my_plan_menu_available();
set_title_text();
set_is_followme_available();
set_is_vm_available();
set_is_voucher_payments_available();
set_conferencing_enabled();
set_warn_ssl_certificate();
set_warn_security_vulnerability();

/* check payments last, because it depends on debit/credit cards and vouchers */
set_is_payment_available();

assign_smarty_const();
?>
