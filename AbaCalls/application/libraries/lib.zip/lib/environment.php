<?php

// Copyright (c) 2006-2009 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class Environment {

    const SSL_CERT_STATUS_UNCHANGED = 0;
    const SSL_CERT_STATUS_UPLOADED = 1;
    const SSL_CERT_STATUS_GENERATED = 2;

    public $i_environment;
    public $enabled;
    public $assigned_ips;
    public $installed_modules;
    public $sip_ports;
    public $max_cps;
    public $max_sessions;
    public $gen_cert;
    public $https_certificate;
    public $https_key;
    public $https_cname;
    public $name;
    public $description;
    public $i_contact;
    public $contact;
    public $enable_sysinfo;
    public $enable_netband;
    public $enable_cpuutil;
    public $enable_diskload;
    public $expiration_date;
    public $notify_on_expiration;
    public $notify_addresses;
    public $siplog_index_enabled;
    public $record_sdp;

    private $_fault;
    private $_ssl_cert_status;

    function __construct($i_environment = NULL) {
        $this->i_environment = $i_environment;
        $this->enabled = FALSE;
        $this->assigned_ips = Array();
        $this->installed_modules = Array();
        $this->sip_ports = '5060';
        $this->max_cps = NULL;
        $this->max_sessions = NULL;
        $this->gen_cert = TRUE;
        $this->https_certificate = NULL;
        $this->https_key = NULL;
        $this->https_cname = '';
        $this->name = '';
        $this->description = '';
        $this->i_contact = NULL;
        $this->enable_sysinfo = TRUE;
        $this->enable_netband = FALSE;
        $this->enable_cpuutil = FALSE;
        $this->enable_diskload = FALSE;
        $this->expiration_date = NULL;
        $this->notify_on_expiration = TRUE;
        $this->notify_addresses = '< E-Mail, CC, BCC >';
        $this->httpd_servers = 0;
        $this->siplog_index_enabled = FALSE;
        $this->record_sdp = FALSE;

        $this->contact = new Contact();

        $this->_fault = FALSE;
        $this->_ssl_cert_status = self::SSL_CERT_STATUS_UNCHANGED;

        if ($this->i_environment !== NULL) {
            $this->getEntry($this->i_environment);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getSSLCertStatus() {
        return $this->_ssl_cert_status;
    }

    public function getEntry($i_environment) {
        global $db;

        $sql = "SELECT e.*,
                       TO_CHAR(e.expiration_date, 'YYYY-MM-DD HH24:MI:SS') AS expiration_date
                  FROM environments e
                 WHERE e.i_environment = ?
                 LIMIT 1";
        $entry = $db->getAssociatedArray($sql, Array($i_environment));

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_environment = $entry['i_environment'];
        $this->enabled = Cast::str2bool($entry['enabled']);
        $this->assigned_ips = $entry['assigned_ips'] == '' ? Array('< Unassigned >') : explode(',', $entry['assigned_ips']);
        $this->installed_modules = $entry['installed_modules'] == '' ? Array() : explode(',', $entry['installed_modules']);
        $this->sip_ports = $entry['sip_ports'];
        $this->max_cps = $entry['max_cps'] == '' ? NULL : $entry['max_cps'];
        $this->max_sessions = $entry['max_sessions'] == '' ? NULL : $entry['max_sessions'];
        $this->gen_cert = Cast::str2bool($entry['https_certificate_type'] == 2);
        $this->https_certificate = base64_decode($entry['https_certificate']);
        $this->https_key = base64_decode($entry['https_key']);
        $this->https_cname = $entry['https_cname'];
        $this->name = $entry['name'];
        $this->description = $entry['description'];
        $this->i_contact = $entry['i_contact'];
        $this->enable_sysinfo = Cast::str2bool($entry['enable_sysinfo']);
        $this->enable_netband = Cast::str2bool($entry['enable_netband']);
        $this->enable_cpuutil = Cast::str2bool($entry['enable_cpuutil']);
        $this->enable_diskload = Cast::str2bool($entry['enable_diskload']);
        $this->expiration_date = $entry['expiration_date'];
        $this->notify_on_expiration = Cast::str2bool($entry['notify_on_expiration']);
        $this->notify_addresses = $entry['notify_addresses'];
        $this->httpd_servers = (int) $entry['httpd_servers'];
        $this->siplog_index_enabled = Cast::str2bool($entry['siplog_index_enabled']);
        $this->record_sdp = Cast::str2bool($entry['record_sdp']);

        $this->contact = new Contact($this->i_contact);
    }

    public function initFromRequest($par) {
        $this->i_environment = $par['i_environment'];
        if ($this->enabled) {
            $this->assigned_ips = $par['assigned_ips'] == '' ? Array()
                                                             : explode(',', $par['assigned_ips']);
        } else {
            $this->assigned_ips = $par['assigned_ips'] == '' ? Array('< Unassigned >')
                                                             : explode(',', $par['assigned_ips']);
            $key = array_search('', $this->assigned_ips);
            if ($key !== FALSE) {
                $this->assigned_ips[$key] = '< Unassigned >';
            }
        }
        $this->installed_modules = $par['installed_modules'] == '' ? Array() : explode(',', $par['installed_modules']);
        $this->sip_ports = $par['sip_ports'];
        $this->max_cps = $par['max_cps'] == 'Unlimited' ? NULL : $par['max_cps'];
        $this->max_sessions = $par['max_sessions'] == 'Unlimited' ? NULL : $par['max_sessions'];
        $this->gen_cert = Cast::str2bool($par['gen_cert']);
        $this->https_certificate = NULL;
        $this->https_key = NULL;
        $this->https_cname = $par['https_cname'];
        $this->name = $par['e_name'];
        $this->description = $par['description'];
        $this->enable_sysinfo = Cast::str2bool($par['enable_sysinfo']);
        $this->enable_netband = Cast::str2bool($par['enable_netband']);
        $this->enable_cpuutil = Cast::str2bool($par['enable_cpuutil']);
        $this->enable_diskload = Cast::str2bool($par['enable_diskload']);
        $this->expiration_date = $par['expiration_date'];
        $this->notify_on_expiration = Cast::str2bool($par['notify_on_expiration']);
        $this->notify_addresses = $par['notify_addresses'];
        $this->httpd_servers = $par['httpd_servers'] == 'Auto' ? 0 : $par['httpd_servers'];
        $this->siplog_index_enabled = Cast::str2bool($par['siplog_index_enabled']);
        $this->record_sdp = Cast::str2bool($par['record_sdp']);

        $this->contact = new Contact($this->i_contact);
        $this->contact->initFromRequest($par);
    }

    public static function buildClause() {
        $ret = Array('sql' => '', 'params' => Array());

        if (get_par('name') != '') {
            $ret['sql'] .= ' AND e.name' . (get_par('name_clause') ? ' NOT' : '') . ' ILIKE ?';
            $ret['params'][] = get_par('name');
        }

        return $ret;
    }

    public static function getTotal() {
        global $db;

        $clause = self::buildClause();

        $sql = "WITH RECURSIVE envs (i_environment, cnt, name, cc, cps) AS (
                    (  SELECT i_environment, 1, name, max_sessions, max_cps
                         FROM environments e
                        WHERE TRUE
                              {$clause['sql']}
                     ORDER BY i_environment
                        LIMIT 1
                    ) UNION ALL (
                       SELECT e.i_environment, 1 + envs.cnt, e.name, e.max_sessions + envs.cc, e.max_cps + envs.cps
                         FROM environments e, envs
                        WHERE e.i_environment > envs.i_environment
                              {$clause['sql']}
                     ORDER BY e.i_environment
                        LIMIT 1
                    )
                ) SELECT cnt, cc, cps FROM envs ORDER BY i_environment DESC LIMIT 1";
        $params = array_merge($clause['params'], $clause['params']);

        return $db->getAssociatedArray($sql, $params);
    }

    public static function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT e.i_environment, e.name, e.description,
                       e.enabled, e.pending_action, e.assigned_ips,
                       EXTRACT(EPOCH FROM e.suspend_date) AS suspend_date,
                       e.max_cps, e.max_sessions, c.email, e.https_cname
                  FROM environments e
                  JOIN contacts c USING (i_contact)
                 WHERE TRUE
                       {$clause['sql']}
              ORDER BY e.i_environment
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = $clause['params'];

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$r) {
            $r['enabled'] = Cast::str2bool($r['enabled']);
        }

        return $ret;
    }

    public static function getDBSizes(&$env_list) {
        global $db;

        $clause = self::buildClause();

        $sql = "SELECT e.i_environment
                  FROM environments e
                 WHERE TRUE
                       {$clause['sql']}
              ORDER BY e.i_environment";

        $params = $clause['params'];

        $ret = $db->getAll($sql, $params);

        /* get DB size */
        $params = Array(
            "audit_info" => new xmlrpcval(Audit_Info::get(), "struct"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),
            "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
        );

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('listEnvironments', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            error_log('unable to call listEnvironments(): ' . htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
            return 'N/A';
        }
        $envs = $res->val['environments'];

        /* * */
        $s = Array();       /* total size */
        $spe = Array();     /* per environment size */

        foreach ($ret as $r) {
            foreach ($envs as $env) {
                if ($env['i_environment'] == $r['i_environment']) {
                    $se = Array();      /* this environment */
                    if ($env['db_info'] != 'N/A') {
                        if ($env['db_info']['main_master'] != 'N/A') {
                            $q = 'CAST (' . $env['db_info']['main_master']['size'] . ' AS bigint)';
                            $s[] = $q;
                            $se[] = $q;
                        }
                        if ($env['db_info']['main_slave'] != 'N/A') {
                            if ($env['db_info']['main_master']['node_id'] != $env['db_info']['main_slave']['node_id']) {
                                $q = 'CAST (' . $env['db_info']['main_slave']['size'] . ' AS bigint)';
                                $s[] = $q;
                                $se[] = $q;
                            }
                        }
                        if ($env['db_info']['balances_master'] != 'N/A') {
                            $q = 'CAST (' . $env['db_info']['balances_master']['size'] . ' AS bigint)';
                            $s[] = $q;
                            $se[] = $q;
                        }
                        if ($env['db_info']['balances_slave'] != 'N/A') {
                            if ($env['db_info']['balances_master']['node_id'] != $env['db_info']['balances_slave']['node_id']) {
                                $q = 'CAST (' . $env['db_info']['balances_slave']['size'] . ' AS bigint)';
                                $s[] = $q;
                                $se[] = $q;
                            }
                        }

                        $spe[$env['i_environment']] = $se;
                    }
                }
            }
        }

        /* * */
        foreach ($env_list as &$e) {
            $e['db_size'] = (string) '0';
            $e['db_size_pretty'] = 'N/A';
            foreach ($envs as $env) {
                if ($env['i_environment'] == $e['i_environment']) {
                    $e['db_info'] = $env['db_info'];
                    if ($env['db_info'] == 'N/A') {
                        continue;
                    }
                    $sql = 'SELECT pg_size_pretty(' . implode(' + ', $spe[$env['i_environment']]) . ') AS db_size_pretty, ' .
                                   implode(' + ', $spe[$env['i_environment']]) . ' AS db_size';
                    $db_info = $db->getAssociatedArray($sql);
                    $e['db_size'] = (string) $db_info['db_size'];
                    $e['db_size'] = $e['db_size'] != '' ? $e['db_size'] : 'N/A';
                    $e['db_size_pretty'] = $db_info['db_size_pretty'];
                    $e['db_size_pretty'] = $e['db_size_pretty'] != '' ? $e['db_size_pretty'] : 'N/A';
                }
            }
        }

        /* * */
        $sql = 'SELECT pg_size_pretty(' . implode(' + ', $s) . ')';
        $total_db_size = $db->getValue($sql);
        $total_db_size = $total_db_size != '' ? $total_db_size : 'N/A';

        return $total_db_size;
    }


    public function validate($par, $i_environment = 0) {

        if (!array_key_exists('gen_cert', $par)) {

            if (($_FILES['https_certificate']['size'] > 0 || $_FILES['https_key']['size'] > 0) &&
                ($_FILES['https_certificate']['size'] == 0 || $_FILES['https_key']['size'] == 0)) {
                throw new Exception(_('Please specify both ""Key" and "Certificate" fields.'));
            }

            if ($i_environment == 0 && $_FILES['https_certificate']['size'] <= 0) {
                throw new Exception(_('"Certificate" field is mandatory.'));
            }

            if ($i_environment == 0 && $_FILES['https_key']['size'] <= 0) {
                throw new Exception(_('"Key" field is mandatory.'));
            }

        } else {        /* array_key_exists('gen_cert', $par) */

            /* check certificate */
            if ($i_environment > 0 &&
                    (!$this->gen_cert ||
                      ($this->gen_cert && $par['https_cname'] != $this->https_cname))) {

                $params = Array(
                    "audit_info" => new xmlrpcval(Audit_Info::get(), "struct"),
                    "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
                    "i_environment" => new xmlrpcval($par['i_environment'], "int"),
                    "https_cname" => new xmlrpcval($par['https_cname'], "string"),
                );

                $params = Array(new xmlrpcval($params, 'struct'));

                $msg = new xmlrpcmsg('checkSSLCertificate', $params);
                $master_addr = get_master_XMLRPC_server();
                $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
                $cli->request_charset_encoding = 'UTF-8';
                $cli->setSSLVerifyPeer(false);
                $cli->return_type = 'phpvals';

                $res = $cli->send($msg);
                if ($res->faultCode()) {
                    error_log('checkSSLCertificate() has failed: ' . htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
                    throw new Exception(_('Unable to generate SSL certificate. You may be trying to use an IP address instead of a domain name. Please check the error logs or contact support for additional assistance.'));
                }
            }
        }

        if (strtolower($par['expiration_date']) != 'never' && strtotime($par['expiration_date']) === FALSE) {
            throw new Exception(_('"Expiration Date" field has incorrect format. Date or "Never" is expected.'));
        }
    }

    public function add($par) {
        $this->setFault(TRUE);

        $this->validate($par);

        $params = Array(
            "audit_info" => new xmlrpcval(Audit_Info::get(), "struct"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),
            "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
            "name" => new xmlrpcval($par['e_name'], "string"),
            "assigned_ips" => new xmlrpcval($par['assigned_ips'], $par['assigned_ips'] == '' ? "null" : "string"),
            "https_cname" => new xmlrpcval($par['https_cname'], "string"),
            "sip_ports" => new xmlrpcval($par['sip_ports'], "string"),
            "max_cps" => new xmlrpcval($par['max_cps'], $par['max_cps'] == 'Unlimited' ? "null" : "string"),
            "max_sessions" => new xmlrpcval($par['max_sessions'], $par['max_sessions'] == 'Unlimited' ? "null" : "string"),
            "installed_modules" => new xmlrpcval($par['installed_modules'],
                                                 $par['installed_modules'] == '' ? "null" : "string"),
            "description" => new xmlrpcval($par['description'], "string"),
            "expiration_date" => new xmlrpcval(prepare_XMLAPI_date($par['expiration_date']),
                                               strtolower($par['expiration_date']) == 'never' ? "null" : "string"),
            "notify_addresses" => new xmlrpcval($par['notify_addresses'], "string"),
            "notify_on_expiration" => new xmlrpcval(Cast::str2bool($par['notify_on_expiration']), "boolean"),
            "httpd_servers" => new xmlrpcval($par['httpd_servers'] == 'Auto' ? 0 : $par['httpd_servers'], "int"),
            "enable_sysinfo" => new xmlrpcval(Cast::str2bool($par['enable_sysinfo']), "boolean"),
            "enable_netband" => new xmlrpcval(Cast::str2bool($par['enable_netband']), "boolean"),
            "enable_cpuutil" => new xmlrpcval(Cast::str2bool($par['enable_cpuutil']), "boolean"),
            "enable_diskload" => new xmlrpcval(Cast::str2bool($par['enable_diskload']), "boolean"),
            "siplog_index_enabled" => new xmlrpcval(Cast::str2bool($par['siplog_index_enabled']), "boolean"),
            "record_sdp" => new xmlrpcval(Cast::str2bool($par['record_sdp']), "boolean"),

            "company_name" => new xmlrpcval($par['company_name'], "string"),
            "salutation" => new xmlrpcval($par['salutation'], "string"),
            "first_name" => new xmlrpcval($par['first_name'], "string"),
            "last_name" => new xmlrpcval($par['last_name'], "string"),
            "mid_init" => new xmlrpcval($par['mid_init'], "string"),
            "street_addr" => new xmlrpcval($par['street_addr'], "string"),
            "state" => new xmlrpcval($par['state'], "string"),
            "postal_code" => new xmlrpcval($par['postal_code'], "string"),
            "country" => new xmlrpcval($par['country'], "string"),
            "contact" => new xmlrpcval($par['contact'], "string"),
            "phone" => new xmlrpcval($par['phone'], "string"),
            "fax" => new xmlrpcval($par['fax'], "string"),
            "alt_phone" => new xmlrpcval($par['alt_phone'], "string"),
            "alt_contact" => new xmlrpcval($par['alt_contact'], "string"),
            "city" => new xmlrpcval($par['city'], "string"),
            "email" => new xmlrpcval($par['email'], "string"),
            "cc" => new xmlrpcval($par['cc'], "string"),
            "bcc" => new xmlrpcval($par['bcc'], "string"),
        );

        if (!array_key_exists('gen_cert', $par)) {
            $cert = chunk_split(base64_encode(file_get_contents($_FILES['https_certificate']['tmp_name'])));
            $key = chunk_split(base64_encode(file_get_contents($_FILES['https_key']['tmp_name'])));

            $params["https_certificate"] = new xmlrpcval($cert, "string");
            $params["https_key"] = new xmlrpcval($key, "string");
        }

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('createEnvironment', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->getEntry($res->val['i_environment']);

        $this->setFault(FALSE);
    }

    public function update($par) {
        $this->setFault(TRUE);

        $this->validate($par, $par['i_environment']);

        $params = Array(
            "audit_info" => new xmlrpcval(Audit_Info::get(), "struct"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),
            "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
            "i_environment" => new xmlrpcval($par['i_environment'], "int"),
            "name" => new xmlrpcval($par['e_name'], "string"),
            "assigned_ips" => new xmlrpcval($par['assigned_ips'], $par['assigned_ips'] == '' ? "null" : "string"),
            "https_cname" => new xmlrpcval($par['https_cname'], "string"),
            "sip_ports" => new xmlrpcval($par['sip_ports'], "string"),
            "max_cps" => new xmlrpcval($par['max_cps'], $par['max_cps'] == 'Unlimited' ? "null" : "string"),
            "max_sessions" => new xmlrpcval($par['max_sessions'], $par['max_sessions'] == 'Unlimited' ? "null" : "string"),
            "installed_modules" => new xmlrpcval($par['installed_modules'],
                                                 $par['installed_modules'] == '' ? "null" : "string"),
            "description" => new xmlrpcval($par['description'], "string"),
            "expiration_date" => new xmlrpcval(prepare_XMLAPI_date($par['expiration_date']),
                                               strtolower($par['expiration_date']) == 'never' ? "null" : "string"),
            "notify_addresses" => new xmlrpcval($par['notify_addresses'], "string"),
            "notify_on_expiration" => new xmlrpcval(Cast::str2bool($par['notify_on_expiration']), "boolean"),
            "httpd_servers" => new xmlrpcval($par['httpd_servers'] == 'Auto' ? 0 : $par['httpd_servers'], "int"),
            "enable_sysinfo" => new xmlrpcval(Cast::str2bool($par['enable_sysinfo']), "boolean"),
            "enable_netband" => new xmlrpcval(Cast::str2bool($par['enable_netband']), "boolean"),
            "enable_cpuutil" => new xmlrpcval(Cast::str2bool($par['enable_cpuutil']), "boolean"),
            "enable_diskload" => new xmlrpcval(Cast::str2bool($par['enable_diskload']), "boolean"),
            "siplog_index_enabled" => new xmlrpcval(Cast::str2bool($par['siplog_index_enabled']), "boolean"),
            "record_sdp" => new xmlrpcval(Cast::str2bool($par['record_sdp']), "boolean"),

            "company_name" => new xmlrpcval($par['company_name'], "string"),
            "salutation" => new xmlrpcval($par['salutation'], "string"),
            "first_name" => new xmlrpcval($par['first_name'], "string"),
            "last_name" => new xmlrpcval($par['last_name'], "string"),
            "mid_init" => new xmlrpcval($par['mid_init'], "string"),
            "street_addr" => new xmlrpcval($par['street_addr'], "string"),
            "state" => new xmlrpcval($par['state'], "string"),
            "postal_code" => new xmlrpcval($par['postal_code'], "string"),
            "country" => new xmlrpcval($par['country'], "string"),
            "contact" => new xmlrpcval($par['contact'], "string"),
            "phone" => new xmlrpcval($par['phone'], "string"),
            "fax" => new xmlrpcval($par['fax'], "string"),
            "alt_phone" => new xmlrpcval($par['alt_phone'], "string"),
            "alt_contact" => new xmlrpcval($par['alt_contact'], "string"),
            "city" => new xmlrpcval($par['city'], "string"),
            "email" => new xmlrpcval($par['email'], "string"),
            "cc" => new xmlrpcval($par['cc'], "string"),
            "bcc" => new xmlrpcval($par['bcc'], "string"),
        );

        /* issue certificate */
        if (array_key_exists('gen_cert', $par)) {
            if (!$this->gen_cert ||
                ($this->gen_cert && $par['https_cname'] != $this->https_cname)) {
                $params2 = Array(
                    "audit_info" => new xmlrpcval(Audit_Info::get(), "struct"),
                    "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
                    "i_environment" => new xmlrpcval($par['i_environment'], "int"),
                    "https_cname" => new xmlrpcval($par['https_cname'], "string"),
                );

                $params2 = Array(new xmlrpcval($params2, 'struct'));

                $msg = new xmlrpcmsg('issueSSLCertificate', $params2);
                $master_addr = get_master_XMLRPC_server();
                $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
                $cli->request_charset_encoding = 'UTF-8';
                $cli->setSSLVerifyPeer(false);
                $cli->return_type = 'phpvals';

                $res = $cli->send($msg);
                if ($res->faultCode()) {
                    error_log('issueSSLCertificate() has failed: ' . htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
                    throw new Exception(_('Unable to generate SSL certificate. Please check the error logs or contact support for additional assistance.'));
                }

                $this->_ssl_cert_status = self::SSL_CERT_STATUS_GENERATED;
            }

            /* do not forget to change https_certificate_type for the environment */
            $params["https_certificate_type"] = new xmlrpcval(2, "int");        /* Issue at LetsEncrypt.org */
        } else {
            if ($_FILES['https_certificate']['size'] > 0 || $_FILES['https_key']['size'] > 0) {
                $cert = chunk_split(base64_encode(file_get_contents($_FILES['https_certificate']['tmp_name'])));
                $key = chunk_split(base64_encode(file_get_contents($_FILES['https_key']['tmp_name'])));

                $params["https_certificate"] = new xmlrpcval($cert, "string");
                $params["https_key"] = new xmlrpcval($key, "string");

                $this->_ssl_cert_status = self::SSL_CERT_STATUS_UPLOADED;
            }

            /* do not forget to change https_certificate_type for the environment */
            $params["https_certificate_type"] = new xmlrpcval(1, "int");        /* Upload Own */
        }

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('updateEnvironment', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }

        $this->getEntry($this->i_environment);

        if ($this->i_environment == 1) {
            set_is_sysinfo_available();
            assign_smarty_const();
        }

        $this->setFault(FALSE);
    }

    protected function queueEnvironmentAction($action, $add_params = NULL) {
        $params = Array(
            "audit_info" => new xmlrpcval(Audit_Info::get(), "struct"),
            "l10n_lang" => new xmlrpcval($_SESSION['lang'], "string"),
            "i_customer" => new xmlrpcval($_SESSION['uid'], "int"),
            "i_environment" => new xmlrpcval($this->i_environment, "int"),
            "action" => new xmlrpcval($action, "string"),
        );

        if (is_array($add_params)) {
            foreach ($add_params as $k => $v) {
                /* do not rewrite system-defined parameters */
                if (!array_key_exists($k, $params)) {
                    $params[$k] = $v;
                }
            }
        }

        $params = Array(new xmlrpcval($params, 'struct'));

        $msg = new xmlrpcmsg('queueEnvironmentAction', $params);
        $master_addr = get_master_XMLRPC_server();
        $cli = new xmlrpc_client('https://' . $master_addr . '/xmlapi/xmlapi');
        $cli->request_charset_encoding = 'UTF-8';
        $cli->setSSLVerifyPeer(false);
        $cli->return_type = 'phpvals';

        $res = $cli->send($msg);
        if ($res->faultCode()) {
            throw new Exception(htmlspecialchars_decode($res->faultString(), ENT_QUOTES));
        }
    }

    public function start($par) {
        $this->queueEnvironmentAction('start');
    }

    public function stop($par) {
        $this->queueEnvironmentAction('stop');
    }

    public function delete($par) {
        $this->queueEnvironmentAction('delete');
    }

    public function suspend($par) {
        $params = Array(
            "suspend_message" => new xmlrpcval($par['suspend_message'], "string"),
        );

        $this->queueEnvironmentAction('suspend', $params);
    }

    public function restart($par) {
        $this->queueEnvironmentAction('restart');
    }

    public function get_available_ips() {
        global $db;

        $ssp_id = trim(file_get_contents('/SSP_ID'));

        $sql = 'SELECT ip
                  FROM net_addresses
                 WHERE node = ? AND iface IS NOT NULL
              ORDER BY iface';
        $params = Array($ssp_id);

        $ret = $db->getCol($sql, $params);

        if ($this->i_environment) {
            $assigned = $db->getCol('SELECT assigned_ips FROM environments WHERE i_environment <> ?',
                                    Array($this->i_environment));
        } else {
            $assigned = $db->getCol('SELECT assigned_ips FROM environments');
        }
        $assigned = implode(',', $assigned);
        $assigned = explode(',', $assigned);
        $assigned = array_merge($assigned, $this->assigned_ips);

        $ret = array_diff($ret, $assigned);

        $vpn_ip = $db->getValue('SELECT vpn_ip FROM system LIMIT 1');
        $ret = array_diff($ret, Array($vpn_ip));

        /* XXX: should be checked as we cannot read configs of other environments */
        $cluster_conf = sprintf(PATH_CLUSTER_CONF, $this->i_environment);
        if (is_file($cluster_conf) && is_readable($cluster_conf)) {
            $fh = fopen($cluster_conf, 'r');
            if ($fh) {
                while (!feof($fh)) {
                    $s = fgets($fh, 256);
                    list($var, $val) = explode('=', trim($s));
                    switch ($var) {
                        case 'HOST_MASTER':
                            $host_master = gethostbyname($val);
                            break;
                        case 'HOST_SLAVE':
                            $host_slave = gethostbyname($val);
                            break;
                        case 'SERVICE_IP':
                            $service_ip = gethostbyname($val);
                            break;
                        default:
                            break;
                    }
                }
                fclose($fh);

                if ($service_ip != '') {
                    $ret = array_diff($ret, Array($host_master, $host_slave));
                }
            }
        }

        natsort($ret);

        $ret2 = Array();
        $ret3 = Array();
        $nets = Array(
            '10.0.0.0' => '255.0.0.0',
            '172.16.0.0' => '255.240.0.0',
            '192.168.0.0' => '255.255.0.0',
        );
        foreach ($ret as $r) {
            $rfc1918_addr = FALSE;
            foreach ($nets as $net => $mask) {
                $v = ip2long($r) & ip2long($mask);
                if (long2ip($v) == $net) {
                    $rfc1918_addr = TRUE;
                    break;
                }
            }

            if ($rfc1918_addr) {
                array_push($ret2, $r);
            } else {
                array_push($ret3, $r);
            }
        }

        $ret = array_merge($ret3, $ret2);

        if ($this->i_environment != 1 && !$this->enabled &&
            !in_array('< Unassigned >', $this->assigned_ips)) {
            array_push($ret, '< Unassigned >'); 
        }

        return $ret;
    }

    public function get_available_modules() {
        global $db;

        $ignore_modules = Array('hosted');
        $ret = Array();

        $installed_modules = $db->getValue("SELECT installed_modules FROM system LIMIT 1");

        if ($installed_modules != '') {
            $installed_modules = explode(",", $installed_modules);
            foreach ($installed_modules as $m) {
                list($m, $args) = explode(':', $m);
                if (in_array($m, $ignore_modules)) {
                    continue;
                }
                $ret[] = $m;
            }
        }

        $ret = array_diff($ret, $this->installed_modules);

        return $ret;
    }
}

?>
