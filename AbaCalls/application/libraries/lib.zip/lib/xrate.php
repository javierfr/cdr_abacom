<?php

// Copyright (c) 2018 Sippy Software, Inc. All rights reserved.
//
// Warning: This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of this
// program, or any portion of it, may result in severe civil and criminal
// penalties, and will be prosecuted under the maximum extent possible under
// law.
//
// $Id$

class XRate {

    const MANUAL_ENTRY = 1;
    const SYSTEM_ENTRY = 3;
    const CUSTOM_SCRIPT_ENTRY = 4;
    const CURRENCYLAYER_ENTRY = 7;

    const UPDATE_SCRIPT = '/home/ssp/scripts/xrate_update.py';
    const CUSTOM_UPDATE_SCRIPT = '/var/env%d/scripts/xrate_update_custom.sh';

    public $i_x_rate;
    public $iso_4217;
    public $name;
    public $i_customer;
    public $base_currency;
    public $rate;
    public $i_x_rates_source;
    public $additional_config;

    private $is_system;

    private $_fault;

    function __construct($i_customer, $base_currency, $i_x_rate = NULL) {
        global $db;

        $this->i_x_rate = $i_x_rate;
        $this->iso_4217 = '';
        $this->name = '';
        $this->i_customer = $i_customer;
        $this->base_currency = $base_currency;
        $this->rate = 1.0;
        $this->i_x_rates_source = self::MANUAL_ENTRY;
        $this->additional_config = Array();

        $this->is_system = FALSE;

        $this->_fault = FALSE;

        if ($this->i_x_rate !== NULL) {
            $this->getEntry($this->i_x_rate);
        }
    }

    function __destruct() {
        /* nothing here */
    }

    protected function setFault($fault) {
        $this->_fault = $fault;
    }

    public function isFault() {
        return $this->_fault;
    }

    public function getEntry($i_x_rate) {
        global $db;

        $sql = 'SELECT xr.*, xr.i_x_rates_source = ? AS is_system,
                       c.name
                  FROM x_rates xr
                  JOIN currencies c USING (iso_4217)
                 WHERE xr.i_customer = ? AND xr.i_x_rate = ?
                 LIMIT 1';
        $params = Array(self::SYSTEM_ENTRY, $this->i_customer, $i_x_rate);

        $entry = $db->getAssociatedArray($sql, $params);

        if ($db->affected_rows != 1) {
            throw new Exception("No such Id.");
        }

        $this->i_x_rate = $i_x_rate;
        $this->iso_4217 = $entry['iso_4217'];
        $this->name = $entry['name'];
        $this->rate = $entry['rate'];
        $this->i_x_rates_source = $entry['i_x_rates_source'];
        $this->additional_config = json_decode($entry['additional_config'], TRUE);

        $this->is_system = Cast::str2bool($entry['is_system']);
    }

    public function get_additional_config($par) {
        $additional_config = Array();

        foreach ($par as $k => $v) {
            $prefix = 'ac' . $par['i_x_rates_source'] . '_';
            $len = strlen($prefix);
            if (substr($k, 0, $len) == $prefix) {
                $additional_config[substr($k, $len)] = $v == 'true' ? TRUE : $v;
            }
        }

        return $additional_config;
    }

    public function initFromRequest($par) {
        $this->iso_4217 = $par['iso_4217'];
        $this->rate = $par['rate'];
        $this->i_x_rates_source = $par['i_x_rates_source'];

        $this->additional_config = $this->get_additional_config($par);
    }

    public function genID() {
        global $db;

        return $db->nextID('x_rates_seq');
    }

    public function buildClause() {
        $fc = (Array) get_par('filter_clause');
        $ret = Array('sql' => 'TRUE', 'params' => Array());

        if ($fc['name'] != '') {
            $ret['sql'] .= ' AND (c.name ' . ($fc['name_clause'] ? ' NOT' : '') . ' ILIKE ?' .
                                ($fc['name_clause'] ? ' AND' : ' OR') .
                                ' c.iso_4217 ' . ($fc['name_clause'] ? ' NOT' : '') . ' ILIKE ?)';
            $ret['params'][] = $fc['name'];
            $ret['params'][] = $fc['name'];
        }

        return $ret;
    }

    public function getTotal() {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT COUNT(xr.*)
                  FROM x_rates xr
                  JOIN currencies c USING (iso_4217)
                 WHERE {$clause['sql']}
                       AND xr.i_customer = ? AND xr.i_x_rates_source <> ?";
        $params = Array($this->i_customer, self::SYSTEM_ENTRY);
        $params = array_merge($clause['params'], $params);

        return $db->getValue($sql, $params);
    }

    public function getList($off = 0, $rpp = ROW_PER_PAGE) {
        global $db;

        $clause = $this->buildClause();

        $sql = "SELECT c.name || ' (' || c.iso_4217 || ')' AS curr,
                       xr.rate AS rate, 1.0 / xr.rate AS rate2,
                       xrs.name AS name,
                       extract(epoch FROM xr.last_update) AS date,
                       xr.i_x_rate AS i_x_rate,
                       now() - xr.last_update > interval '1 day' AS outdated,
                       (
                           (SELECT COUNT(*)
                              FROM accounts
                              WHERE base_currency = (SELECT a.iso_4217
                                                       FROM x_rates a
                                                      WHERE a.i_customer = ? AND a.i_x_rate = xr.i_x_rate)
                                    AND i_customer = ?)
                           +
                           (SELECT COUNT(*)
                              FROM vouchers
                             WHERE currency = (SELECT a.iso_4217
                                                 FROM x_rates a
                                                WHERE a.i_customer = ? AND a.i_x_rate = xr.i_x_rate)
                                   AND i_customer = ?)
                           +
                           CASE WHEN customers.i_customer = 1 THEN
                               (SELECT COUNT(*)
                                  FROM vendors
                                 WHERE base_currency = (SELECT a.iso_4217
                                                          FROM x_rates a
                                                         WHERE a.i_customer = ? AND a.i_x_rate = xr.i_x_rate))
                           ELSE 0 END
                           +
                           CASE WHEN customers.i_customer = 1 THEN
                               (SELECT COUNT(*)
                                  FROM destination_sets
                                 WHERE iso_4217 = (SELECT a.iso_4217
                                                     FROM x_rates a
                                                    WHERE a.i_customer = ? AND a.i_x_rate = xr.i_x_rate))
                           ELSE 0 END
                           +
                           (SELECT COUNT(*)
                              FROM customers
                             WHERE base_currency = (SELECT a.iso_4217
                                                      FROM x_rates a
                                                     WHERE a.i_customer = ? AND a.i_x_rate = xr.i_x_rate)
                                   AND (i_customer = ?
                                        OR i_customer IN (SELECT i_customer
                                                            FROM customers
                                                           WHERE i_wholesaler = ?)))
                           +
                           (SELECT COUNT(*)
                              FROM payment_processors
                             WHERE iso_4217 = xr.iso_4217 AND i_customer = ?)
                           +
                           (SELECT COUNT(*)
                              FROM tariffs t
                              JOIN customers c ON (c.i_customer = t.i_owner)
                             WHERE get_customer_i_tariff(c.i_customer) != t.i_tariff AND t.iso_4217 = xr.iso_4217
                                   AND t.i_owner = ?)
                       ) > 0 AS linked
                  FROM x_rates xr
                  JOIN currencies c USING (iso_4217)
                  JOIN x_rates_sources xrs USING (i_x_rates_source)
                  JOIN customers USING (i_customer)
                 WHERE ${clause['sql']}
                       AND xr.i_customer = ? AND xr.iso_4217 <> customers.base_currency
                 ORDER BY 1
                 LIMIT ${rpp}
                OFFSET ${off}";

        $params = Array($this->i_customer, $this->i_customer, $this->i_customer, $this->i_customer, $this->i_customer,
                        $this->i_customer, $this->i_customer, $this->i_customer, $this->i_customer, $this->i_customer,
                        $this->i_customer);
        $params = array_merge($params, $clause['params']);
        $params = array_merge($params, Array($this->i_customer));

        $ret = $db->getAll($sql, $params);

        foreach ($ret as &$r) {
            $r['outdated'] = Cast::str2bool($r['outdated']);
            $r['linked'] = Cast::str2bool($r['linked']);
        }

        return $ret;

    }

    private function doesRateExist($iso_4217, $i_x_rate = 0) {
        global $db;

        $sql = 'SELECT COUNT(xr.*)
                  FROM x_rates xr
                 WHERE xr.i_customer = ? AND
                       xr.iso_4217 = ? AND xr.i_x_rate <> ?';

        $params = Array($this->i_customer, $iso_4217, $i_x_rate);

        return $db->getValue($sql, $params) > 0;
    }

    public function validate($par, $i_x_rate = 0) {
        global $db;

        if ($this->doesRateExist($par['iso_4217'], $i_x_rate)) {
            throw new Exception(sprintf(_('Another exchange rate for %s currency already exists.'), $par['iso_4217']));
        }

        if ($par['i_x_rates_source'] == self::MANUAL_ENTRY) {
            if ($par['rate'] <= 0.0) {
                throw new Exception(_('"Exchange Rate" field has incorrect number format. Non-negative number is expected.'));
            }
        }

        if ($par['i_x_rates_source'] == self::SYSTEM_ENTRY) {
            throw new Exception(sprintf(_('Cannot update system entry.')));
        }

        if ($par['i_x_rates_source'] == self::CURRENCYLAYER_ENTRY) {
            if ($par['ac7_api_access_key'] == '') {
                throw new Exception(sprintf(_('"API Access Key" field is mandatory.')));
            }
        }
    }

    public function add($par) {
        global $db;

        $this->setFault(TRUE);

        $i_x_rate = $this->genID();

        $this->validate($par);

        $rate = $this->fetch_xrate($par);

        $additional_config = json_encode($this->get_additional_config($par), JSON_FORCE_OBJECT);

        $sql = "INSERT INTO x_rates (i_x_rate, iso_4217, rate, i_x_rates_source, i_customer,
                                     last_update, additional_config)
                     VALUES (?, ?, 1.0 / ?, ?, ?, CURRENT_TIMESTAMP, ?)";
        $params = Array($i_x_rate, $par['iso_4217'],
                        sprintf(get_dpf(), $rate), $par['i_x_rates_source'],
                        $this->i_customer, $additional_config);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot insert Exchange Rate."));
        }

        $this->getEntry($i_x_rate);

        $this->setFault(FALSE);
    }

    public function update($par) {
        global $db;

        $this->setFault(TRUE);

        $this->validate($par, $this->i_x_rate);

        $rate = $this->fetch_xrate($par);

        $additional_config = json_encode($this->get_additional_config($par), JSON_FORCE_OBJECT);

        $sql = "UPDATE x_rates
                   SET rate = 1.0 / ?, i_x_rates_source = ?,
                       last_update = CURRENT_TIMESTAMP,
                       additional_config = ?
                 WHERE i_customer = ? AND i_x_rates_source <> ?
                       AND i_x_rate = ?";
        $params = Array(sprintf(get_dpf(), $rate), $par['i_x_rates_source'],
                        $additional_config, $this->i_customer,
                        self::SYSTEM_ENTRY, $this->i_x_rate);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot update Exchange Rate."));
        }

        $this->getEntry($this->i_x_rate);

        $this->setFault(FALSE);
    }

    public function delete($par) {
        global $db;

        $sql = 'DELETE FROM x_rates
                      WHERE i_customer = ? AND i_x_rates_source <> ?
                            AND i_x_rate = ?';
        $params = Array($this->i_customer, self::SYSTEM_ENTRY,
                        $this->i_x_rate);

        if (!$db->prepNexec($sql, $params) || $db->affected_rows != 1) {
            throw new Exception(_("Cannot delete Exchange Rate."));
        }
    }

    function fetch_xrate($par) {
        global $db;

        if ($par['i_x_rates_source'] == self::MANUAL_ENTRY) {
            return $par['per_x'] == 1 ? 1.0 / $par['rate'] : $par['rate'];
        }

        $safe_base = escapeshellarg($this->base_currency);
        $safe_curr = escapeshellarg($par['iso_4217']);
        $safe_additional_config = escapeshellarg(json_encode($this->get_additional_config($par), JSON_FORCE_OBJECT));

        $sql = "SELECT name
                  FROM x_rates_sources
                 WHERE i_x_rates_source = ?
                 LIMIT 1";
        $params = Array($par['i_x_rates_source']);
        
        $source_name = $db->getValue($sql, $params);
        $safe_source_name = escapeshellarg(str_replace(' ', '', $source_name));

        exec('/home/ssp/scripts/python_exec.sh ' . self::UPDATE_SCRIPT . ' ' . $safe_source_name .
            " $safe_base $safe_curr $safe_additional_config", $output, $ret);

        if ($ret != 0) {
            throw new Exception(sprintf(_('Cannot retrieve %s to %s currency conversion rate - communication with %s has failed. Please report this issue to the system administrator. The rate will have to be updated manually in the meantime.'), $this->base_currency, $par['iso_4217'], $source_name));
        }

        if (preg_match('/^ERROR: UNKNOWN RATE/', $output[0])) {
            throw new Exception(sprintf(_('The %s does not support currency conversion from %s to %s. The rate will have to be updated manually.'), $this->base_currency, $par['iso_4217'], $source_name));
        }

        if (preg_match('/^ERROR:/', $output[0])) {
            throw new Exception(sprintf(_('Cannot retrieve %s to %s currency conversion rate - communication with %s has failed. Please report this issue to the system administrator. The rate will have to be updated manually in the meantime.'), $this->base_currency, $par['iso_4217'], $source_name));
        }

        return $output[0];
    }
}

?>
